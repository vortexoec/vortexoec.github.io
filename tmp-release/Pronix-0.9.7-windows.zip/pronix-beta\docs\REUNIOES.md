# Reuniões, Google Agenda, Meet e Drive — beta v0.2

O programa consulta a agenda e importa uma transcrição existente. O texto segue para a revisão local e para as regras de direcionamento. Esta integração não usa IA, não grava reuniões, não modifica agendas e não transcreve vídeos.

Cada especialista conecta a própria conta Google na própria instalação. A conexão do ChatGPT/Codex não é reutilizada pelo programa. Não foram criados projeto Google Cloud nem credenciais para o usuário, e o fluxo Google real ainda depende dessas credenciais e de uma autorização no navegador. A implementação foi verificada com respostas simuladas das APIs.

## Preparar a conexão individual

1. No [Google Cloud Console](https://console.cloud.google.com/), escolha um projeto para o beta e ative **Google Calendar API**, **Google Meet API** e **Google Drive API**.
2. Configure o aplicativo no Google Auth Platform: nome, e-mail de suporte, público e permissões. Em um aplicativo externo em teste, inclua os especialistas permitidos como usuários de teste. Uma organização pode ter restrições administrativas próprias.
3. Crie um cliente OAuth do tipo **Aplicativo para computador / Desktop app**. Copie o ID e, quando fornecido pelo Google, o segredo do cliente para Integrações no Pronix. O cliente precisa ser Desktop; uma chave de API ou conta de serviço não substitui o login do especialista.
4. Mantenha o programa aberto e use **Conectar Google**. O navegador abre o consentimento oficial. Confira a conta e autorize as permissões de leitura. O retorno usado pelo programa é `http://localhost:8765/api/google/callback`; o cliente também aceita `127.0.0.1` caso o servidor utilize esse endereço.
5. Selecione a agenda e um período. Escolha o evento e confira o nome sugerido do cliente. Se houver mais de um documento/ocorrência, selecione a transcrição correta antes de importar.

O fluxo Desktop usa o navegador do sistema, PKCE S256, um estado de uso único e retorno HTTP de loopback. A troca do código e a renovação do acesso usam HTTPS. O segredo de um cliente Desktop não é uma credencial confidencial que possa ser protegida pela distribuição do aplicativo; ele é guardado localmente para evitar exposição acidental. [OAuth para aplicativos nativos](https://developers.google.com/identity/protocols/oauth2/native-app)

Para distribuir o programa a outros especialistas, é possível manter um aplicativo OAuth do produto e cada pessoa autorizar a própria conta, com tokens separados. Isso exige preparar o consentimento e atender aos requisitos aplicáveis de verificação do Google antes da distribuição pública. O beta permite informar o cliente Desktop individual; não publica um aplicativo OAuth automaticamente. [Configurar consentimento](https://developers.google.com/workspace/guides/configure-oauth-consent), [escolher escopos do Drive](https://developers.google.com/workspace/drive/api/guides/api-specific-auth)

## Permissões solicitadas

| Escopo | Uso no programa |
| --- | --- |
| `calendar.calendarlist.readonly` | Listar as agendas disponíveis para seleção. |
| `calendar.events.readonly` | Ler títulos, datas, descrições e anexos dos eventos do período escolhido. |
| `meetings.space.readonly` | Consultar ocorrências e artefatos de reuniões acessíveis à conta. |
| `drive.meet.readonly` | Padrão: ler arquivos criados ou editados pelo Google Meet. |
| `drive.readonly` | Alternativa explícita ao escopo anterior: ler também Docs/TXT externos ao Meet quando o especialista habilita o acesso ampliado ao Drive. |

Os dois escopos de Drive são alternativas; mudar o modo exige reconectar. `drive.file` não daria acesso automático a qualquer link colado sem um fluxo adicional de seleção de arquivos. O beta não pede escopos para escrever, excluir ou alterar compartilhamentos. A conta ainda precisa ter permissão no arquivo, e o proprietário pode impedir downloads/exportações. [Escopos do Calendar](https://developers.google.com/workspace/calendar/api/auth), [autorização do Meet](https://developers.google.com/workspace/meet/api/guides/authenticate-authorize)

## O que vem da agenda

O usuário escolhe a agenda e um intervalo de até 93 dias na interface. As datas inicial e final são inclusivas e o beta usa o fuso de Brasília (`-03:00`) para a consulta. A consulta expande eventos recorrentes, ordena por início e limita o resultado a 200 eventos, avisando quando o período precisa ser reduzido. Não há monitoramento contínuo em segundo plano. Agendas com acesso apenas a livre/ocupado não são apresentadas como agendas com detalhes legíveis. [Listar agendas](https://developers.google.com/workspace/calendar/api/v3/reference/calendarList/list), [listar eventos](https://developers.google.com/workspace/calendar/api/v3/reference/events/list)

O programa lê links na descrição, em anexos e no campo oficial da conferência. Descrições HTML são convertidas em texto, sem executar conteúdo. Só links HTTPS reconhecidos de `meet.google.com`, `docs.google.com` e `drive.google.com` entram no fluxo de importação. O tipo de um link indicado por um rótulo como “Transcrição” é uma sugestão; o conteúdo é verificado ao selecionar o arquivo. O título completo do evento é uma sugestão editável de nome do cliente, sem atribuir identidade aos participantes. [Estrutura dos eventos](https://developers.google.com/workspace/calendar/api/v3/reference/events)

## O que cada link permite

- **Sala Meet:** procura ocorrências acessíveis da sala e apresenta transcrições/gravações separadas, com suas datas. Não escolhe a primeira nem une reuniões automaticamente. São consultadas até 20 ocorrências recentes e até 50 artefatos de cada tipo por ocorrência, com aviso de limitação.
- **Google Doc:** consulta os metadados e exporta o documento selecionado como texto simples. Um Doc comum precisa ser confirmado como transcrição pelo usuário.
- **TXT, VTT ou SRT no Drive:** consulta os metadados e baixa somente o texto selecionado. Arquivos texto usam `files.get` com `alt=media`; Docs usam `files.export` com `text/plain`.
- **Vídeo/áudio no Drive:** mostra o vínculo e os metadados, sem baixar a mídia. O usuário deve indicar a transcrição separada. O programa não procura arquivos por semelhança de nome/pasta para inventar uma associação.
- **Pasta, atalho, endereço externo ou formato incompatível:** não é importado como transcrição.

O limite local é **4 MiB por transcrição**, aplicado antes da leitura quando há tamanho conhecido e também durante a resposta HTTP. O conteúdo não é truncado silenciosamente. UTF-8 e UTF-16 com BOM são aceitos; Windows-1252 gera aviso para revisão dos acentos. [Baixar arquivos](https://developers.google.com/workspace/drive/api/reference/rest/v3/files/get), [exportar Google Docs](https://developers.google.com/workspace/drive/api/reference/rest/v3/files/export)

Uma sala Meet não garante que haja gravação ou transcrição. Elas precisam existir, estar prontas e ser acessíveis à conta conectada. Registros de conferência da API são excluídos 30 dias após o encerramento; isso não significa que o arquivo correspondente tenha sido excluído do Drive. Para reuniões antigas, prefira o link direto encontrado na agenda. [Registros de conferência](https://developers.google.com/workspace/meet/api/reference/rest/v2/conferenceRecords), [transcrições](https://developers.google.com/workspace/meet/api/reference/rest/v2/conferenceRecords.transcripts), [gravações](https://developers.google.com/workspace/meet/api/reference/rest/v2/conferenceRecords.recordings)

## Armazenamento e falhas

Configuração, token de acesso e token de renovação são protegidos pelo DPAPI do usuário atual do Windows em `%LOCALAPPDATA%\PronixBeta\google.dpapi`, fora da pasta iCloud/projeto. O estado OAuth pendente e os candidatos da consulta mais recente ficam apenas na memória. Depois de reiniciar o programa ou consultar outro link, consulte novamente o link desejado antes de importar um candidato anterior.

**Desconectar** remove a conexão local. Para revogar também a autorização concedida ao aplicativo no Google, use as configurações da Conta Google. Outros especialistas usam seus próprios tokens; copiar o arquivo DPAPI para outro usuário Windows não transfere a conexão.

Falhas de quota, API desativada, permissão negada e autorização vencida têm mensagens próprias sem retornar tokens ou o corpo bruto do erro. Para erro de acesso, confira primeiro a conta selecionada, o compartilhamento do arquivo e o modo de Drive. Links que exigem `resourcekey` preservam essa chave no cabeçalho oficial da API. [Chaves de recursos do Drive](https://developers.google.com/workspace/drive/api/guides/resource-keys)

## Contrato do serviço

Implementação: `services/google_meet.py`, classe `GoogleMeetClient`.

- `status()` não retorna segredos. Inclui `configured`, `connected`, `client_id`, `has_client_secret`, `driveAccess`, `scopes`, `needs_login`, `redirect_uri`, `setup_url` e `error`.
- `configure({clientId, clientSecret?, driveAccess: 'meet'|'all'})` guarda as opções; também aceita nomes em snake_case. O modo inicial é `meet`.
- `authorization_url(redirect_uri)`, `complete_oauth(code, state, redirect_uri)` e `disconnect()` controlam a conexão. O servidor precisa manter a mesma instância durante o retorno OAuth.
- `list_calendars()` retorna `{calendars:[{id,name,primary,timeZone,accessRole}],warnings}`.
- `list_events(calendar_id, time_min, time_max)` recebe RFC3339 com fuso e retorna `{events,warnings,calendarId,timeMin,timeMax}`. Cada evento tem `id`, `title`, `start`, `end`, `allDay`, `description`, `meetingUrl`, `recordingUrls`, `transcriptUrls`, `links`, `sellerSuggestion` e indicadores para revisão. Links têm `kind` `meeting`, `transcript`, `recording`, `document` ou `file`.
- `resolve_link(url)` retorna `{candidates,warnings,sourceUrl}`. Cada candidato contém `id`, `name`, `kind` (`transcript`/`recording`), `url`, `provider`, `fileId` e `available`. Candidatos Meet incluem a ocorrência e seus horários. `available` em Meet significa arquivo gerado, sem prometer permissão de exportação no Drive.
- `fetch_transcript(candidate)` aceita o objeto ou seu `id`, mas só usa candidatos já resolvidos nesta sessão. Retorna `{text,source,warnings}`. Dados alterados no navegador não substituem o arquivo previamente selecionado.

As fontes importadas são dados para revisão. Este módulo não envia transcrições a um serviço de IA. Qualquer análise opcional com IA precisa ser acionada separadamente pelo programa.

## Validação executada

`python -m unittest discover -s tests -p test_google_meet.py -v`

24 testes sem rede cobrem PKCE, estado/retorno/replay, renovação, permissões incompletas, troca de escopo, erro sem segredo, limite de tamanho, gravação sem download, exportação Docs, TXT/VTT, seleção explícita, registros repetidos da sala, agendas/eventos paginados, rótulos ambíguos, prioridade da sala oficial e seleção em resultados grandes. **Não equivale a validação OAuth com conta Google real.**

`python -m unittest discover -s tests -p test_google_routes.py -v`

Mais 10 testes das rotas HTTP, com servidor em porta local efêmera e cliente Google simulado, cobrem status, agendas, datas inclusivas/RFC3339, limite de 93 dias, CSRF/origem/formato do corpo, retorno OAuth sem código nos logs, seleção de transcrição e extração de ações sem duplicar cards ou perder edições. Nenhuma configuração Google real ou relatório é salvo nesses testes.
