"""Cache Mercado Livre product thumbnails for offline, self-contained reports."""
import base64
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
from . import assets, storage


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs): return None


def allowed_url(url):
    try:
        parsed=urlsplit(url)
        return (parsed.scheme=='https' and not parsed.username and not parsed.password and
                parsed.port in (None,443) and
                (parsed.hostname=='mlstatic.com' or parsed.hostname.endswith('.mlstatic.com')))
    except (ValueError,AttributeError): return False


def _cache(url):
    if not allowed_url(url): return None
    record=storage.RUNTIME/'market-images'/(hashlib.sha256(url.encode()).hexdigest()+'.json')
    try:
        cached=json.loads(record.read_text(encoding='utf-8'))
        assets.get_path(cached['id'])
        return cached['id']
    except (OSError,ValueError,KeyError): pass
    try:
        with build_opener(_NoRedirect).open(Request(url,headers={'User-Agent':'PronixBeta/0.2','Accept':'image/*'}),timeout=6) as response:
            raw=response.read(assets.MAX_BYTES+1)
        saved=assets.save_image({'name':'Produto Mercado Livre','data':base64.b64encode(raw).decode()})
        record.parent.mkdir(parents=True,exist_ok=True)
        storage.write_json(record,{'id':saved['id'],'source':url})
        return saved['id']
    except Exception:
        # A missing thumbnail cannot discard the underlying market analysis.
        return None


def cache_evidence_images(evidence):
    rows=[]
    for product in evidence.get('products',[]):
        rows += [product.get('reference') or {}]+list(product.get('candidates') or [])+list(product.get('competitors') or [])
    urls=list(dict.fromkeys(row.get('imageUrl') for row in rows if row.get('imageUrl') and allowed_url(row['imageUrl'])))[:150]
    if not urls: return
    with ThreadPoolExecutor(max_workers=5) as pool:
        mapping=dict(zip(urls,pool.map(_cache,urls)))
    for row in rows:
        image_id=mapping.get(row.get('imageUrl'))
        if image_id: row['imageId']=image_id
