"""Registro básico de uso, só para o dono do Vórtex.

Uma vez por dia (e quando a versão muda) a Central envia a um formulário Google do
Vórtex: código aleatório da instalação, nome (e e-mail) que a pessoa informou no
instalador, ou o especialista salvo em Preferências, usuário e nome do computador
Windows e a versão. Nada sobre clientes, análises,
arquivos, contas conectadas ou tempo de uso. O endereço do formulário vem só no
pacote da equipe (resources/conexoes.bin); sem ele, nada é enviado. As respostas
ficam numa planilha que só o dono vê; o programa não mostra nada disso.
"""
from __future__ import annotations

import json
import os
import platform
import secrets
import threading
import time
from urllib import parse, request

from . import bundled, storage
from .version import VERSION

STATE_FILE = "uso.json"
PERSON_KEY = r"Software\Vortex\CentralAnalises"
FIELDS = ("instalacao", "nome", "usuario", "computador", "versao", "windows")


def _config() -> dict:
    data = bundled.load().get("uso") or {}
    url, fields = data.get("url"), data.get("fields")
    if not isinstance(url, str) or not isinstance(fields, dict):
        return {}
    parts = parse.urlsplit(url)
    if parts.scheme != "https" or parts.hostname != "docs.google.com" or not parts.path.endswith("/formResponse"):
        return {}
    return {"url": url, "fields": {k: v for k, v in fields.items() if k in FIELDS and isinstance(v, str) and v.startswith("entry.")}}


def _state_path():
    from .secure_dir import secure_dir
    return secure_dir() / STATE_FILE


def _state() -> dict:
    try:
        data = json.loads(_state_path().read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def person() -> dict:
    """Nome e e-mail informados no instalador .exe (registro do usuário, chave PERSON_KEY)."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, PERSON_KEY) as key:
            def read(name):
                try:
                    return str(winreg.QueryValueEx(key, name)[0] or "").strip()[:150]
                except OSError:
                    return ""
            return {"nome": read("Nome"), "email": read("Email")}
    except (ImportError, OSError):
        return {"nome": "", "email": ""}


def display_name(settings: dict) -> str:
    who = person()
    name = who["nome"] or str((settings or {}).get("specialist") or "").strip()
    return (name + (" (" + who["email"] + ")" if who["email"] else ""))[:200]


def payload(state: dict, settings: dict) -> dict:
    return {"instalacao": state["id"],
            "nome": display_name(settings),
            "usuario": os.environ.get("USERNAME", "")[:100],
            "computador": os.environ.get("COMPUTERNAME", platform.node())[:100],
            "versao": VERSION,
            "windows": platform.release()[:40]}


def due(state: dict, now: float | None = None, name: str | None = None) -> bool:
    now = time.time() if now is None else now
    changed = name is not None and name != state.get("nome", "")       # a pessoa informou ou corrigiu o nome
    return changed or state.get("versao") != VERSION or now - float(state.get("enviadoEm") or 0) >= 20 * 3600


def send_once(settings: dict, opener=None) -> bool:
    config = _config()
    if not config:
        return False
    state = _state()
    state.setdefault("id", secrets.token_hex(8))
    data = payload(state, settings)
    if not due(state, name=data["nome"]):
        return False
    body = parse.urlencode({config["fields"][k]: v for k, v in data.items() if k in config["fields"]}).encode()
    req = request.Request(config["url"], data=body, headers={"Content-Type": "application/x-www-form-urlencoded",
                                                              "User-Agent": "CentralDeAnalises"})
    try:
        with (opener or request.urlopen)(req, timeout=20) as response:
            response.read(1024)
    except Exception:
        return False
    state.update(enviadoEm=time.time(), versao=VERSION, nome=data["nome"])
    try:
        path = _state_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(state), encoding="utf-8")
    except OSError:
        pass
    return True


def start_background(settings_reader):
    def loop():
        time.sleep(30)
        while True:
            try:
                send_once(settings_reader())
            except Exception:
                pass
            time.sleep(3 * 3600)
    threading.Thread(target=loop, name="central-uso", daemon=True).start()
