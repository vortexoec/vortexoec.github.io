"""Pure product viability calculations; no model, marketplace request, or I/O.

analyze_product(product, context, evidence, policy=None, override=None) accepts:
  product: name/reference/cost/salePrice, optional purchaseQuantity, salesQuantity,
           desiredMarginPercent and alternativeMargins. Original fields are data
           only: minimum purchase and reported margin aren't inferred as goals.
  context: logistics/cityState/taxPercent/analysisDate (YYYY-MM-DD).
  evidence: reference identity flags; candidates/competitors with exactMatch,
            active/current/observedAt, itemId/id, price and periods; manual fees.
  fees: commissionPercent/fixedFee/shipping/otherCosts, confirmed,
        allApplicableCostsConfirmed, quotedPrice, optional validPriceMin/Max,
        categoryId/listingType/source. Monetary costs are per sold unit.

Only complete, aligned item periods contribute to demand totals. Catalogue
aggregates remain context. Forecast amounts use the client's stated quantities;
the fixed 10% summary is arithmetic, never an assumed share of customer sales.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, localcontext
import math
import re


LABELS = {"viable": "Viável", "adjust": "Necessita de ajustes", "invalid": "Inviável no cenário informado",
          "insufficient": "Dados insuficientes para concluir", "not_matching": "Referência não correspondente"}
DEFAULT_POLICY = {"maxPricePremiumPercent": 0, "minMarginPercent": None,
                  "demandHighUnitsPerDay": None, "demandMediumUnitsPerDay": None,
                  "minDemandUnitsPerDay": None, "maxStockDays": None}
POLICY_NOTE = ("Critério operacional editável: preço até a média da amostra (tolerância inicial 0%), "
               "lucro unitário positivo e vendas recentes observadas. Não é uma regra do Mercado Livre "
               "nem um limite de demanda definido pelo prompt.")
D = Decimal
HUNDRED = D(100)
MISSING = "Dado não disponível"
REQUESTED_WINDOW_DAYS = 120


def _num(value):
    if value is None or value == "" or isinstance(value, bool):
        return None
    try:
        text = str(value).strip().replace("R$", "").replace("%", "").replace(" ", "").replace("\xa0", "")
        if "," in text:
            text = text.replace(".", "").replace(",", ".")
        number = D(text)
        return number if number.is_finite() and abs(number) <= D("1e15") else None
    except (InvalidOperation, ValueError):
        return None


def _nonnegative(value):
    number = _num(value)
    return number if number is not None and number >= 0 else None


def _quantity(value):
    number = _nonnegative(value)
    return number if number is not None and number == number.to_integral_value() else None


def _out(value, places=4):
    if value is None:
        return None
    with localcontext() as decimal_context:
        decimal_context.prec = 64
        value = D(value).quantize(D(1).scaleb(-places), rounding=ROUND_HALF_UP)
    return float(value)


def _json_safe(value):
    if isinstance(value, dict):
        return {key: _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, Decimal):
        return _out(value) if value.is_finite() else None
    return value


def _day(value):
    try:
        return date.fromisoformat(str(value)[:10])
    except (ValueError, TypeError):
        return None


def _identity(row):
    value = row.get("itemId") if row.get("kind", "item") == "item" else row.get("catalogId")
    return re.sub(r"[- ]", "", str(value or row.get("id") or "")).upper()


def _current(row, today):
    observed = _day(row.get("observedAt"))
    if observed is not None:
        return today is not None and today - timedelta(days=29) <= observed <= today and row.get("current") is not False
    return today is not None and row.get("current") is True


def _window(today):
    return {"requestedWindowDays": REQUESTED_WINDOW_DAYS,
            "windowStart": (today - timedelta(days=REQUESTED_WINDOW_DAYS - 1)).isoformat() if today else None,
            "windowEnd": today.isoformat() if today else None}


def _observed_trend(periods, today):
    unavailable = {"available": False, "reason": "Sem dois intervalos consecutivos, fechados, de igual duração e com faturamento informado."}
    closed = [row for row in periods if today is not None and row[1] < today]
    if len(closed) < 2:
        return unavailable
    previous, latest = closed[-2:]
    days = (previous[1] - previous[0]).days + 1
    if (previous[1] + timedelta(days=1) != latest[0] or (latest[1] - latest[0]).days + 1 != days
            or previous[3] is None or latest[3] is None):
        return unavailable
    def data(row):
        return {"periodStart": row[0].isoformat(), "periodEnd": row[1].isoformat(), "periodDays": days,
                "units": _out(row[2]), "revenue": _out(row[3], 2)}
    change = latest[3] - previous[3]
    return {"available": True, "previous": data(previous), "latest": data(latest),
            "revenueChange": _out(change, 2),
            "revenueChangePercent": _out(change / previous[3] * HUNDRED) if previous[3] > 0 else None,
            "direction": "increasing" if change > 0 else "decreasing" if change < 0 else "stable",
            "note": "Comparação descritiva dos dois intervalos indicados; não representa tendência de 120 dias nem classifica demanda."}


def _periods(rows, identity, kind, today, warnings):
    accepted, seen = [], {}
    invalid = False
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict) or row.get("scope") != kind:
            continue
        row_id = row.get("itemId") if kind == "item" else row.get("catalogId")
        if row_id and re.sub(r"[- ]", "", str(row_id)).upper() != identity:
            warnings.append("Uma série de outra identidade foi excluída das métricas.")
            continue
        start, end = _day(row.get("periodStart", row.get("start"))), _day(row.get("periodEnd", row.get("end")))
        if (not start or not end or start > end or today is None or end > today
                or start < today - timedelta(days=REQUESTED_WINDOW_DAYS - 1)
                or row.get("complete") is False or row.get("closed") is False):
            warnings.append("Uma série sem período completo dentro da janela de 120 dias foi excluída; não houve rateio de semanas nem uso de médias históricas.")
            continue
        units, revenue = _nonnegative(row.get("units")), _nonnegative(row.get("revenue"))
        key = (start, end)
        if key in seen:
            if seen[key] != (units, revenue):
                invalid = True
                warnings.append("Há métricas conflitantes para o mesmo período; os totais desta série foram suspensos.")
            continue
        seen[key] = (units, revenue)
        accepted.append((start, end, units, revenue))
    accepted.sort(key=lambda row: (row[0], row[1]))
    if any(before[1] >= after[0] for before, after in zip(accepted, accepted[1:])):
        invalid = True
        warnings.append("Há períodos sobrepostos; vendas e faturamento desta série não foram somados.")
    if not accepted or invalid:
        return {**_window(today), "periodStart": None, "periodEnd": None, "periodDays": None, "complete": False,
                "observedDays": 0, "coveragePercent": 0, "windowComplete": False, "intervals": [],
                "units": None, "revenue": None, "estimated": True, "trend": _observed_trend([], today)}
    start, end = accepted[0][0], accepted[-1][1]
    days = (end - start).days + 1
    observed_days = sum((row[1] - row[0]).days + 1 for row in accepted)
    complete = observed_days == days
    if not complete:
        warnings.append("Há lacunas entre períodos da série; ela não define uma velocidade diária contínua.")
    units = sum((row[2] for row in accepted), D(0)) if all(row[2] is not None for row in accepted) else None
    revenue = sum((row[3] for row in accepted), D(0)) if all(row[3] is not None for row in accepted) else None
    return {**_window(today), "periodStart": start.isoformat(), "periodEnd": end.isoformat(), "periodDays": days,
            "observedDays": observed_days, "coveragePercent": _out(D(observed_days) / REQUESTED_WINDOW_DAYS * HUNDRED),
            "windowComplete": complete and observed_days == REQUESTED_WINDOW_DAYS,
            "intervals": [{"periodStart": row[0].isoformat(), "periodEnd": row[1].isoformat(),
                           "periodDays": (row[1] - row[0]).days + 1} for row in accepted],
            "complete": complete, "units": _out(units), "revenue": _out(revenue, 2), "estimated": True,
            "trend": _observed_trend(accepted, today)}


def _market(evidence, today, policy, warnings):
    reference = evidence.get("reference") or {}
    reference_id = _identity(reference)
    reference_kind = reference.get("kind", "item")
    rows = list(evidence.get("competitors") or []) + list(evidence.get("candidates") or [])
    accepted, excluded, catalog_context, seen = [], [], [], set()
    for row in rows:
        if not isinstance(row, dict):
            continue
        identity, kind = _identity(row), row.get("kind", "item")
        reason = None
        if row.get("excluded") is True:
            reason = "Excluído pelo especialista."
        elif kind != "item":
            reason = "Agregado de catálogo: contexto separado, não é um anúncio concorrente adicional."
            catalog_context.append(deepcopy(row))
        elif not identity:
            reason = "Anúncio sem código verificável."
        elif row.get("exactMatch") is not True:
            reason = "Equivalência exata de modelo, variação e kit não confirmada."
        elif row.get("active") is not True:
            reason = "Anúncio ativo não confirmado."
        elif not _current(row, today):
            reason = "Atualidade dos dados não confirmada no intervalo de 30 dias."
        elif identity in seen:
            reason = "Código de anúncio duplicado; não contado novamente."
        elif len(accepted) >= 5:
            reason = "Amostra limitada aos primeiros cinco anúncios idênticos confirmados; oferta preservada para revisão."
        if reason:
            excluded.append({"id": identity or None, "reason": reason})
            continue
        seen.add(identity)
        price = _nonnegative(row.get("price"))
        periods = row.get("periods")
        if periods is None and (row.get("periodStart") or row.get("start")):
            periods = [{**row, "scope": "item"}]
        metrics = _periods(periods, identity, "item", today, warnings)
        accepted.append({"id": identity, "kind": "item", "catalogId": row.get("catalogId"),
            "title": row.get("title"), "url": row.get("url"), "imageUrl": row.get("imageUrl"),
            "price": _out(price, 2), "active": True, "exactMatch": True,
            "observedAt": row.get("observedAt"), "metrics": metrics,
            "exposureDays": _out(_nonnegative(row.get("exposureDays"))),
            "exposureBasis": row.get("exposureBasis"),
            "sellThroughDays": _out(_nonnegative(row.get("sellThroughDays")))})
    prices = [_num(row["price"]) for row in accepted if row["price"] is not None]
    price_average = sum(prices, D(0)) / len(prices) if prices else None
    common = {(row["metrics"]["periodStart"], row["metrics"]["periodEnd"]) for row in accepted}
    aligned = bool(accepted) and len(common) == 1 and all(row["metrics"]["complete"] for row in accepted)
    if len(common) > 1:
        warnings.append("Os concorrentes cobrem períodos diferentes; não foi produzido um total ou ritmo diário misturando intervalos.")
    units = (sum((_num(row["metrics"]["units"]) for row in accepted), D(0))
             if aligned and all(row["metrics"]["units"] is not None for row in accepted) else None)
    revenue = (sum((_num(row["metrics"]["revenue"]) for row in accepted), D(0))
               if aligned and all(row["metrics"]["revenue"] is not None for row in accepted) else None)
    days = accepted[0]["metrics"]["periodDays"] if aligned else None
    coverage_intervals = {tuple((period["periodStart"], period["periodEnd"]) for period in row["metrics"]["intervals"]) for row in accepted}
    observed_days = accepted[0]["metrics"]["observedDays"] if accepted and len(coverage_intervals) == 1 else None
    daily_units = units / days if units is not None and days else None
    daily_revenue = revenue / days if revenue is not None and days else None
    exposure = [_num(row["exposureDays"]) for row in accepted
                if row["exposureDays"] is not None and row["exposureBasis"] == "item_age"]
    # The age of the first item in a catalogue isn't the age of each offer.
    # Keep those source values as individual context, without mixing or adding
    # repeated catalogues to the item-age average or time-to-sell statistic.
    catalog_exposure = [{"id": row["id"], "catalogId": row.get("catalogId"),
                         "exposureDays": row["exposureDays"], "exposureBasis": row["exposureBasis"]}
                        for row in accepted if row["exposureDays"] is not None
                        and row["exposureBasis"] == "catalog_first_item_age"]
    if any(row["exposureDays"] is not None and row["exposureBasis"] != "item_age" for row in accepted):
        warnings.append("Idade de catálogo e exposição sem escopo confirmado foram preservadas na fonte, mas não compõem a idade média dos anúncios nem o tempo de venda.")
    sell_time = [_num(row["sellThroughDays"]) for row in accepted if row["sellThroughDays"] is not None]
    demand_label = "Não classificada"
    high, medium = (_num(policy.get(key)) for key in ("demandHighUnitsPerDay", "demandMediumUnitsPerDay"))
    if daily_units is not None and high is not None and medium is not None and high >= medium >= 0:
        demand_label = "Alta" if daily_units >= high else "Média" if daily_units >= medium else "Baixa"
    return {**_window(today), "competitors": accepted, "excluded": excluded, "catalogContext": catalog_context,
        "competitorCount": len(accepted), "priceCount": len(prices), "priceMin": _out(min(prices), 2) if prices else None,
        "priceMax": _out(max(prices), 2) if prices else None, "priceAverage": _out(price_average, 2),
        "unitsTotal": _out(units), "revenueTotal": _out(revenue, 2),
        "unitsAverage": _out(units / len(accepted)) if units is not None else None,
        "revenueAverage": _out(revenue / len(accepted), 2) if revenue is not None else None,
        "unitsPerDay": _out(daily_units), "revenuePerDay": _out(daily_revenue, 2),
        "averageUnitsPerDay": _out(daily_units / len(accepted)) if daily_units is not None else None,
        "periodStart": accepted[0]["metrics"]["periodStart"] if aligned else None,
        "periodEnd": accepted[0]["metrics"]["periodEnd"] if aligned else None,
        "periodDays": days, "periodComplete": aligned,
        "observedDays": observed_days,
        "coveragePercent": _out(D(observed_days) / REQUESTED_WINDOW_DAYS * HUNDRED) if observed_days is not None else None,
        "windowComplete": aligned and observed_days == REQUESTED_WINDOW_DAYS,
        "exposureDaysAverage": _out(sum(exposure, D(0)) / len(exposure)) if exposure else None,
        "catalogExposure": catalog_exposure,
        "sellThroughDaysAverage": _out(sum(sell_time, D(0)) / len(sell_time)) if sell_time and len(sell_time) == len(accepted) else None,
        "demandLabel": demand_label,
        "demandObservation": "Vendas observadas" if units is not None and units > 0 else "Nenhuma venda observada no período" if units == 0 else "Vendas do período não disponíveis",
        "estimated": True, "dailyScope": "Total da amostra por dia do intervalo comum observado, dentro da janela solicitada de 120 dias; não é total de 120 dias nem previsão de vendas do cliente quando a cobertura é parcial.",
        "referenceMetrics": _periods(evidence.get("periods"), reference_id, reference_kind, today, warnings)}


def _fee_scope(fees, price, reference):
    if not isinstance(fees, dict) or fees.get("confirmed") is not True:
        return False, "Confirmação das taxas e custos unitários aplicáveis."
    for key in ("categoryId", "listingType"):
        if fees.get(key) and reference.get(key) and fees[key] != reference[key]:
            return False, "As taxas informadas pertencem a outra categoria ou tipo de anúncio."
    quote = _nonnegative(fees.get("quotedPrice"))
    low, high = _nonnegative(fees.get("validPriceMin")), _nonnegative(fees.get("validPriceMax"))
    if price is not None and ((quote is not None and price == quote) or
                             (low is not None and high is not None and low <= price <= high)):
        return True, None
    return False, "Confirmar as taxas para o preço pretendido; a cotação atual não cobre esse preço."


def _financial(product, context, evidence):
    price, cost = _nonnegative(product.get("salePrice")), _nonnegative(product.get("cost"))
    tax = _nonnegative(context.get("taxPercent"))
    if tax is not None and tax > 100:
        tax = None
    fees = evidence.get("fees") or {}
    scoped, scope_error = _fee_scope(fees, price, evidence.get("reference") or {})
    commission = _nonnegative(fees.get("commissionPercent")) if scoped else None
    if commission is not None and commission > 100:
        commission = None
    fixed, shipping, others = (_nonnegative(fees.get(key)) if scoped else None for key in ("fixedFee", "shipping", "otherCosts"))
    # Sem conferência do especialista, usa a estimativa automática (API do ML +
    # tabela oficial) somente quando ela foi calculada para este mesmo preço.
    auto = evidence.get("autoFees") if isinstance(evidence.get("autoFees"), dict) else {}
    estimated = False
    if (not scoped and price is not None and _nonnegative(auto.get("quotedPrice")) == price
            and any(_nonnegative(auto.get(key)) is not None for key in ("commissionPercent", "shipping"))):
        estimated = True
        scope_error = None
        commission = _nonnegative(auto.get("commissionPercent"))
        if commission is not None and commission > 100:
            commission = None
        fixed = _nonnegative(auto.get("fixedFee"))
        typed_shipping, typed_others = _nonnegative(fees.get("shipping")), _nonnegative(fees.get("otherCosts"))
        shipping = typed_shipping if typed_shipping is not None else _nonnegative(auto.get("shipping"))
        others = typed_others
    # The scenario uses cent-rounded unit charges throughout: the displayed
    # unit result and the lot projection must reconcile. This is a simulation
    # convention, not a claim about an eventual marketplace invoice.
    commission_amount = (price * commission / HUNDRED).quantize(D('0.01'), rounding=ROUND_HALF_UP) if price is not None and commission is not None else None
    tax_amount = (price * tax / HUNDRED).quantize(D('0.01'), rounding=ROUND_HALF_UP) if price is not None and tax is not None else None
    components = {"Custo unitário do produto": cost, "Comissão percentual": commission_amount,
                  "Tarifa fixa por unidade": fixed, "Imposto sobre vendas": tax_amount,
                  "Frete/logística suportado pelo vendedor": shipping, "Outros custos unitários aplicáveis": others}
    missing = [label for label, value in components.items() if value is None]
    if price is None:
        missing.insert(0, "Preço pretendido de venda")
    if scope_error:
        missing.append(scope_error)
    if fees.get("allApplicableCostsConfirmed") is not True:
        missing.append("Confirmação de que todos os custos aplicáveis foram incluídos, sem duplicidade.")
    known = sum((value for value in components.values() if value is not None), D(0))
    profit = price - known if price is not None else None
    # Proceeds excludes the acquisition cost; unknown costs remain explicit.
    deductions = sum((value for label, value in components.items() if value is not None and label != "Custo unitário do produto"), D(0))
    net = price - deductions if price is not None else None
    complete = not missing
    result = {"salePrice": _out(price, 2), "cost": _out(cost, 2), "commissionPercent": _out(commission),
              "commissionAmount": _out(commission_amount, 2), "fixedFee": _out(fixed, 2),
              "taxPercent": _out(tax), "taxAmount": _out(tax_amount, 2), "shipping": _out(shipping, 2),
              "otherCosts": _out(others, 2), "knownCosts": _out(known, 2), "netProceeds": _out(net, 2),
              "profit": _out(profit, 2), "marginPercent": _out(profit / price * HUNDRED) if price and profit is not None else None,
              "complete": complete, "upperBound": not complete, "missing": list(dict.fromkeys(missing)),
              "estimated": estimated, "autoNotes": list(auto.get("notes") or []) if estimated else [],
              "source": ("Estimativa automática: comissão pela API do Mercado Livre e frete pela tabela oficial; " + "; ".join(auto.get("notes") or []))
                        if estimated else fees.get("source"), "scope": "Resultado unitário no preço e nos custos informados; não é lucro contábil de toda a empresa.",
              "roundingNote": "Simulação com comissão e imposto arredondados ao centavo por unidade; a cobrança efetiva pode ter critérios próprios.",
              "note": ("Resultado completo com comissão e frete estimados (API do Mercado Livre e tabela oficial)." if estimated else "Resultado completo no escopo confirmado.") if complete else
                      "Cálculo parcial: desconta apenas custos conhecidos e confirmados. O saldo é um teto, que pode cair com os custos pendentes."}
    return result, {"price": price, "cost": cost, "tax": tax, "commission": commission,
                    "fixed": fixed, "shipping": shipping, "others": others, "profit": profit, "scoped": scoped}


def _pricing(product, evidence, financial, numbers, market):
    target = _nonnegative(product.get("desiredMarginPercent"))
    if target is not None and target >= 100:
        target = None
    raw_margins = product.get("alternativeMargins") or []
    raw_margins = raw_margins if isinstance(raw_margins, list) else []
    margins = [(target, "desired")] if target is not None else []
    for value in raw_margins:
        margin = _nonnegative(value)
        if margin is not None and margin < 100 and margin not in [item[0] for item in margins]:
            margins.append((margin, "alternative"))
    scenarios, missing = [], list(financial["missing"])
    if target is None:
        missing.append("Margem desejada não informada; não foi adotada uma meta de 30%.")
    required = None
    fees = evidence.get("fees") or {}
    if financial["complete"]:
        fixed_cost = numbers["cost"] + numbers["fixed"] + numbers["shipping"] + numbers["others"]
        for margin, kind in margins:
            denominator = 1 - (numbers["commission"] + numbers["tax"] + margin) / HUNDRED
            price = fixed_cost / denominator if denominator > 0 else None
            low, high = _nonnegative(fees.get("validPriceMin")), _nonnegative(fees.get("validPriceMax"))
            covered = price is not None and ((price == numbers["price"]) or
                      (low is not None and high is not None and low <= price <= high))
            average = _num(market["priceAverage"])
            comparison = (price / average - 1) * HUNDRED if price is not None and average else None
            note = ("Meta incompatível com a soma de taxas e imposto: o denominador da fórmula não é positivo." if price is None else
                    "Base condicional: confirmar comissão, tarifa fixa e logística nesta nova faixa de preço." if not covered else
                    "Cálculo dentro da faixa de custos declarada; não garante vendas nem futuras tarifas.")
            scenarios.append({"marginPercent": _out(margin), "price": _out(price, 2), "conditional": not covered,
                              "comparisonPercent": _out(comparison), "kind": kind, "note": note})
            if kind == "desired":
                required = price
    desired = next((row for row in scenarios if row["kind"] == "desired"), None)
    return {"requiredPrice": _out(required, 2), "desiredMarginPercent": _out(target),
            "conditional": desired["conditional"] if desired else True, "missing": missing,
            "scenarios": scenarios, "formula": "(custo + tarifa fixa + logística + outros custos) / (1 - (comissão% + imposto% + margem%) / 100)",
            "note": "Margens alternativas são possibilidades escolhidas pelo usuário; não há recomendação automática de reduzi-las."}


def _inventory(product, financial, numbers, market):
    purchase, sales = _quantity(product.get("purchaseQuantity")), _quantity(product.get("salesQuantity"))
    investment = numbers["cost"] * purchase if numbers["cost"] is not None and purchase is not None else None
    revenue = numbers["price"] * sales if numbers["price"] is not None and sales is not None else None
    profit = numbers["profit"] * sales if numbers["profit"] is not None and sales is not None else None
    speed = _num(market["averageUnitsPerDay"])
    coverage = purchase / speed if purchase is not None and speed and speed > 0 else None
    missing = []
    if purchase is None:
        missing.append("Quantidade que pretende comprar; mínimo de compra não foi usado como intenção de compra.")
    if sales is None:
        missing.append("Quantidade que pretende vender.")
    if financial["missing"]:
        missing.append("Custos completos para apurar lucro e retorno no cenário.")
    return {"purchaseQuantity": _out(purchase), "salesQuantity": _out(sales),
            "stockInvestment": _out(investment, 2), "projectedRevenue": _out(revenue, 2),
            "projectedProfit": _out(profit, 2), "profitIsUpperBound": financial["upperBound"],
            "marginPercent": financial["marginPercent"] if revenue and revenue > 0 else None,
            "roiPercent": _out(profit / investment * HUNDRED) if investment and profit is not None else None,
            "quantityCoverageDays": _out(coverage), "missing": missing,
            "salesExceedPurchase": purchase is not None and sales is not None and sales > purchase,
            "note": "Faturamento e lucro são cenários para a quantidade de venda informada, sem garantia de demanda. "
                    "Investimento em estoque considera custo de compra × quantidade; despesas adicionais não estão incluídas nesse investimento.",
            "coverageNote": "Dias equivalentes ao ritmo médio dos concorrentes idênticos; não é previsão do prazo de venda deste cliente."}


def _money(value):
    return MISSING if value is None else "R$ " + f"{value:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")


def _fmt(value, decimals=2):
    return MISSING if value is None else f"{value:,.{decimals}f}".replace(",", "_").replace(".", ",").replace("_", ".")


def _summary(market):
    revenue, units = _num(market["revenueTotal"]), _num(market["unitsTotal"])
    values = {"F26": market["demandLabel"], "F6": market["revenueTotal"],
              "F7": _out(revenue / 10, 2) if revenue is not None else None, "F9": market["priceAverage"],
              "F8": market["sellThroughDaysAverage"], "F12": market["revenuePerDay"],
              "F11": market["unitsPerDay"], "F10": _out(units / 10) if units is not None else None}
    unit_decimals = 0 if values["F10"] is not None and float(values["F10"]).is_integer() else 2
    text = (f"O produto apresenta uma demanda {values['F26']}, com faturamento total de {_money(values['F6'])}, "
            f"sendo 10% equivalente a {_money(values['F7'])}. O preço médio é de {_money(values['F9'])} "
            f"e o tempo médio de venda é de {_fmt(values['F8'], 1)}" + (" dias" if values["F8"] is not None else "") +
            f". Isso representa aproximadamente {_money(values['F12'])} em vendas por dia, equivalente a uma média de "
            f"{_fmt(values['F11'])} vendas por dia (cerca de {_fmt(values['F10'], unit_decimals)} unidades vendidas no total, considerando os 10%).")
    return {"text": text.replace("disponível..", "disponível."), "values": values, "limitations": [
        "10% é apenas a fração aritmética exigida pelo modelo; não é participação garantida nem projeção de vendas do cliente.",
        "Os valores diários usam o total da amostra dividido pelos dias do período comum, sem multiplicar por 10%.",
        "Idade/exposição de anúncio não foi substituída por tempo para vender estoque.",
        "Alta/Média/Baixa depende de limites definidos pelo especialista; não existem cortes automáticos no prompt fornecido."]}


def analyze_product(product, context, evidence, policy=None, override=None):
    """Return market/financial/pricing/inventory, calculated and final verdicts.

    Output monetary fields are numbers or None, percentages are percentage
    points. verdict.calculated is never replaced by specialist overrides.
    checklist entries have id/label/status(complete|missing|attention)/detail.
    """
    if not all(isinstance(value, dict) for value in (product, context, evidence)):
        raise ValueError("Produto, contexto e evidências precisam ser registros separados.")
    configured = {**DEFAULT_POLICY}
    for key in configured:
        if isinstance(policy, dict) and key in policy:
            value = _num(policy[key])
            if policy[key] is not None and (value is None or value < 0):
                raise ValueError("Critério operacional inválido: " + key)
            configured[key] = _out(value)
    if configured["maxPricePremiumPercent"] is None:
        configured["maxPricePremiumPercent"] = 0
    high, medium = configured["demandHighUnitsPerDay"], configured["demandMediumUnitsPerDay"]
    if high is not None and medium is not None and high < medium:
        raise ValueError("O limite de demanda alta não pode ser menor que o de demanda média.")
    warnings = []
    today = _day(context.get("analysisDate") or evidence.get("analysisDate"))
    if today is None:
        warnings.append("Data da análise ausente; não foi possível confirmar recência ou usar vendas como demanda atual.")
    market = _market(evidence, today, configured, warnings)
    financial, numbers = _financial(product, context, evidence)
    pricing = _pricing(product, evidence, financial, numbers, market)
    inventory = _inventory(product, financial, numbers, market)
    reference = evidence.get("reference") or {}
    identity_ok = reference.get("referenceValidated") is True and reference.get("identityValidated") is True
    logistics = str(context.get("logistics") or "").strip()
    current_sales = market["periodComplete"] and market["unitsTotal"] is not None
    average = _num(market["priceAverage"])
    premium = ((numbers["price"] / average - 1) * HUNDRED
               if numbers["price"] is not None and average and average > 0 else None)
    competitive = premium is not None and premium <= _num(configured["maxPricePremiumPercent"])
    target = _num(pricing["desiredMarginPercent"])
    margin = _num(financial["marginPercent"])
    checklist = []
    def check(key, label, ok, detail, attention=False):
        checklist.append({"id": key, "label": label, "status": "complete" if ok else "attention" if attention else "missing", "detail": detail})
    check("identity", "Referência e produto exato", identity_ok,
          "Código e equivalência do produto confirmados." if identity_ok else "Confirmar o anúncio exato, modelo, versão, quantidade e kit; título semelhante não basta.")
    check("competitors", "Concorrentes idênticos, ativos e atuais", bool(market["competitors"]),
          f"{market['competitorCount']} anúncio(s) idêntico(s) aceito(s); nenhum foi inventado para completar cinco.")
    check("period", "Vendas recentes em período comum completo", current_sales,
          (f"{market['periodStart']} a {market['periodEnd']}: {market['unitsTotal']} unidades estimadas na amostra; {market['observedDays']} de 120 dias cobertos. O intervalo observado é completo, não necessariamente a janela de 120 dias." if current_sales else
           "Confirmar séries do anúncio específico dentro dos 120 dias solicitados, sem sobreposição, lacunas ou períodos diferentes entre concorrentes."))
    check("costs", "Custos unitários completos", financial["complete"],
          financial["note"] + (" Pendências: " + "; ".join(financial["missing"]) if financial["missing"] else ""))
    check("logistics", "Modalidade logística", bool(logistics),
          logistics or "Informar a modalidade para conferir os custos específicos do vendedor.")
    check("location", "Cidade e estado", bool(context.get("cityState")),
          str(context.get("cityState") or "Informar cidade/UF para contextualizar logística; nenhuma tarifa regional foi presumida."))
    check("margin", "Meta de margem", target is not None,
          f"Meta informada: {_fmt(_out(target))}%." if target is not None else "Definir uma meta com o cliente; margem de 30% não foi aplicada automaticamente.")
    check("price", "Preço frente à média da amostra", competitive,
          f"Diferença: {_fmt(_out(premium))}%; tolerância configurada: {configured['maxPricePremiumPercent']}%." if premium is not None else
          "Preço pretendido ou média de preços atuais dos concorrentes idênticos não disponível.", attention=premium is not None)
    check("quantities", "Quantidades para investimento e cenário", inventory["purchaseQuantity"] is not None and inventory["salesQuantity"] is not None,
          "; ".join(inventory["missing"]) if inventory["missing"] else inventory["note"])
    critical = []
    if not identity_ok:
        critical.append("Identidade exata da referência ainda não confirmada.")
    if not market["competitors"] or average is None or average <= 0:
        critical.append("Faltam preços atuais de ao menos um concorrente comprovadamente idêntico.")
    if not current_sales:
        critical.append("Faltam vendas recentes em um período completo comparável.")
    if not financial["complete"]:
        critical.extend(financial["missing"])
    if not logistics:
        critical.append("Modalidade logística não informada.")
    reasons = []
    # Missing charges are non-negative; a non-positive upper bound is decisive
    # for this unit-price scenario even if other inputs remain incomplete.
    if numbers["profit"] is not None and numbers["profit"] <= 0:
        status = "invalid"
        reasons.append("O preço não supera os custos já conhecidos: mesmo antes de cobranças pendentes, não há lucro unitário positivo nesse cenário.")
    elif critical:
        status = "insufficient"
        reasons.extend(critical)
    else:
        if not competitive:
            reasons.append("O preço pretendido supera o critério configurado em relação à média dos concorrentes; revisar preço, custo ou posicionamento.")
        if market["unitsTotal"] == 0:
            reasons.append("Nenhuma venda foi observada no período da amostra; isso pede validação adicional de demanda, não prova inviabilidade.")
        if target is None:
            reasons.append("O saldo unitário é positivo, mas a meta de margem ainda precisa ser definida com o cliente.")
        elif margin is None or margin < target:
            reasons.append("A margem no preço pretendido fica abaixo da meta informada; negociar custos ou comparar cenários é uma possibilidade.")
        minimum = _num(configured["minMarginPercent"])
        if minimum is not None and margin is not None and margin < minimum:
            reasons.append("Margem abaixo do mínimo operacional configurado pelo especialista.")
        minimum_demand = _num(configured["minDemandUnitsPerDay"])
        if minimum_demand is not None and _num(market["unitsPerDay"]) < minimum_demand:
            reasons.append("O ritmo de vendas da amostra fica abaixo do mínimo de demanda configurado.")
        max_stock = _num(configured["maxStockDays"])
        if max_stock is not None and inventory["quantityCoverageDays"] is not None and _num(inventory["quantityCoverageDays"]) > max_stock:
            reasons.append("A compra equivale a mais dias de vendas dos concorrentes que o limite de estoque configurado; considerar lote menor como teste.")
        if inventory["salesExceedPurchase"]:
            reasons.append("A quantidade pretendida de venda excede a compra informada; confirmar estoque existente ou reposição antes de assumir esse cenário.")
        status = "adjust" if reasons else "viable"
        if status == "viable":
            reasons.append("No cenário unitário informado, custos estão completos, lucro e meta de margem são atendidos, o preço respeita o critério da amostra e há vendas recentes observadas.")
    calculated = {"status": status, "label": LABELS[status], "reasons": list(dict.fromkeys(reasons)),
                  "confidence": "complete" if not critical and market['windowComplete'] else "partial",
                  "scope": "Parecer determinístico do produto no preço, período observado e custos declarados; não garante vendas nem lucro da operação inteira. " +
                           (f"Janela solicitada: 120 dias; cobertura comparável observada: {market['observedDays']} dias. Não extrapola os dias sem dados." if market['observedDays'] is not None else
                            "Janela solicitada: 120 dias; cobertura comparável da amostra ainda não disponível.")}
    final = deepcopy(calculated)
    specialist_override = None
    if override is not None:
        if not isinstance(override, dict) or override.get("status") not in LABELS or not str(override.get("reason") or "").strip():
            raise ValueError("Informe um veredito válido e o motivo da revisão do especialista.")
        specialist_override = {"status": override["status"], "reason": str(override["reason"]).strip()[:2000]}
        final = {**deepcopy(calculated), "status": override["status"], "label": LABELS[override["status"]],
                 "reasons": [specialist_override["reason"]], "source": "specialist_override"}
    logistics_note = ("Frete grátis ao comprador não prova custo zero ao vendedor. "
        "Os valores de envio são os informados para esta modalidade; sem cotação confirmada não há tarifa presumida. "
        "Cada R$ 1,00 adicional por unidade reduz o lucro em R$ 1,00" +
        (f" e a margem em {_fmt(_out(HUNDRED / numbers['price']))} ponto(s) percentual(is) no preço atual." if numbers["price"] and numbers["price"] > 0 else "."))
    if "full" in logistics.lower():
        logistics_note += " No Full, conferir preparo/envio para abastecimento, armazenagem e outros custos aplicáveis; não foram presumidos nem zerados."
    elif "flex" in logistics.lower():
        logistics_note += " No Flex, confirmar entrega na região atendida, deslocamento e capacidade; não há custo único para todas as regiões."
    elif "ag" in logistics.lower():
        logistics_note += " Na Agência, conferir preparo, postagem, peso/dimensões e custos efetivos da conta."
    return _json_safe({"version": 1, "product": {key: deepcopy(product.get(key)) for key in ("index", "name", "reference", "fields")},
        "inputs": {key: deepcopy(product.get(key)) for key in ("cost", "salePrice", "purchaseQuantity", "salesQuantity", "desiredMarginPercent", "alternativeMargins")},
        "market": market, "financial": financial, "pricing": pricing, "inventory": inventory,
        "comparison": {"premiumPercent": _out(premium), "competitive": competitive, "maxPricePremiumPercent": configured["maxPricePremiumPercent"]},
        "verdict": {"calculated": calculated, "final": final, "override": specialist_override},
        "checklist": checklist, "executiveSummary": _summary(market), "logisticsExplanation": logistics_note,
        "warnings": list(dict.fromkeys(warnings)), "policy": {**configured, "explanation": POLICY_NOTE},
        "limitations": ["Vendas e faturamento de mercado são estimativas da fonte, restritas ao período indicado.",
                        "Equivalência de concorrentes depende da confirmação registrada; títulos ou catálogo agrupador não bastam.",
                        "Quantidade de compra/venda ausente limita investimento e estoque, sem impedir por si só o parecer unitário."]})
