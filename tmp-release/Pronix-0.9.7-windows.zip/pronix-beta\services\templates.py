"""Local reusable cards/sections, retaining asset references and editable copy.

Templates deliberately accept one content node, never a complete client report.
Applying a template creates new checklist identities and resets execution state.
"""
from __future__ import annotations

import copy
import json
import re
import uuid

from . import storage


def _directory():
    directory = storage.RUNTIME / "templates"
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def _path(template_id):
    if not isinstance(template_id, str):
        raise ValueError("Identificador de modelo inválido.")
    return _directory() / (storage.identifier(template_id) + ".json")


def _text(value, limit, label):
    text = str(value if value is not None else "")
    if len(text) > limit:
        raise ValueError(f"{label} excede o limite de {limit} caracteres.")
    return text


def _images(images):
    if not isinstance(images, list) or len(images) > 6:
        raise ValueError("O modelo aceita até 6 imagens por seção ou card.")
    result = []
    for image in images:
        if not isinstance(image, dict):
            raise ValueError("Imagem do modelo inválida.")
        if not isinstance(image.get("id"), str):
            raise ValueError("Identificador da imagem inválido.")
        asset_id = storage.identifier(image["id"])
        item = {"id": asset_id, "caption": _text(image.get("caption"), 5000, "Legenda"),
                "name": _text(image.get("name"), 500, "Nome da imagem")}
        # Asset identity stays stable. The report validator reconstructs the URL.
        url = str(image.get("url") or "")
        if re.fullmatch(r"/api/assets/" + asset_id + r"(?:\.(?:png|jpg|jpeg|webp))?", url):
            item["url"] = url
        result.append(item)
    return result


def _content(kind, content):
    if not isinstance(content, dict):
        raise ValueError("Envie o conteúdo de um único card ou seção.")
    if any(key in content for key in ("clientName", "actionCards", "sections", "transcript", "meetingText", "ads", "account")):
        raise ValueError("Salve somente um card ou seção, sem dados gerais do cliente ou transcrição completa.")
    try:
        json.dumps(content, ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ValueError("O conteúdo do modelo deve conter apenas dados JSON válidos.") from exc
    result = {"id": _text(content.get("id") or uuid.uuid4().hex, 200, "Identificador"),
              "title": _text(content.get("title"), 500, "Título"),
              "images": _images(content.get("images", []))}
    # Quotes are deliberate editable content; meeting metadata and audit are not.
    for key in ("sourceQuote", "quote"):
        if key in content:
            result[key] = _text(content[key], 200000, "Trecho de origem")
    if isinstance(content.get("source"), str):
        result["source"] = _text(content["source"], 5000, "Fonte")
    if kind == "section":
        result["body"] = _text(content.get("body"), 200000, "Texto da seção")
        return result
    for key in ("problem", "why", "metric", "target", "owner", "due"):
        result[key] = _text(content.get(key), 10000, key)
    result["priority"] = content.get("priority") if content.get("priority") in ("alta", "media", "baixa") else "media"
    result["status"] = content.get("status") if content.get("status") in ("pending", "doing", "done") else "pending"
    steps = content.get("steps", [])
    if not isinstance(steps, list) or len(steps) > 50:
        raise ValueError("O modelo aceita até 50 etapas por card.")
    result["steps"] = []
    for step in steps:
        if not isinstance(step, dict):
            raise ValueError("Etapa do modelo inválida.")
        result["steps"].append({"id": _text(step.get("id") or uuid.uuid4().hex, 200, "Identificador da etapa"),
                                "text": _text(step.get("text"), 10000, "Texto da etapa"), "done": step.get("done") is True})
    return result


def save_template(data):
    """Create a new template. Re-saving makes another model, never replaces one."""
    if not isinstance(data, dict) or data.get("kind") not in ("card", "section"):
        raise ValueError("Escolha um modelo de card ou seção.")
    title = _text(data.get("title"), 200, "Nome do modelo").strip()
    if not title:
        raise ValueError("Dê um nome ao modelo para encontrá-lo na biblioteca.")
    timestamp = storage.now()
    template = {"id": uuid.uuid4().hex, "title": title, "kind": data["kind"],
                "content": _content(data["kind"], data.get("content")),
                "createdAt": timestamp, "updatedAt": timestamp, "archived": False}
    with storage.LOCK:
        storage.write_json(_path(template["id"]), template)
    return copy.deepcopy(template)


def get_template(template_id):
    template = storage.read_json(_path(template_id))
    if (not isinstance(template, dict) or template.get("id") != template_id
            or template.get("kind") not in ("card", "section")
            or not isinstance(template.get("content"), dict)
            or not isinstance(template.get("title"), str)):
        raise FileNotFoundError("Modelo não encontrado.")
    return template


def list_templates():
    items = []
    with storage.LOCK:
        for path in _directory().glob("*.json"):
            try:
                template = get_template(path.stem)
                if template.get("archived"):
                    continue
                content = template.get("content") or {}
                preview = str(content.get("problem") or content.get("body") or content.get("title") or "")
                preview = re.sub(r"\s+", " ", preview).strip()[:180]
                items.append({"id": template["id"], "title": template["title"], "kind": template["kind"],
                              "updatedAt": template.get("updatedAt"), "preview": preview})
            except (ValueError, OSError, TypeError, KeyError):
                continue
    return {"templates": sorted(items, key=lambda item: (item.get("updatedAt") or "", item["id"]), reverse=True)}


def apply_template(report, template_id):
    """Append an independent editable copy; never mutate the input or model.

    Names, numbers, captions and quotes remain literal and need user review. Asset
    IDs identify shared immutable files; nodeId identifies each image placement.
    """
    if not isinstance(report, dict):
        raise ValueError("Relatório inválido.")
    template = get_template(template_id)
    if template.get("archived"):
        raise ValueError("Este modelo está arquivado. Escolha um modelo ativo.")
    result = copy.deepcopy(report)
    node = _content(template["kind"], template["content"])
    node["id"] = uuid.uuid4().hex
    node["templateOrigin"] = {"id": template["id"], "title": template["title"], "source": "Biblioteca local de modelos"}
    for image in node["images"]:
        image["nodeId"] = uuid.uuid4().hex
    if template["kind"] == "card":
        node.update({"owner": "", "due": "", "status": "pending"})
        for step in node["steps"]:
            step.update({"id": uuid.uuid4().hex, "done": False})
        destination, limit = "actionCards", 100
    else:
        destination, limit = "sections", 200
    existing = result.setdefault(destination, [])
    if not isinstance(existing, list) or len(existing) >= limit:
        raise ValueError("O relatório atingiu o limite de cards ou seções. Organize o conteúdo antes de adicionar um modelo.")
    existing.append(node)
    return result


def archive_template(template_id):
    """Archive without deleting the model or referenced image assets."""
    with storage.LOCK:
        template = get_template(template_id)
        template["archived"] = True
        template["updatedAt"] = storage.now()
        storage.write_json(_path(template_id), template)
    return template
