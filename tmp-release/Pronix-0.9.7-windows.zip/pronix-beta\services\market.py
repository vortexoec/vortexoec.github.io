"""Documento de produtos e conexão de mercado. Sem IA: toda análise é local e determinística."""
from __future__ import annotations

import json

from . import storage
from .market_data import extract_references, reference_spec


def connection_message(joom_connected, *_ignored):
    if not joom_connected:
        return 'Conecte a JoomPulse em Integrações para consultar os dados de mercado.'
    return ''


def source_document(document_id, references=None):
    """Rebuild commercial inputs from the stored source, applying local URL edits."""
    upload=json.loads(json.dumps(storage.get_upload(document_id),ensure_ascii=False))
    if upload.get('kind') not in ('pdf','html'):
        raise ValueError('Importe um PDF de produtos ou o HTML da planilha do Pronix Hub.')
    if upload['kind']=='html':
        from .product_source import render_source_text, extract_product_html
        products=upload.get('products') or []
        # Older imports excluded the Hub's existing opinions. Recover only from
        # the stored HTML and only when every product/reference still matches.
        # No remote page is fetched and no user-edited commercial field changes.
        if products and any(not p.get('hubReview') for p in products):
            try:
                recovered=extract_product_html(upload['path']).get('products') or []
                if len(recovered)==len(products) and all(
                        p.get('originalReference',p.get('reference'))==q.get('reference')
                        and p.get('name')==q.get('name') for p,q in zip(products,recovered)):
                    for product,original in zip(products,recovered):
                        if not product.get('hubReview') and original.get('hubReview'):
                            product['hubReview']=original['hubReview']
            except (OSError,ValueError,KeyError):
                pass
        warnings=list(upload.get('warnings') or [])
        if references is not None and (not isinstance(references,list) or len(references)!=len(products)):
            raise ValueError('A lista de links deve manter todos os produtos do documento original.')
        for index,product in enumerate(products):
            original=product.get('originalReference',product.get('reference',''))
            old_error=product.get('referenceError')
            if old_error:
                warnings=[w for w in warnings if w!=f"Produto {product.get('index',index+1)}: {old_error}"]
            ref=references[index] if references is not None else product.get('reference','')
            if not isinstance(ref,str) or len(ref)>8192:
                raise ValueError('Confira o link informado para cada produto.')
            spec=reference_spec(ref.strip())
            error=spec['error']
            if ref.strip()==product.get('reference','') and old_error and 'mais de um link' in old_error:
                error=old_error
            product.update(reference=ref.strip(),originalReference=original,
                           referenceStatus='ready' if spec['valid'] and not error else 'needs_review',
                           referenceId=spec['id'],referenceError=error)
            if error: warnings.append(f"Produto {product.get('index',index+1)}: {error}")
        upload['warnings']=list(dict.fromkeys(warnings))
        upload['links']=[product['reference'] for product in products]
        upload['text']=render_source_text(upload.get('clientName',''),products,upload.get('metadata') or {})
    elif references is not None:
        original=extract_references(str(upload.get('text',''))+'\n'+'\n'.join(upload.get('links') or []))
        if not isinstance(references,list) or len(references)!=len(original):
            raise ValueError('A lista de links deve manter os produtos identificados no PDF original.')
        products=[]
        for index,ref in enumerate(references):
            if not isinstance(ref,str) or len(ref)>8192: raise ValueError('Confira o link do produto no PDF.')
            spec=reference_spec(ref.strip())
            products.append({'index':index+1,'name':f'Produto {index+1} · {spec.get("id") or "conferir"}',
                'reference':ref.strip(),'originalReference':original[index],'referenceStatus':'ready' if spec['valid'] else 'needs_review',
                'referenceError':spec.get('error'),'referenceId':spec.get('id'),'cost':None,'salePrice':None,'fields':{}})
        upload['products']=products
    return upload


def report_document(report):
    source=report.get('productSource') or {}
    products=source.get('products')
    references=[product.get('reference','') for product in products] if isinstance(products,list) else None
    return source_document(report['pdfId'],references)


def _pdf_references(upload):
    if upload.get('kind')=='html':
        specs=[];warnings=[]
        for product in upload.get('products',[]):
            spec=reference_spec(product.get('reference',''))
            if spec['valid'] and product.get('referenceStatus')!='needs_review':
                specs.append(spec)
            else:
                warnings.append(f"Produto {product.get('index','')} - {product.get('name','')}: referência pendente. {product.get('referenceError') or spec['error']} Não pesquisar por título nem emitir conclusão de mercado para este produto.")
        if not specs:
            raise ValueError('Nenhum produto tem um anúncio verificável. Corrija pelo menos um link antes de consultar a JoomPulse.')
        if len(specs)>30:
            raise ValueError('O documento ultrapassa o limite de 30 referências. Divida os produtos em arquivos menores.')
        return specs,warnings
    text=str(upload.get('text') or '')
    links=upload.get('links') or []
    if isinstance(links,list):
        text+='\n'+'\n'.join(link for link in links if isinstance(link,str))
    specs=[reference_spec(ref) for ref in extract_references(text)]
    if not specs:
        raise ValueError('O PDF não contém links Mercado Livre ou códigos MLB identificáveis. Inclua a referência de cada produto; nenhuma análise por IA foi iniciada.')
    invalid=[spec for spec in specs if not spec['valid']]
    if invalid:
        raise ValueError('Há referência de produto sem identidade verificável ou com códigos conflitantes: '+
                         '; '.join(str(spec['error']) for spec in invalid[:3])+'. Corrija os links no PDF antes de iniciar a IA.')
    if len(specs)>30:
        raise ValueError('O PDF contém mais de 30 referências obrigatórias e ultrapassa o limite de 30 consultas. Divida os produtos em PDFs menores.')
    warnings=[]
    ambiguous=[spec['id'] for spec in specs if spec['kind']=='ambiguous']
    if ambiguous:
        warnings.append('Códigos MLB sem URL: o tipo anúncio/catálogo ainda precisa de confirmação pela consulta exata ('+', '.join(ambiguous)+'). Título semelhante não confirma a identidade.')
    return specs,warnings


def import_market(report, text, origin='Texto revisado/importado pelo especialista'):
    if not str(text).strip(): raise ValueError('Cole o resultado da análise de mercado.')
    report=storage.validate_report(report)
    report['marketText']=str(text)
    report['sections']=[s for s in report['sections'] if not str(s['id']).startswith('market-')]
    report['sections'].insert(0, {'id':'market-analysis','title':'Análise de mercado e viabilidade','body':str(text)})
    report['sources']=[s for s in report.get('sources',[]) if not isinstance(s,dict) or s.get('kind')!='market']
    report['sources'].append({'kind':'market','name':origin,'date':storage.now()})
    report['warnings']=[w for w in report.get('warnings',[]) if not str(w).startswith('Análise de mercado pendente')]
    return report
