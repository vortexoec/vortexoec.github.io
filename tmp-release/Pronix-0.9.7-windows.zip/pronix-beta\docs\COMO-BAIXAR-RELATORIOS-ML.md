# Relatórios do Mercado Livre usados no beta

Fluxos conferidos na conta aberta em 30/10/2026. Os nomes podem variar por conta ou atualização da plataforma. O programa importa arquivos locais e não altera campanhas ou a conta.

## Desempenho da conta

1. Na Central de vendedores, abra **Métricas > Gerar relatórios**: [Relatórios de métricas](https://vendedores.mercadolivre.com.br/metricas/relatorios).
2. No card **Resumo de desempenho do negócio**, clique em **Gerar relatório**.
3. Escolha o período. Para cruzar com Ads, prefira **Data personalizada** e use as mesmas datas do relatório de publicidade.
4. Clique em **Gerar**, aguarde **Arquivo gerado com sucesso** e clique em **Baixar**.
5. Importe o XLSX no campo **Métricas da conta** do programa.

O beta lê a aba **Negócio**, com as linhas diárias de Data, Visitas, Quantidade de vendas, Unidades vendidas, Vendas brutas, cancelamentos e devoluções. As abas por faixa de preço e tipo de comprador não são somadas novamente. Rodapés sem data também não entram no total.

Na amostra real, o Mercado Livre agrupou o intervalo personalizado por **meses**. O beta também reconhece esse formato quando o cabeçalho do arquivo informa o intervalo completo. Nesse caso, calcula os totais do intervalo, mas não inventa dados diários: as janelas de 7/15/30/60/90 dias ficam indisponíveis e não é permitido recortar parte do intervalo. Use uma exportação diária para tendências por janela.

## Campanhas de Product Ads

1. Na Central de vendedores, abra **Publicidade > Relatórios**: [Publicidade](https://vendedores.mercadolivre.com.br/publicidade/resumo-anunciante?from=seller_central&validate_user=true).
2. Em **Campanhas de vendas**, escolha **Ir para relatório**.
3. Em **Tipo de relatório**, escolha **Campanhas > Padrão**. Há outra opção Padrão para anúncios patrocinados; a amostra validada neste beta é a de campanhas.
4. Defina o período e escolha **Agrupamento de dados: Diário**.
5. Clique em **Criar relatório**. A plataforma pode avisar que enviará um e-mail, mas o arquivo também fica em **Histórico de relatórios**.
6. Abra **Histórico de relatórios**, encontre o relatório com status **Pronto** e clique em **Baixar**.
7. Importe o XLSX no campo **Relatório de Ads** do programa. Confira a aba **Relatório de campanha** e o mapeamento sugerido.

As datas **Desde** e **Até** são lidas do arquivo. Se forem diferentes, a linha é um agregado; o programa não divide proporcionalmente uma semana ou mês para fingir que são dados diários. Receitas e vendas diretas/indiretas são mantidas separadas e o total atribuído não é somado novamente com seus componentes.

## Períodos precisam coincidir

Na validação, a opção **Mês anterior** do relatório da conta retornou 30/09–30/10/2026, enquanto **Últimos 30 dias** em Ads retornou 29/09–29/10/2026. Por isso, o nome do filtro não basta: confira as datas dentro dos dois arquivos.

TACOS só pode combinar investimento em Ads e faturamento total quando se referem ao mesmo período. A receita atribuída de Ads é diferente das vendas brutas da conta. Faturamento e ROAS não comprovam lucro sem custos e margem.

## O que os arquivos permitem analisar

- Conta: vendas brutas, quantidade de vendas e unidades, conversão, ticket, cancelamentos/devoluções e janelas completas de 7/15/30/60/90 dias quando houver histórico.
- Ads: investimento, receita atribuída, vendas, cliques, impressões, ROAS, ACOS, CTR, CPC, CVR e hipóteses de direcionamento condicionadas aos dados.
- Os relatórios não substituem fontes de estoque, custos por SKU, reputação ou pesquisa de concorrentes. Campos ausentes permanecem sinalizados.

As amostras reais usadas no desenvolvimento estão em `fontes/relatorios-mercado-livre/`, fora do código distribuível. Não publique arquivos de clientes junto do futuro instalador ou repositório público.
