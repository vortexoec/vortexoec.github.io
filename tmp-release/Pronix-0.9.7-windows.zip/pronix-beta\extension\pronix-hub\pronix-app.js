// Central de Análises - Vórtex · ponte entre a página do programa local (localhost:8765) e a extensão.
// Só existe nas páginas do próprio programa. Avisa a página que a extensão está instalada
// e recebe o vínculo direto dela: a conexão acontece sozinha, sem copiar e colar código.
(() => {
  if (window.__pronixAppBridgeListener) window.removeEventListener("message", window.__pronixAppBridgeListener);
  // Depois de uma atualização da extensão, a cópia antiga deste script fica sem contexto: ela se cala.
  const alive = () => { try { return !!chrome.runtime?.id; } catch { return false; } };
  const reply = data => window.postMessage({source: "pronix-extension", ...data}, location.origin);
  const version = chrome.runtime.getManifest().version;
  const announce = () => {
    if (!alive()) return;
    try {
      chrome.runtime.sendMessage({type: "app_status"}, response => {
        void chrome.runtime.lastError;
        reply({type: "pronix-extension-ready", version, paired: response?.data?.paired, connected: response?.data?.connected});
      });
    } catch { /* extensão recarregando */ }
  };
  const listener = event => {
    if (event.source !== window || event.origin !== location.origin || !alive()) return;
    const data = event.data;
    if (!data || data.source !== "pronix-app") return;
    if (data.type === "pronix-ping") { announce(); return; }
    if (data.type !== "pronix-pair" || typeof data.code !== "string" || data.code.length > 128) return;
    try {
      chrome.runtime.sendMessage({type: "app_pair", code: data.code}, response => {
        if (chrome.runtime.lastError) return reply({type: "pronix-pair-result", ok: false, error: "Extensão indisponível. Recarregue a página."});
        reply({type: "pronix-pair-result", ok: !!response?.ok, error: response?.error || ""});
      });
    } catch {
      reply({type: "pronix-pair-result", ok: false, error: "Extensão indisponível. Recarregue a página."});
    }
  };
  window.__pronixAppBridgeListener = listener;
  window.addEventListener("message", listener);
  announce();
})();
