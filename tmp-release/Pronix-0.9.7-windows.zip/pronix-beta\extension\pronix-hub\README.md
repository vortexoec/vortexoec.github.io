# Central de Análises - Vórtex · extensão do Chrome · 0.7.3

Extensão própria do Pronix Beta. Lê a tabela já aberta no Pronix Hub e envia os dados ao programa deste computador quando o especialista solicita a importação. Não depende do ChatGPT ou do Codex e não usa IA nesta etapa.

Requer Chrome 120 ou superior, Pronix Beta aberto e a conta do especialista conectada ao Pronix Hub no mesmo perfil do navegador. Em 04/11/2026, o fluxo real foi validado no Chrome: conexão, escolha da aba e importação pelo botão do programa, com nove produtos e todos os valores e links preservados. Duas referências de busca foram corretamente sinalizadas para revisão. A distribuição continua em fase beta.

## Instalar e parear o beta

1. Extraia o ZIP da extensão para uma pasta permanente. A pasta escolhida deve conter `manifest.json`.
2. Abra `chrome://extensions`, ative **Modo do desenvolvedor**, escolha **Carregar sem compactação** e selecione essa pasta.
3. Abra o Pronix Beta local e gere um código na importação do Hub.
4. Abra o popup **Pronix Hub — Importação Local**, cole o código e clique em **Conectar ao Pronix Beta**.
5. Abra a tabela do cliente no Hub, aguarde todos os produtos carregarem e volte ao programa local. Atualize a lista de abas, confira o nome do cliente, selecione a aba e solicite a importação.
6. Revise os dados importados no programa antes de iniciar a análise ou gerar o relatório.

Na importação do Hub, a extensão não abre abas, troca de cliente, navega, clica, preenche campos ou envia pareceres. Apenas as páginas `https://pronixhub.com.br/validacao-planilhas/<id>` são aceitas. Parâmetros, fragmentos, portas explícitas, subdomínios e outras rotas ficam fora da importação.

## Botões dentro do Pronix Hub (0.6.0)

- **Lista de planilhas:** botão **Importar na Central** (roxo) ao lado do prazo, só nas planilhas não concluídas. A extensão abre a planilha numa aba em segundo plano, lê os produtos, fecha a aba e envia ao Pronix, que já inicia a análise.
- **Dentro da planilha:** o mesmo botão ao lado de "revisor: …" e, acima de cada caixa de parecer, um balão com a sugestão do Pronix e o botão **Inserir** (marca 🟢/🟡/🔴 e preenche o texto). A extensão nunca clica em "Enviar validação".
- O script da página (`hub-ui.js`) só conversa com a própria extensão; os pedidos ao programa local passam pela conexão pareada.

## Conexão automática do Mercado Livre

Na versão 0.5.0 a extensão também conclui a **conexão do Mercado Livre sem copiar e colar**: quando você clica em Conectar conta no Pronix, a extensão abre o login do Mercado Livre, reconhece a página de retorno da autorização iniciada (mesmo código de segurança `state`), entrega o endereço ao programa local e fecha a aba sozinha. Para isso ela usa a permissão `tabs` (ver o endereço das abas); ela só age na aba que ela mesma abriu e por até 10 minutos.

A partir da versão 0.4.0 a extensão faz **apenas a importação da tabela do Hub**. A consulta à calculadora JoomPulse foi removida; as comissões vêm da API oficial do Mercado Livre pelo programa local. Ao atualizar, a permissão opcional para `joompulse.com` deixa de existir.

## O que é importado

- Nome do cliente no cabeçalho.
- Logística, cidade/estado e imposto informados no cabeçalho.
- Nome e links de referência de cada card `Produto N`.
- Os cinco campos do primeiro bloco comercial: custo de compra, preço de venda, margem informada, mínimo de compra e preço médio do produto.
- A leitura da automação: estado, data exibida, margem estimada, linhas de métricas, motivos e nota da coleta.
- O painel **Seu parecer**: estado selecionado, texto atual da caixa e nome do revisor informado no cabeçalho.

O HTML é reconstruído com esses dados; não é uma cópia da página inteira. Os pareceres ficam separados dos dados comerciais para comparação: não alteram automaticamente a análise, as taxas ou a identidade dos produtos. A caixa **Seu parecer** é somente lida; nenhum texto é escrito no Hub. Scripts, formulários e controles de outras partes da página ficam de fora. Valores ausentes permanecem ausentes. Um card incompleto interrompe a captura; aguarde a página carregar e tente novamente. Links múltiplos do mesmo card são preservados para revisão no programa.

A captura tem limite de 2 MiB em UTF-8 e 500 cards. A URL é conferida antes, durante e depois da leitura. Se a aba mudar, a importação é descartada. A extensão lê somente os cards presentes no DOM; não busca outras páginas nem aciona carregamento adicional.

## Conexão e desligamento

O pareamento vincula este perfil do Chrome a uma instalação local. O token fica em `chrome.storage.local` com acesso restrito aos contextos da própria extensão (`TRUSTED_CONTEXTS`). O código temporário não é salvo. O token não aparece no popup, nas URLs ou nos logs da extensão. Os produtos capturados não são persistidos pela extensão; o programa local gerencia os relatórios.

Toda comunicação da extensão é direcionada a `ws://127.0.0.1:8766/`. O endereço não é configurável e a política CSP permite conexão somente a essa porta. A extensão tenta reconectar a cada 30 segundos e envia uma mensagem de presença a cada 20 segundos enquanto conectada. Essas mensagens não capturam páginas.

**Desconectar** no popup apaga o token deste perfil, encerra a conexão e cancela a reconexão. Para invalidar a credencial também no programa local, use a revogação de pareamento no aplicativo. Cada especialista utiliza seu próprio programa e perfil do Chrome. Não copie o perfil do navegador ou seu armazenamento para distribuir a extensão.

## Atualização e distribuição futura

No beta, mantenha a pasta no mesmo caminho, substitua somente os arquivos públicos por uma versão revisada e clique em **Recarregar** em `chrome://extensions`. Mudar a pasta ou reinstalar pode mudar o identificador da extensão e exigir novo pareamento.

Para passar da 0.1.0 para a 0.2.0, recarregue a extensão e importe a tabela novamente. Capturas antigas mantêm seus dados comerciais, mas não ganham pareceres retroativamente. O programa aceita a extensão antiga e mostra um aviso para atualizar. Os testes desta versão verificam a leitura dos pareceres com DOM local; a conferência no Chrome deve ser feita após recarregar.

Para passar da 0.2.0 para a 0.3.0, recarregue a extensão na mesma pasta. O pareamento permanece salvo. A nova permissão da JoomPulse só é solicitada ao clicar no botão específico do popup; a importação já existente não depende dela.

O instalador futuro do programa pode incluir este pacote e orientar a instalação. A distribuição comum da extensão no Chrome deve passar pela Chrome Web Store; instalação externa administrada usa políticas corporativas. Este beta não modifica políticas, registro do Windows ou configurações de segurança para instalar silenciosamente. Consulte as [formas oficiais de distribuição do Chrome](https://developer.chrome.com/docs/extensions/how-to/distribute).

## Permissões e manutenção técnica

| Permissão | Finalidade |
|---|---|
| `scripting` | Leitura pontual do DOM em contexto isolado, após pedido do programa. |
| `storage` | Guardar a credencial do pareamento neste perfil. |
| `alarms` | Reconectar ao programa local após suspensão do service worker. |
| `https://pronixhub.com.br/*` | Consultar títulos/URLs e executar a leitura apenas no domínio do Hub; o código restringe a rota. |
| `http://127.0.0.1/*` | Escopo declarado para a comunicação com o serviço deste computador; a CSP e o código restringem o WebSocket à porta 8766. |

A permissão `tabs` é usada só para reconhecer o retorno do login do Mercado Livre na aba que a própria extensão abriu. Não são solicitadas permissões `cookies`, `debugger`, `activeTab`, `webRequest` ou `nativeMessaging`. Não há scripts de conteúdo permanentes, mensagens externas, recursos remotos ou código carregado da internet.

O [exemplo oficial de WebSockets](https://github.com/GoogleChrome/chrome-extensions-samples/tree/main/functional-samples/tutorial.websockets) funciona sem declarar host permissions para o socket em si. Mantemos o escopo explícito de loopback neste beta. A conexão funcionou no Chrome usado no teste real de 04/11/2026; outros ambientes ainda precisam de validação, inclusive quanto a eventuais solicitações de acesso à rede local. Não desative proteções do navegador como solução.

Fontes técnicas: [WebSocket no service worker](https://developer.chrome.com/docs/extensions/how-to/web-platform/websockets), [Chrome 120 e alarmes de 30 segundos](https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle#chrome-120), [host permissions e leitura de abas](https://developer.chrome.com/docs/extensions/reference/api/tabs#permissions), [permissões opcionais](https://developer.chrome.com/docs/extensions/reference/api/permissions), [scripting](https://developer.chrome.com/docs/extensions/reference/api/scripting), [acesso ao armazenamento](https://developer.chrome.com/docs/extensions/reference/api/storage#type-AccessLevel) e [CSP de extensões](https://developer.chrome.com/docs/extensions/reference/manifest/content-security-policy).

## Testes offline

Na raiz do projeto, com Node.js disponível:

```text
node --test extension/pronix-hub/tests/*.test.mjs
```

Os testes usam mocks do Chrome, WebSocket e DOM. Verificam pareamento, armazenamento restrito, reconexão, contrato das mensagens, limites, alteração de URL, captura mínima, múltiplas referências e campos comerciais incompletos. Também conferem a conexão do Mercado Livre: só a aba aberta pela extensão, com o mesmo código de segurança, é entregue ao programa e fechada. Não instalam a extensão nem acessam contas. O diretório `tests` não precisa entrar no ZIP distribuído.

Arquivos públicos do pacote: `manifest.json`, `service-worker.js`, `bridge.js`, `capture.js`, `popup.html`, `popup.js`, `popup.css` e `README.md`.
