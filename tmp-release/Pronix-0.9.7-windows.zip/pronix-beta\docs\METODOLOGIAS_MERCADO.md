# Métodos de análise: Gabriel e André / DVP

Leitura do material **Pronix — Análise de Mercado (Método DVP).pdf**, 20 páginas, recebido em 04/11/2026, e comparação com `services/market_rules.py` e `docs/ANALISE_MERCADO.md`. A página 20 contém apenas a marca. Os valores abaixo transcrevem critérios internos apresentados no material; não são regras oficiais nem uma tabela vigente de tarifas do Mercado Livre.

## Diferença principal

O DVP cruza **faturamento acumulado desde a criação** e idade dos anúncios (p. 8 e 10). O método Gabriel usa **vendas e faturamento observados dentro de até 120 dias**, com datas e cobertura explícitas. Os dois números não são intercambiáveis. Não se aplica a régua financeira do DVP a uma série parcial de 21 dias, à média mensal da JoomPulse ou ao total de 120 dias como se fossem faturamento acumulado.

A mensagem de André acrescenta: “sempre faturamento, dias médios e preço médio; só 10% do faturamento dos 5 anúncios que mais vendem”. O PDF não define a fórmula de “dias médios” nem resolve se “mais vendem” ordena unidades ou faturamento; suas páginas 7 e 10 citam maior faturamento e menor tempo de criação.

## Regras documentadas e comparação

| Critério | André / DVP, conforme o PDF | Gabriel / motor atual | Efeito na combinação |
| --- | --- | --- | --- |
| Objetivo, p. 4 | Demanda, viabilidade e espaço para posicionamento na primeira página. | Evidências de mercado, resultado financeiro e parecer do especialista. | Pilares podem ser mostrados lado a lado; não há fórmula de nota conjunta no PDF. |
| Logística, p. 5 e 18 | Correios abaixo de R$ 79 não recomendado; Flex, Places, Coleta e Full podem competir a partir de R$ 19. A p. 18 pede ticket **acima** de R$ 79 para Correios. | Modalidade e custos efetivos informados; não há bloqueio automático por ticket/logística. | Limite exato em R$ 79 precisa de confirmação. A afirmação da p. 5 de frete sem custo adicional não pode preencher frete zero sem cotação da conta. |
| Universo, p. 7, 12 e 18 | Busca ampla; primeira página; produtos iguais ou similares diretos. | Até cinco anúncios idênticos, ativos e atuais, com identidade confirmada. | DVP precisa de confirmação própria de similaridade e da primeira página. Candidatos de busca MCP não provam posição na página do Mercado Livre. |
| Seleção dos cinco, p. 7 e 10 | Maior faturamento e menor tempo de criação. | Primeiros cinco candidatos aceitos; a coleta prioriza métricas explicitamente disponíveis. | Não há prioridade ou desempate definido entre faturamento e idade; a ordem da coleta não é confirmação da seleção DVP. |
| Receita e período, p. 7–10 | Soma do faturamento acumulado dos cinco; calcular 10% dessa soma. | Soma de séries estimadas do anúncio em período comum dentro de 120 dias; 10% apenas aritmético. | Separar total vitalício, total da janela e médias históricas. Os 10% não são previsão garantida de participação do cliente. |
| Idade × faturamento, p. 8 | Até 30 dias: ≥ R$ 5 mil; até 60: R$ 7–20 mil; até 90: ≥ R$ 20 mil; acima de 120: ≥ R$ 40 mil. | Idade própria do anúncio separada de idade do catálogo e de tempo para vender estoque. | Faixas sobrepostas; 91–120 dias sem regra. Não está definido se a régua é filtro obrigatório por anúncio ou orientação. |
| Demanda por ticket, p. 9 | Sobre **10% da soma**: ticket ≤ R$ 79 valida em ≥ R$ 5 mil, alta de R$ 7–20 mil, oportunidade ≥ R$ 20 mil; ticket > R$ 79 valida em ≥ R$ 10 mil, alta de R$ 15–30 mil, oportunidade ≥ R$ 30 mil. Abaixo do mínimo: não validado. | Gab não formalizou limites de demanda; o motor não inventa faixas Alta/Média/Baixa. | Limiares DVP pertencem somente a esse método. Nos limites R$ 20/30 mil as classes se sobrepõem; falta regra de precedência. |
| Avaliações, p. 7, 9 e 18 | 30 ou mais nos últimos 60 dias; p. 9 chama de confirmação extra, p. 18 inclui no checklist. | Avaliações disponíveis são contexto; totais históricos não comprovam uma contagem em 60 dias. | Falta definir se a contagem é por anúncio, produto/catálogo ou soma dos cinco, e se é obrigatória. Não duplicar avaliações de um catálogo. |
| PMM, p. 12 | Média aritmética dos preços de iguais/similares diretos da primeira página; amostra representativa pode bastar se a variação for pequena. | Média aritmética dos preços atuais dos concorrentes idênticos aceitos. | O universo do PMM DVP pode ser maior que os cinco de faturamento; isso não está resolvido no material. |
| Discrepância, p. 12 | Variação acima de R$ 30 para ticket ≤ R$ 79; acima de R$ 70 para ticket > R$ 79. Alta discrepância + alta demanda **pode** indicar saturação. | Sem regra automática de saturação ou amplitude absoluta. | “Variação” não tem fórmula explícita; não transformar indício em reprovação automática. |
| Preço por logística, p. 13 | Correios: R$ 20–30 abaixo do PMM, tendo como referência direta o menor preço de concorrente com logística superior e giro; Agências/Coleta: próximo ou igual ao PMM; Full: PMM ou abaixo. | Preço até a média, tolerância percentual inicial de 0%, editável. | “Próximo” e prioridade entre PMM e menor preço não têm tolerância definida. Flex não aparece nesta tabela. |
| Margem e lote, p. 14 | Primeira compra até 30 un.: Correios “até −10%”; Agências/Coleta e Full breakeven. Pedido 50–100 un.: Agências/Coleta e Full ≥ 3%; Correios exige avaliar risco. | Lucro unitário positivo e meta informada. Lucro ≤ 0 é cenário financeiramente inviável. Custos completos exigidos. | DVP admite teste com perda/breakeven; isso não pode ser apresentado como lucro positivo. Faltam regras para 31–49 e >100 un., confirmação da margem líquida e interpretação exata de “até −10%”. |
| Diferenciação, p. 16 | Poucos Full podem abrir espaço; produto que só gira no Full exige operação Full; avaliar fotos, título, ficha e oferta. | Nenhuma inferência visual automática de anúncio superior ou de necessidade de Full. | Preservar análise qualitativa do especialista e evidências; faltam limites de “poucos” e “quase ninguém vende”. |
| Concorrência Full, p. 17 | Correios: até R$ 79 demanda mínima R$ 5 mil e zero Full; acima de R$ 79 R$ 7 mil e até 20 Full. Agências/Coleta: mínimos R$ 7 mil / R$ 10 mil, até 35 Full. Full: mínimos R$ 7 mil / R$ 10 mil, sem análise de concorrência Full necessária. | Sem contagem da primeira página; dado isFull de candidatos isolados não prova a página inteira. | Limiares divergem da p. 9: Correios alto ticket 7 mil × 10 mil; demais baixo ticket 7 mil × 5 mil. O título não explicita novamente a base de 10%. |

## Roteiro simples para conversar com André

Este é um roteiro interno, não uma lista para enviar de uma vez. Fazer **uma pergunta por vez**, aguardar a resposta e só seguir se a informação ainda fizer falta. Preferir um produto real que André já analisou. As dúvidas técnicas da tabela acima não precisam ser repassadas a ele como estão escritas.

**Primeira pergunta, já enviada — aguardar resposta:**

“André, desculpa, acho que compliquei minha pergunta. Quando você olha um anúncio que existe há dois anos, usa tudo que ele vendeu nesses dois anos ou só o que vendeu nos últimos meses?”

**Depois, somente se necessário:**

1. “Para escolher os cinco anúncios, você pega os que faturaram mais dinheiro? Por exemplo: um vendeu R$ 20 mil e outro R$ 50 mil.”
2. “Quando você fala em dias médios, quer dizer há quantos dias esses anúncios foram criados?”
3. “Para calcular o preço médio, você usa os preços desses mesmos cinco anúncios?”
4. “Um produto parecido, mas de outra marca ou tamanho, pode entrar nessa comparação?”

Se uma dúvida do PDF impedir a análise de um produto real, perguntar **só sobre aquele caso**. Exemplos de perguntas para usar separadamente:

- “Nesse produto de R$ 100 vendido pelos Correios, usamos R$ 7 mil ou R$ 10 mil como mínimo? Encontrei os dois valores no material.”
- “As 30 avaliações precisam aparecer em cada anúncio ou podem ser a soma dos cinco?”
- “Nesse primeiro lote, o cálculo deu prejuízo de R$ 2 por unidade. Você deixaria como teste a revisar ou já aprovaria?”

Não apresentar uma suposição como resposta confirmada. Se André preferir, pedir que mostre uma análise pronta e explique suas escolhas; isso costuma esclarecer melhor do que várias perguntas abstratas. Até haver resposta, o programa mostra a dúvida e os dados disponíveis, sem criar um número ou uma regra por conta própria.

## Evidências disponíveis no cache, sem novas consultas

O `meli_get_item/full_info` testado em 04/11/2026 fornece preço atual, marca, categoria, modalidade Full quando conhecida, `itemCreatedDate`, idade e médias históricas. Sua legenda define `itemRevenue1m`, `itemRevenue1w` e `itemRevenue1d` como **médias do anúncio**, e `revenue1m` como **média do catálogo**. Nenhum desses campos é receita acumulada comprovada.

`itemTotalSold` é um indicador vitalício em faixas, não um total exato de faturamento. Preço atual × indicador de vendidos não reconstrói receita histórica. `itemAgeDays` pode ser a idade da primeira oferta do catálogo, e `itemCreatedDate` pode ter precisão apenas mensal. Séries parciais de `meli_get_sales_estimates` também não substituem faturamento desde a criação.

O adapter DVP conserva preços e proveniência, mantém médias históricas apenas como contexto e deixa receita acumulada ausente até existir uma fonte explícita e conferida com escopo de anúncio ou catálogo. Nenhuma confirmação de primeira página, comparação ou seleção é herdada automaticamente.

## Recomendação de apresentação

Oferecer **Gabriel**, **André / DVP** e **Comparar**, reutilizando as fontes sem misturar definições. Cada método mantém sua seleção, período, critérios, pendências e parecer. A mesma receita de catálogo não pode ser somada várias vezes pelos seus vendedores. Uma divergência deve explicar a causa — por exemplo, o DVP admite um teste de breakeven enquanto o cenário financeiro não apresenta lucro — sem esconder o valor calculado.

Implementar somente critérios explícitos como cálculos e verificações identificados por página. Ambiguidades permanecem pendentes, e não recebem um limite arbitrário. O parecer final do especialista continua separado; não há média de notas, voto de maioria nem regra automática “passou em um método, aprovado”.
