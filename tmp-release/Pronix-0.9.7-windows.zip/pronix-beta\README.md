# Pronix Beta Local

Central local para importar produtos, analisar a conta e Ads, revisar o direcionamento e salvar os arquivos do cliente. Interface clara inspirada nas referências Pronix fornecidas. Beta **v0.8**, sem IA.

## Novidades da versão visual

- **Extensão própria Pronix Hub:** escolha uma tabela aberta no Chrome e importe produtos, custos, preços, links e pareceres anteriores. Os pareceres do robô/especialista ficam como histórico; não são evidência atual para a nova análise. Pareamento individual por código, transferência local e conferência antes da análise. Consulte a [ajuda de instalação](http://localhost:8765/api/hub/help) com o programa aberto. A importação não usa IA nem altera o Hub.
- **Reputação:** checklist inicial para anúncios, fotos, ficha, custos, envios e atendimento; permite começar sem planilha.
- **Análise de mercado:** parecer por produto e devolutiva editável de até 1.000 caracteres, com concorrentes, cenários, fontes e limitações para revisão. Tudo é calculado localmente, sem IA; a validação comercial com casos reais continua em andamento. Veja [ANALISE_MERCADO.md](docs/ANALISE_MERCADO.md).
- **Critérios técnicos:** “Análise comercial”, “Referência DVP” e “Comparação dos critérios” continuam em áreas recolhidas, sem alterar os identificadores das análises antigas. São cálculos locais para conferência, separados do parecer manual. Veja a [documentação dos critérios](docs/METODOLOGIAS_MERCADO.md).
- **Conta em operação:** indicadores, gráficos e ações para todas as campanhas importadas. Os campos são editáveis; fontes e lacunas permanecem explícitas.
- **Imagens de apoio:** até seis PNG/JPG/WebP por card ou seção, com legenda e ordem. O arquivo original pode ter até 5 MB; uma cópia normalizada é guardada localmente e incorporada ao PDF e ao HTML.
- **Modelos:** salve um card ou uma seção, incluindo prints, e insira em outro direcionamento. A cópia recebe novos identificadores; responsáveis, prazos e conclusão dos passos são reiniciados. Revise nomes, números e demais referências ao cliente que estejam no texto.
- **Reuniões:** conexão Google individual, escolha de agenda/evento e importação de transcrição acessível no Drive/Meet. Também aceita texto e TXT/VTT/SRT localmente. A extração de ações usa regras, conserva o trecho original e exige revisão; não transcreve vídeo. A autorização Google real ainda precisa ser configurada. Veja [REUNIOES.md](docs/REUNIOES.md).
- **PDF claro:** capa, indicadores, gráficos, cards, checklists, prints e referências. A opção de incluir o detalhamento controla a prévia e o PDF; TXT/JSON preservam as seções completas.

O HTML independente permite editar textos e marcar passos. Alterações feitas nessa cópia não atualizam o aplicativo. Para mudar dados de gráficos, imagens ou estrutura e manter TXT/PDF/JSON alinhados, use o editor do Pronix.

## Fluxo pelo Pronix Hub (o mais rápido)

1. Na lista de planilhas do Hub, clique em **Importar na Central** (roxo), ao lado do prazo (aparece só nas planilhas não concluídas). Também existe o botão dentro da planilha, ao lado do revisor.
2. O Pronix lê a planilha numa aba escondida, cria a análise (especialista = revisor do Hub) e consulta JoomPulse e Mercado Livre sozinho, em 2 a 3 minutos.
3. Ao abrir a planilha no Hub, cada produto ganha um **balão com a sugestão** (🟢 Validado, 🟡 Atenção ou 🔴 Invalidado) e a mensagem ao cliente. **Inserir** marca o parecer e preenche o texto; o envio da validação continua sendo seu.
4. Se você editar a devolutiva no Pronix, o balão passa a mostrar a sua versão.

O parecer automático usa: referência confirmada pela JoomPulse, anúncios parecidos (preço típico e vendas por mês), comissão oficial do ML, frete pela tabela oficial (peso tirado da linha "Embalagem" do Hub, o maior entre peso real e cúbico) e os custos informados. Os limites (margem mínima, preço acima da média aceito e procura mínima) ficam em **Preferências**.

## Abrir neste computador

Use o atalho **Pronix** na Área de Trabalho (ou `C:\Users\<você>\Pronix\Iniciar Pronix.bat`). O navegador abre em **http://localhost:8765**.

## Instalar em outro computador e atualizar

- Monte o pacote: `powershell -ExecutionPolicy Bypass -File instalador\montar-pacote.ps1` (gera `dist\Pronix-<versão>-windows.zip`, com Python próprio).
- O script gera dois arquivos: **`-equipe.zip`** (primeira instalação; leva os aplicativos do Mercado Livre e da JoomPulse embutidos, para as integrações terem só o botão Conectar — entregue só para a equipe, não publique) e o ZIP sem sufixo (atualizações; é o que vai para o GitHub).
- No outro computador: extraia o ZIP e rode **Instalar Pronix.cmd**. Instala em `%USERPROFILE%\Pronix`, cria atalhos e preserva os dados numa atualização.
- Atualização automática: publique a versão com `instalador\publicar-release.ps1 -Repo dono/nome` e informe o mesmo repositório em **Preferências → Atualizações**. O Pronix avisa no topo quando houver versão nova.

## Análise de mercado

Funciona sem IA: os dados vêm da JoomPulse e do Mercado Livre e todos os cálculos e o parecer são feitos neste computador, por regras fixas.

1. Abra **Análise de mercado** e informe cliente, especialista e data.
2. Use **Importar do Pronix Hub**, escolha a aba do cliente e confira os produtos (ou use PDF pesquisável / HTML salvo da página). Confira custo, preço e referência.
3. Clique em **Analisar produtos**. O programa consulta na JoomPulse o anúncio, os concorrentes e as vendas, e no Mercado Livre a comissão do preço informado.
4. Em cada produto, informe o **peso do pacote embalado (kg)** para estimar o frete pela tabela oficial e clique em **Atualizar comissão e frete**. Use o mesmo botão sempre que mudar preço ou peso.
5. Confirme a identidade do anúncio, os concorrentes idênticos e os custos. O parecer (Validado, Atenção ou Invalidado) e a mensagem de até 1.000 caracteres são montados automaticamente; edite se quiser e use **Salvar análise**.

Comissão e frete automáticos são **estimativas** usadas enquanto as taxas não forem conferidas pelo especialista. Outros custos desconhecidos continuam como pendência: sem eles o resultado fica em Atenção, com o saldo antes dos custos pendentes. Abrir uma análise salva não inicia consultas.

## Performance e Reputação

1. Abra **Nova análise** e escolha Performance ou Reputação.
2. Para Performance, importe as planilhas de Ads e de desempenho geral da conta. Confira a aba, o mapeamento e os períodos. O **Guia de importação** mostra os caminhos de download no Mercado Livre.
3. Informe somente os parâmetros conhecidos: margem antes de Ads, ROAS objetivo e estoque, quando aplicáveis. Campos ausentes não viram zero.
4. Gere o direcionamento, revise textos, indicadores, gráficos, cards, passos e imagens. Os cálculos de conta/Ads são locais, sem IA.
5. Salve a revisão e use **Salvar PDF** para gerar a entrega clara e as cópias editáveis. O detalhamento completo é opcional e começa desmarcado em novos relatórios.

O HTML independente permite editar textos e marcar passos. Essa cópia não atualiza o aplicativo; faça a revisão principal no Pronix para manter os formatos alinhados.

## Onde ficam os arquivos

```text
gabriel automação/
  Iniciar Pronix.bat
  fontes/                         arquivos originais e relatórios baixados
  analise de mercado/
    Nome do cliente/
      AAAA-MM-DD_identificador/
        Nome do cliente_AAAA-MM-DD.pdf
        Nome do cliente_AAAA-MM-DD.txt
        Nome do cliente_AAAA-MM-DD.html
        Nome do cliente_AAAA-MM-DD.json
  pronix-beta/
    app.py                        servidor local
    static/                       interface
    services/                     importadores, cálculos, conexão e exportação
    resources/                    prompts e base fornecida
    docs/                         ajuda e documentação
    examples/                     dados fictícios identificados
    tests/                        validação automática
    extension/pronix-hub/         extensão própria para Chrome (código público)
    runtime/                      uploads, histórico e registros locais
      jobs/                       progresso temporário para retomada (até 1 hora)
```

Relatórios do mesmo cliente no mesmo dia recebem identificadores diferentes para evitar sobrescrita. Ao editar um relatório já exportado, o PDF anterior é preservado em `runtime/revisions`; gere o novo PDF para entregar a versão atual. As revisões JSON também são preservadas.

O HTML exportado abre independentemente do programa e permite editar textos, salvar uma nova cópia HTML e imprimir em PDF. Essa cópia não altera automaticamente o relatório dentro do aplicativo. Para manter todos os formatos sincronizados, faça a revisão principal no programa.

Os arquivos são guardados localmente. **Esta pasta está dentro do iCloud Drive**: a sincronização configurada no Windows pode enviá-los ao seu iCloud. JoomPulse, Mercado Livre e Google usam suas respectivas conexões. As credenciais ficam em `%USERPROFILE%\.pronix-beta`, fora da pasta sincronizada.

## JoomPulse e outras contas

A conexão usa o MCP oficial da JoomPulse, OAuth com PKCE e retorno local. Cada instalação pode configurar a própria aplicação/conta; nenhuma credencial pessoal está embutida no código. As credenciais são criptografadas com DPAPI e guardadas em `%LOCALAPPDATA%/PronixBeta`, vinculadas ao usuário do Windows.

Enquanto o programa local estiver em execução, ele tenta renovar automaticamente o acesso quando a autorização permitir. Em **Integrações**, o contador indica o momento previsto dessa renovação, **não um prazo para fazer login novamente**. Uma falha temporária de rede mostra a espera ou a próxima tentativa. Se a autorização for recusada ou não puder mais ser renovada, o aviso global muda para **Reconectar JoomPulse** e a tela oferece o botão de reconexão. Autorizações sem renovação automática têm uma explicação própria sobre validade e novo login, sem contador de renovação.

O contador avança localmente a cada segundo. A interface lê o status a cada 30 segundos enquanto visível e ao retornar à janela; essa leitura não consulta produtos, não gasta a franquia MCP de dados e não inicia login ou renovação. A manutenção da autorização é feita separadamente pelo programa. As atualizações de status preservam os campos preenchidos, os rascunhos e as análises em andamento.

O programa aceita somente ferramentas declaradas como consulta pela JoomPulse. Não modifica anúncios, campanhas ou preços. A coleta pode consumir a franquia MCP da conta JoomPulse.

Consulte [JOOMPULSE.md](docs/JOOMPULSE.md). A aplicação desta conta foi conectada durante a validação do beta. Outras pessoas fazem seu próprio login e não recebem essa conexão ao copiar o código.


## Critérios dos cálculos

- ROAS = receita atribuída / investimento.
- ACOS = investimento / receita atribuída × 100.
- CTR = cliques / impressões × 100.
- CPC = investimento / cliques.
- CVR de Ads = vendas atribuídas / cliques × 100.
- TACOS = investimento / faturamento total da conta no mesmo período × 100.
- Margem e ROAS de equilíbrio dependem de uma margem antes de Ads informada pelo especialista.

Razões são calculadas sobre totais; não se faz média simples dos percentuais das linhas. Totais/subtotais não são somados novamente. Dados ausentes e divisões por zero são sinalizados. Receita atribuída não é lucro. Vendas não atribuídas não são classificadas automaticamente como orgânicas.

A conta e Ads têm receitas separadas. O cruzamento automático depende de períodos comprovadamente compatíveis. Janelas de 7/15/30/60/90 dias exigem dados diários suficientes; um arquivo mensal não é convertido artificialmente em dias.

Na análise de mercado, vendas e faturamento podem ser estimativas. Métricas repetidas de catálogo não são somadas como se fossem receitas independentes de várias ofertas. Os cenários monetários são calculados localmente com a comissão oficial do Mercado Livre e a tabela oficial de frete.

Estimativa com fonte pública não é cotação da conta. Custos desconhecidos permanecem ausentes, e o resultado informa premissas e limitações. Não há meta automática de 30%, lote padrão nem garantia de vendas. O parecer e a devolutiva continuam editáveis. Veja [ANALISE_MERCADO.md](docs/ANALISE_MERCADO.md).

## Frete e comissões na análise de mercado

A [tabela oficial de frete 48392](https://www.mercadolivre.com.br/ajuda/custos-envio-reputacao-verde-sem-reputacao_48392) está armazenada localmente e versionada. A cópia é vigente desde 24/08/2026, foi conferida em 04/11/2026 e tem prazo local de revisão até **04/12/2026**. Antes da vigência ou depois desse prazo, o programa não disponibiliza automaticamente seus valores. O prazo é uma política de conferência do programa, não uma garantia de preços inalterados.

O cálculo considera preço e peso tarifável do pacote para produtos novos e vendedores MercadoLíder, verdes ou sem reputação, no Full, Coleta e Agências. Correios, Flex, usados, anúncios gratuitos e categorias especiais ficam fora da aplicação automática. Frete rápido abaixo de R$ 79 substitui o valor padrão; não é somado a ele. Abaixo de R$ 19, há teto de 50% do preço. Peso estimado e condições ainda não conferidas permanecem como premissas.

Para ME2 comprovadamente nas modalidades `fulfillment`, `cross_docking` e `xd_drop_off`, a [regra oficial de comissão](https://developers.mercadolivre.com.br/pt_br/descricao-de-produtos/comissao-por-vender), conferida em 04/11/2026, estabelece tarifa fixa zero. O custo de envio continua separado da comissão percentual: não se soma a antiga tarifa fixa à tabela de frete. Essa regra não é estendida a Flex, Correios ou modalidade desconhecida.

A **comissão** (Clássico e Premium) e a **tarifa fixa** vêm da API oficial do Mercado Livre ([`/sites/MLB/listing_prices`](https://developers.mercadolivre.com.br/pt_br/comissao-por-vender)), consultada por categoria e por preço, sem abrir abas nem depender da extensão. A categoria vem da JoomPulse; se faltar, o Mercado Livre sugere a categoria pelo título e a análise avisa para conferir. Cada preço é consultado separadamente e a taxa nunca é transferida entre preços. Os valores são a tabela vigente da categoria: estimativa, não cotação particular da conta do cliente. Para usar, configure o aplicativo do Mercado Livre e conecte uma conta em **Integrações → Mercado Livre · comissões** (veja [docs/MERCADO-LIVRE.md](docs/MERCADO-LIVRE.md)). Sem essa conexão, a análise continua, mas a comissão fica como lacuna explícita.

A ferramenta local de **sensibilidade de frete** compara preços e hipóteses explícitas de peso tarifável do pacote usando a tabela vigente. As condições e a justificativa do peso acompanham cada alternativa. Não é peso medido, tarifa particular da conta ou cotação confirmada; comissão, tarifa fixa e frete continuam separados.

## Limites deste beta

- Importação de PDF pesquisável, HTML do Hub, XLSX, CSV e TSV. PDF digitalizado sem texto precisa de OCR externo. XLS antigo deve ser salvo como XLSX.
- A extensão beta é instalada manualmente no Chrome 120+. A página autenticada deve estar aberta e carregada; a captura lê a tabela comercial e preserva os pareceres anteriores como histórico, sem tratá-los como evidência atual nem modificar o Hub. Mudanças na estrutura da página podem exigir uma atualização do leitor.
- O modelo de conta é o **Resumo de desempenho do negócio** do Mercado Livre. Outros modelos podem precisar de adaptação.
- Reputação, estoque por SKU, taxas efetivas, logística e custos não são presumidos quando ausentes nos arquivos.
- A análise aceita até 30 produtos, processando até **três em paralelo**, com **20 rodadas por produto** e **40 consultas MCP de dados JoomPulse por tentativa**, compartilhadas por todos os produtos. O teto não é de 40 por produto. Retomar abre nova tentativa para os pendentes ou alterados, respeitando a franquia MCP e os limites do provedor. Uma falha não aciona a API paga nem substitui a revisão por uma resposta incompleta.
- **Validação em 04/11/2026:** conexão JoomPulse e coleta direta testadas; Em 06/11/2026 a consulta real de comissões pela API do Mercado Livre retornou os mesmos valores que a calculadora mostrava (cesto: 11,5%/16,5% a R$ 80 e 10,5%/13,5% a R$ 150); a análise comercial integral continua em validação. Os testes automatizados usam respostas simuladas e conexões locais. O caminho de API com chave não foi validado de ponta a ponta. Configuração salva, por si só, não comprova saldo, elegibilidade ou acesso ao modelo.
- **Testes em 04/11/2026:** passaram rodadas da suíte Python e testes offline da interface para conexão JoomPulse e preservação de análises/retomadas. O cenário de oito produtos e a retomada de sete concluídos foram simulados; não são benchmark real de tempo, custo ou qualidade. O [registro de validação](docs/VALIDACAO-BETA.md) informa o escopo de cada rodada e distingue os testes locais dos reais; código preparado e testes locais não comprovam que a nova consulta em lote já passou na conta real.
- Windows no beta, devido à proteção de credenciais. Há instalador (pasta `instalador`) e instruções guiadas dentro do programa no primeiro acesso (`static/pronix-tour.js`; Preferências > Rever instruções). A atualização automática pelo GitHub ainda não funciona com o repositório privado; por enquanto, atualiza-se rodando o instalador da versão nova. Não há sincronização entre usuários.
- Os relatórios de teste identificados como **TESTE BETA** não são documentos finais para clientes.

## Desenvolvimento e futura distribuição

Requer Python 3.11+ e as bibliotecas de `requirements.txt`. Para preparar outro ambiente de desenvolvimento:

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements.txt
.\.venv\Scripts\python app.py --open
```

O servidor escuta apenas em `127.0.0.1:8765`. As escritas usam um token da sessão local. A extensão conversa por WebSocket em `127.0.0.1:8766`, exige pareamento e não recebe acesso às demais APIs. O segredo local é vinculado à extensão e protegido pelo usuário Windows; nenhuma credencial acompanha o ZIP. Chaves não são retornadas à interface nem registradas nos logs. Mantenha `runtime`, arquivos de clientes e credenciais fora de futuros commits; os `.gitignore` já refletem essa separação.

Teste:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
node --check static/pronix-ui-v02.js
node runtime/qa/joompulse-auth-ui-smoke.cjs
```

Próxima etapa após sua aprovação: empacotar o runtime e criar instalador Windows assinado, definir a estratégia de aplicativo JoomPulse distribuído e publicar releases/versionamento no repositório escolhido. O beta não presume aprovação para publicar dados ou código.

Os testes automatizados usam respostas simuladas e servidores locais temporários; são separados dos testes reais de conexão descritos acima.
