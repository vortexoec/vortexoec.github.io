"""Deterministic market evidence collection using verified JoomPulse MCP tools.

No language model is called. Product identity and commercial viability remain
reviewable decisions: catalogue/title matches alone do not validate a variant.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date as Date, datetime, timedelta, timezone
import json
import math
import re
import unicodedata
from urllib.parse import parse_qs, unquote, urlsplit

from . import market_niche


MAX_PRODUCTS = 30
MAX_PAID_CALLS = 75
MAX_CANDIDATES = 5
MAX_SEARCH_RESULTS = market_niche.ROWS
MAX_SEARCH_ATTEMPTS = 3
PERIOD_BOUNDARY_WARNING = "Há semanas que ultrapassam o intervalo solicitado; elas não são somadas como se estivessem inteiramente dentro da janela de análise."
LEGACY_PERIOD_WARNING = "Há semanas que ultrapassam o intervalo solicitado; não representam vendas exatas de 30 dias."
MISSING = "Dado não disponível."
DOCUMENT_FIELDS = ("Custo de compra", "Preço de venda", "Margem informada", "Mínimo de compra", "Preço médio do produto")
ML_HOSTS = ("mercadolivre.com.br", "mercadolivre.com", "mercadolibre.com.br", "mercadolibre.com")
ID_RE = re.compile(r"\bMLBU?[- ]?\d{5,16}\b", re.I)


def _normal_id(value):
    return re.sub(r"[- ]", "", str(value)).upper()


def _id_value(value):
    if not isinstance(value, str):
        return None
    value = value.strip()
    return _normal_id(value) if ID_RE.fullmatch(value) else None


def reference_spec(ref) -> dict:
    """Classify an explicit reference without fetching or guessing a product.

    A selected offer may differ from its /p/ catalogue or /up/ grouping ID. Two selected offer
    IDs, or an offer conflicting with an item URL's path, are never resolved by
    choosing the first one. A bare MLB code has no namespace information.
    """
    result = {"reference": ref, "id": None, "kind": "unknown", "valid": False, "error": None}
    if not isinstance(ref, str):
        result["error"] = "Referência de produto inválida."
        return result
    value = ref.strip()
    bare_id = _id_value(value)
    if bare_id:
        result.update(id=bare_id, kind="ambiguous", valid=True)
        return result
    if value.lower().startswith("www."):
        value = "https://" + value
    try:
        parsed = urlsplit(value)
        host = (parsed.hostname or "").lower()
        if (parsed.scheme.lower() not in ("http", "https") or parsed.username or parsed.password
                or parsed.port not in (None, 80, 443)
                or not any(host == h or host.endswith("." + h) for h in ML_HOSTS)):
            raise ValueError()
    except (ValueError, TypeError):
        result["error"] = "Use um link Mercado Livre com o código do anúncio ou catálogo."
        return result
    selected_ids = set()
    for component in (parsed.query, parsed.fragment.lstrip("?")):
        for key, values in parse_qs(component, keep_blank_values=True).items():
            if key.lower() == "pdp_filters":
                selections = []
                for filters in values:
                    for entry in filters.split("|"):
                        field, separator, supplied = entry.partition(":")
                        if field.strip().lower() in ("item_id", "itemid"):
                            selections.append(supplied.strip() if separator else "")
            elif key.lower() in ("wid", "item_id", "itemid"):
                selections = values
            else:
                continue
            for supplied in selections:
                item_id = _id_value(supplied)
                if not item_id or item_id.startswith("MLBU"):
                    result["error"] = "O link contém um código de anúncio inválido nos parâmetros de seleção."
                    return result
                selected_ids.add(item_id)
    if len(selected_ids) > 1:
        result["error"] = "O link contém códigos de anúncio conflitantes. Confirme o link de uma única oferta."
        return result
    path = unquote(parsed.path)
    path_ids = {_normal_id(match.group()) for match in ID_RE.finditer(path)}
    catalogue = re.search(r"/p/(MLBU?[- ]?\d{5,16})(?=/|$)", path, re.I)
    catalogue_id = _normal_id(catalogue[1]) if catalogue else None
    grouping = re.search(r"/up/(MLBU[- ]?\d{5,16})(?=/|$)", path, re.I)
    grouping_id = _normal_id(grouping[1]) if grouping else None
    if grouping_id:
        if path_ids != {grouping_id}:
            result["error"] = "O caminho do link contém códigos de produto conflitantes."
        elif selected_ids:
            result.update(id=next(iter(selected_ids)), kind="item", valid=True, groupingId=grouping_id)
        else:
            result.update(kind="group", groupingId=grouping_id,
                          error="O link identifica um agrupamento MLBU, sem selecionar um anúncio. Informe o link de uma oferta específica.")
        return result
    if catalogue_id:
        if path_ids != {catalogue_id}:
            result["error"] = "O caminho do link contém códigos de produto conflitantes."
            return result
        if selected_ids:
            result.update(id=next(iter(selected_ids)), kind="item", valid=True, catalogId=catalogue_id)
        else:
            result.update(id=catalogue_id, kind="catalog", valid=True)
        return result
    if len(path_ids) > 1 or (selected_ids and path_ids and selected_ids != path_ids):
        result["error"] = "O anúncio do caminho e os parâmetros do link são conflitantes."
        return result
    ids = selected_ids or path_ids
    if ids:
        result.update(id=next(iter(ids)), kind="item", valid=True)
    elif host.startswith("lista."):
        result.update(kind="search", error="O link é uma página de busca, sem selecionar um anúncio. Informe o link de uma oferta específica.")
    else:
        result["error"] = "O link não contém um código MLB verificável. Use o link completo do anúncio ou catálogo."
    return result


def validate_reference_subject(ref, subject, tool) -> dict:
    """Validate only reference identity, not kit/variant equivalence or viability."""
    spec = reference_spec(ref)
    result = {"valid": False, "error": spec["error"], "referenceId": spec["id"],
              "kind": spec["kind"], "returnedId": None}
    if not spec["valid"]:
        return result
    expected_kind = {"meli_get_item": "item", "meli_get_product": "catalog"}.get(tool)
    if not expected_kind or (spec["kind"] != "ambiguous" and spec["kind"] != expected_kind):
        result["error"] = "A consulta trocou o tipo da referência entre anúncio e catálogo."
        return result
    if not isinstance(subject, dict):
        result["error"] = "A consulta não retornou uma identidade de produto verificável."
        return result
    field = "itemId" if expected_kind == "item" else "productId"
    returned_id = _id_value(subject.get(field))
    result.update(kind=expected_kind, returnedId=returned_id)
    if not returned_id:
        result["error"] = "A consulta não informou " + field + " para confirmar a referência recebida."
    elif returned_id != spec["id"]:
        result["error"] = "Identidade divergente: a consulta retornou outro " + ("anúncio" if expected_kind == "item" else "catálogo") + ". Nenhuma métrica foi associada à referência."
    else:
        result.update(valid=True, error=None)
    return result


def _reference_id(ref):
    spec = reference_spec(ref)
    return spec["id"] if spec["valid"] else ref


def extract_references(text: str) -> list[str]:
    """Resolve only explicit marketplace links / MLB IDs from user-provided text."""
    found = []
    consumed = []
    for match in re.finditer(r"(?:https?://|www\.)[^\s<>\"\[\]]+", text, re.I):
        ref = match.group().rstrip(".,;:)")
        if ref.lower().startswith("www."):
            ref = "https://" + ref
        consumed.append((match.start(), match.end()))
        try:
            hostname = (urlsplit(ref).hostname or "").lower()
        except ValueError:
            continue
        if any(hostname == h or hostname.endswith("." + h) for h in ML_HOSTS):
            found.append((match.start(), ref))
    for match in ID_RE.finditer(text):
        if not any(start <= match.start() < end for start, end in consumed):
            found.append((match.start(), _normal_id(match.group())))
    # Visible bare codes can precede the PDF's hyperlink appendix. Prefer the
    # typed URL when it disambiguates that same code, regardless of text order.
    typed = {}
    for _, ref in found:
        spec = reference_spec(ref)
        if spec["valid"] and spec["kind"] != "ambiguous":
            typed.setdefault(spec["id"], set()).add(spec["kind"])
    result, seen = [], {}
    for _, ref in sorted(found):
        spec = reference_spec(ref)
        kind = spec["kind"]
        if kind == "ambiguous" and len(typed.get(spec["id"], set())) == 1:
            kind = next(iter(typed[spec["id"]]))
        key = (kind, spec["id"]) if spec["valid"] else ("invalid", ref)
        if key not in seen:
            seen[key] = len(result)
            result.append(ref)
        elif spec["valid"] and spec["kind"] != "ambiguous" and reference_spec(result[seen[key]])["kind"] == "ambiguous":
            result[seen[key]] = ref
    return result


def unpack_result(result: dict) -> dict:
    if isinstance(result.get("structuredContent"), dict):
        return result["structuredContent"]
    for block in result.get("content", []):
        if block.get("type") == "text":
            try:
                parsed = json.loads(block.get("text", ""))
                if isinstance(parsed, dict):
                    return parsed
            except (ValueError, TypeError):
                pass
    return {"text": "\n".join(x.get("text", "") for x in result.get("content", []) if x.get("type") == "text")}


def rows_from(result: dict) -> list[dict]:
    columns = result.get("columns")
    rows = result.get("data")
    if not isinstance(columns, list) or not isinstance(rows, list):
        return []
    return [dict(zip(columns, row)) for row in rows if isinstance(row, list) and len(row) == len(columns)]


def period_estimates(result: dict) -> list[dict]:
    # Never substitute a lifetime/monthly average for a closed-period estimate.
    return [row for row in rows_from(result) if row.get("kind") == "estimate"
            and row.get("periodStart") and row.get("periodEnd")]


def _money(value):
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return MISSING
    return "R$ " + f"{value:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")


def _number(value):
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return MISSING
    return f"{value:g}".replace(".", ",")


def _numeric(value):
    """Only provider numbers count as numbers; unavailable is never zero."""
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return None
    try:
        return value if math.isfinite(value) and value >= 0 else None
    except (ValueError, OverflowError):
        return None


def _text(value):
    return value.strip() if isinstance(value, str) and value.strip() else None


def _day(value):
    try:
        return Date.fromisoformat(value) if isinstance(value, str) else None
    except ValueError:
        return None


def _public_url(value):
    if not isinstance(value, str):
        return None
    try:
        parsed = urlsplit(value)
        return value if parsed.scheme in ("http", "https") and parsed.hostname and not parsed.username and not parsed.password else None
    except ValueError:
        return None


def adapt_tool_arguments(tool, arguments):
    """Follow the advertised schema, including legacy singular MCP parameters.

    This only changes parameter spelling/cardinality, never the selected IDs.
    A rejected batch is not truncated or sent as a paid request.
    """
    args = deepcopy(arguments)
    schema = tool.get("inputSchema", {}) if isinstance(tool, dict) else {}
    properties = schema.get("properties", {})
    required = schema.get("required", [])
    if not isinstance(properties, dict):
        properties = {}
    for singular, plural in (("id", "ids"), ("query", "queries"), ("product", "products"), ("category", "categories")):
        if singular not in args and plural not in args:
            continue
        if singular in args and plural in args:
            raise ValueError(f"Parâmetros conflitantes: {singular}/{plural}.")
        target = (plural if plural in properties and (singular not in properties or plural in required)
                  else singular if singular in properties else None)
        if target == plural and singular in args:
            args[plural] = [args.pop(singular)]
        elif target == singular and plural in args:
            values = args.pop(plural)
            if not isinstance(values, list) or len(values) != 1:
                raise ValueError("A ferramenta não aceita este lote de referências.")
            args[singular] = values[0]
    for key, value in args.items():
        prop = properties.get(key, {})
        if schema.get("additionalProperties") is False and key not in properties:
            raise ValueError(f"Parâmetro não disponibilizado pela ferramenta: {key}.")
        if prop.get("type") == "array" and not isinstance(value, list):
            raise ValueError(f"O parâmetro {key} precisa ser uma lista.")
        if isinstance(value, list):
            maximum = prop.get("maxItems", 100)
            minimum = prop.get("minItems", 0)
            if len(value) > maximum or len(value) < minimum:
                raise ValueError(f"O lote do parâmetro {key} excede os limites da ferramenta.")
    if any(key not in args for key in required):
        raise ValueError("A ferramenta exige parâmetros não disponíveis nesta consulta.")
    references = args.get("ids", [args["id"]] if "id" in args else [])
    name = tool.get("name") if isinstance(tool, dict) else None
    if references and name in ("meli_get_sales_estimates", "meli_get_review_history"):
        first, last = _day(args.get("date_from")), _day(args.get("date_to"))
        if first and last:
            if first > last:
                raise ValueError("Intervalo de consulta inválido.")
            granularity = args.get("granularity", "month")
            if name == "meli_get_review_history":
                periods = (last - first).days + 1
            elif granularity == "week":
                periods = ((last - timedelta(days=last.weekday())) - (first - timedelta(days=first.weekday()))).days // 7 + 1
            elif granularity == "month":
                periods = (last.year - first.year) * 12 + last.month - first.month + 1
            else:  # Daily sales exposes one average row, not a daily time series.
                periods = 1
            if len(references) * periods > 100:
                raise ValueError("O lote excede 100 combinações de referência e período; divida a consulta.")
    return args


def normalize_historical_averages(row, *, item_id=None, catalog_id=None, source_result=None,
                                  observed_at=None, source_tool="meli_get_item"):
    """Preserve source averages as context, never as a dated sales estimate."""
    source_result = source_result or {}
    legend = source_result.get("_legend", {})
    legend = legend if isinstance(legend, dict) else {}
    averages = {"basis": "creation_date_average", "periodSpecific": False,
                "item": {}, "catalog": {}, "source": "JoomPulse MCP / " + source_tool,
                "sourceRefreshedAt": _text(source_result.get("lastRefreshTime")),
                "observedAt": observed_at, "legend": {}}
    for scope, entity_id, prefix in (("item", item_id, "item"), ("catalog", catalog_id, "")):
        if not entity_id:
            continue
        for period, suffix in (("month", "1m"), ("week", "1w"), ("day", "1d")):
            units_field = prefix + ("Sales" if prefix else "sales") + suffix
            revenue_field = prefix + ("Revenue" if prefix else "revenue") + suffix
            units, revenue = _numeric(row.get(units_field)), _numeric(row.get(revenue_field))
            if units is None and revenue is None:
                continue
            averages[scope][period] = {"units": units, "revenue": revenue, "scope": scope,
                "entityId": entity_id, "sourceFields": {"units": units_field, "revenue": revenue_field}}
            for field in (units_field, revenue_field):
                if isinstance(legend.get(field), str):
                    averages["legend"][field] = legend[field]
    return averages if averages["item"] or averages["catalog"] else None


def _reported_performance(row, catalog_id, item_id, source_result):
    """Provider period summaries are context, never undated 120-day periods."""
    periods = {}
    for suffix, label in (("LastMonth", "lastMonth"), ("PrevMonth", "previousMonth"),
                          ("LastWeek", "lastWeek"), ("PrevWeek", "previousWeek")):
        units, revenue = _numeric(row.get("sales" + suffix)), _numeric(row.get("revenue" + suffix))
        if units is not None or revenue is not None:
            periods[label] = {"units": units, "revenue": revenue,
                              "sourceFields": {"units": "sales" + suffix, "revenue": "revenue" + suffix}}
    if not periods:
        return None
    return {"scope": "catalog" if catalog_id else "item", "entityId": catalog_id or item_id,
            "estimated": True, "basis": "provider_closed_period_summary", "periods": periods,
            "growthRatios": {field: row[field] for field in ("revenueMonthGrowth", "salesMonthGrowth", "revenueWeekGrowth", "salesWeekGrowth")
                if isinstance(row.get(field), (int, float)) and not isinstance(row[field], bool)
                and abs(row[field]) <= 1e15 and math.isfinite(row[field])},
            "periodLabels": [str(note) for note in source_result.get("notes", []) if isinstance(note, str)
                             and ("LastMonth" in note or "LastWeek" in note)],
            "sourceRefreshedAt": _text(source_result.get("lastRefreshTime")),
            "note": "Resumos da fonte para meses/semanas fechados; não são totais vitalícios nem substituem séries datadas."}


def _bestseller_positions(value):
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (ValueError, TypeError):
            return []
    return [{"category_id": _text(row.get("category_id")), "category_name": _text(row.get("category_name")),
             "category_level": _numeric(row.get("category_level")), "position": _numeric(row.get("position"))}
            for row in value[:20] if isinstance(row, dict)] if isinstance(value, list) else []


def normalize_market_item(row, *, kind="item", source_result=None, observed_at=None,
                          reference_validated=False, reference_url=None, source_tool=None):
    """Normalize observed MCP fields, preserving unknowns and their provenance.

    MLBU groups variations; MLB-<item> in productId is a non-catalog stub. Neither
    is an identity anchor for identical competing products. The current MCP has
    no model/SKU/voltage/pack/dimension attributes, so this never asserts them.
    """
    row = row if isinstance(row, dict) else {}
    source_result = source_result or {}
    observed_at = observed_at or datetime.now(timezone.utc).isoformat()
    item_id = _id_value(row.get("itemId"))
    product_id = _text(row.get("productId"))
    catalog_id = (product_id.upper() if row.get("isCatalogProduct") is True and product_id and
                  re.fullmatch(r"MLB\d{5,16}", product_id, re.I) else None)
    identity = catalog_id if kind == "catalog" else item_id
    source_url = _public_url(row.get("meliUrl"))
    direct_url, url_basis = None, None
    for value, basis in ((reference_url, "document_reference"), (source_url, "provider_url")):
        spec = reference_spec(value)
        if spec["valid"] and spec["id"] == identity and spec["kind"] == kind:
            direct_url, url_basis = value, basis
            break
    if not direct_url and identity:
        direct_url = ("https://www.mercadolivre.com.br/p/" + identity if kind == "catalog" else
                      "https://produto.mercadolivre.com.br/MLB-" + identity.removeprefix("MLB"))
        url_basis = "canonical_id_link"
    refreshed = _text(source_result.get("lastRefreshTime"))
    current = None
    if refreshed:
        try:
            stamp = datetime.fromisoformat(refreshed.replace("Z", "+00:00"))
            observed = datetime.fromisoformat(observed_at.replace("Z", "+00:00"))
            current = stamp.astimezone(timezone.utc).date() == observed.astimezone(timezone.utc).date() if stamp.tzinfo and observed.tzinfo else None
        except ValueError:
            pass
    status = _text(row.get("itemStatus"))
    active = status == "active" if status else (True if identity and reference_validated else None)
    category_path = [_text(row.get(f"categoryL{level}Name")) for level in range(1, 8)]
    category_path = [part for part in category_path if part]
    brand = _text(row.get("brand"))
    return {"id": identity, "kind": kind, "itemId": item_id if kind == "item" else None,
            "catalogId": catalog_id, "userProductId": _text(row.get("userProductId")),
            "sourceProductId": product_id, "title": _text(row.get("title")), "brand": brand,
            "price": _numeric(row.get("price")), "categoryId": _text(row.get("categoryLeafId")),
            "categoryPath": category_path, "categoryName": _text(row.get("categoryLeafName")) or (category_path[-1] if category_path else None),
            "listingType": _text(row.get("listingType")),
            "sellerId": _text(row.get("sellerId")), "sellerName": _text(row.get("sellerName")),
            "sellerReputation": _text(row.get("sellerReputation")), "sellerMedal": _text(row.get("sellerMedal")),
            "imageUrl": _public_url(row.get("imageUrl")), "url": direct_url, "urlBasis": url_basis,
            "sourceUrl": source_url, "pulseUrl": _public_url(row.get("pulseUrl")), "linkChecked": False,
            "active": active, "activeBasis": "explicit_item_status" if status else "provider_active_only_lookup" if active is True else None,
            "current": current, "observedAt": observed_at, "sourceRefreshedAt": refreshed,
            "referenceValidated": reference_validated is True, "identityValidated": False, "exactMatch": False,
            "isFull": row.get("isFull") if isinstance(row.get("isFull"), bool) else None,
            "hasFreeShipping": row.get("hasFreeShipping") if isinstance(row.get("hasFreeShipping"), bool) else None,
            "isCatalogProduct": row.get("isCatalogProduct") if isinstance(row.get("isCatalogProduct"), bool) else None,
            **{flag: row.get(flag) if isinstance(row.get(flag), bool) else None
               for flag in ("isBuyBoxWinner", "isOfficialStore", "isInternational", "isBestseller")},
            "itemStatus": status, "imageCount": _numeric(row.get("imageCount")),
            "priceHistory": {"original": _numeric(row.get("originalPrice")),
                "minimum": _numeric(row.get("priceHistoricMin")), "maximum": _numeric(row.get("priceHistoricMax")),
                "maxDiscountRatio": _numeric(row.get("maxDiscountPercent"))},
            "competitionContext": {"sellerCount": _numeric(row.get("sellerCount")),
                "priceMin": _numeric(row.get("priceMin")), "priceMax": _numeric(row.get("priceMax")),
                "buyBoxItemId": _id_value(row.get("buyBoxItemId")),
                "buyBoxPrice": _numeric(row.get("buyBoxPrice"))},
            "bestsellerPositions": _bestseller_positions(row.get("bestsellersInfo")),
            "reportedPerformance": _reported_performance(row, catalog_id, item_id, source_result),
            "salesBadge": {"unitsBucket": _numeric(row.get("itemTotalSold", row.get("totalSold"))),
                "scope": "catalog" if catalog_id and "itemTotalSold" not in row else "item",
                "approximate": True, "note": "Indicador acumulado em faixas; não é faturamento nem ritmo de vendas."},
            "rating": _numeric(row.get("rating")), "reviewsCount": _numeric(row.get("reviewsCount")),
            "exposureDays": _numeric(row.get("itemAgeDays")),
            "exposureBasis": "catalog_first_item_age" if catalog_id else "item_age",
            "createdAt": _text(row.get("itemCreatedDate")), "createdAtPrecision": "source_may_be_month",
            "attributes": {"brand": brand, "model": None, "sku": None, "gtin": None, "voltage": None,
                           "capacity": None, "size": None, "weight": None, "packCount": None, "kitContents": None, "color": None},
            "attributeSource": "A ferramenta MCP fornece marca, mas não os demais atributos de identidade.",
            "historicalAverages": normalize_historical_averages(row, item_id=item_id if kind == "item" else None,
                catalog_id=catalog_id, source_result=source_result, observed_at=observed_at,
                source_tool=source_tool or ("meli_get_product" if kind == "catalog" else "meli_get_item")),
            "source": "JoomPulse MCP", "periods": [], "catalogPeriods": []}


def normalize_sales_periods(result, reference, requested_from, requested_to):
    """Keep item and catalog estimates distinct, without filling missing periods."""
    periods, warnings, by_key = [], [], {}
    ref_id = reference.get("id")
    first, last = _day(requested_from), _day(requested_to)
    for row in period_estimates(result):
        if not ref_id or _id_value(row.get("id")) != ref_id:
            warnings.append("Uma linha de estimativas sem identidade coincidente foi excluída.")
            continue
        start, end = _day(row.get("periodStart")), _day(row.get("periodEnd"))
        if not start or not end or start > end:
            warnings.append("Uma linha de estimativas com período inválido foi excluída.")
            continue
        scope = row.get("scope")
        values = []
        if scope == "item" and reference.get("kind") == "item":
            values.append(("item", ref_id, row.get("estSales"), row.get("estRevenue")))
        elif scope == "catalog" and reference.get("catalogId"):
            values.append(("catalog", reference["catalogId"], row.get("estSales"), row.get("estRevenue")))
            if reference.get("kind") == "item":
                values.append(("item", ref_id, row.get("itemEstSales"), row.get("itemEstRevenue")))
        else:
            warnings.append("Uma linha de estimativas com escopo incompatível foi excluída.")
            continue
        for measured_scope, entity_id, units, revenue in values:
            row_key = (measured_scope, entity_id, start.isoformat(), end.isoformat())
            period = {"scope": measured_scope, "entityId": entity_id,
                      "itemId": entity_id if measured_scope == "item" else None,
                      "catalogId": reference.get("catalogId"), "periodStart": start.isoformat(),
                      "periodEnd": end.isoformat(), "units": _numeric(units), "revenue": _numeric(revenue),
                      "estimated": True, "periodDays": (end - start).days + 1,
                      "withinRequestedPeriod": bool(first and last and start >= first and end <= last),
                      "closedPeriod": bool(last and end < last), "source": "JoomPulse MCP / meli_get_sales_estimates",
                      "sourceRefreshedAt": _text(result.get("lastRefreshTime")),
                      "observedAt": reference.get("observedAt"), "conflicting": False}
            period["eligibleForRequestedPeriod"] = period["withinRequestedPeriod"] and period["closedPeriod"]
            if row_key in by_key:
                previous = by_key[row_key]
                if (previous["units"], previous["revenue"]) != (period["units"], period["revenue"]):
                    previous.update(conflicting=True, eligibleForRequestedPeriod=False)
                    warnings.append("Estimativas duplicadas com valores divergentes exigem revisão.")
                continue
            by_key[row_key] = period
            periods.append(period)
    for index, period in enumerate(periods):
        for other in periods[index + 1:]:
            if (period["scope"], period["entityId"]) == (other["scope"], other["entityId"]) and period["periodStart"] <= other["periodEnd"] and other["periodStart"] <= period["periodEnd"]:
                period.update(conflicting=True, eligibleForRequestedPeriod=False)
                other.update(conflicting=True, eligibleForRequestedPeriod=False)
                warnings.append("Períodos sobrepostos foram sinalizados para não somar demanda duas vezes.")
    if any(not period["withinRequestedPeriod"] for period in periods):
        warnings.append(PERIOD_BOUNDARY_WARNING)
    return periods, list(dict.fromkeys(warnings))


def re_enrich_cached_bundle(bundle, audit=None):
    """Return a copy enriched from successful, identity-matched cached calls.

    No network or file I/O. Original audit, commercial decisions, prices and
    period values remain unchanged. Only derived evidence metadata is updated.
    ``audit`` can supply the raw audit separately when bundle is evidence only.
    """
    if not isinstance(bundle, dict):
        raise ValueError("O pacote de evidências precisa ser um registro válido.")
    enriched = deepcopy(bundle)
    sources = {}

    def index_audit(value):
        if not isinstance(value, dict):
            return
        for run in value.get("runs", []):
            index_audit(run)
        for call in value.get("calls", []):
            if not isinstance(call, dict) or call.get("success") is not True:
                continue
            tool = call.get("tool")
            if tool not in ("meli_get_item", "meli_get_product", "meli_search_products"):
                continue
            result = call.get("result")
            if not isinstance(result, dict) or result.get("candidates"):
                continue
            rows = rows_from(result)
            args = call.get("arguments", {})
            ids = args.get("ids", [args["id"]] if "id" in args else [])
            requested = {_id_value(value) for value in ids} if isinstance(ids, list) else set()
            kind = "catalog" if tool == "meli_get_product" else "item"
            identity_field = "productId" if kind == "catalog" else "itemId"
            for row in rows:
                identity = _id_value(row.get(identity_field))
                if not identity or identity.startswith("MLBU"):
                    continue
                if tool != "meli_search_products" and identity not in requested:
                    continue
                if sum(_id_value(other.get(identity_field)) == identity for other in rows) != 1:
                    continue
                key = kind, identity
                rank = (tool != "meli_search_products", _text(call.get("at")) or "")
                if key not in sources or rank > sources[key][0]:
                    sources[key] = (rank, row, result, tool, call.get("at"))

    index_audit(audit if audit is not None else bundle.get("audit", {}))
    evidence = enriched.get("evidence", enriched)
    if not isinstance(evidence, dict) or not isinstance(evidence.get("products"), list):
        return enriched
    old_period = deepcopy(evidence.get("period", {}))
    end = _day(old_period.get("end")) if isinstance(old_period, dict) else None
    if not end:
        end = _day(evidence.get("historyPeriod", {}).get("end"))
    start = end - timedelta(days=119) if end else None
    if end:
        evidence["period"] = {"start": start.isoformat(), "end": end.isoformat()}
        evidence["historyPeriod"] = dict(evidence["period"])
        evidence["recentPeriod"] = {"start": (end - timedelta(days=29)).isoformat(), "end": end.isoformat()}

    def visit(node):
        if not isinstance(node, dict):
            return
        source = sources.get((node.get("kind"), node.get("id")))
        if source:
            _, row, result, tool, at = source
            normalized = normalize_market_item(row, kind=node["kind"], source_result=result,
                                               observed_at=at or node.get("observedAt"), source_tool=tool)
            for field in ("historicalAverages", "categoryName", "categoryPath"):
                if normalized.get(field) is not None and normalized.get(field) != []:
                    node[field] = normalized[field]
        periods = []
        for key in ("periods", "catalogPeriods"):
            for period in node.get(key, []):
                if not isinstance(period, dict):
                    continue
                first, last = _day(period.get("periodStart")), _day(period.get("periodEnd"))
                if end and first and last:
                    period["withinRequestedPeriod"] = start <= first <= last <= end
                    period["closedPeriod"] = last < end
                    period["eligibleForRequestedPeriod"] = (period["withinRequestedPeriod"] and
                        period["closedPeriod"] and not period.get("conflicting", False))
                periods.append(period)
        if end and isinstance(node.get("limitations"), list):
            node["limitations"] = [reason for reason in node["limitations"]
                                   if reason not in (LEGACY_PERIOD_WARNING, PERIOD_BOUNDARY_WARNING)]
            if any(period.get("withinRequestedPeriod") is False for period in periods):
                node["limitations"].append(PERIOD_BOUNDARY_WARNING)
        for key in ("reference",):
            visit(node.get(key))
        for key in ("candidates", "competitors"):
            for child in node.get(key, []):
                visit(child)

    for product in evidence["products"]:
        visit(product)
    evidence["offlineEnrichment"] = {"version": 1, "previousPeriod": old_period,
                                      "source": "cached_audit", "networkCalls": 0}
    return enriched


def normalize_review_history(result, item_id, requested_from, requested_to):
    rows = []
    for row in rows_from(result):
        day = _day(row.get("date"))
        if _id_value(row.get("itemId")) != item_id or not day or not requested_from <= day.isoformat() <= requested_to:
            continue
        rows.append({"date": day.isoformat(), "cumulativeCount": _numeric(row.get("reviewsCountToDate")), "rating": _numeric(row.get("rating"))})
    rows.sort(key=lambda row: row["date"])
    first, last = (rows[0], rows[-1]) if rows else ({}, {})
    counts = first.get("cumulativeCount"), last.get("cumulativeCount")
    delta = counts[1] - counts[0] if len(rows) >= 2 and all(value is not None for value in counts) and counts[1] >= counts[0] else None
    return {"itemId": item_id, "requestedStart": requested_from, "requestedEnd": requested_to,
            "observedStart": first.get("date"), "observedEnd": last.get("date"), "rows": rows,
            "countChangeObserved": delta,
            "fullWindow": bool(rows and first["date"] == requested_from and last["date"] == requested_to),
            "reviewTextsAvailable": False, "source": "JoomPulse MCP / meli_get_review_history",
            "sourceRefreshedAt": _text(result.get("lastRefreshTime")),
            "limitation": "Contagens acumuladas observadas; não são os textos nem a confirmação de todas as avaliações dos últimos 7 dias."}


def _candidate_reason(reference, candidate):
    if reference.get("catalogId") and reference["catalogId"] == candidate.get("catalogId"):
        return "Mesmo catálogo informado pela fonte; variação, quantidade e kit ainda exigem confirmação."
    return "Candidato da busca por palavras, marca e categoria; identidade, variação e kit não foram confirmados."


def _search_key(value):
    return "".join(character for character in unicodedata.normalize("NFKD", str(value).casefold())
                   if not unicodedata.combining(character))


def _search_query(title, brand=None):
    """Compact wording, without guessing which model/variant tokens matter.

    Keep all unknown words, numbers, units, model codes and kit quantities.
    Only known grammatical/generic words are removed; never truncate the tail.
    Brand is a separate exact filter when the caller supplies it here.
    """
    ignored = {"de", "da", "do", "das", "dos", "para", "com", "em", "e", "a", "o", "as", "os"}
    generic = {"suporte", "base", "limpeza", "higienico", "higienica", "banheiro", "vaso"}
    units = {"a", "v", "w", "ah", "mah", "kg", "g", "cm", "mm", "ml", "l", "hz"}
    words = re.findall(r"\w+(?:[.,/+-]\w+)*", str(title), flags=re.UNICODE)
    brand_words = {_search_key(word) for word in re.findall(r"\w+(?:[.,/+-]\w+)*", str(brand or ""))}
    content = []
    for index, word in enumerate(words):
        key = _search_key(word)
        unit_after_number = key in units and index > 0 and any(character.isdigit() for character in words[index - 1])
        model_value = index > 0 and _search_key(words[index - 1]) in ("modelo", "model", "sku", "codigo", "cod")
        if key in brand_words or (key in ignored and not unit_after_number and not model_value):
            continue
        content.append(word)
    has_kit = any(_search_key(word) in ("kit", "kits", "conjunto", "par", "pares") for word in content)
    result = []
    for index, word in enumerate(content):
        key = _search_key(word)
        model_value = index > 0 and _search_key(content[index - 1]) in ("modelo", "model", "sku", "codigo", "cod")
        kit_component = has_kit and key in ("suporte", "base")
        if index >= 2 and key in generic and not model_value and not kit_component:
            continue
        result.append(word)
    return " ".join(result)


def _search_options(tool):
    properties = tool.get("inputSchema", {}).get("properties", {})
    limit_schema = properties.get("limit", {})
    maximum = limit_schema.get("maximum", MAX_SEARCH_RESULTS if "limit" in properties else 10)
    maximum = maximum if isinstance(maximum, int) and not isinstance(maximum, bool) and maximum > 0 else 10
    args = {"country": "BR", "group": "product", "preset": "full_info", "limit": min(MAX_SEARCH_RESULTS, maximum)}
    choices = properties.get("sort_by", {}).get("enum", [])
    rank = next((field for field in ("revenueLastMonth", "salesLastMonth", "revenue1m", "sales1m", "revenue1w", "sales1w") if field in choices), None)
    if rank:
        args["sort_by"] = rank
        if "desc" in properties.get("sort_order", {}).get("enum", []):
            args["sort_order"] = "desc"
    return args


def _usable_brand(brand, title):
    """Reject generic/product-description labels as mandatory brand filters."""
    value = _search_key(brand or "")
    compact = re.sub(r"\W", "", value)
    if not compact or compact in {"generica", "generico", "generic", "semmarca", "semfabricante",
                                  "na", "naoseaplica", "importado", "importada", "outros", "outras"}:
        return False
    words = re.findall(r"\w+", _search_key(title or ""))
    # E.g. CESTOROUPABAMBU is a seller's concatenated product description.
    # Do not generalize this to real brands merely because they occur in titles.
    if words and " " not in str(brand).strip() and compact.startswith(words[0]) and len(compact) > len(words[0]) + 2:
        return False
    return True


def _compact_search(title, brand=None):
    words = _search_query(title, brand).split()
    if not words:
        return "", []
    keys = [_search_key(word) for word in words]
    units = {"v", "volts", "w", "watts", "ah", "mah", "kg", "g", "cm", "mm", "ml", "l", "litro", "litros",
             "hz", "pas", "pa", "un", "unidade", "unidades", "peca", "pecas", "pcs"}
    labels = {"modelo", "model", "sku", "codigo", "cod"}
    materials = {"inox", "bambu", "silicone", "ceramica", "pvc", "plastico", "metal", "ferro", "madeira",
                 "aluminio", "litio", "chumbo", "vidro", "aco", "tecido", "algodao", "couro"}
    shape = {"tampa", "pedal", "slim", "coluna", "mesa", "parede", "universal", "almofadado",
             "dobravel", "termica", "termico", "impermeavel", "recarregavel"}
    critical, keep = set(), set(range(min(2, len(words))))
    for index, (word, key) in enumerate(zip(words, keys)):
        numeric = any(character.isdigit() for character in word)
        if numeric or key in labels or key in {"kit", "kits", "par", "pares", "conjunto"}:
            critical.add(index)
            if index + 1 < len(words) and (key in labels or key in {"kit", "kits", "par", "pares", "conjunto"} or keys[index + 1] in units):
                critical.add(index + 1)
            if index and keys[index - 1] in labels:
                critical.add(index - 1)
        if key in materials or key in shape:
            keep.add(index)
    keep |= critical
    kit_start = next((i for i, key in enumerate(keys) if key in {"kit", "kits", "conjunto"}), None)
    if kit_start is not None:
        # Bundle components are identity, even when their words look generic.
        critical.update(range(kit_start, len(words)))
        keep |= critical
    # Unknown model-like tokens with punctuation are retained even without digits.
    keep |= {i for i, word in enumerate(words) if re.search(r"[+-]", word) and len(word) > 2}
    return " ".join(word for i, word in enumerate(words) if i in keep), [word for i, word in enumerate(words) if i in critical]


def _unit_query_variant(query):
    """Equivalent spelling only: 72l/72 litros, 40cm/40 cm, 110v/110 v."""
    result = re.sub(r"\b(\d+(?:[.,]\d+)?)\s*(l|litro|litros)\b", r"\1 litros", query, flags=re.I)
    result = re.sub(r"\b(\d+(?:[.,]\d+)?)(cm|mm|ml|kg|mah|ah|hz|v|w)\b", r"\1 \2", result, flags=re.I)
    return result


def _numeric_variant_conflicts(reference_title, candidate_title):
    """Reject explicit conflicting measures; missing attributes remain unknown."""
    aliases = {"litro": "l", "litros": "l", "volts": "v", "pa": "pas", "unidade": "un", "unidades": "un"}
    def values(title):
        result = {}
        for number, unit in re.findall(r"\b(\d+(?:[.,]\d+)?)\s*(cm|mm|ml|kg|mah|ah|hz|volts|v|w|litros?|l|pas|pa|unidades?|un)\b", _search_key(title or "")):
            result.setdefault(aliases.get(unit, unit), set()).add(float(number.replace(",", ".")))
        return result
    reference, candidate = values(reference_title), values(candidate_title)
    return [unit for unit, expected in reference.items() if unit in candidate and expected.isdisjoint(candidate[unit])]


def _niche_plan(title, brand, category, tool, attempts=MAX_SEARCH_ATTEMPTS):
    """Buscas do nicho, da mais estreita à mais larga: tipo de produto em 3 palavras, em 2, e sem categoria.

    Não há filtro de marca nem as medidas no texto da busca: a auditoria de 14/11/2026 mostrou que o
    título inteiro com marca devolvia só o próprio anúncio. Medida e kit conflitantes saem depois,
    em market_niche.select.
    """
    base = _search_options(tool)
    queries = market_niche.queries(title, brand if _usable_brand(brand, title) else None)
    if not queries:
        return []
    variants = [(query, category, "Anúncios do mesmo tipo de produto" + (" na categoria da referência." if category else "."))
                for query in queries]
    if category:
        variants.append((queries[-1], None, "Mesmo tipo de produto em qualquer categoria."))
    plan = []
    for words, scope, reason in variants[:attempts]:
        args = {**base, "query": words}
        if scope:
            args["category"] = scope
        plan.append({"arguments": args, "reason": reason, "scope": "niche", "requiredTerms": [],
                     "brandFilterApplied": False,
                     "brandFilterOmittedReason": "O nicho reúne todas as marcas; não confirma equivalência."})
    return plan


def _search_plan(subject, tool):
    """Ofertas do catálogo exato (quando a referência é de catálogo) e, sempre, a amostra do nicho."""
    plan = []
    catalog = subject.get("productId") if subject.get("isCatalogProduct") is True else None
    if catalog and re.fullmatch(r"MLB\d{5,16}", str(catalog), re.I):
        plan.append({"arguments": {**_search_options(tool), "group": "item", "product": catalog}, "scope": "catalog",
                     "reason": "Ofertas do catálogo exato da referência.", "requiredTerms": []})
    title = subject.get("title")
    if title:
        plan += _niche_plan(title, subject.get("brand"), subject.get("categoryLeafId"), tool,
                            MAX_SEARCH_ATTEMPTS - len(plan))
    return plan


def _niche_candidates(subject, state):
    """Até cinco anúncios do nicho para detalhar: mesma categoria e marca primeiro, depois os mais parecidos."""
    subject_id = _id_value(subject.get("itemId") or subject.get("buyBoxItemId"))
    brand = _text(subject.get("brand"))
    usable = bool(brand and _usable_brand(brand, subject.get("title")))
    category = subject.get("categoryLeafId")
    picked = []
    for row in state["niche"]:
        original = state["rawNiche"][row["position"]]
        item_id = _id_value(original.get("itemId"))
        if (not item_id or item_id == subject_id
                or (subject.get("productId") and original.get("productId") == subject.get("productId"))):
            continue
        other_brand = bool(usable and row.get("brand") and str(row["brand"]).casefold() != brand.casefold())
        other_category = bool(category and row.get("categoryId") and row["categoryId"] != category)
        picked.append(((other_category, other_brand, -row["share"], -(row.get("revenue") or 0), len(picked)), original))
    picked.sort(key=lambda entry: entry[0])
    return [original for _, original in picked[:MAX_CANDIDATES]]


def _discovery_item(row):
    """Expose one representative item per product without changing its identity."""
    result = dict(row)
    if not _id_value(result.get("itemId")) and _id_value(result.get("buyBoxItemId")):
        result.update(itemId=result["buyBoxItemId"], price=result.get("buyBoxPrice"),
                      sellerId=result.get("buyBoxSellerId"), sellerName=result.get("buyBoxSellerName"))
    return result


def _unique_discovery_rows(rows, group):
    result, seen = [], set()
    for original in rows:
        row = _discovery_item(original)
        identity = _id_value(row.get("itemId"))
        if not identity:
            continue
        product = str(row.get("productId") or "")
        key = ("catalog", product) if group == "product" and re.fullmatch(r"MLB\d{5,16}", product, re.I) else ("item", identity)
        if key not in seen:
            seen.add(key)
            result.append(row)
    return result


def _rank_search_rows(rows):
    """Prioritize evidence, never infer equivalence or convert averages to sales.

    One field is chosen for the entire page, avoiding a comparison between
    monthly and weekly values. Catalog-wide fields only rank research priority.
    """
    fields = ("itemRevenueLastMonth", "itemSalesLastMonth", "revenueLastMonth", "salesLastMonth",
              "itemRevenueLastWeek", "itemSalesLastWeek", "revenueLastWeek", "salesLastWeek",
              "itemRevenue1m", "itemSales1m", "revenue1m", "sales1m", "revenue1w", "sales1w")
    field = next((field for field in fields if any((_numeric(row.get(field)) or 0) > 0 for row in rows)), None)
    if not field:
        field = next((field for field in fields if any(_numeric(row.get(field)) is not None for row in rows)), None)
    basis = "closed_period_estimate" if field and ("LastMonth" in field or "LastWeek" in field) else "historical_average" if field else "provider_order"
    ranking = {"field": field, "basis": basis, "scope": ("item" if field.startswith("item") else "catalog_product") if field else None,
               "purpose": "candidate_priority_only", "equivalenceConfirmed": False}
    if not field:
        return list(rows), ranking
    # Python's stable sort retains the provider's order when evidence ties.
    return sorted(rows, key=lambda row: (_numeric(row.get(field)) is not None, _numeric(row.get(field)) or 0), reverse=True), ranking


def _safe(value):
    if value is None or value == "":
        return MISSING
    return str(value).replace("|", "/").replace("\n", " ")


def _http_link(value):
    if not isinstance(value, str):
        return MISSING
    parsed = urlsplit(value)
    return value if parsed.scheme in ("http", "https") and parsed.hostname else MISSING


def _is_catalog_link(ref):
    spec = reference_spec(ref)
    return spec["valid"] and spec["kind"] == "catalog"


def _catalog_candidates(subject: dict, candidates: list[dict]) -> tuple[list[dict], int]:
    same_catalog = subject.get("isCatalogProduct") is True
    catalog_id = subject.get("productId")
    subject_id = _id_value(subject.get("itemId") or subject.get("buyBoxItemId"))
    result, seen = [], set()
    rejected = 0
    for row in candidates:
        item_id = _id_value(row.get("itemId"))
        if not item_id or item_id == subject_id or item_id in seen:
            continue
        if same_catalog and (not catalog_id or row.get("productId") != catalog_id):
            rejected += 1
            continue
        seen.add(item_id)
        result.append(row)
    return result[:5], rejected


def _context_excerpt(text, ref):
    needle = _reference_id(ref)
    index = text.upper().find(needle)
    if index < 0:
        index = text.find(ref)
    if index < 0:
        return "Os dados comerciais do documento precisam ser associados a este produto na revisão."
    return text[max(0, index - 200):index + 450].strip()


def _document_product(product, index):
    """Keep the card's explicit fields as documentary input, never market evidence."""
    if not isinstance(product, dict):
        raise ValueError("Cada produto do documento precisa ser um registro válido.")
    reference = product.get("reference")
    if not isinstance(reference, str):
        reference = ""
    fields = product.get("fields") if isinstance(product.get("fields"), dict) else {}
    return {"index": index, "name": str(product.get("name") or f"Produto {index}"),
            "reference": reference, "originalReference": product.get("originalReference") or reference,
            "fields": {key: fields[key] for key in DOCUMENT_FIELDS if key in fields},
            "cost": product.get("cost"), "salePrice": product.get("salePrice"),
            "referenceStatus": product.get("referenceStatus"), "referenceError": product.get("referenceError")}


def _document_context(product):
    lines = ["Dados informados no documento, no mesmo card do link de referência:",
             f"Produto no documento: {_safe(product['name'])}",
             f"Link original do card: {_safe(product['originalReference'])}"]
    lines += [f"{label} (informado no documento): {_safe(product['fields'].get(label))}"
              for label in DOCUMENT_FIELDS]
    lines.append("A associação documental ao card foi preservada. Valores, unidade, quantidade, variação e kit ainda precisam de conferência; estes campos não validam a viabilidade comercial.")
    return "\n".join(lines)


def _render_product(index, ref, subject, candidates, estimates, lookup, sales, requested_from, requested_to, excerpt, reference_kind, document_product=None):
    title = _safe(subject.get("title"))
    catalog = subject.get("isCatalogProduct") is True
    reference_is_item = reference_kind == "item"
    category = " > ".join(str(subject[f"categoryL{level}Name"]) for level in range(1, 8) if subject.get(f"categoryL{level}Name")) or MISSING
    heading = _safe(document_product["name"]) if document_product else title
    lines = [f"PRODUTO {index} - {heading}", f"Referência recebida: {ref}", "",
             "1. Produto identificado", f"Título: {title}", f"Marca: {_safe(subject.get('brand'))}",
             (f"Código do anúncio: {_safe(subject.get('itemId'))}" if reference_is_item else
              f"Código do catálogo: {_safe(subject.get('productId'))}"),
             f"Preço observado: {_money(subject.get('price'))}",
             f"Atualização informada pela JoomPulse: {_safe(lookup.get('lastRefreshTime'))}",
             "Confira modelo, voltagem, capacidade, peso, quantidade e kit antes de validar a identidade.", "",
             "2. Anúncios candidatos para conferência",
             "A busca retornou candidatos; a equivalência exata não foi validada automaticamente."]
    if candidates:
        lines += ["# | Produto | Preço observado | Identificação | Correspondência"]
        for n, row in enumerate(candidates, 1):
            identity = "Mesmo catálogo; conferir variação e kit" if catalog else "Busca por título; equivalência não confirmada"
            lines.append(f"{n} | {_safe(row.get('title'))} | {_money(row.get('price'))} | {_safe(row.get('itemId'))} | {identity}")
    else:
        lines.append("Nenhum concorrente validado nesta coleta. Ausência de resultado na JoomPulse não prova ausência no mercado.")
    lines += ["", "3. Imagens e links dos anúncios", f"Produto: {_http_link(subject.get('meliUrl'))}",
              f"Imagem do produto: {_http_link(subject.get('imageUrl'))}", f"Fonte JoomPulse: {_http_link(subject.get('pulseUrl'))}"]
    for n, row in enumerate(candidates, 1):
        lines += [f"Candidato {n}: {_http_link(row.get('meliUrl'))}", f"Imagem {n}: {_http_link(row.get('imageUrl'))}"]
    lines += ["", "4. Diagnóstico rápido de viabilidade", "EM REVISÃO - Dados de mercado coletados. Viabilidade comercial não determinada: falta validar equivalência, custos, taxas, impostos e logística.",
              "", "5. Categoria e subcategoria", category, f"Categoria final: {_safe(subject.get('categoryLeafId'))}",
              f"Tipo de anúncio: {_safe(subject.get('listingType'))}", "",
              "6. Taxas e custos aplicáveis", "Dado não disponível. Confirmar comissão do anúncio/categoria, tarifa fixa, imposto do CNPJ, custo unitário, embalagem e custo logístico suportado pelo vendedor. Frete grátis ao comprador não significa custo zero ao vendedor.", "",
              "7. Métricas do mercado", f"Intervalo solicitado: {requested_from} a {requested_to} (120 dias).",
              "A cobertura efetivamente disponível é identificada pelas datas de cada linha. Dias sem dados não foram preenchidos ou tratados como vendas zero.",
              "As estimativas são publicadas por semanas fechadas. Cada linha mantém seu período; cobertura parcial não representa um total exato dos últimos 120 dias.",
              "Não foram somadas vendas entre ofertas do mesmo catálogo. Vendas e faturamento são estimativas JoomPulse, não transações confirmadas."]
    if estimates:
        lines += ["Período | Escopo | Vendas estimadas | Faturamento estimado"]
        for row in estimates:
            period = f"{_safe(row.get('periodStart'))} a {_safe(row.get('periodEnd'))}"
            scope = row.get("scope")
            if scope == "catalog" and reference_is_item:
                lines.append(f"{period} | Anúncio específico | {_number(row.get('itemEstSales'))} | {_money(row.get('itemEstRevenue'))}")
                lines.append(f"{period} | Catálogo completo (todos os vendedores; contexto) | {_number(row.get('estSales'))} | {_money(row.get('estRevenue'))}")
            else:
                label = "Catálogo completo" if scope == "catalog" else "Anúncio específico" if scope == "item" else "Escopo não informado"
                if scope in ("catalog", "item"):
                    lines.append(f"{period} | {label} | {_number(row.get('estSales'))} | {_money(row.get('estRevenue'))}")
    else:
        lines.append("Não há estimativas de período disponíveis para este produto na resposta. Médias históricas não foram usadas como vendas recentes.")
    lines += [f"Atualização das estimativas informada pela fonte: {_safe(sales.get('lastRefreshTime'))}",
              "Preço médio de concorrentes idênticos: não calculado até confirmar a equivalência de cada candidato.",
              "", "8. Dados comerciais do cliente",
              ("Campos do card preservados para conferência:" if document_product else "Trecho do documento para conferência. A associação destes dados ao produto ainda precisa ser revisada:"), excerpt,
              "Confirmar por produto: custo unitário, quantidade de compra/venda, preço pretendido e margem desejada. Confirmar por cliente: cidade, UF, modalidade e imposto.",
              "", "9. Investimento", "Não calculado. Após confirmar os campos: custo unitário × quantidade de compra; incluir despesas adicionais quando aplicáveis.",
              "", "10. Preço necessário para atingir a margem", "Não calculado. Depende dos custos fixos por unidade, comissão, impostos, logística e margem pretendida. As tarifas devem ser confirmadas para este produto e faixa de preço.",
              "", "11. Comparação com concorrentes", f"Preço observado da referência: {_money(subject.get('price'))}. Confira os candidatos acima antes de tratá-los como concorrentes idênticos. Preço anunciado não comprova custo total ao comprador nem rentabilidade.",
              "", "12. Cenários alternativos de margem", "Não calculados. Margem é uma meta do cliente. Validar custos e preços comparáveis antes de simular alternativas; nenhuma redução de margem foi recomendada automaticamente.",
              "", "13. Análise financeira", "Faturamento, lucro e margem são medidas distintas. Não há cálculo de lucro líquido, retorno sobre estoque ou margem sem custos e taxas confirmados.",
              "", "14. Análise de demanda e estoque", "As estimativas acima são evidências de mercado. Não projetam as vendas deste cliente. Confirmar estoque pretendido, período, concorrência e capacidade logística antes de estimar giro.",
              "", "15. Resumo executivo", "Resumo quantitativo pendente de validação. Não há base confirmada para calcular participação de 10%, prazo de giro ou unidades do cliente. Nenhum número foi preenchido por suposição.",
              "", "16. Parecer final", "EM REVISÃO. Próximas ações: conferir a identidade do produto e dos candidatos, validar custos e impostos, revisar condições logísticas e só então concluir viabilidade e direcionamento de compra.", ""]
    return "\n".join(lines)


def collect_market(pdf_text: str, date: str, client, progress=lambda message: None, products=None) -> dict:
    analysis_date = Date.fromisoformat(date)
    recent_from = (analysis_date - timedelta(days=29)).isoformat()
    date_from = (analysis_date - timedelta(days=119)).isoformat()
    history_from = (analysis_date - timedelta(days=119)).isoformat()
    if products is not None and not isinstance(products, list):
        raise ValueError("Os produtos do documento precisam ser uma lista de registros.")
    document_products = [_document_product(product, index) for index, product in enumerate(products, 1)] if products is not None else None
    references = [product["reference"] for product in document_products] if document_products is not None else extract_references(str(pdf_text))
    if not references:
        raise ValueError("O documento não contém produtos com links Mercado Livre ou códigos MLB identificáveis. Inclua o link de cada produto no documento e importe novamente.")
    if len(references) > MAX_PRODUCTS:
        raise ValueError(f"A análise aceita até {MAX_PRODUCTS} produtos. Divida o documento antes de consultar; nenhum produto foi omitido nem enviado nesta execução.")
    has_valid = any(reference_spec(ref)["valid"] and
                    (document_products is None or document_products[index].get("referenceStatus") != "needs_review")
                    for index, ref in enumerate(references[:MAX_PRODUCTS]))
    if not has_valid and document_products is None:
        reason = reference_spec(references[0])["error"]
        raise ValueError("Nenhuma referência verificável foi encontrada. " + reason)
    if has_valid and not client.status().get("connected"):
        raise ValueError("Conecte sua JoomPulse antes de coletar dados de mercado.")
    available, tool_schemas = set(), {}
    if has_valid:
        progress("Conferindo consultas disponíveis na JoomPulse…")
        tool_schemas = {tool["name"]: tool for tool in client.list_tools() if tool.get("pronix_read_only")}
        available = set(tool_schemas)
    if has_valid and not {"meli_get_item", "meli_get_product", "meli_get_sales_estimates", "meli_search_products"} <= available:
        raise ValueError("A conexão não disponibiliza todas as consultas de produto exigidas por este modo. Atualize a conexão JoomPulse.")
    warnings = ["Coleta estruturada sem IA adicional. Revise a equivalência dos candidatos e complete custos, taxas e logística antes de emitir um parecer comercial."]
    audit = {"mode": "deterministic", "dateFrom": date_from, "dateTo": date,
             "references": references, "calls": [], "products": [], "completedAt": None,
             "paidCallBudget": MAX_PAID_CALLS, "paidCallAttempts": 0, "skippedPaidCalls": 0, "cacheHits": 0}
    evidence = {"version": 1, "period": {"start": date_from, "end": date},
                "historyPeriod": {"start": history_from, "end": date},
                "recentPeriod": {"start": recent_from, "end": date}, "products": []}
    audit["historyDateFrom"] = history_from
    cache, quota_exhausted = {}, False

    def call(name, args):
        nonlocal quota_exhausted
        if name not in available:
            return {}
        try:
            args = adapt_tool_arguments(tool_schemas[name], args)
        except ValueError as exc:
            warnings.append(f"Consulta {name} não enviada: {exc}")
            audit["calls"].append({"tool": name, "arguments": deepcopy(args), "at": datetime.now(timezone.utc).isoformat(),
                                   "success": False, "schemaRejected": True, "error": str(exc)})
            return {}
        cache_key = (name, json.dumps(args, sort_keys=True, ensure_ascii=False))
        if cache_key in cache:
            audit["cacheHits"] += 1
            return cache[cache_key]
        paid = name not in {"read_resource", "list_resources", "get_mcp_usage"}
        if paid and (quota_exhausted or audit["paidCallAttempts"] >= audit["paidCallBudget"]):
            audit["skippedPaidCalls"] += 1
            warnings.append(f"A coleta atingiu o limite disponível ou o orçamento de {audit['paidCallBudget']} consultas. Os produtos e campos restantes foram mantidos como pendentes.")
            return {}
        if paid:
            audit["paidCallAttempts"] += 1
        progress("Consultando JoomPulse: " + name)
        entry = {"tool": name, "arguments": args, "at": datetime.now(timezone.utc).isoformat()}
        try:
            raw = client.call_tool(name, args)
            if raw.get("isError"):
                raise ValueError("Consulta recusada pela JoomPulse.")
            result = unpack_result(raw)
            entry.update(success=True, result=result)
            cache[cache_key] = result
            return result
        except Exception as exc:
            entry.update(success=False, error=str(exc))
            warnings.append(f"Consulta {name} não concluída: {exc}")
            if any(word in str(exc).casefold() for word in ("quota", "limite de consultas", "limite de requisi", "request limit", "rate limit", "too many requests")):
                quota_exhausted = True
            return {}
        finally:
            audit["calls"].append(entry)

    def discover(plan, titles, brand=None, anchor_price=None):
        """Roda as buscas do plano até a amostra do nicho ter linhas suficientes."""
        state = {"search": {}, "args": None, "actual": None, "nicheArgs": None, "catalogSearch": False,
                 "catalogRows": [], "rawNiche": [], "niche": [], "weak": 0, "variant": 0,
                 "attempts": [], "notes": [], "more": False, "sources": {}}
        for step in plan:
            if quota_exhausted or audit["paidCallAttempts"] >= audit["paidCallBudget"]:
                break
            args = step["arguments"]
            result = call("meli_search_products", args)
            raw_rows = rows_from(result)
            try:
                actual = adapt_tool_arguments(tool_schemas["meli_search_products"], args)
            except ValueError:
                actual = deepcopy(args)
            notes = [note for note in result.get("notes", []) if isinstance(note, str)] if isinstance(result.get("notes"), list) else []
            state["notes"].extend(note for note in notes if note not in state["notes"])
            truncated = len(raw_rows) >= args["limit"] or any(
                re.search(r"more may match|first \d+ results|offset\s*=|primeiros? \d+ resultados", note, re.I) for note in notes)
            state["more"] |= truncated
            state["attempts"].append({**deepcopy(step), "arguments": actual, "returnedRows": len(raw_rows),
                                      "moreMayMatch": truncated, "sourceNotes": notes,
                                      "sourceRefreshedAt": _text(result.get("lastRefreshTime"))})
            for original in raw_rows:
                state["sources"].setdefault(_id_value(_discovery_item(original).get("itemId")), result)
            state.update(search=result, args=args, actual=actual)
            if step.get("scope") == "catalog":
                state["catalogSearch"] = True
                state["catalogRows"] = _unique_discovery_rows(raw_rows, args["group"])
                continue
            state["nicheArgs"] = actual
            state["rawNiche"] = _unique_discovery_rows(state["rawNiche"] + raw_rows, args["group"])
            state["niche"], state["weak"], state["variant"] = market_niche.select(titles, state["rawNiche"], brand, anchor_price)
            if market_niche.enough(state["niche"], len(raw_rows), args["limit"]):
                break
        return state

    def search_record(state, candidates=(), rejected=0, ranking=None):
        args = state["args"]
        return {"arguments": state["actual"], "returnedRows": len(state["catalogRows"]) + len(state["rawNiche"]),
                "requestedLimit": args.get("limit") if args else None, "moreMayMatch": state["more"],
                "completeMarketCoverage": False,
                "excludedByLowSimilarity": state["weak"], "excludedByBrandOrCategory": state["weak"],
                "excludedByCatalog": rejected, "excludedByNumericVariant": state["variant"],
                "providerSort": args.get("sort_by") if args else None,
                "selectionRanking": ranking or {"field": None, "basis": "provider_order", "scope": None,
                                                "purpose": "candidate_priority_only", "equivalenceConfirmed": False},
                "selectedForDetail": [_id_value(row.get("itemId")) for row in candidates],
                "sourceNotes": state["notes"],
                "querySource": ("niche_product_type_queries" if state["nicheArgs"] else "exact_catalog_id") if args else None,
                "attempts": state["attempts"], "attemptLimit": MAX_SEARCH_ATTEMPTS,
                "discoveryGroup": args.get("group") if args else None,
                "providerReturnedRows": sum(attempt["returnedRows"] for attempt in state["attempts"])}

    def attach_niche(evidence_product, state, located, category=None):
        """Guarda as medidas do nicho (procura e preço) calculadas sobre as linhas da busca."""
        niche = market_niche.summarize(state["niche"], market_niche.period_label(state["notes"]))
        if not niche:
            return
        used = state["nicheArgs"] or {}
        niche.update(query=used.get("query") or " | ".join(used.get("queries") or []) or None,
                     searchedCategory=used.get("category") or next(iter(used.get("categories") or []), None),
                     categoryId=category or market_niche.main_category(state["niche"]),
                     excludedLowSimilarity=state["weak"], excludedVariant=state["variant"],
                     referenceLocated=located, source="JoomPulse MCP / meli_search_products",
                     note="Estimativas da JoomPulse por produto no último mês fechado; não são vendas confirmadas.")
        evidence_product["niche"] = niche

    def niche_without_reference(evidence_product, ref, document_product):
        """Anúncio do link fora da base, ou link de busca: mede o nicho pelo nome do produto."""
        if "meli_search_products" not in available:
            return
        titles = [title for title in (market_niche.title_from_link(ref), document_product["name"] if document_product else None) if title]
        if not titles:
            return
        state = discover(_niche_plan(titles[0], None, None, tool_schemas["meli_search_products"]), titles)
        if state["attempts"]:
            evidence_product["search"] = search_record(state)
            attach_niche(evidence_product, state, located=False)
            if evidence_product.get("niche"):
                evidence_product["limitations"].append("O anúncio do link não foi localizado; a comparação usa anúncios do mesmo tipo de produto, encontrados pelo nome.")

    if "get_mcp_usage" in available:
        usage = call("get_mcp_usage", {})
        remaining = [_numeric(bucket.get("remaining")) for bucket in usage.get("buckets", []) if isinstance(bucket, dict)
                     and not bucket.get("unlimited") and (bucket.get("scope") == "total" or bucket.get("marketplace") == "meli")]
        remaining = [int(value) for value in remaining if value is not None]
        if remaining:
            audit["paidCallBudget"] = min(MAX_PAID_CALLS, *remaining)
            quota_exhausted = audit["paidCallBudget"] == 0
    if "read_resource" in available:
        for uri in ("pulse://overview", "pulse://tool-tips"):
            call("read_resource", {"uri": uri})
    texts = ["COLETA DE MERCADO - JOOMPULSE", f"Data da análise: {date}",
             ("Dados consultados diretamente na JoomPulse. Montagem local por regras, sem chamada a modelo de linguagem." if has_valid else
              "Produtos mantidos para revisão. Nenhuma referência permite consultar uma oferta exata na JoomPulse."),
             "As referências foram extraídas do documento. Cada produto e cada candidato precisam de revisão antes do envio ao cliente.", ""]
    found = 0
    for index, ref in enumerate(references[:MAX_PRODUCTS], 1):
        skipped_before = audit["skippedPaidCalls"]
        progress(f"Coletando produto {index} de {min(len(references), MAX_PRODUCTS)}…")
        document_product = document_products[index - 1] if document_products is not None else None
        heading = _safe(document_product["name"]) if document_product else ref
        excerpt = _document_context(document_product) if document_product else _context_excerpt(pdf_text, ref)
        source_audit = {"documentProduct": document_product} if document_product else {}
        evidence_product = {"index": index, "sourceReference": ref,
                            "reference": normalize_market_item({}, reference_url=ref),
                            "candidates": [], "competitors": [], "periods": [], "catalogPeriods": [],
                            "reviews": None, "fees": None, "provenance": [], "limitations": [],
                            "status": "needs_review"}
        evidence["products"].append(evidence_product)

        def pending(reason, identity=None):
            texts.append(f"PRODUTO {index} - {heading}\nReferência recebida: {ref}\n{reason}\nNão foram preenchidos métricas, concorrentes ou viabilidade.\n" +
                         ("\n" + excerpt + "\n" if document_product else ""))
            warnings.append(f"{heading}: {reason}")
            entry = {"reference": ref, "status": "needs_review", "reason": reason,
                     "referenceValidated": False, "identityValidated": False, **source_audit}
            if identity is not None:
                entry["referenceIdentity"] = identity
            evidence_product["limitations"].append(reason)
            entry["evidence"] = evidence_product
            audit["products"].append(entry)

        if document_product and document_product.get("referenceStatus") == "needs_review":
            reason = document_product.get("referenceError") or "A referência do card precisa de revisão antes da consulta."
            niche_without_reference(evidence_product, ref, document_product)
            pending(str(reason) + " Nenhuma consulta de produto foi executada para esta referência.")
            continue
        spec = reference_spec(ref)
        if not spec["valid"]:
            reason = spec["error"]
            niche_without_reference(evidence_product, ref, document_product)
            pending(reason + " Nenhuma consulta de produto foi executada para esta referência.")
            continue
        evidence_product["reference"].update(id=spec["id"], kind=spec["kind"],
                                             itemId=spec["id"] if spec["kind"] == "item" else None,
                                             catalogId=spec["id"] if spec["kind"] == "catalog" else None)
        tool = "meli_get_product" if spec["kind"] == "catalog" else "meli_get_item"
        lookup = call(tool, {"country": "BR", "id": spec["id"], "preset": "full_info"})
        rows = rows_from(lookup)
        if (spec["kind"] == "ambiguous" and not rows and not lookup.get("candidates")
                and not quota_exhausted and audit["paidCallAttempts"] < audit["paidCallBudget"]):
            alternate = "meli_get_item" if tool == "meli_get_product" else "meli_get_product"
            lookup = call(alternate, {"country": "BR", "id": spec["id"], "preset": "full_info"})
            rows = rows_from(lookup)
            tool = alternate
        if len(rows) != 1 or lookup.get("candidates"):
            reason = ("Consulta do produto pendente porque a cota ou o orçamento de consultas foi atingido." if quota_exhausted or audit["skippedPaidCalls"] > skipped_before else
                      "Referência ambígua; selecione um anúncio específico." if lookup.get("candidates") or len(rows) > 1 else "Produto não localizado na cobertura consultada; isso não prova ausência no marketplace.")
            if reason.startswith("Produto não localizado"):
                niche_without_reference(evidence_product, ref, document_product)
            pending(reason)
            continue
        subject = rows[0]
        identity = validate_reference_subject(ref, subject, tool)
        if not identity["valid"]:
            reason = identity["error"]
            pending(reason, identity)
            continue
        found += 1
        if tool == "meli_get_product" and subject.get("productId"):
            subject.setdefault("isCatalogProduct", True)
        observed_at = datetime.now(timezone.utc).isoformat()
        normalized_reference = normalize_market_item(subject, kind=identity["kind"], source_result=lookup,
                                                    observed_at=observed_at, reference_validated=True, reference_url=ref)
        evidence_product.update(reference=normalized_reference, status="collected")
        evidence_product["provenance"].append({"tool": tool, "id": spec["id"], "observedAt": observed_at,
                                               "sourceRefreshedAt": _text(lookup.get("lastRefreshTime"))})
        evidence_product["limitations"].extend([
            "A fonte não disponibiliza modelo/SKU, voltagem, medidas, quantidade e conteúdo do kit como atributos estruturados. Confirme a equivalência antes de usar candidatos como concorrentes idênticos.",
            "Comissão, tarifa fixa, frete suportado pelo vendedor e demais custos aplicáveis não estão disponíveis neste MCP. Frete grátis ao comprador não confirma custo zero ao vendedor."])
        sales = call("meli_get_sales_estimates", {"country": "BR", "id": spec["id"],
                     "granularity": "week", "date_from": history_from, "date_to": date})
        estimates = [row for row in period_estimates(sales) if _id_value(row.get("id")) == spec["id"]]
        periods, period_warnings = normalize_sales_periods(sales, normalized_reference, date_from, date)
        evidence_product["limitations"].extend(period_warnings)
        evidence_product["periods"] = [period for period in periods if period["scope"] == identity["kind"]]
        evidence_product["catalogPeriods"] = [period for period in periods if period["scope"] == "catalog"] if identity["kind"] == "item" else []
        normalized_reference["periods"] = evidence_product["periods"]
        normalized_reference["catalogPeriods"] = evidence_product["catalogPeriods"]
        evidence_product["candidates"].append({**normalized_reference, "isReference": True,
            "attributes": dict(normalized_reference["attributes"]),
            "periods": [dict(period) for period in normalized_reference["periods"]],
            "catalogPeriods": [dict(period) for period in normalized_reference["catalogPeriods"]],
            "matchReason": "Anúncio de referência enviado no documento. Confirme que corresponde ao produto, à variação e ao kit pretendidos antes de usá-lo como concorrente.",
            "matchStatus": "needs_review", "limitations": list(period_warnings),
            "provenance": list(evidence_product["provenance"]) + [{"tool": "meli_get_sales_estimates", "id": spec["id"],
                "sourceRefreshedAt": _text(sales.get("lastRefreshTime")), "estimated": True}]})
        search_plan = _search_plan(subject, tool_schemas["meli_search_products"])
        state = discover(search_plan, [subject.get("title"), document_product["name"] if document_product else None],
                         subject.get("brand"), _numeric(subject.get("price")))
        search, search_args, actual_search_args = state["search"], state["args"], state["actual"]
        attempts, search_notes, more_may_match, row_sources = state["attempts"], state["notes"], state["more"], state["sources"]
        search_rows = state["catalogRows"] + state["rawNiche"]
        rejected = 0
        if state["catalogSearch"]:
            candidates, rejected = _catalog_candidates(subject, state["catalogRows"])
        else:
            candidates = _niche_candidates(subject, state)
        _, local_ranking = _rank_search_rows(candidates)
        search_summary = search_record(state, candidates, rejected, local_ranking)
        evidence_product["search"] = search_summary
        attach_niche(evidence_product, state, located=True, category=subject.get("categoryLeafId"))
        evidence_product["limitations"].append("A busca consulta uma página de candidatos, não todo o mercado. Receita e vendas históricas servem somente para priorizar consultas; não confirmam equivalência nem substituem vendas dos 120 dias.")
        if more_may_match:
            coverage_warning = f"Busca limitada aos {len(search_rows)} resultados retornados; a fonte pode conter outras ofertas. Foram priorizados até {MAX_CANDIDATES} anúncios para detalhamento."
            evidence_product["limitations"].append(coverage_warning)
            warnings.append(f"{ref}: {coverage_warning}")
        if rejected:
            warnings.append(f"{ref}: {rejected} resultado(s) com catálogo divergente foram excluídos.")
        if not estimates:
            warnings.append(f"{ref}: estimativas do período indisponíveis; médias históricas não substituem vendas recentes.")
            evidence_product["limitations"].append("Estimativas de período indisponíveis para a referência; médias históricas não foram substituídas por vendas recentes.")
        candidate_ids = [_id_value(row.get("itemId")) for row in candidates]
        candidate_ids = [item_id for item_id in candidate_ids if item_id and not item_id.startswith("MLBU")]
        detail_results = {}
        batch_supported = "ids" in tool_schemas.get("meli_get_item", {}).get("inputSchema", {}).get("properties", {})
        if candidate_ids and batch_supported:
            details = call("meli_get_item", {"country": "BR", "ids": candidate_ids, "preset": "full_info"})
            for candidate_id in candidate_ids:
                matching = [row for row in rows_from(details) if _id_value(row.get("itemId")) == candidate_id]
                if len(matching) == 1 and not details.get("candidates"):
                    detail_results[candidate_id] = (matching[0], details)
        for row in candidates[:MAX_CANDIDATES]:
            candidate_id = _id_value(row.get("itemId"))
            if not candidate_id or candidate_id.startswith("MLBU"):
                continue
            if not batch_supported:
                details = call("meli_get_item", {"country": "BR", "id": candidate_id, "preset": "full_info"})
                matching = rows_from(details)
                if len(matching) == 1 and not details.get("candidates") and validate_reference_subject(candidate_id, matching[0], "meli_get_item")["valid"]:
                    detail_results[candidate_id] = (matching[0], details)
            discovery_source = row_sources.get(candidate_id, search)
            detailed, detail_source = detail_results.get(candidate_id, (row, discovery_source))
            validated = candidate_id in detail_results
            normalized = normalize_market_item(detailed, source_result=detail_source,
                                                reference_validated=validated, observed_at=datetime.now(timezone.utc).isoformat(),
                                                source_tool="meli_get_item" if validated else "meli_search_products")
            # A lookup can confirm an ad while revealing that the original
            # search row belonged to a different catalog/brand/category.
            conflicts = ((normalized_reference.get("catalogId") and normalized.get("catalogId") != normalized_reference["catalogId"]) or
                         (_usable_brand(normalized_reference.get("brand"), normalized_reference.get("title")) and normalized_reference.get("brand") and normalized.get("brand") and normalized_reference["brand"].casefold() != normalized["brand"].casefold()) or
                         (normalized_reference.get("categoryId") and normalized.get("categoryId") and normalized_reference["categoryId"] != normalized["categoryId"]))
            normalized["matchReason"] = _candidate_reason(normalized_reference, normalized)
            normalized["searchPriority"] = {**local_ranking,
                "value": _numeric(row.get(local_ranking["field"])) if local_ranking["field"] else None}
            # Details may omit search-only closed-period summaries or catalog
            # competition. Keep that snapshot separately, with its own scope.
            discovery = normalize_market_item(row, source_result=discovery_source,
                observed_at=normalized["observedAt"], source_tool="meli_search_products")
            normalized["discoveryContext"] = {key: deepcopy(discovery.get(key)) for key in
                ("catalogId", "brand", "categoryName", "categoryPath", "priceHistory", "competitionContext",
                 "reportedPerformance", "historicalAverages", "bestsellerPositions", "imageCount", "isOfficialStore",
                 "isInternational", "isBuyBoxWinner", "isBestseller", "isFull", "sourceRefreshedAt")}
            normalized["discoveryContext"].update(source="JoomPulse MCP / meli_search_products", identityConfirmed=False)
            normalized["isReference"] = False
            normalized["matchStatus"] = "needs_review"
            normalized["limitations"] = []
            normalized["provenance"] = [{"tool": "meli_get_item" if validated else "meli_search_products",
                                          "id": candidate_id, "observedAt": normalized["observedAt"],
                                          "sourceRefreshedAt": normalized["sourceRefreshedAt"]}]
            if conflicts:
                normalized.update(matchStatus="rejected", matchReason="O detalhe consultado diverge da marca, categoria ou catálogo da referência.")
            elif not validated:
                normalized["limitations"].append("Não foi possível revalidar o anúncio pelo seu código; as séries não foram associadas.")
            else:
                candidate_sales = call("meli_get_sales_estimates", {"country": "BR", "id": candidate_id,
                                       "granularity": "week", "date_from": history_from, "date_to": date})
                candidate_periods, candidate_warnings = normalize_sales_periods(candidate_sales, normalized, date_from, date)
                normalized["periods"] = [period for period in candidate_periods if period["scope"] == "item"]
                normalized["catalogPeriods"] = [period for period in candidate_periods if period["scope"] == "catalog"]
                normalized["limitations"].extend(candidate_warnings)
                normalized["provenance"].append({"tool": "meli_get_sales_estimates", "id": candidate_id,
                                                 "sourceRefreshedAt": _text(candidate_sales.get("lastRefreshTime")), "estimated": True})
                if not normalized["periods"]:
                    normalized["limitations"].append("Estimativas próprias do anúncio indisponíveis; não foram usadas as vendas de todo o catálogo como vendas deste vendedor.")
            evidence_product["candidates"].append(normalized)
        if "meli_get_review_history" in available and normalized_reference.get("itemId"):
            review_from = (analysis_date - timedelta(days=7)).isoformat()
            review_id = normalized_reference["itemId"]
            review_result = call("meli_get_review_history", {"country": "BR", "id": review_id,
                                  "date_from": review_from, "date_to": date})
            evidence_product["reviews"] = normalize_review_history(review_result, review_id, review_from, date)
        if not any(not candidate.get("isReference") for candidate in evidence_product["candidates"]):
            evidence_product["limitations"].append("Nenhum candidato verificável foi retornado; isso não prova ausência de concorrência no marketplace.")
        if quota_exhausted or audit["skippedPaidCalls"] > skipped_before:
            evidence_product["status"] = "partial"
            evidence_product["limitations"].append("Coleta parcial deste produto: a cota ou o orçamento de consultas foi atingido. Os dados ausentes não foram preenchidos com estimativas alternativas.")
        evidence_product["provenance"].extend([
            {"tool": "meli_search_products", "arguments": actual_search_args, "search": search_summary,
             "sourceRefreshedAt": _text(search.get("lastRefreshTime"))},
            {"tool": "meli_get_sales_estimates", "id": spec["id"], "sourceRefreshedAt": _text(sales.get("lastRefreshTime")), "estimated": True}])
        evidence_product["limitations"] = list(dict.fromkeys(evidence_product["limitations"]))
        audit["products"].append({"reference": ref, "subject": subject, "candidates": candidates,
                                  "periodEstimates": estimates, "identityValidated": False,
                                  "referenceValidated": True, "referenceIdentity": identity,
                                  "evidence": evidence_product, **source_audit})
        texts.append(_render_product(index, ref, subject, candidates, estimates, lookup, sales,
                                    date_from, date, excerpt, identity["kind"], document_product))
    if not found:
        warnings.append("Nenhum produto foi identificado sem ambiguidade nesta coleta. O relatório precisa de referências válidas antes de uma análise comercial.")
    audit["completedAt"] = datetime.now(timezone.utc).isoformat()
    evidence["completedAt"] = audit["completedAt"]
    evidence["paidCallAttempts"] = audit["paidCallAttempts"]
    return {"text": "\n\n".join(texts), "audit": audit, "warnings": list(dict.fromkeys(warnings)), "evidence": evidence}
