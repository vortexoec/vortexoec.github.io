"""Comissão (API oficial do Mercado Livre) e frete (tabela oficial local) sem IA.

Preenche ``autoFees`` em cada produto coletado. São estimativas para o preço
informado: a comissão vem de ``/sites/MLB/listing_prices`` na categoria do anúncio
e o frete da tabela 48392, quando a modalidade é coberta pela tabela. O peso do
pacote vem, nesta ordem, do especialista, da linha "Embalagem" do Hub ou de uma
estimativa pelo anúncio (ver ``market_package``). Nada aqui altera os valores digitados pelo
especialista; as regras usam ``autoFees`` só enquanto as taxas não forem conferidas.
"""
from __future__ import annotations

from datetime import datetime, timezone
import math
import re

from . import market_package
from .mercadolivre import LISTING_RATES_URL, MercadoLivreError
from .market_shipping import SOURCE_URL as SHIPPING_SOURCE_URL, ShippingReferenceError, estimate_shipping

PREMIUM_FROM_PRICE = 150.0  # preferência comercial do cliente, não regra do Mercado Livre
_TABLE_LOGISTICS = ("agênc", "agenc", "coleta", "full", "drop", "cross")
_OUTSIDE_TABLE = ("flex", "correio")


def _number(value):
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value > 0 else None


CUBIC_DIVISOR = 6000  # peso cúbico do Mercado Envios: C × L × A (cm) / 6000


def package_from_hub(fields):
    """Lê "192 g · 27 × 15 × 15 cm" da planilha do Hub. Devolve (peso faturável kg, explicação) ou (None, None)."""
    text = str((fields or {}).get("Embalagem") or "").lower().replace(",", ".")
    if not text:
        return None, None
    weight = None
    match = re.search(r"(\d+(?:\.\d+)?)\s*(kg|g)\b", text)
    if match:
        weight = float(match.group(1)) / (1 if match.group(2) == "kg" else 1000)
    dims = re.search(r"(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)\s*cm", text)
    cubic = None
    if dims:
        a, b, c = (float(v) for v in dims.groups())
        cubic = a * b * c / CUBIC_DIVISOR
    if not weight and not cubic:
        return None, None
    billable = max(v for v in (weight, cubic) if v)
    note = (f"Pacote informado no Hub ({(fields or {}).get('Embalagem')}): peso real {weight:g} kg" if weight else "Pacote informado no Hub") +            (f", peso cúbico {cubic:.2f} kg; usado o maior ({billable:.2f} kg)." if cubic else ".")
    return round(billable, 3), note


def _listing(chosen_type, price, reference_type=None):
    """Tipo de anúncio usado na comissão.

    1) o que o especialista escolheu na análise; 2) a preferência por preço (Clássico abaixo de
    R$ 150, Premium a partir daí). O tipo do anúncio de referência não decide: um concorrente
    Premium não obriga o cliente a anunciar no Premium. Ele entra só como informação na nota.
    """
    names = {"gold_pro": "premium", "premium": "premium", "gold_special": "classic", "classic": "classic", "clássico": "classic", "classico": "classic"}
    # O campo "Tipo de anúncio" nasce preenchido com o código do anúncio de referência (gold_pro/gold_special).
    # Só conta como escolha do especialista quando ele escreve Premium ou Clássico.
    typed = str(chosen_type or "").strip().lower()
    chosen = names.get(typed) if typed in ("premium", "classic", "clássico", "classico") else None
    reference_type = reference_type or (chosen_type if typed.startswith("gold_") else None)
    if chosen:
        return chosen, "tipo escolhido na análise (" + ("Premium" if chosen == "premium" else "Clássico") + ")"
    listing = "premium" if price >= PREMIUM_FROM_PRICE else "classic"
    reason = "preferência Pronix: Premium a partir de R$ 150" if listing == "premium" else "preferência Pronix: Clássico abaixo de R$ 150"
    other = names.get(str(reference_type or "").lower())
    if other and other != listing:
        reason += "; o anúncio de referência é " + ("Premium" if other == "premium" else "Clássico")
    return listing, reason


def _shipping(price, weight, logistics, analysis_date):
    text = str(logistics or "").lower()
    if weight is None:
        return None, "Informe o peso do pacote (kg) para estimar o frete pela tabela oficial."
    if any(word in text for word in _OUTSIDE_TABLE) or not any(word in text for word in _TABLE_LOGISTICS):
        return None, "A tabela oficial cobre Agências, Coleta e Full; informe o frete desta modalidade manualmente."
    try:
        row = estimate_shipping(round(price, 2), weight, False, analysis_date)
    except ShippingReferenceError as exc:
        return None, str(exc)
    return row["shipping"], None


def fees_for(entry, evidence_item, context, meli, captured_at=None):
    """Monta autoFees para um produto. Nunca lança erro: falhas viram aviso."""
    inputs, fees = entry.get("inputs") or {}, entry.get("fees") or {}
    price = _number(inputs.get("salePrice"))
    reference = (evidence_item or {}).get("reference") or {}
    result = {"quotedPrice": price, "capturedAt": captured_at or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
              "basis": "estimate", "commissionPercent": None, "fixedFee": None, "shipping": None,
              "listingType": None, "categoryId": None, "categoryName": None, "notes": [], "sources": []}
    if price is None:
        result["notes"].append("Informe o preço de venda para consultar comissão e frete.")
        return result
    listing, listing_reason = _listing(fees.get("listingType"), price, reference.get("listingType"))
    result["listingType"] = listing
    if meli is None:
        result["notes"].append("Conecte o Mercado Livre em Integrações para consultar a comissão oficial.")
    else:
        try:
            category = reference.get("categoryId") or None
            name = reference.get("categoryName") or None
            if not category:
                predicted = meli.predict_category(reference.get("title") or (entry.get("source") or {}).get("name") or "")
                if predicted:
                    category, name = predicted
                    result["notes"].append("Categoria sugerida pelo Mercado Livre a partir do título; confira.")
            if not category:
                raise MercadoLivreError("Categoria do anúncio não identificada.")
            rates = meli.listing_rates(category, price)
            chosen = rates.get(listing) or rates.get("classic") or rates.get("premium")
            result.update(categoryId=category, categoryName=name,
                          commissionPercent=chosen["percent"], fixedFee=chosen["fixedFee"],
                          classicPercent=(rates.get("classic") or {}).get("percent"),
                          premiumPercent=(rates.get("premium") or {}).get("percent"))
            result["notes"].append(f"Comissão {'Premium' if listing == 'premium' else 'Clássico'} ({listing_reason}).")
            result["sources"].append(LISTING_RATES_URL)
        except MercadoLivreError as exc:
            result["notes"].append("Comissão não consultada: " + str(exc))
    package = _package(entry, reference, fees, meli, result.get("categoryId") or reference.get("categoryId"))
    weight = package["billableKg"] if package else None
    if package:
        estimated = package["source"] in market_package.ESTIMATED_SOURCES
        result.update(shippingSource=package["source"], shippingConfidence=package["confidence"],
                      packageEstimated=estimated, shippingNote=package["note"])
        if estimated:
            result.update(estimatedPackageWeightKg=weight, packageRealWeightKg=package.get("realWeightKg"),
                          packageCubicWeightKg=package.get("cubicWeightKg"), packageDimensionsCm=package.get("dimensionsCm"))
    shipping, note = _shipping(price, weight, context.get("logistics"), context.get("analysisDate"))
    if shipping is not None:
        result["shipping"] = shipping
        result["packageWeightKg"] = weight
        result["sources"].append(SHIPPING_SOURCE_URL)
        result["notes"].append(f"Frete estimado pela tabela oficial para {weight:g} kg. {package['note']}")
    elif note:
        result["notes"].append(note)
        if package and package["source"] in market_package.ESTIMATED_SOURCES:
            result["notes"].append(package["note"])
    return result


def _package(entry, reference, fees, meli, category_id):
    """Peso tarifável e origem: especialista > planilha do Hub > anúncio > título > categoria."""
    weight = _number(fees.get("packageWeightKg"))
    if weight is not None:
        return {"source": "especialista", "confidence": "alta", "billableKg": weight, "note": "peso informado pelo especialista"}
    weight, note = package_from_hub((entry.get("source") or {}).get("fields"))
    if weight is not None:
        return {"source": "hub", "confidence": "alta", "billableKg": weight, "note": note}
    try:
        return market_package.estimate(entry, reference, meli, category_id)
    except Exception:
        return None  # a estimativa nunca derruba a análise


def attach(report, evidence, meli, progress=lambda text: None):
    """Acrescenta autoFees aos produtos coletados (estrutura de collect_market)."""
    envelope = (report or {}).get("marketAnalysis") or {}
    entries = {str(entry.get("index")): entry for entry in envelope.get("products") or []}
    context = envelope.get("context") or {}
    items = [item for item in (evidence or {}).get("products") or [] if isinstance(item, dict)]
    for position, item in enumerate(items, 1):
        entry = entries.get(str(item.get("index")))
        if entry is None:
            continue
        progress(f"Consultando comissão e frete · produto {position} de {len(items)}…")
        item["autoFees"] = fees_for(entry, item, context, meli)
    return evidence


def refresh(report, meli):
    """Recalcula autoFees com os preços e pesos atuais, sem nova consulta à JoomPulse."""
    envelope = (report or {}).get("marketAnalysis") or {}
    context = envelope.get("context") or {}
    for entry in envelope.get("products") or []:
        evidence = entry.get("evidence")
        if isinstance(evidence, dict) and evidence:
            evidence["autoFees"] = fees_for(entry, evidence, context, meli)
    return report
