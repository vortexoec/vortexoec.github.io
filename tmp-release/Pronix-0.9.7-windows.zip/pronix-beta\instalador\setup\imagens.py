"""Gera as imagens da janela do instalador (identidade Vórtex) a partir do logo."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = Path(__file__).resolve().parent
LOGO = HERE.parents[1] / 'static' / 'central-logo.png'
FONTS = Path(r'C:\Windows\Fonts')


def font(name, size):
    try:
        return ImageFont.truetype(str(FONTS / name), size)
    except OSError:
        return ImageFont.load_default()


def gradient(w, h):
    img = Image.new('RGB', (w, h))
    top, bottom = (24, 14, 48), (8, 7, 14)
    px = img.load()
    for y in range(h):
        t = y / (h - 1)
        c = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        for x in range(w):
            px[x, y] = c
    return img


def side(scale):
    w, h = int(164 * scale), int(314 * scale)
    img = gradient(w, h)
    d = ImageDraw.Draw(img)
    glow = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    r = int(70 * scale)
    gd.ellipse((w // 2 - r, int(95 * scale) - r, w // 2 + r, int(95 * scale) + r), fill=(112, 48, 255, 70))
    glow = glow.filter(ImageFilter.GaussianBlur(int(26 * scale)))
    img.paste(glow, (0, 0), glow)
    logo = Image.open(LOGO).convert('RGBA').resize((int(84 * scale),) * 2, Image.LANCZOS)
    img.paste(logo, ((w - logo.width) // 2, int(53 * scale)), logo)
    f1, f2, f3 = font('segoeuib.ttf', int(17 * scale)), font('segoeui.ttf', int(11 * scale)), font('segoeuib.ttf', int(9 * scale))
    for text, f, y, fill in (('Central', f1, 160, (255, 255, 255)), ('de Análises', f1, 181, (255, 255, 255)),
                             ('Mercado, margem e parecer', f2, 214, (185, 170, 225)), ('no seu computador', f2, 229, (185, 170, 225)),
                             ('VÓRTEX', f3, 285, (160, 120, 255))):
        tw = d.textlength(text, font=f)
        d.text(((w - tw) / 2, int(y * scale)), text, font=f, fill=fill)
    return img


def small(scale):
    s = int(55 * scale)
    img = Image.new('RGB', (s, s), (255, 255, 255))
    logo = Image.open(LOGO).convert('RGBA').resize((s - int(6 * scale),) * 2, Image.LANCZOS)
    img.paste(logo, ((s - logo.width) // 2, (s - logo.height) // 2), logo)
    return img


if __name__ == '__main__':
    for scale, tag in ((1, '100'), (1.25, '125'), (1.5, '150'), (2, '200'), (2.5, '250')):
        side(scale).save(HERE / f'lateral-{tag}.bmp')
        small(scale).save(HERE / f'pequena-{tag}.bmp')
    print('ok')
