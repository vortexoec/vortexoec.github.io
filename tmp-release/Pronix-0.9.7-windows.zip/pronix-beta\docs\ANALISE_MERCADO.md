> **Atualização 07/11/2026:** a IA foi removida do Pronix. A análise usa somente JoomPulse, a API de comissões do Mercado Livre, a tabela oficial de frete e regras locais. Trechos abaixo que citam ChatGPT, OpenAI ou "análise com IA" descrevem versões anteriores.

# Análise de mercado — beta v0.6

A área de mercado reúne produtos, pareceres e devolutivas editáveis de até 1.000 caracteres. Há dois modos de trabalho: análise contextual com IA e **Consultar dados sem IA**, com consulta JoomPulse e cálculos locais. A conexão de IA é escolhida explicitamente; não há troca automática para API paga.

## Conectar a IA

Em **Integrações**, o caminho principal é **Continuar com ChatGPT**. O login e o consentimento acontecem no site da OpenAI. Depois de autorizar o uso do plano, clique em **Carregar modelos disponíveis**, escolha um modelo da lista da conta e use **Salvar e usar ChatGPT**. Nenhum modelo é escolhido automaticamente. A conexão não permite ler suas conversas do ChatGPT.

As solicitações elegíveis usam os limites disponíveis do plano pessoal, sem comprar créditos de API para esse caminho. Veja [Gerenciar uso](https://chatgpt.com/settings/usage) e a [documentação oficial](https://developers.openai.com/siwc/token-sharing-open-source). Em 04/11/2026, login, listagem de modelos e uma resposta real de teste foram confirmados. A análise comercial integral continua em validação; o teste de conexão não comprova que todas as ferramentas e etapas funcionam para qualquer conta.

A **API com chave** fica recolhida como opção separada, com cobrança por uso. Só passa a ser o provedor ao clicar em **Salvar e usar API**. Essa opção usa chave, modelo e saldo próprios; a sugestão `gpt-5.4-mini` é editável e não se aplica automaticamente ao catálogo ChatGPT. Desconectar o ChatGPT ou atingir seus limites não ativa a API paga.

Cada pessoa autoriza suas próprias contas. As credenciais ficam em `%LOCALAPPDATA%/PronixBeta`, protegidas com DPAPI e vinculadas ao usuário do Windows. Não acompanham uma cópia do programa nem aparecem no relatório. Não cole senha, cookie ou token na interface.

Conectar, carregar modelos e salvar configurações não inicia uma análise. Importar produtos e consultar a JoomPulse sem IA continuam disponíveis sem conexão ChatGPT ou chave de API.

A JoomPulse renova o acesso automaticamente enquanto o programa local estiver em execução e a autorização permitir. O contador em Integrações indica a renovação prevista, não um prazo de novo login. Falhas temporárias mostram a espera; uma autorização recusada produz aviso global e botão **Reconectar minha conta**. A leitura periódica do status é somente leitura e preserva os campos e a análise em andamento. Veja os [estados da conexão](JOOMPULSE.md#renovação-e-avisos-de-conexão).

## Importar, analisar e revisar

1. Abra **Análise de mercado** e informe cliente, especialista e data.
2. Importe a tabela do cliente pela extensão Pronix Hub pareada. Alternativamente, use PDF pesquisável ou HTML salvo da página. Confira produtos, custos, preços e referências; um link de busca não identifica um anúncio específico.
3. Com JoomPulse e IA prontas, clique em **Analisar produtos**. Os dados comerciais atuais e os retornos de consulta são enviados à OpenAI, usando o provedor selecionado. A IA pode consultar a JoomPulse e pesquisar fontes oficiais.
4. Se quiser somente dados e cálculos locais, escolha **Consultar dados sem IA**. A consulta pode consumir a franquia MCP da JoomPulse mesmo sem usar IA.
5. Revise o parecer e a devolutiva de cada produto. Abra os detalhes para conferir concorrentes, categoria, cenários, fontes, premissas e limitações. Produtos iguais, similares, diferentes e equivalência incerta são identificados separadamente.
6. Edite a mensagem, copie o texto ou ajuste o parecer com justificativa. Use **Salvar análise** para reabrir depois. Esta área não exige gerar PDF.

Abrir uma análise salva não inicia consultas. **Atualizar cálculos locais** usa os dados existentes, sem chamar a IA nem consultar novamente a JoomPulse. Uma nova análise com IA precisa ser iniciada explicitamente.

### Acompanhar e retomar uma análise

O programa pode trabalhar em **até três produtos ao mesmo tempo**, mantendo as consultas e os dados de cada produto separados. A tela mostra o andamento e a quantidade concluída; os novos pareceres aparecem somente quando o lote inteiro termina e passa pelas conferências.

Se houver uma falha, a tela oferece **Retomar produtos pendentes** quando existe progresso válido, ou **Tentar novamente** quando não existe. **Abrir revisão anterior** permite voltar ao que já estava salvo, com aviso de que a tentativa mais recente não foi concluída.

Os produtos já validados são guardados em um arquivo temporário local, em `runtime/jobs`, por **uma hora desde o início da tentativa original**. Retomar não renova esse prazo. O motor confere novamente a identidade, os dados de entrada e as evidências antes de reaproveitar um produto: os pendentes e os produtos alterados voltam à análise; os demais não repetem suas consultas. Alterar o contexto pode invalidar todos os produtos. Trocar documento, conta, provedor ou modelo exige uma nova análise.

Esse progresso temporário não é um relatório parcial para envio ao cliente. A revisão anterior e os textos manuais permanecem preservados; o lote completo é aplicado ao final. Depois de salvar o resultado completo, os arquivos temporários de retomada desse relatório são removidos.

## De onde vêm os dados

| Origem | Uso |
| --- | --- |
| Dados comerciais importados e revisados | Produto, referência, custo, preço informado, contexto logístico e imposto. Ausências permanecem ausentes; imposto informado como zero é preservado. |
| JoomPulse MCP | Anúncios, preços, categorias e estimativas disponíveis, com períodos e significado. A conexão é somente de leitura. |
| API oficial do Mercado Livre (`listing_prices`) | Comissão Clássico/Premium e tarifa fixa por categoria e preço. Requer a conexão Mercado Livre do Pronix. É a tabela vigente da categoria, não cotação da conta do cliente. |
| Tabela oficial de frete local | Valores versionados por preço e peso tarifável, com fonte, data da conferência e condições de aplicação. O prazo de revisão local impede reutilização automática de uma tabela vencida. |
| Fontes oficiais consultadas | Regras e informações públicas de Mercado Livre, JoomPulse e gov.br. Uma tabela pública pode fundamentar uma estimativa, mas não comprova a cotação da conta. |
| Pareceres do Hub | Histórico do robô e do especialista. Não entram como evidência da nova análise nem viram automaticamente taxas, custos ou confirmação de equivalência. |
| Revisão do especialista | Correções comerciais, seleção de concorrentes, custos conferidos, mensagem manual e parecer justificado. |

A análise com IA usa os dados atuais da revisão, não apenas o PDF original. O texto manual da devolutiva e o parecer pessoal não são enviados como fatos de mercado. A planilha de Ads não participa dessa chamada.

Identificar um código confirma qual anúncio foi consultado, não que o produto do cliente tenha a mesma variação, voltagem, tamanho ou kit. A comparação deve considerar essas diferenças. Um similar pode ajudar na avaliação de posicionamento, mas não é apresentado como idêntico.

## Custos e cenários

Os valores financeiros são calculados por uma função local e conferidos antes da incorporação da resposta da IA. Comissão percentual e tarifa fixa permanecem separadas para evitar duplicidade. Os valores monetários são arredondados ao centavo.

| Base do cenário | Significado |
| --- | --- |
| **Estimativa** (`estimate`) | Custos estimados com fontes oficiais consultadas e premissas explícitas. Não é cotação específica da conta. A devolutiva precisa identificar o resultado como estimado. |
| **Cotação informada** (`quote`) | Custos explicitamente conferidos pelo especialista, com fonte, confirmação dos custos aplicáveis e preço correspondente à cotação. Mudar preço ou logística pode exigir outra cotação. |
| **Incompleto** (`incomplete`) | Faltam custos necessários. O programa não apresenta lucro líquido confirmado nem completa os campos com zero. |

Se apenas embalagem, publicidade ou outros custos adicionais ainda não foram informados, a prévia pode mostrar o **saldo antes dos custos não informados** e seu percentual sobre o preço. Esse valor só aparece quando custo de compra, comissão, tarifa fixa, frete e imposto já têm valores. Ele ajuda a avaliar o espaço restante para os gastos ausentes; não é lucro líquido, não confirma as premissas de frete e não autoriza aprovação sozinho. Se faltar algum desses custos principais, o saldo parcial também permanece indisponível.

No MCP conectado durante a validação, não havia uma ferramenta que fornecesse a cotação completa de comissão, tarifa fixa e frete efetivo da conta. Por isso a comissão vem da API oficial do Mercado Livre, descrita abaixo. Consultar regras públicas ou simular um produto não dá acesso às condições particulares do vendedor.

Confira a cotação no [simulador oficial de custos do Mercado Livre](https://www.mercadolivre.com.br/simulador-de-custos), considerando categoria, preço, modalidade e condições da operação. Frete grátis ao comprador não significa custo zero para o vendedor. No Full, preparação, envio ao centro de distribuição e armazenagem precisam ser considerados quando aplicáveis. Custos estimados, inclusive zero, exigem fonte e premissa; a tabela local tem escopo definido e não cobre todas as operações.

### Frete oficial versionado

O programa contém uma cópia numérica da [tabela oficial de custos de envio 48392](https://www.mercadolivre.com.br/ajuda/custos-envio-reputacao-verde-sem-reputacao_48392), vigente desde **24/08/2026** e conferida em **04/11/2026**. O prazo de revisão adotado pelo programa é de 30 dias: a referência não fornece tarifas automaticamente para análises anteriores à vigência ou posteriores a **04/12/2026**. Essa data é um limite local de conferência, não uma garantia do Mercado Livre de que os valores permanecerão inalterados.

- Aplica-se a produtos novos, vendedores MercadoLíder, com reputação verde ou sem reputação, nas modalidades Full, Coleta e Agências, sujeitas às condições da fonte.
- Não se aplica automaticamente a Correios, Flex, produtos usados, anúncios gratuitos, Full Super, livros, alimentos para animais ou outras categorias com regra especial.
- O cálculo usa o preço e o **peso tarifável do pacote**. Peso real, peso volumétrico e embalagem precisam ser considerados; um peso estimado deve aparecer como premissa, nunca como medição confirmada.
- Abaixo de R$ 19, aplica-se o teto de 50% do preço. Quando há meio centavo, o programa arredonda esse teto para baixo como política conservadora local, pois a fonte não detalha esse caso.
- O envio rápido abaixo de R$ 79 usa a coluna correspondente à faixa de R$ 79 a R$ 99,99 como alternativa exclusiva. Esse valor substitui o frete padrão; os dois não são somados.

A ferramenta local de **sensibilidade de frete** recebe até quatro preços e três hipóteses de peso tarifável, com rótulo, justificativa e condições da operação. Ela consulta a matriz local vigente e devolve os custos de envio correspondentes, sem acesso à conta do vendedor. As hipóteses não são medições; o cálculo não confirma elegibilidade, logística, armazenagem ou outros custos desconhecidos. Cada cenário deve preservar as condições que produziram aquele frete. Uma estimativa nunca é promovida automaticamente a cotação.

A [regra oficial de comissão por vender](https://developers.mercadolivre.com.br/pt_br/descricao-de-produtos/comissao-por-vender), atualizada em 03/09/2026 e conferida em 04/11/2026, fundamenta **tarifa fixa zero** para ME2 nas modalidades `fulfillment`, `cross_docking` e `xd_drop_off`. Nesses casos, não se adiciona a antiga tarifa fixa ao custo de envio da tabela. Comissão percentual e frete continuam separados. A regra não é generalizada para Flex, Correios, logística desconhecida ou outra modalidade, nem confirma que a conta é elegível.

### Comissões pela API do Mercado Livre

A **comissão** (Clássico e Premium) e a **tarifa fixa** vêm da API oficial do Mercado Livre ([`/sites/MLB/listing_prices`](https://developers.mercadolivre.com.br/pt_br/comissao-por-vender)), consultada por categoria e por preço, sem abrir abas nem depender da extensão. A categoria vem da JoomPulse; se faltar, o Mercado Livre sugere a categoria pelo título e a análise avisa para conferir. Cada preço é consultado separadamente e a taxa nunca é transferida entre preços. Os valores são a tabela vigente da categoria: estimativa, não cotação particular da conta do cliente. Para usar, configure o aplicativo do Mercado Livre e conecte uma conta em **Integrações → Mercado Livre · comissões** (veja [MERCADO-LIVRE.md](MERCADO-LIVRE.md)). Sem essa conexão, a análise continua, mas a comissão fica como lacuna explícita.

**Não existe meta de 30% por padrão.** Se 30% aparecer, será somente um cenário comparativo identificado; não altera a margem desejada do cliente. Mínimo de compra e margem informada no Hub também não viram automaticamente quantidade pretendida ou meta. Imposto zero não é usado para presumir o regime tributário.

Uma sugestão de preço precisa considerar concorrentes e custos, não apenas maximizar margem. A quantidade sugerida exige justificativa; sem base suficiente, fica ausente. Lote, armazenagem e demais custos não são preenchidos com números de exemplos. Cenários de estoque e giro não garantem vendas.

## Períodos e estimativas de mercado

- A janela principal solicitada para vendas e faturamento é de até **120 dias**. O resultado informa o período realmente disponível. Algumas semanas de dados não representam os 120 dias completos.
- Vendas e faturamento da JoomPulse podem ser estimativas. Ausência de série não é zero vendas. Não são somados períodos sobrepostos nem repetidos os totais de um catálogo em várias ofertas.
- Dados do anúncio, de todo o catálogo e médias históricas ficam identificados separadamente. Médias desde a criação não são vendas específicas dos 120 dias nem faturamento acumulado exato.
- Séries semanais e mensais são alternativas independentes: não são somadas entre si. O programa prepara opções por anúncio, período e tipo de métrica, preservando lacunas e valores ausentes. A logística do catálogo é identificada como sendo da oferta principal quando essa informação existe; ausência não significa que o anúncio não seja Full.
- Atualidade do preço e janela de vendas são verificações diferentes. Os critérios comerciais locais usam uma referência de recência de até 30 dias; alguns critérios DVP exigem conferência na data da análise.
- Não há limites numéricos formalizados para classificar automaticamente toda demanda em Alta/Média/Baixa. Alegações de crescimento precisam de dados comparáveis. A avaliação contextual com IA deve explicar os dados e os riscos da recomendação.
- A fração de 10% usada no DVP é uma comparação aritmética, não participação garantida ou previsão de vendas do cliente.

## Parecer e alterações

A IA apresenta **Validado**, **Atenção** ou **Invalidado**, com justificativa e devolutiva. Um parecer favorável pode usar um cenário estimado; isso precisa estar explícito e não o transforma em cotação confirmada ou garantia de retorno. Dados incompletos continuam sinalizados. Os cálculos locais e a revisão manual também podem apresentar **Não concluído** ou **Não correspondente**.

A mensagem manual e o parecer do especialista permanecem preservados ao receber um resultado novo. A resposta só pode ser associada à mesma análise, fonte e referência. Se custo, preço, imposto, taxas ou seleção relevante de concorrentes mudarem, a resposta anterior é marcada como desatualizada. Ela permanece consultável como histórico, sem ser apresentada como conclusão nova para os dados alterados.

Os pareceres do robô e do especialista do Hub conservam seus textos e datas disponíveis. Adotar um parecer exige um clique explícito e não confirma automaticamente tarifas ou equivalência. Textos históricos maiores que 1.000 caracteres permanecem íntegros; a adoção abre um trecho para revisão antes de usá-lo na devolutiva.

## Critérios locais e modo sem IA

“Análise comercial”, “Referência DVP” e “Comparação dos critérios” ficam em áreas técnicas recolhidas. Os identificadores e as revisões antigas são preservados. Trocar o critério não inicia uma análise com IA e não modifica a mensagem manual.

Na análise comercial local, o critério inicial considera preço frente aos concorrentes aceitos, custos completos, lucro positivo, meta informada e vendas observadas. Tolerância de preço, mínimo de margem e limite de estoque são parâmetros internos editáveis, não regras do Mercado Livre. Custos faltantes geram uma avaliação parcial; se os custos conhecidos já alcançam o preço, o cenário pode ser inviável mesmo sem os demais custos.

O DVP conserva suas próprias entradas e confirmações. Primeira página, faturamento acumulado, avaliações recentes e escolha de anúncios não são inferidos automaticamente de uma busca JoomPulse. A coleta direta atual consulta avaliações dos últimos sete dias da referência; isso não atende, por si só, ao requisito DVP de 60 dias dos anúncios escolhidos. Veja a [documentação dos critérios](METODOLOGIAS_MERCADO.md).

## Limites e estado da validação

- O relatório aceita até **30 produtos**. Documentos maiores precisam ser divididos; não devem ter produtos omitidos silenciosamente.
- A execução com IA tem até **três produtos em paralelo**, limite de **20 rodadas por produto** e **40 consultas MCP de dados JoomPulse por tentativa**, compartilhadas por todos os produtos dessa tentativa. Não são 40 consultas por produto. Uma retomada abre nova tentativa, pesquisando apenas o que não pôde ser reaproveitado. A franquia MCP e os limites do plano ChatGPT, ou do modelo/saldo de API escolhido, continuam valendo e podem interromper antes desse teto.
- Uma resposta truncada, inválida ou que não cubra corretamente os produtos é recusada. Uma falha não substitui a revisão por uma resposta incompleta nem troca automaticamente o provedor.
- A consulta direta tem orçamento de até **75 tentativas pagas**, limitado também pela cota informada. Pode receber até 30 resultados por busca e prioriza até cinco candidatos para detalhamento. A lista não representa todo o mercado. Limites e falhas ficam registrados; não provam ausência de concorrência ou vendas.
- Referências, fontes, períodos e cálculos são verificados pelo programa. Essas verificações não substituem a revisão comercial nem comprovam toda interpretação da IA.
- **Estado em 04/11/2026:** conexão JoomPulse e consulta direta testadas; login ChatGPT, listagem de modelos e resposta real de teste confirmados. Os testes automatizados de validação e preservação de revisões usam respostas simuladas. Em 06/11/2026 a consulta real de comissões pela API do Mercado Livre foi confirmada para o cesto. A análise comercial integral pelo plano e a cobertura das demais condições continuam em validação. O caminho opcional de API com chave também não foi validado integralmente. Configuração salva, por si só, não comprova elegibilidade, saldo ou acesso a um modelo.
- **Verificação automatizada em 04/11/2026:** uma rodada passou pelos 634 testes da suíte Python e três testes offline da interface para conexão JoomPulse, ChatGPT e análise de mercado também passaram. A revisão independente posterior acrescentou regressões específicas, discriminadas no registro de validação. A última análise comercial real foi interrompida sem substituir o relatório; a nova execução real continua pendente. O caso de oito produtos, concorrência de até três e retomada de sete concluídos foi testado com respostas simuladas e armazenamento temporário. Não foi realizado um benchmark real de oito produtos, nem esses testes comprovam desempenho ou custo em contas reais. Veja o [registro de validação](VALIDACAO-BETA.md).

Performance e Reputação continuam na área de direcionamentos, com cálculos sem IA e exportação PDF. Esta mudança não altera campanhas, métricas publicitárias ou a exportação desses relatórios.

## Implementação

`market_data.py` faz a consulta à JoomPulse. `market_fees.py` junta a comissão do Mercado Livre e o frete da tabela oficial. `market_shipping.py` valida e calcula a tabela local em `resources/market/`; `hub_bridge.py` recebe a importação da tabela do Hub pela extensão; `mercadolivre.py` consulta comissões na API oficial do Mercado Livre. `market_rules.py` e `market_dvp.py` calculam os critérios locais sem rede. `market_workflow.py` preserva evidências, resultados e revisões; `market_presentation.py` prepara a apresentação. A interface principal é `static/pronix-ui-v02.js`.
