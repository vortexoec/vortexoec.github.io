# Validação do beta visual v0.2

Data: 30/10/2026.

## Resultado

141 testes automáticos passaram: importadores e cálculos existentes, OAuth JoomPulse, Google com respostas simuladas, rotas locais, imagens, modelos, extração de ações, schema e exportação. Os gráficos foram testados com lacunas, pontos isolados, rótulos longos, valores extremos e múltiplas páginas. O PDF preservou textos longos e imagens com legenda.

Na interface, foram validados: criação de Reputação sem arquivos; edição, salvamento e reabertura; checklist; salvar e reutilizar modelos; cópia independente com responsável/prazo/conclusão reiniciados; imagens e legendas; detalhe oculto na prévia; trecho original das ações de reunião. O envio das imagens foi exercitado pela API local e sua edição/reutilização foi conferida no navegador. O seletor automatizado de arquivos não foi validado por limitação de acesso file:// da extensão de automação.

## Exemplos para revisão

- **EXEMPLO VISUAL - Conta em operação:** 8 páginas; métricas das fontes de validação autorizadas, dois gráficos, seis ações e um print ilustrativo.
- **EXEMPLO VISUAL - Reputação:** 5 páginas; seis cards iniciais, checklist e print ilustrativo.

Todas as páginas desses dois PDFs foram renderizadas e inspecionadas. Os exemplos têm nome explícito de demonstração e permanecem editáveis no programa. Os arquivos ficam em `analise de mercado`, organizados por nome e data. As folhas de conferência e os scripts de reprodução ficam em `runtime/qa`.

## Limites de validação

- Google Agenda/Meet/Drive: fluxo implementado e coberto com APIs simuladas; ainda requer configurar o cliente Desktop e autorizar a conta real de cada especialista.
- Gravações são referenciadas por link. O beta importa transcrição existente, sem transcrever áudio/vídeo.
- Extração da reunião usa regras e frases explícitas; não é um resumo semântico de toda a conversa. Trechos e encaminhamentos exigem conferência.
- O HTML exportado permite edição de textos e checklist. A reabertura do HTML baixado não foi automatizada no Chrome; seu conteúdo, imagens incorporadas e serialização foram verificados nos testes.
- A integração automática de contas de clientes com Mercado Livre continua como melhoria futura documentada.

## Cópias da pasta sincronizada

Foram encontradas variantes de arquivo JavaScript e cópias de um relatório dentro da pasta iCloud. A causa da renomeação não foi confirmada. A interface usa agora `static/pronix-ui-v02.js`, com estabilidade e HTTP 200 verificados. As variantes foram preservadas em `runtime/backups/icloud-conflitos`.

A biblioteca deduplica relatórios pelo identificador interno e escolhe a revisão mais recente pelo horário salvo, com desempates determinísticos. A leitura não apaga nem move cópias. Novos salvamentos preservam a revisão anterior. Essa proteção não substitui um backup externo da pasta de dados.
