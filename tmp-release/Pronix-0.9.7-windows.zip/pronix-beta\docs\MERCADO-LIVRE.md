# Conexão Mercado Livre (comissões)

A análise de mercado usa a API oficial do Mercado Livre **somente para leitura** de:

- comissão percentual de **Clássico** (`gold_special`) e **Premium** (`gold_pro`) e a **tarifa fixa** de cada um, por categoria e preço — `GET /sites/MLB/listing_prices?price=…&category_id=…`;
- sugestão de categoria pelo título, quando a JoomPulse não informar — `GET /sites/MLB/domain_discovery/search`.

Nada é publicado ou alterado na conta. O frete continua vindo da tabela oficial local (`resources/market/`).

## Configurar

1. Em **Integrações → Mercado Livre · comissões**, informe o aplicativo de desenvolvedor do Mercado Livre: Client ID, Client Secret e a URL de retorno HTTPS cadastrada nele.
   - Se o **Vórtex Automação** estiver instalado neste computador, o botão **Usar o aplicativo do Vórtex** copia só esses três dados (os tokens do Vórtex não são lidos nem renovados).
2. Clique em **Conectar conta**, autorize no Mercado Livre e copie o endereço completo da página que abrir (contém `?code=…&state=…`).
3. Cole esse endereço no campo **Endereço depois de autorizar** e clique em **Concluir conexão**.

O acesso dura 6 horas e é renovado automaticamente pelo Pronix. O refresh token do Mercado Livre é de uso único, por isso o Pronix guarda a conexão própria em `%LOCALAPPDATA%\PronixBeta\mercadolivre.dpapi`, criptografada pelo DPAPI do Windows.

**Recomendação:** conecte uma conta diferente da usada no Vórtex Automação, para que um programa nunca invalide a autorização do outro. Qualquer conta serve: a comissão consultada é a tabela da categoria, não depende da reputação.

## Limites

- A API não permite consultar anúncios de outros vendedores (`/items/{id}` responde 403); por isso a categoria vem da JoomPulse.
- O valor é a tabela vigente da categoria: **estimativa**, não cotação particular da conta do cliente (campanhas e descontos específicos podem alterar).
- Validação real em 06/11/2026: cesto (MLB269766) — Clássico 11,5% / Premium 16,5% a R$ 80 e R$ 78,90; 10,5% / 13,5% a R$ 150; tarifa fixa 0. Mesmos valores que a calculadora JoomPulse exibia.
