"""Local orchestration: immutable market evidence, editable review, pure calculations."""
from __future__ import annotations

from copy import deepcopy
from datetime import date, timedelta
import math
import json
import re
import unicodedata
from . import market, storage
from .market_data import extract_references, reference_spec
from .market_rules import analyze_product, DEFAULT_POLICY
from .market_decision import decision_for
from .market_methods import normalize_methodology, apply_methods
from .market_dvp_source import build_dvp_evidence

INPUTS = ('cost','salePrice','purchaseQuantity','salesQuantity','desiredMarginPercent')
FEES = ('commissionPercent','fixedFee','shipping','otherCosts','quotedPrice','validPriceMin','validPriceMax','packageWeightKg')


def _dvp_review(value, date_changed=False):
    value=deepcopy(value) if value is not None else {}
    if not isinstance(value,dict): raise ValueError('Confira os dados da análise DVP.')
    for field in ('search','selection','sourceMetadata'):
        if field in value and not isinstance(value[field],dict):
            raise ValueError('Confira os dados da busca e dos anúncios DVP.')
    rows=value.get('listings',[])
    if not isinstance(rows,list) or len(rows)>500 or any(not isinstance(r,dict) for r in rows):
        raise ValueError('A análise DVP aceita até 500 anúncios por produto.')
    try: encoded=json.dumps(value,ensure_ascii=False,allow_nan=False)
    except (ValueError,TypeError): raise ValueError('Há um valor inválido nos anúncios DVP.') from None
    if len(encoded)>2000000: raise ValueError('Os dados DVP deste produto ficaram muito grandes.')
    if date_changed:
        value.setdefault('search',{}).update(firstPageConfirmed=False,countsComplete=False)
        value.setdefault('selection',{})['confirmed']=False
        for row in rows: row['firstPageConfirmed']=False
    return value


def _catalog_match_text(value):
    """Normalize typography only; preserve quantities, punctuation and models."""
    if not isinstance(value,str): return ''
    return ' '.join(unicodedata.normalize('NFKC',value).casefold().split())


def _verified_shared_catalog(reference,candidate,reference_confirmed):
    """Match offers inside a verified catalog after the user binds the product.

    MLB stubs and MLBU variation groups are never catalog identities. This
    establishes equivalence only, not current price, activity or fee validity.
    """
    catalog=reference.get('catalogId')
    if (reference_confirmed is not True or reference.get('referenceValidated') is not True
            or candidate.get('referenceValidated') is not True
            or reference.get('isCatalogProduct') is not True or candidate.get('isCatalogProduct') is not True
            or reference.get('kind') not in ('item','catalog') or candidate.get('kind')!='item'
            or not isinstance(catalog,str) or not re.fullmatch(r'MLB\d{5,16}',catalog)
            or not re.fullmatch(r'MLB\d{5,16}',str(reference.get('id') or ''))
            or not re.fullmatch(r'MLB\d{5,16}',str(candidate.get('itemId') or candidate.get('id') or ''))
            or candidate.get('catalogId')!=catalog):
        return False
    brand=_catalog_match_text(reference.get('brand'))
    title=_catalog_match_text(reference.get('title'))
    return bool(brand and title and brand==_catalog_match_text(candidate.get('brand'))
                and title==_catalog_match_text(candidate.get('title')))


def _number(value, label, percent=False):
    if value in (None,''): return None
    if isinstance(value,bool): raise ValueError('Confira o valor de '+label+'.')
    try:
        text=str(value).replace('R$','').replace('%','').strip()
        if ',' in text: text=text.replace('.','').replace(',','.')
        number=float(text)
    except (ValueError,TypeError): raise ValueError('Confira o valor de '+label+'.') from None
    if not math.isfinite(number) or number<0 or number>1e12 or (percent and number>=100):
        raise ValueError('Confira o valor de '+label+'. Use um número não negativo'+(' menor que 100%.' if percent else '.'))
    return number


def prepare(report, document=None):
    """Initialize once and retain specialist edits only within the same source."""
    result=deepcopy(report)
    if not result.get('pdfId'): return result
    document=document or market.report_document(result)
    products=document.get('products')
    if not isinstance(products,list):
        refs=extract_references(str(document.get('text',''))+'\n'+'\n'.join(document.get('links') or []))
        products=[{'index':i+1,'name':f'Produto {i+1} · {reference_spec(ref).get("id") or "conferir"}',
                   'reference':ref,'cost':None,'salePrice':None,'fields':{}} for i,ref in enumerate(refs)]
    if len(products)>30: raise ValueError('Divida a análise em até 30 produtos por relatório.')
    if not products:
        result.pop('marketAnalysis',None);result.pop('marketText',None)
        result['sections']=[s for s in result.get('sections',[]) if not str(s.get('id','')).startswith('market-')]
        result['sources']=[s for s in result.get('sources',[]) if not isinstance(s,dict) or s.get('kind')!='market']
        return result
    if document.get('kind')=='pdf':
        result['productSource']={'type':'pdf','id':result['pdfId'],'name':document.get('name','PDF de produtos'),
                                 'products':deepcopy(products),'metadata':deepcopy(document.get('metadata') or {})}
    elif document.get('kind')=='html':
        result['productSource']={**(result.get('productSource') or {}),'id':result['pdfId'],'type':'html',
            'name':document.get('name','Planilha de produtos'), 'products':deepcopy(products),
            'metadata':deepcopy(document.get('metadata') or {})}
    previous=result.get('marketAnalysis') or {}
    if not isinstance(previous,dict): raise ValueError('Estrutura da análise de mercado inválida.')
    same_source=not previous or previous.get('sourceId')==result['pdfId']
    if not same_source: previous={}
    metadata=document.get('metadata') or {}
    defaults={'analysisDate':result['date'],'logistics':metadata.get('logistics',''),
              'cityState':metadata.get('cityState',''),'taxPercent':metadata.get('taxPercent')}
    context={**defaults,**(previous.get('context') or {}),'analysisDate':result['date']}
    context['taxPercent']=_number(context.get('taxPercent'),'imposto',True)
    context['logistics']=str(context.get('logistics') or '')[:250]
    context['cityState']=str(context.get('cityState') or '')[:250]
    old={str(p.get('key')):p for p in previous.get('products',[]) if isinstance(p,dict)}
    entries=[]
    for i,source in enumerate(products):
        key=f'product-{i+1}'; saved=deepcopy(old.get(key) or {})
        source=deepcopy(source); source['index']=i+1
        inputs=saved.get('inputs') or {}
        if not isinstance(inputs,dict): raise ValueError('Dados comerciais inválidos.')
        inputs={name:_number(inputs.get(name,source.get(name)),name,'Percent' in name) for name in INPUTS}
        alternatives=(saved.get('inputs') or {}).get('alternativeMargins',[])
        if not isinstance(alternatives,list) or len(alternatives)>10: raise ValueError('Informe até dez cenários de margem.')
        inputs['alternativeMargins']=[_number(v,'margem alternativa',True) for v in alternatives if v not in (None,'')]
        fees=saved.get('fees') or {}
        if not isinstance(fees,dict): raise ValueError('Custos da operação inválidos.')
        fees={**{name:_number(fees.get(name),name,name=='commissionPercent') for name in FEES},
              **{name:fees.get(name) is True for name in ('confirmed','allApplicableCostsConfirmed')},
              **{name:str(fees.get(name) or '')[:2000] for name in ('source','categoryId','listingType')}}
        review=saved.get('review') or {}
        if not isinstance(review,dict) or not isinstance(review.get('competitors',{}),dict): raise ValueError('Revisão de concorrentes inválida.')
        review={**{'referenceIdentityConfirmed':False,'competitors':{},'override':{'status':'','reason':''},'executiveSummary':'','notes':''},**review}
        old_date=(previous.get('context') or {}).get('analysisDate')
        dvp_review=_dvp_review(saved.get('dvpReview'),bool(old_date and old_date!=result['date']))
        if old_date and old_date!=result['date']:
            for decision in review['competitors'].values():
                if isinstance(decision,dict): decision['currentPriceConfirmed']=False
            fees.update(confirmed=False,allApplicableCostsConfirmed=False)
            result.setdefault('warnings',[]).append('A data da análise mudou: confira novamente os preços atuais e as cotações de custos.')
        for name in ('notes','executiveSummary'): review[name]=str(review.get(name) or '')[:20000]
        evidence=saved.get('evidence') or {}
        # A changed offer invalidates identity confirmations and all previous facts.
        bound_reference=evidence.get('sourceReference',saved.get('boundReference',saved.get('source',{}).get('reference')))
        if bound_reference != source.get('reference'):
            evidence={}; review['referenceIdentityConfirmed']=False;review['competitors']={}
            dvp_review={}
            review['override']={'status':'','reason':''}; review['executiveSummary']=''
            fees.update(confirmed=False,allApplicableCostsConfirmed=False)
        entry={'key':key,'index':i+1,'source':source,'boundReference':source.get('reference'), 'inputs':inputs,'fees':fees,
               'review':review,'evidence':evidence,'dvpReview':dvp_review}
        entries.append(entry)
    result['marketAnalysis']={'version':1,'mode':'rules','sourceId':result['pdfId'],
        'collectedAt':previous.get('collectedAt'),'context':context,
        'methodology':normalize_methodology(previous.get('methodology')),
        'policy':{**DEFAULT_POLICY,**(previous.get('policy') or {})},'products':entries}
    result['warnings']=list(dict.fromkeys(result.get('warnings',[])))
    return result


def recalculate(report, document=None):
    """Recalculate locally. No provider calls and no save; callers control persistence."""
    result=prepare(report,document)
    envelope=result.get('marketAnalysis')
    if not envelope: return result
    for entry in envelope['products']:
        evidence=deepcopy(entry['evidence']); review=entry['review']
        reference=evidence.setdefault('reference',{})
        automatic=(envelope.get('policy') or {}).get('automatic') is True
        # Modo automático (importação pelo Hub): a consulta exata da JoomPulse confirma a referência.
        reference['identityValidated']=review.get('referenceIdentityConfirmed') is True or (automatic and reference.get('referenceValidated') is True)
        evidence['fees']=deepcopy(entry['fees'])
        candidate_matches={}
        for group in ('candidates','competitors'):
            for candidate in evidence.get(group) or []:
                candidate_id=str(candidate.get('itemId') or candidate.get('id') or '')
                decision=review['competitors'].get(candidate_id) or {}
                if not isinstance(decision,dict): raise ValueError('Confirmação do concorrente inválida.')
                basis,reason=None,None
                if decision.get('exclude') is True:
                    candidate.update(exactMatch=False,excluded=True)
                    basis,reason='specialist_exclusion','Candidato excluído explicitamente pelo especialista.'
                elif 'exactMatchConfirmed' in decision:
                    candidate['exactMatch']=decision['exactMatchConfirmed'] is True
                    basis='specialist_confirmation' if candidate['exactMatch'] else 'specialist_rejection'
                    reason='Equivalência confirmada pelo especialista.' if candidate['exactMatch'] else 'Equivalência não confirmada por decisão explícita do especialista.'
                elif not candidate.get('excluded') and _verified_shared_catalog(reference,candidate,reference['identityValidated']):
                    candidate['exactMatch']=True
                    basis='verified_shared_catalog'
                    reason='Mesmo catálogo Mercado Livre verificado, marca e título iguais; referência do produto confirmada pelo especialista. Preço atual, disponibilidade e custos são conferidos separadamente.'
                if basis:
                    candidate['exactMatchBasis']=basis
                    candidate['exactMatchSource']='Catálogo Mercado Livre via JoomPulse + confirmação da referência' if basis=='verified_shared_catalog' else 'Especialista'
                candidate_matches[candidate_id]={'exactMatch':candidate.get('exactMatch') is True,
                    'exactMatchBasis':basis,'source':candidate.get('exactMatchSource') if basis else None,
                    'catalogId':candidate.get('catalogId'),'reason':reason,'excluded':candidate.get('excluded') is True}
                if decision.get('currentPriceConfirmed') is True:
                    candidate.update(current=True,active=True,observedAt=envelope['context']['analysisDate'],confirmationSource='specialist')
        override=review.get('override') or {}
        if not isinstance(override,dict): raise ValueError('Parecer do especialista inválido.')
        entry['analysis']=analyze_product({**entry['source'],**entry['inputs']},envelope['context'],evidence,
                    envelope['policy'],override if override.get('status') else None)
        entry['candidateMatches']=candidate_matches
        for accepted in entry['analysis'].get('market',{}).get('competitors',[]):
            match=candidate_matches.get(str(accepted.get('id') or '')) or {}
            accepted['exactMatchBasis']=match.get('exactMatchBasis')
            accepted['exactMatchSource']=match.get('source')
            accepted['exactMatchReason']=match.get('reason')
        entry['analysis']['decision']=decision_for(entry)
        entry['dvpReview']=build_dvp_evidence(entry,envelope['context'])
        apply_methods(entry,envelope['context'],envelope['methodology'])
        if automatic:
            from .market_auto import verdict
            limits=storage.read_json(storage.RUNTIME/'settings.json',{}) if hasattr(storage,'read_json') else {}
            auto=verdict(entry,envelope['context'],{**{k:v for k,v in (limits or {}).items() if k.startswith('auto')},**(envelope.get('policy') or {})})
            entry['analysis']['autoVerdict']=auto
            decision=entry['analysis'].get('decision') or {}
            if not decision.get('specialistOverride'):
                calculated={'status':auto['status'],'label':auto['label'],'message':auto['message']}
                entry['analysis']['decision']={**decision,**calculated,'source':'automatic','preliminary':False,'incomplete':auto.get('incomplete'),
                    'reasons':auto['reasons'],'calculated':calculated}
    from .market_presentation import text_report
    result['marketText']=text_report(result)
    attachments=[]
    for section in result.get('sections',[]):
        if str(section.get('id','')).startswith('market-') and section.get('images'):
            attachments.append({'id':'specialist-attachments-'+str(section['id']),
                'title':'Imagens complementares · '+str(section.get('title') or 'Mercado'),
                'body':'Orientações visuais acrescentadas pelo especialista.', 'images':deepcopy(section['images'])})
    result['sections']=[s for s in result.get('sections',[]) if not str(s.get('id','')).startswith('market-')]
    known_ids={s.get('id') for s in result['sections']}
    result['sections'].extend(s for s in attachments if s['id'] not in known_ids)
    result['sections'].insert(0,{'id':'market-analysis','title':'Viabilidade dos produtos · análise de mercado','body':result['marketText']})
    result['warnings']=[w for w in result.get('warnings',[]) if not w.startswith('Análise de mercado pendente:')]
    if not envelope.get('collectedAt'):
        result['warnings'].append('Análise de mercado pendente: a coleta automática da JoomPulse ainda não foi concluída.')
    result['sources']=[s for s in result.get('sources',[]) if not isinstance(s,dict) or s.get('kind')!='market']
    result['sources'].append({'kind':'market','name':'JoomPulse MCP · estimativas da fonte e cálculos locais; confirmações e parecer do especialista registrados separadamente.'})
    if not result.get('accountId') and not result.get('sheetId'):
        if result.get('title')=='Análise de mercado e performance': result['title']='Análise de mercado e viabilidade'
        summary=result.get('summary') or {}
        if summary==result.get('marketGeneratedSummary') or summary.get('headline')=='Transformar os achados em um plano de execução':
            count=len(envelope['products'])
            confirmed=sum(p['analysis']['decision']['status']=='validado' for p in envelope['products'])
            summary={'headline':'Uma decisão fundamentada para cada produto',
                     'body':f'{count} produtos organizados para revisão, com {confirmed} parecer(es) final(is) viável(is). '
                     'Compare as ofertas, confirme as características e os custos da operação e revise os próximos passos indicados em cada produto. '
                     'Dados ausentes permanecem sinalizados; o parecer do especialista pode ser ajustado antes da entrega.'}
            result['summary']=summary;result['marketGeneratedSummary']=deepcopy(summary)
        result['warnings']=[w for w in result['warnings'] if w!='Relatório de Ads não importado. Não há métricas publicitárias calculadas.']
    return result


def apply_evidence(report, collection, collected_at=None):
    """Merge only matching references; a completed old job cannot change a new link."""
    result=prepare(report); envelope=result.get('marketAnalysis')
    if not envelope: raise ValueError('A fonte não contém produtos identificáveis. Importe a planilha pelo Pronix Hub.')
    if not isinstance(collection,dict) or not isinstance(collection.get('products'),list):
        raise ValueError('A coleta não retornou evidências estruturadas por produto.')
    matches={(str(p.get('index')),str(p.get('sourceReference') or '')):p for p in collection['products'] if isinstance(p,dict)}
    applied=0
    for entry in envelope['products']:
        item=matches.get((str(entry['index']),str(entry['source'].get('reference',''))))
        if item is None: continue
        entry['evidence']=deepcopy(item);applied+=1
        ref=item.get('reference') or {}
        for name in ('categoryId','listingType'):
            if not entry['fees'].get(name): entry['fees'][name]=str(ref.get(name) or '')
    if applied:
        envelope['collectedAt']=collected_at or storage.now()
    else:
        result.setdefault('warnings',[]).append('A coleta foi feita para outros links. Consulte novamente os produtos editados.')
    return recalculate(result)


def attach_narrative(report, text, origin='Texto de mercado revisado pelo especialista'):
    """Optional narrative complements the factual analysis instead of hiding it."""
    if not report.get('marketAnalysis'): return market.import_market(report,text,origin)
    result=deepcopy(report)
    result['marketNarrative']=str(text)[:200000]
    result['sections']=[s for s in result.get('sections',[]) if s.get('id')!='specialist-market-notes']
    result['sections'].append({'id':'specialist-market-notes','title':'Parecer complementar de mercado','body':result['marketNarrative']})
    result['sources']=[s for s in result.get('sources',[]) if not isinstance(s,dict) or s.get('kind')!='market-narrative']
    result['sources'].append({'kind':'market-narrative','name':origin})
    return recalculate(result)
