"""Deterministic importer for the official 'Resumo de desempenho do negócio'.

Only daily business data is aggregated. Price-band/buyer sheets and exported
footer artifacts are not added again. Account revenue never becomes Ads revenue.
"""
from __future__ import annotations

import hashlib
import re
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from .ads import PeriodCutError, _date, _fmt, _money, _ratio, _read_sheets, normalize, parse_number


FIELDS = {
    "date": ("data",),
    "accountRevenue": ("vendas brutas", "faturamento bruto", "receita bruta"),
    "accountOrders": ("quantidade de vendas", "numero de vendas"),
    "accountUnits": ("unidades vendidas",),
    "accountVisits": ("visitas",),
    "accountCancelledOrders": ("quantidade de vendas canceladas",),
    "accountCancelledRevenue": ("valor de vendas canceladas",),
    "accountReturnedOrders": ("quantidade de vendas devolvidas",),
    "accountReturnedRevenue": ("valor de vendas devolvidas",),
}
LABELS = {
    "accountRevenue": "Vendas brutas da conta",
    "accountOrders": "Vendas da conta",
    "accountUnits": "Unidades vendidas",
    "accountVisits": "Visitas (soma diária)",
    "accountConversion": "Conversão da conta",
    "accountAverageTicket": "Ticket médio por venda",
    "accountRevenuePerDay": "Vendas brutas por dia",
    "accountCancelledOrders": "Vendas canceladas",
    "accountCancelledRevenue": "Valor de vendas canceladas",
    "accountReturnedOrders": "Vendas devolvidas",
    "accountReturnedRevenue": "Valor de vendas devolvidas",
}
MONTHS = {name: index for index, name in enumerate(("janeiro", "fevereiro", "marco", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"), 1)}


def _source_period(rows):
    """Only trust explicit date intervals printed by the exported source."""
    text = normalize(" ".join(str(value or "") for row in rows[:5] for value in row))
    dates = re.findall(r"(\d{1,2}) de ([a-z]+) de (\d{4})", text)
    if len(dates) >= 2:
        try:
            result = [date(int(year), MONTHS[month], int(day)) for day, month, year in dates[:2]]
            return tuple(result) if result[0] <= result[1] else (None, None)
        except (KeyError, ValueError):
            pass
    return None, None


def _mapping(headers):
    result = {}
    for index, header in enumerate(headers):
        for key, aliases in FIELDS.items():
            if normalize(header) in aliases and key not in result:
                result[key] = index
    return result


def _choose(path):
    candidates = []
    for name, rows in _read_sheets(path):
        for index, row in enumerate(rows[:60]):
            mapping = _mapping(row)
            if "date" in mapping and "accountRevenue" in mapping and "accountOrders" in mapping:
                candidates.append((len(mapping), name, rows, index, mapping))
    if not candidates:
        raise ValueError("Formato de conta não reconhecido. Exporte Métricas > Gerar relatórios > Resumo de desempenho do negócio. O arquivo deve conter Data, Vendas brutas e Quantidade de vendas.")
    _, name, rows, header, mapping = max(candidates, key=lambda item: item[0])
    return name, rows, header, mapping


def inspect_account(path):
    name, rows, header, mapping = _choose(path)
    return {"reportType": "account", "sheet": name, "headerRow": header,
            "headers": [str(value or "") for value in rows[header]],
            "mapping": mapping, "labels": LABELS,
            "preview": [[str(value) if isinstance(value, (date, datetime)) else value for value in row] for row in rows[header + 1:header + 7]]}


def _metrics(rows, complete=True, days=None):
    result = {}
    for key in FIELDS:
        if key == "date":
            continue
        values = [row[key] for row in rows]
        result[key] = round(sum(values), 6) if values and all(value is not None for value in values) else None
    result["accountConversion"] = _ratio(result["accountOrders"], result["accountVisits"], True)
    result["accountAverageTicket"] = _ratio(result["accountRevenue"], result["accountOrders"])
    result["accountRevenuePerDay"] = _ratio(result["accountRevenue"], days or len(rows)) if complete else None
    return result


def analyze_account(path, context=None):
    context = dict(context or {})
    name, raw, header, mapping = _choose(path)
    start, end = _date(context.get("periodStart")), _date(context.get("periodEnd"))
    if bool(start) != bool(end):
        raise ValueError("Para filtrar o relatório da conta, informe a data inicial e a data final.")
    if start and end and start > end:
        raise ValueError("A data inicial não pode ser posterior à final.")
    warnings, entries, monthly, invalid, undated = [], [], [], [], 0
    declared_start, declared_end = _source_period(raw)
    dates_seen = set()
    for line, values in enumerate(raw[header + 1:], start=header + 2):
        if not any(value not in (None, "", " ") for value in values):
            continue
        cell = lambda key: values[mapping[key]] if key in mapping and mapping[key] < len(values) else None
        day = _date(cell("date"))
        month_label = normalize(cell("date"))
        is_month = month_label in MONTHS
        if day is None and not is_month:
            undated += 1
            continue
        if day and start and end and not start <= day <= end:
            continue
        if day and day in dates_seen:
            raise ValueError(f"Data duplicada na aba {name}: {day.strftime('%d/%m/%Y')}. Este importador exige uma linha diária por conta; confira se importou o Resumo de desempenho do negócio.")
        if day:
            dates_seen.add(day)
        entry = {"date": day, "sourceRow": line}
        if is_month:
            entry["periodLabel"] = str(cell("date"))
        for key in FIELDS:
            if key == "date":
                continue
            number = parse_number(cell(key))
            if number is not None and number < 0:
                number = None
                invalid.append(f"linha {line}, {LABELS[key]}")
            elif key in mapping and number is None and cell(key) not in (None, "", "-", "—"):
                invalid.append(f"linha {line}, {LABELS[key]}")
            entry[key] = number
        (monthly if is_month else entries).append(entry)
    aggregated = False
    if not entries and monthly:
        if not declared_start or not declared_end:
            raise ValueError("A fonte possui meses agregados, mas não informa um intervalo completo no cabeçalho. Exporte um relatório diário.")
        if start and end and (start != declared_start or end != declared_end):
            raise PeriodCutError(
                f"O relatório da conta traz os valores somados por mês, de {declared_start.strftime('%d/%m/%Y')} a {declared_end.strftime('%d/%m/%Y')}, "
                f"e o período pedido ({start.strftime('%d/%m/%Y')} a {end.strftime('%d/%m/%Y')}) é diferente. Não dá para cortar esses valores. "
                f"Use {declared_start.strftime('%d/%m/%Y')} a {declared_end.strftime('%d/%m/%Y')}, deixe as datas em branco ou exporte o relatório dia a dia.",
                declared_start, declared_end)
        labels = [normalize(entry["periodLabel"]) for entry in monthly]
        if len(labels) != len(set(labels)):
            raise ValueError("Há meses duplicados sem identificação do ano. Exporte um período menor ou um relatório diário.")
        entries = monthly
        aggregated = True
    if not entries:
        raise ValueError("Nenhuma linha diária reconhecida nesse período. Confira as datas e o modelo do relatório.")
    if not aggregated:
        entries.sort(key=lambda item: item["date"])
    source_start, source_end = (declared_start, declared_end) if aggregated else (entries[0]["date"], entries[-1]["date"])
    effective_start, effective_end = start or source_start, end or source_end
    expected_days = (effective_end - effective_start).days + 1
    complete = aggregated or len(entries) == expected_days
    if aggregated:
        warnings.append("A fonte personalizada agrupa as métricas por mês. O período foi comprovado no cabeçalho; totais e média por dia usam esse intervalo integral, mas janelas de 7/15/30/60/90 dias ficam indisponíveis sem linhas diárias.")
    if not complete:
        warnings.append(f"Cobertura parcial: {len(entries)} datas presentes em um período de {expected_days} dias. Dias ausentes não são zero; médias diárias do período completo ficam indisponíveis.")
    if undated:
        warnings.append(f"{undated} linha(s) sem período reconhecido ignorada(s), incluindo rodapés e resumos. Somente linhas {'mensais identificadas' if aggregated else 'diárias'} da aba {name} compõem os totais.")
    if invalid:
        warnings.append(f"{len(invalid)} célula(s) inválida(s), preservada(s) como indisponível: " + "; ".join(invalid[:6]) + ".")
    for key in FIELDS:
        if key == "date":
            continue
        missing = sum(entry[key] is None for entry in entries)
        if missing:
            warnings.append(f"{LABELS[key]} não disponível em {missing} dia(s); o total correspondente fica indisponível.")
    metrics = _metrics(entries, complete, expected_days)
    windows = []
    for length in (7, 15, 30, 60, 90):
        window_start = effective_end - timedelta(days=length - 1)
        subset = [] if aggregated else [entry for entry in entries if window_start <= entry["date"] <= effective_end]
        window_complete = len(subset) == length
        windows.append({"days": length, "start": window_start.isoformat(), "end": effective_end.isoformat(),
                        "observedDays": len(subset), "complete": window_complete,
                        "metrics": _metrics(subset) if window_complete else None})
    known = {item["days"]: item["metrics"] for item in windows if item["complete"]}
    comparisons = []
    if 7 in known and 30 in known:
        for key, label in (("accountRevenue", "vendas brutas"), ("accountOrders", "vendas"), ("accountVisits", "visitas")):
            short = _ratio(known[7][key], 7)
            baseline = _ratio(known[30][key], 30)
            variation = _ratio(short - baseline, baseline, True) if short is not None and baseline is not None else None
            if variation is not None:
                comparisons.append(f"{label.capitalize()}: média diária de 7 dias {_fmt(short)} versus 30 dias {_fmt(baseline)}; variação de {_fmt(variation)}%." + (" Desvio superior a 20% em relação à referência de 30 dias (critério interno)." if abs(variation) > 20 else ""))
    if not all(value in known for value in (7, 30, 90)):
        warnings.append("Tendência acelerando/estável/desacelerando/oscilando não classificada: faltam janelas completas de 7, 30 e 90 dias. O comparativo curto, quando disponível, é apresentado separadamente.")
    today = datetime.now(timezone(timedelta(hours=-3))).date()
    if source_end >= today:
        warnings.append("O arquivo inclui a data atual; o último dia pode estar incompleto. Evite comparar um dia em andamento com dias encerrados.")
    warnings.extend([
        "Vendas brutas não são lucro nem receita líquida: a fonte informa valores antes de custos, cancelamentos e devoluções.",
        "Visitas são somadas entre os períodos das linhas. Essa soma não representa pessoas únicas no intervalo inteiro, pois a mesma pessoa pode visitar em períodos diferentes.",
        "Este relatório agregado não contém custos por SKU, estoque, reputação, preços por anúncio ou campanhas. Curva ABC, cobertura de estoque e rentabilidade por produto dependem dessas fontes adicionais.",
        "Vendas da conta incluem o total da operação; não foram classificadas como orgânicas. Atribuição a Ads deve vir do relatório publicitário.",
    ])
    period = f"{effective_start.strftime('%d/%m/%Y')} a {effective_end.strftime('%d/%m/%Y')}"
    window_text = []
    for window in windows:
        if not window["complete"]:
            window_text.append(f"{window['days']} dias: dados insuficientes ({window['observedDays']} dias disponíveis).")
        else:
            wm = window["metrics"]
            window_text.append(f"{window['days']} dias: vendas brutas {_money(wm['accountRevenue'])}; média por dia {_money(wm['accountRevenuePerDay'])}; vendas {_fmt(wm['accountOrders'], 0)}; unidades {_fmt(wm['accountUnits'], 0)}; conversão {_fmt(wm['accountConversion'])}%.")
    action_lines = ["7 dias — conferir anúncios com queda de conversão, disponibilidade de estoque e condições de preço + frete. Relacionar a evolução de visitas à evolução de vendas. Responsável sugerido: especialista e cliente.",
                    "30 dias — revisar custos por SKU e integrar o relatório de Ads com o mesmo período. Acompanhar faturamento, conversão, ticket e custo de publicidade; metas dependem da validação dos custos e do objetivo do cliente.",
                    "90 dias — reavaliar tendência estrutural com histórico completo antes de projetar expansão, mix ou compras de estoque. Não há projeção automática sem premissas rastreáveis."]
    sections = [
        {"id": "account-overview", "title": "Panorama do negócio", "body": f"Período: {period}. {len(entries)} {'linhas agrupadas por mês' if aggregated else 'dias registrados'}. Fonte: {Path(path).name}, aba {name}.\nVendas brutas: {_money(metrics['accountRevenue'])}. Vendas: {_fmt(metrics['accountOrders'], 0)}. Unidades vendidas: {_fmt(metrics['accountUnits'], 0)}. Visitas (soma dos períodos): {_fmt(metrics['accountVisits'], 0)}.\nConversão: {_fmt(metrics['accountConversion'])}% (vendas / visitas × 100). Ticket médio: {_money(metrics['accountAverageTicket'])} (vendas brutas / quantidade de vendas)."},
        {"id": "account-windows", "title": "Evolução em 7, 15, 30, 60 e 90 dias", "body": "\n\n".join(window_text + comparisons) + "\n\nJanelas terminam na data final selecionada e só são calculadas quando todos os dias estão presentes. Períodos de durações diferentes são comparados por média diária."},
        {"id": "account-cancellations", "title": "Cancelamentos e devoluções", "body": f"Cancelamentos: {_fmt(metrics['accountCancelledOrders'], 0)} vendas, {_money(metrics['accountCancelledRevenue'])}. Devoluções: {_fmt(metrics['accountReturnedOrders'], 0)} vendas, {_money(metrics['accountReturnedRevenue'])}.\nEsses indicadores descrevem os eventos do relatório. Não equivalem à reputação da conta e não foram descontados automaticamente para estimar lucro ou receita líquida."},
        {"id": "account-actions", "title": "Plano de ação da conta", "body": "\n\n".join(action_lines)},
        {"id": "account-limits", "title": "Fontes e limites da análise de conta", "body": "\n".join("• " + warning for warning in warnings) + "\n\nCritérios de comparação e plano 7/30/90 derivados do prompt de direcionamento Pronix fornecido. Definições financeiras seguem a aba de definições do arquivo exportado, sem inferir mudanças nas regras oficiais."},
    ]
    return {"reportType": "account", "metrics": metrics, "metricLabels": {**LABELS, "accountVisits": "Visitas (soma dos períodos)" if aggregated else LABELS["accountVisits"]}, "sections": sections,
            "warnings": warnings, "windows": windows,
            "daily": [] if aggregated else [{**entry, "date": entry["date"].isoformat()} for entry in entries],
            "monthly": monthly if aggregated else [],
            "provenance": {"filename": Path(path).name, "sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                           "sheet": name, "headerRow": header, "mapping": mapping, "rowsAnalyzed": len(entries),
                           "periodStart": effective_start.isoformat(), "periodEnd": effective_end.isoformat(),
                           "dataStart": source_start.isoformat(), "dataEnd": source_end.isoformat(), "completeCoverage": complete,
                           "periodIsDaily": not aggregated,
                           "periodSource": "intervalo explícito no cabeçalho da fonte; linhas mensais" if aggregated else "datas diárias comprovadas no arquivo", "engineVersion": "1.0.0"}}
