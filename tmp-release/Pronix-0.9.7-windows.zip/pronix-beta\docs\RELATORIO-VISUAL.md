# Relatório visual e biblioteca de modelos

## Preparar a entrega

1. Em **Nova análise**, escolha **Construção de reputação** ou **Performance e crescimento**.
2. Informe cliente, data e objetivo. No modo Reputação, os arquivos são opcionais. No modo Performance, importe uma fonte ou registre a reunião que sustenta o direcionamento.
3. Revise o resumo e os cards. Ajuste o problema identificado, motivo, passos, indicador, meta, responsável, prazo e andamento.
4. Nos gráficos, revise categorias, séries, valores, fonte e unidade. Uma célula vazia indica dado indisponível; zero é um valor observado. Editar um indicador não recalcula automaticamente os textos ou gráficos relacionados.
5. Em **Imagens de apoio**, adicione o print, escreva a legenda e organize a ordem. O mesmo recurso está disponível nas seções de detalhamento.
6. Confira a **Prévia**. Para uma entrega mais curta, desmarque **Incluir detalhamento da análise na prévia e no PDF**. Os textos originais continuam no editor, TXT e JSON.
7. Clique **Salvar PDF**. O programa salva o PDF e as cópias TXT, HTML e JSON na pasta do cliente e da data.

O PDF é a cópia de entrega. A revisão principal fica no programa, onde tudo pode ser alterado antes de gerar a próxima versão. O HTML exportado também permite corrigir textos, marcar passos e imprimir uma cópia; essas alterações não retornam automaticamente ao Pronix.

## Reutilizar orientações

Use **Salvar ação como modelo** ou **Salvar seção como modelo** e dê um nome que explique o conteúdo. A biblioteca **Modelos** guarda os blocos com seus prints e legendas. Em outro relatório, use **Inserir modelo**.

O novo bloco é independente: mudar o texto de um cliente não modifica o modelo nem os relatórios anteriores. Passos voltam a ficar desmarcados; responsável, prazo e andamento são reiniciados. Textos e imagens são preservados, portanto revise nomes de clientes, preços, links e outros dados específicos antes de reutilizar. Arquivar um modelo o retira da biblioteca, mas preserva seu arquivo e as cópias já inseridas.

As imagens normalizadas ficam em `runtime/assets`; os modelos, em `runtime/templates`. Não exclua essas pastas ao copiar ou fazer backup do programa. PDF e HTML já exportados incorporam as imagens e podem ser enviados sem esses diretórios.

## Reuniões

Cada especialista configura sua conexão Google e escolhe a agenda que tem permissão para consultar. O nome do evento é apenas uma sugestão de cliente. Data, links e transcrição precisam ser conferidos na seleção.

Uma gravação permanece como link. O beta importa uma transcrição existente e destaca frases explícitas de ação para revisão. Ele não interpreta semanticamente toda a reunião nem transcreve o áudio. Para começar sem a conexão, cole a transcrição ou as anotações no relatório.

## Dados e prioridades

As regras priorizam margem comprometida, custos ainda não validados e ocorrências operacionais. Nas revisões de campanhas, os maiores investimentos têm precedência. Ausência de vendas em uma amostra pequena não é classificada isoladamente como urgência alta nem comprova uma causa. As seis ações iniciais não substituem o detalhamento; o especialista pode acrescentar, remover e reorganizar cards.

Gráficos respeitam os períodos das fontes. Janelas de 7/30/90 dias sobrepostas não são apresentadas como períodos consecutivos; ausência de dados não vira zero. Os textos são sugestões e devem ser ajustados ao contexto do cliente.
