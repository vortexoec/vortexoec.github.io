"""Abre a Central em janela própria (sem abas nem barra de endereço), como o atalho faz.

Mesma regra do iniciar.ps1: Chrome, onde a extensão está; depois Edge; por fim o navegador padrão.
Usado quando a extensão pede "Abrir a Central" com o programa no ar e a janela fechada.
"""
from __future__ import annotations

import subprocess
import webbrowser
from pathlib import Path

APP_PATHS = (r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths",
             r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths")
BROWSERS = ("chrome.exe", "msedge.exe")


def find_browser() -> str | None:
    try:
        import winreg
    except ImportError:
        return None
    for exe in BROWSERS:
        for root, base in ((winreg.HKEY_CURRENT_USER, APP_PATHS[0]), (winreg.HKEY_LOCAL_MACHINE, APP_PATHS[0]),
                           (winreg.HKEY_LOCAL_MACHINE, APP_PATHS[1])):
            try:
                path = str(winreg.QueryValue(root, base + "\\" + exe) or "").strip().strip('"')
            except OSError:
                continue
            if path and Path(path).is_file():
                return path
    return None


def open_window(port: int = 8765, finder=find_browser, popen=subprocess.Popen, fallback=webbrowser.open) -> str:
    url = f"http://localhost:{int(port)}"
    browser = finder()
    if browser:
        popen([browser, f"--app={url}", "--window-size=1440,900"], close_fds=True)
        return "app"
    fallback(url)
    return "browser"
