"""Conexão própria do Pronix com a API oficial do Mercado Livre.

Usada somente para leitura de comissões (``/sites/MLB/listing_prices``) e
categorias. O aplicativo de desenvolvedor (client_id, client_secret e URL de
retorno HTTPS) pode ser digitado ou importado do Vórtex Automação; os tokens do
Pronix são sempre próprios e ficam criptografados pelo DPAPI do Windows em
``%USERPROFILE%\\.pronix-beta\\mercadolivre.dpapi``. Nada aqui renova ou altera
os tokens do Vórtex.
"""
from __future__ import annotations

import base64
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import threading
import time
from urllib import error, parse, request

API_BASE = "https://api.mercadolibre.com"
AUTH_ENDPOINT = "https://auth.mercadolivre.com.br/authorization"
LISTING_RATES_URL = API_BASE + "/sites/MLB/listing_prices"
PENDING_SECONDS = 600
REFRESH_LEAD_SECONDS = 300
MAX_RESPONSE_BYTES = 2 * 1024 * 1024
LISTING_TYPES = {"gold_special": "classic", "gold_pro": "premium"}
_CATEGORY = re.compile(r"MLB\d{1,12}")
_ITEM = re.compile(r"MLB\d{6,15}")
PACKAGE_CACHE_LIMIT = 2000
PACKAGE_TEXT_LIMIT = 8000
_REFERENCE = re.compile(r"(MLB)-?(\d{6,15})", re.I)
_VORTEX_MAGIC = b"VORTEX-DPAPI1\0"
_VORTEX_ENTROPY = b"VortexAutomacao:SecretVault:DPAPI:v1"


class MercadoLivreError(RuntimeError):
    """Mensagem segura para a interface; nunca contém tokens ou respostas remotas."""

    def __init__(self, message: str, code: str | None = None, status: int | None = None):
        super().__init__(message)
        self.code = code
        self.status = status


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _default_storage() -> Path:
    from .secure_dir import secure_dir
    return secure_dir()


def _dpapi(data: bytes, decrypt: bool, entropy: bytes | None = None) -> bytes:
    if os.name != "nt":
        raise MercadoLivreError("A proteção de credenciais deste beta requer Windows (DPAPI).")

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

    def blob(value):
        buffer = ctypes.create_string_buffer(value, max(1, len(value)))
        return BLOB(len(value), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte))), buffer

    source, _keep_source = blob(data)
    extra, _keep_extra = blob(entropy) if entropy else (None, None)
    out = BLOB()
    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    pointer = ctypes.POINTER(BLOB)
    if decrypt:
        fn = crypt32.CryptUnprotectData
        fn.argtypes = [pointer, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                       ctypes.c_void_p, wintypes.DWORD, pointer]
        ok = fn(ctypes.byref(source), None, ctypes.byref(extra) if extra else None, None, None, 1, ctypes.byref(out))
    else:
        fn = crypt32.CryptProtectData
        fn.argtypes = [pointer, wintypes.LPCWSTR, ctypes.c_void_p, ctypes.c_void_p,
                       ctypes.c_void_p, wintypes.DWORD, pointer]
        ok = fn(ctypes.byref(source), "Pronix Beta - Mercado Livre", ctypes.byref(extra) if extra else None,
                None, None, 1, ctypes.byref(out))
    if not ok:
        raise MercadoLivreError("Não foi possível proteger ou abrir a conexão neste usuário do Windows.")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)


def _check_redirect(value) -> str:
    if not isinstance(value, str) or not value or len(value) > 2048 or any(c.isspace() for c in value):
        raise MercadoLivreError("Informe a URL HTTPS de retorno cadastrada no aplicativo do Mercado Livre.")
    url = parse.urlsplit(value)
    if (url.scheme != "https" or not url.hostname or "." not in url.hostname
            or url.username or url.password or url.fragment):
        raise MercadoLivreError("A URL de retorno precisa ser HTTPS e igual à cadastrada no Mercado Livre.")
    return value


def reference_id(value) -> str | None:
    """MLB id de um link/código de anúncio, sem hífen."""
    if not isinstance(value, str):
        return None
    match = _REFERENCE.search(value)
    return (match.group(1).upper() + match.group(2)) if match else None


_VORTEX_CACHE: list = []
_SKIP_DIRS = {"node_modules", ".git", ".venv", "__pycache__", "runtime", "AppData"}


def find_vortex_vault(refresh: bool = False) -> Path | None:
    """Procura o cofre do Vórtex Automação em Documentos/Área de trabalho (busca limitada e em cache)."""
    if _VORTEX_CACHE and not refresh:
        return _VORTEX_CACHE[0]
    home = Path(os.environ.get("USERPROFILE") or Path.home())
    found = []
    for base in (home / "Documents", home / "Desktop"):
        if not base.is_dir():
            continue
        root_depth = len(base.parts)
        for folder, dirs, _files in os.walk(base):
            path = Path(folder)
            if path.name == "VortexAutomacao":
                vault = path / "dados-mercadolivre" / "credenciais.dpapi"
                if vault.is_file():
                    found.append(vault)
                dirs[:] = []
                continue
            if len(path.parts) - root_depth >= 6:
                dirs[:] = []
            else:
                dirs[:] = [d for d in dirs if d not in _SKIP_DIRS and not d.startswith(".")]
    result = max(found, key=lambda p: p.stat().st_mtime) if found else None
    _VORTEX_CACHE[:] = [result]
    return result


class MercadoLivreClient:
    def __init__(self, storage_dir: Path | str | None = None, opener=None, clock=time.time):
        self.storage_dir = Path(storage_dir) if storage_dir else _default_storage()
        self.path = self.storage_dir / "mercadolivre.dpapi"
        self._clock = clock
        self._opener = opener or request.build_opener(_NoRedirect())
        self._lock = threading.RLock()
        self._app: dict = {}
        self._tokens: dict = {}
        self._pending: dict = {}
        self._load_error: str | None = None
        self._categories: dict[str, str] = {}
        self._package_cache: dict[tuple, object] = {}
        self._load()

    # ---------- armazenamento ----------
    def _load(self):
        if not self.path.exists():
            return
        try:
            data = json.loads(_dpapi(self.path.read_bytes(), decrypt=True))
            self._app = data.get("app") or {}
            self._tokens = data.get("tokens") or {}
        except Exception:
            self._load_error = "A conexão salva não pôde ser aberta neste usuário do Windows. Configure novamente."

    def _save(self):
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        blob = _dpapi(json.dumps({"app": self._app, "tokens": self._tokens}).encode(), decrypt=False)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_bytes(blob)
        os.replace(temporary, self.path)
        self._load_error = None

    # ---------- estado ----------
    def status(self) -> dict:
        app, tokens = dict(self._app), dict(self._tokens)
        configured = bool(app.get("client_id") and app.get("client_secret") and app.get("redirect_uri"))
        connected = bool(tokens.get("access_token") and tokens.get("refresh_token")) and not tokens.get("requires_reconnect")
        remaining = max(0, int((tokens.get("expires_at") or 0) - self._clock())) if connected else 0
        message = self._load_error
        if not message and tokens.get("requires_reconnect"):
            message = "O Mercado Livre recusou a renovação. Conecte a conta novamente."
        return {"configured": configured, "connected": connected,
                "clientId": app.get("client_id", ""), "redirectUri": app.get("redirect_uri", ""),
                "appSource": app.get("source", ""), "userId": tokens.get("user_id"),
                "nickname": tokens.get("nickname"), "remainingSeconds": remaining,
                "connectedAt": tokens.get("connected_at"),
                "pending": bool(self._pending) and self._clock() - self._pending.get("created_at", 0) <= PENDING_SECONDS,
                "vortexAvailable": bool(_VORTEX_CACHE and _VORTEX_CACHE[0]), "message": message}

    # ---------- aplicativo ----------
    def configure(self, client_id, client_secret, redirect_uri, source="manual") -> dict:
        client_id = str(client_id or "").strip()
        client_secret = str(client_secret or "").strip()
        if not client_id.isdigit() or len(client_id) > 30:
            raise MercadoLivreError("Informe o Client ID numérico do aplicativo do Mercado Livre.")
        if not client_secret or len(client_secret) > 200 or any(c.isspace() for c in client_secret):
            raise MercadoLivreError("Informe o Client Secret do aplicativo do Mercado Livre.")
        redirect_uri = _check_redirect(str(redirect_uri or "").strip())
        with self._lock:
            changed = (self._app.get("client_id") != client_id)
            self._app = {"client_id": client_id, "client_secret": client_secret,
                         "redirect_uri": redirect_uri, "source": source}
            if changed:
                self._tokens = {}
            self._pending = {}
            self._save()
        return self.status()

    def import_from_vortex(self, vault_path: Path | str | None = None) -> dict:
        """Copia só o aplicativo (client_id/secret/URL). Tokens do Vórtex não são lidos."""
        path = Path(vault_path) if vault_path else (find_vortex_vault() or find_vortex_vault(refresh=True))
        if not path or not path.is_file():
            raise MercadoLivreError("Não encontrei o Vórtex Automação neste computador. Informe os dados do aplicativo manualmente.")
        content = path.read_bytes()
        if not content.startswith(_VORTEX_MAGIC):
            raise MercadoLivreError("O arquivo do Vórtex não está no formato esperado.")
        try:
            data = json.loads(_dpapi(content[len(_VORTEX_MAGIC):], decrypt=True, entropy=_VORTEX_ENTROPY))
            app = data["app"]
            values = (app["client_id"], app["client_secret"], app["redirect_uri"])
        except Exception:
            raise MercadoLivreError("Não consegui abrir os dados do aplicativo no Vórtex com este usuário do Windows.") from None
        return self.configure(*values, source="vortex")

    # ---------- OAuth ----------
    def authorization_url(self) -> str:
        with self._lock:
            if not self.status()["configured"]:
                raise MercadoLivreError("Configure o aplicativo do Mercado Livre antes de conectar.")
            verifier = secrets.token_urlsafe(64)
            challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
            state = secrets.token_urlsafe(24)
            self._pending = {"state": state, "verifier": verifier, "created_at": self._clock(),
                             "redirect_uri": self._app["redirect_uri"]}
            return AUTH_ENDPOINT + "?" + parse.urlencode({
                "response_type": "code", "client_id": self._app["client_id"],
                "redirect_uri": self._app["redirect_uri"], "state": state,
                "code_challenge": challenge, "code_challenge_method": "S256"})

    def complete(self, return_url: str) -> dict:
        """Recebe a URL completa para onde o Mercado Livre redirecionou após autorizar."""
        with self._lock:
            pending = self._pending
            if not pending or self._clock() - pending.get("created_at", 0) > PENDING_SECONDS:
                raise MercadoLivreError("A autorização expirou. Clique em Conectar novamente.")
            if not isinstance(return_url, str) or len(return_url) > 8192:
                raise MercadoLivreError("Cole o endereço completo que apareceu depois de autorizar.")
            returned = parse.urlsplit(return_url.strip())
            expected = parse.urlsplit(pending["redirect_uri"])
            if (returned.scheme, returned.hostname, returned.path) != (expected.scheme, expected.hostname, expected.path):
                raise MercadoLivreError("O endereço colado não é a URL de retorno cadastrada no aplicativo.")
            query = parse.parse_qs(returned.query)
            state = (query.get("state") or [""])[0]
            code = (query.get("code") or [""])[0]
            if not secrets.compare_digest(state, pending["state"]):
                raise MercadoLivreError("Esta autorização não corresponde à conexão iniciada. Clique em Conectar novamente.")
            if not code or len(code) > 512:
                raise MercadoLivreError("O endereço colado não contém o código de autorização.")
            self._pending = {}
            tokens = self._token_request({"grant_type": "authorization_code", "code": code,
                                          "redirect_uri": pending["redirect_uri"],
                                          "code_verifier": pending["verifier"]})
            self._tokens = tokens
            self._save()
        try:
            me = self.get("/users/me")
            with self._lock:
                self._tokens["nickname"] = str(me.get("nickname") or "")[:100] or None
                self._save()
        except MercadoLivreError:
            pass
        return self.status()

    def disconnect(self) -> dict:
        with self._lock:
            self._tokens, self._pending = {}, {}
            self._save()
        return self.status()

    def _token_request(self, fields: dict) -> dict:
        body = parse.urlencode({**fields, "client_id": self._app["client_id"],
                                "client_secret": self._app["client_secret"]}).encode()
        try:
            payload = self._http("POST", API_BASE + "/oauth/token", body=body,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
        except MercadoLivreError as exc:
            if exc.code in ("invalid_grant", "invalid_client", "unauthorized_client"):
                raise MercadoLivreError("O Mercado Livre recusou a autorização. Conecte a conta novamente.", exc.code) from None
            raise
        access, refresh, expires = payload.get("access_token"), payload.get("refresh_token"), payload.get("expires_in")
        if (not isinstance(access, str) or not access or not isinstance(refresh, str) or not refresh
                or not isinstance(expires, (int, float)) or isinstance(expires, bool) or not 60 < expires < 86400 * 30):
            raise MercadoLivreError("O Mercado Livre devolveu uma autorização incompleta. Tente conectar novamente.")
        return {"access_token": access, "refresh_token": refresh, "expires_at": self._clock() + expires,
                "user_id": payload.get("user_id"), "nickname": self._tokens.get("nickname"),
                "connected_at": self._tokens.get("connected_at") if fields.get("grant_type") == "refresh_token" else self._clock()}

    def _access_token(self) -> str:
        with self._lock:
            if self._tokens.get("requires_reconnect") or not self._tokens.get("access_token"):
                raise MercadoLivreError("Conecte a conta do Mercado Livre em Conexões para consultar comissões.")
            if self._clock() >= self._tokens.get("expires_at", 0) - REFRESH_LEAD_SECONDS:
                try:
                    # Refresh token é de uso único: grava o substituto antes de liberar consultas.
                    renewed = self._token_request({"grant_type": "refresh_token",
                                                   "refresh_token": self._tokens["refresh_token"]})
                    renewed["nickname"] = self._tokens.get("nickname")
                    self._tokens = renewed
                    self._save()
                except MercadoLivreError as exc:
                    if exc.code in ("invalid_grant", "invalid_client", "unauthorized_client"):
                        self._tokens = dict(self._tokens, requires_reconnect=True)
                        self._save()
                    if self._clock() >= self._tokens.get("expires_at", 0) or exc.code:
                        raise
            return self._tokens["access_token"]

    # ---------- HTTP ----------
    def _http(self, method, url, body=None, headers=None) -> dict | list:
        req = request.Request(url, data=body, method=method, headers={"Accept": "application/json", **(headers or {})})
        try:
            with self._opener.open(req, timeout=30) as response:
                raw = response.read(MAX_RESPONSE_BYTES + 1)
        except error.HTTPError as exc:
            code = None
            try:
                data = json.loads(exc.read(16384) or b"{}")
                code = data.get("error") if isinstance(data, dict) and isinstance(data.get("error"), str) else None
            except (ValueError, OSError):
                pass
            if exc.code == 401:
                raise MercadoLivreError("A conexão com o Mercado Livre expirou. Conecte novamente.", code or "unauthorized") from None
            if exc.code == 429:
                raise MercadoLivreError("O Mercado Livre limitou as consultas por alguns instantes. Tente novamente.") from None
            if exc.code == 400 and code in ("invalid_grant", "invalid_client", "unauthorized_client"):
                raise MercadoLivreError("O Mercado Livre recusou a autorização.", code) from None
            raise MercadoLivreError(f"O Mercado Livre não concluiu a consulta (HTTP {exc.code}).", status=exc.code) from None
        except (error.URLError, TimeoutError, OSError):
            raise MercadoLivreError("Não foi possível alcançar o Mercado Livre. Confira a internet.") from None
        if len(raw) > MAX_RESPONSE_BYTES:
            raise MercadoLivreError("Resposta do Mercado Livre maior que o esperado.")
        try:
            return json.loads(raw)
        except ValueError:
            raise MercadoLivreError("O Mercado Livre respondeu em formato inesperado.") from None

    def get(self, path: str, params: dict | None = None):
        if not path.startswith("/") or ".." in path:
            raise MercadoLivreError("Consulta inválida.")
        url = API_BASE + path + ("?" + parse.urlencode(params) if params else "")
        return self._http("GET", url, headers={"Authorization": "Bearer " + self._access_token()})

    # ---------- consultas ----------
    def category_name(self, category_id: str) -> str | None:
        if category_id in self._categories:
            return self._categories[category_id]
        try:
            data = self.get(f"/categories/{category_id}")
        except MercadoLivreError:
            return None
        name = data.get("name") if isinstance(data, dict) else None
        if isinstance(name, str) and name.strip():
            self._categories[category_id] = name.strip()[:200]
            return self._categories[category_id]
        return None

    def predict_category(self, title: str) -> tuple[str, str] | None:
        title = str(title or "").strip()[:200]
        if not title:
            return None
        data = self.get("/sites/MLB/domain_discovery/search", {"limit": 1, "q": title})
        if isinstance(data, list) and data and isinstance(data[0], dict):
            cid, name = data[0].get("category_id"), data[0].get("category_name")
            if isinstance(cid, str) and _CATEGORY.fullmatch(cid):
                return cid, str(name or cid)[:200]
        return None

    def listing_rates(self, category_id: str, price: float) -> dict:
        """Comissão percentual e tarifa fixa de Clássico/Premium para um preço."""
        if not isinstance(category_id, str) or not _CATEGORY.fullmatch(category_id):
            raise MercadoLivreError("Categoria do anúncio inválida para consultar comissões.")
        data = self.get("/sites/MLB/listing_prices", {"price": f"{float(price):.2f}", "category_id": category_id})
        rows = data if isinstance(data, list) else []
        result = {}
        for row in rows:
            kind = LISTING_TYPES.get(row.get("listing_type_id")) if isinstance(row, dict) else None
            details = row.get("sale_fee_details") if kind else None
            if not isinstance(details, dict):
                continue
            percent, fixed = details.get("percentage_fee"), details.get("fixed_fee")
            if isinstance(percent, (int, float)) and not isinstance(percent, bool) and 0 <= percent <= 100:
                result[kind] = {"percent": float(percent),
                                "fixedFee": float(fixed) if isinstance(fixed, (int, float)) and not isinstance(fixed, bool) and fixed >= 0 else None}
        if not result:
            raise MercadoLivreError("O Mercado Livre não devolveu comissões para esta categoria e preço.")
        return result

    # ---------- peso e medidas do anúncio (para estimar o frete) ----------
    # /items/{id} e /user-products/{id} respondem 403 para anúncios de terceiros; o que o
    # Mercado Livre libera é a descrição, a ficha do catálogo e o pacote padrão da categoria.
    def _package_lookup(self, kind: str, key: str, loader):
        """Consulta com cache por execução. Nunca lança erro: sem dado, devolve None."""
        cache_key = (kind, key)
        if cache_key in self._package_cache:
            return self._package_cache[cache_key]
        try:
            value = loader()
        except MercadoLivreError as exc:
            if exc.status not in (403, 404):
                return None  # falha passageira (rede, limite, conexão): tenta de novo na próxima
            value = None
        except Exception:
            return None
        if len(self._package_cache) >= PACKAGE_CACHE_LIMIT:
            self._package_cache.clear()
        self._package_cache[cache_key] = value
        return value

    def item_description(self, item_id: str) -> str | None:
        """Texto da descrição do anúncio (pode trazer "Peso: 542g", "Dimensões: 36 x 26 x 59 cm")."""
        if not isinstance(item_id, str) or not _ITEM.fullmatch(item_id):
            return None

        def load():
            data = self.get(f"/items/{item_id}/description")
            text = data.get("plain_text") if isinstance(data, dict) else None
            return text[:PACKAGE_TEXT_LIMIT] if isinstance(text, str) and text.strip() else None
        return self._package_lookup("description", item_id, load)

    def catalog_product(self, product_id: str) -> dict | None:
        """Ficha do catálogo: atributos (peso, medidas, pacote do vendedor) e descrição curta."""
        if not isinstance(product_id, str) or not _ITEM.fullmatch(product_id):
            return None

        def load():
            data = self.get(f"/products/{product_id}")
            if not isinstance(data, dict):
                return None
            attributes = [{"id": row["id"], "value": row["value_name"]} for row in data.get("attributes") or []
                          if isinstance(row, dict) and isinstance(row.get("id"), str) and isinstance(row.get("value_name"), str)]
            short = data.get("short_description")
            text = short.get("content") if isinstance(short, dict) else None
            return {"attributes": attributes[:300], "text": text[:PACKAGE_TEXT_LIMIT] if isinstance(text, str) and text.strip() else None}
        return self._package_lookup("product", product_id, load)

    def category_package(self, category_id: str) -> dict | None:
        """Pacote padrão que o Mercado Livre usa para a categoria: {"weightKg", "dimensionsCm"}."""
        if not isinstance(category_id, str) or not _CATEGORY.fullmatch(category_id):
            return None

        def load():
            data = self.get(f"/categories/{category_id}/shipping_preferences")
            dims = data.get("dimensions") if isinstance(data, dict) else None
            if not isinstance(dims, dict):
                return None
            number = lambda value: float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) and value > 0 else None
            weight = number(dims.get("weight"))
            sides = [number(dims.get(key)) for key in ("length", "width", "height")]
            if weight is None and not all(sides):
                return None
            return {"weightKg": weight / 1000 if weight is not None else None,
                    "dimensionsCm": sides if all(sides) else None}
        return self._package_lookup("category", category_id, load)

    def rates_batch(self, reference_url: str, prices, hint: dict | None = None) -> dict:
        """Mesmo contrato usado pela análise: uma linha por preço, na ordem pedida."""
        ref = reference_id(reference_url)
        if not ref:
            raise MercadoLivreError("Link de anúncio inválido para consultar comissões.")
        hint = hint or {}
        category_id = hint.get("categoryId") if isinstance(hint.get("categoryId"), str) and _CATEGORY.fullmatch(hint.get("categoryId") or "") else None
        category_name = None
        note = None
        if category_id:
            category_name = hint.get("categoryName") if isinstance(hint.get("categoryName"), str) and hint.get("categoryName").strip() else self.category_name(category_id)
        else:
            predicted = self.predict_category(hint.get("title") or "")
            if not predicted:
                raise MercadoLivreError("Não foi possível identificar a categoria do anúncio para consultar comissões.")
            category_id, category_name = predicted
            note = "Categoria sugerida pelo Mercado Livre a partir do título; confira se é a mesma do anúncio."
        captured_at = _now_iso()
        rates = []
        for price in prices:
            observed = self.listing_rates(category_id, price)
            classic, premium = observed.get("classic") or {}, observed.get("premium") or {}
            rates.append({"referenceId": ref, "referenceUrl": reference_url, "salePrice": float(price),
                          "categoryId": category_id, "categoryName": category_name or category_id,
                          "classicPercent": classic.get("percent"), "premiumPercent": premium.get("percent"),
                          "classicFixedFee": classic.get("fixedFee"), "premiumFixedFee": premium.get("fixedFee"),
                          "discountNote": note, "sourceUrl": LISTING_RATES_URL,
                          "capturedAt": captured_at, "basis": "estimate"})
        return {"referenceId": ref, "referenceUrl": reference_url, "rates": rates}


class _NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # nunca reenviar token ou código em redirecionamento
