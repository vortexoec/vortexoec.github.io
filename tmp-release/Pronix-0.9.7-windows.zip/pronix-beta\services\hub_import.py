"""Store a selected Hub capture through the same inert HTML import pipeline."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import uuid
import zipfile

from . import storage
from .product_source import extract_product_html

MAX_CAPTURE_BYTES = 2 * 1024 * 1024
HUB_URL = re.compile(r"https://pronixhub\.com\.br/validacao-planilhas/[A-Za-z0-9_-]+/?\Z")
EXTENSION_FILES = (
    "manifest.json", "service-worker.js", "bridge.js", "capture.js", "popup.html", "popup.js",
    "popup.css", "README.md", "hub-ui.js", "pronix-app.js",
)


def save_capture(capture, expected_url, extension_version=""):
    if not isinstance(capture, dict) or not isinstance(expected_url, str) or not HUB_URL.fullmatch(expected_url):
        raise ValueError("Selecione uma planilha de validação do Pronix Hub.")
    if capture.get("url") != expected_url:
        raise ValueError("A página mudou. Atualize a lista de abas e selecione a planilha novamente.")
    html = capture.get("html")
    if not isinstance(html, str) or not html.strip():
        raise ValueError("A extensão não recebeu uma tabela de produtos. Aguarde a página carregar.")
    raw = html.encode("utf-8")
    if len(raw) > MAX_CAPTURE_BYTES:
        raise ValueError("A captura excede 2 MB. Use apenas uma planilha de produtos por importação.")
    timestamp = capture.get("capturedAt")
    try:
        captured = datetime.fromisoformat(str(timestamp).replace("Z", "+00:00"))
        if captured.tzinfo is None or abs((datetime.now(timezone.utc) - captured).total_seconds()) > 300:
            raise ValueError
    except (ValueError, TypeError, OverflowError):
        raise ValueError("A captura expirou. Importe novamente a planilha aberta no Chrome.") from None
    upload_id = uuid.uuid4().hex
    file = storage.UPLOADS / (upload_id + ".html")
    meta_file = storage.UPLOADS / (upload_id + ".json")
    try:
        file.write_bytes(raw)
        parsed = extract_product_html(file)
        for product in parsed.get("products", []):
            if isinstance(product.get("hubReview"), dict):
                product["hubReview"]["provenance"] = {"source": "Pronix Hub", "method": "rendered_dom",
                    "url": expected_url, "capturedAt": captured.astimezone(timezone.utc).isoformat()}
        if extension_version == "0.1.0":
            parsed.setdefault("warnings", []).append("Esta captura foi feita com a extensão 0.1.0, que não inclui os pareceres do Hub. Atualize e recarregue a extensão 0.2.0; depois importe novamente para comparar robô e especialista.")
        client = str(parsed.get("clientName") or "Produtos").strip()
        meta = {
            "id": upload_id, "name": f"Pronix Hub - {client[:160]}.html",
            "extension": ".html", "sha256": hashlib.sha256(raw).hexdigest(),
            "createdAt": storage.now(), **parsed,
            "hubSource": {
                "url": expected_url, "capturedAt": captured.astimezone(timezone.utc).isoformat(),
                "importedAt": storage.now(), "method": "pronix-extension",
                "extensionVersion": str(extension_version)[:40],
            },
        }
        storage.write_json(meta_file, meta)
        return meta
    except Exception:
        file.unlink(missing_ok=True)
        meta_file.unlink(missing_ok=True)
        raise


def extension_zip():
    """Package public extension files only, never runtime or customer uploads."""
    folder = storage.ROOT / "extension" / "pronix-hub"
    manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    names = list(EXTENSION_FILES)
    for icon in manifest.get("icons", {}).values():
        if not isinstance(icon, str) or not re.fullmatch(r"icons/[a-zA-Z0-9_-]+\.png", icon):
            raise ValueError("Ícone inválido no pacote da extensão.")
        if icon not in names:
            names.append(icon)
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in names:
            file = folder / name
            if file.is_symlink() or not file.is_file() or not file.resolve().is_relative_to(folder.resolve()):
                raise FileNotFoundError("O pacote da extensão está incompleto.")
            archive.writestr("pronix-hub/" + name, file.read_bytes())
    return output.getvalue()
