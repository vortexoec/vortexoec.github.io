﻿# Instala ou atualiza a Central de Análises em %USERPROFILE%\Pronix, preservando dados e conexões.
# Fica dentro do pacote ZIP, ao lado das pastas "python" e "pronix-beta".
param([switch]$Silencioso, [switch]$NaoIniciar, [string]$Destino = '', [switch]$SemAtalhos)
$ErrorActionPreference = 'Stop'
$appName = 'Central de Análises'
$source = $PSScriptRoot
$target = if ($Destino) { $Destino } else { Join-Path $env:USERPROFILE 'Pronix' }
function Say($text) { if (-not $Silencioso) { Write-Host $text } }

# Rodado de dentro do ZIP (sem extrair), o Windows só traz este arquivo para uma pasta temporária.
if (-not (Test-Path -LiteralPath (Join-Path $source 'python\python.exe')) -or -not (Test-Path -LiteralPath (Join-Path $source 'pronix-beta\app.py'))) {
    throw "Os arquivos do programa não estão ao lado do instalador. Clique com o botão direito no ZIP, escolha 'Extrair tudo…' e rode o instalador de dentro da pasta extraída."
}
$version = (Get-Content -LiteralPath (Join-Path $source 'pronix-beta\VERSION') -Raw).Trim()
Say "Instalando a $appName $version em $target…"

# Fecha uma instância aberta (somente se for o programa desta pasta).
try {
    $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/health' -TimeoutSec 2
    $boot = Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/bootstrap' -TimeoutSec 3
    $sameFolder = $boot.outputDirectory -eq (Join-Path $target 'analise de mercado')
    if ($health.app -eq 'pronix-beta' -and $sameFolder) {
        if ($health.activeJobs -gt 0) { throw 'Há uma análise em andamento. Espere terminar e rode o instalador de novo.' }
        $listener = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($listener) { Stop-Process -Id $listener.OwningProcess -Force; Start-Sleep -Seconds 1 }
    }
} catch [System.Net.WebException] { } catch { if ($_.Exception.Message -like 'Há uma análise*') { throw } }

New-Item -ItemType Directory -Force -Path $target | Out-Null
# Python: substituído por inteiro. Programa: espelhado, mantendo runtime (relatórios, revisões) e .venv.
robocopy (Join-Path $source 'python') (Join-Path $target 'python') /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { throw 'Falha ao copiar o Python.' }
# Numa pasta de desenvolvimento (com .git) só copia por cima, sem apagar testes e anotações.
$mode = if (Test-Path (Join-Path $target 'pronix-beta\.git')) { '/E' } else { '/MIR' }
# O pacote de atualização não leva resources\conexoes.bin: mantém o que veio no instalador.
$keep = if (Test-Path -LiteralPath (Join-Path $source 'pronix-beta\resources\conexoes.bin')) { @() } else { @('/XF', 'conexoes.bin') }
robocopy (Join-Path $source 'pronix-beta') (Join-Path $target 'pronix-beta') $mode /XD runtime .venv .git dist @keep /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { throw 'Falha ao copiar o programa.' }
New-Item -ItemType Directory -Force -Path (Join-Path $target 'analise de mercado') | Out-Null
# Arquivos vindos da internet (WhatsApp, e-mail, navegador) chegam marcados; tira a marca para o Windows não travar o programa.
Get-ChildItem -LiteralPath $target -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue

$launcher = Join-Path $target 'pronix-beta\iniciar.ps1'
$icon = Join-Path $target 'pronix-beta\static\central.ico'
$psArgs = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$launcher`" -Janela"
$powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

# Arquivos .bat na pasta do programa (o antigo "Iniciar Pronix.bat" sai).
$start = "@echo off`r`ntitle Central de Analises`r`nstart `"`" `"$powershell`" $psArgs`r`n"
Set-Content -LiteralPath (Join-Path $target 'Abrir Central de Analises.bat') -Value $start -Encoding ascii
$restart = "@echo off`r`ntitle Central de Analises`r`npowershell.exe -NoProfile -ExecutionPolicy Bypass -File `"%~dp0pronix-beta\reiniciar.ps1`"`r`nif errorlevel 1 pause`r`n"
Set-Content -LiteralPath (Join-Path $target 'Reiniciar Central de Analises.bat') -Value $restart -Encoding ascii
foreach ($old in 'Iniciar Pronix.bat', 'Reiniciar Pronix.bat') { Remove-Item -LiteralPath (Join-Path $target $old) -Force -ErrorAction SilentlyContinue }

# Link "central-analises://" (o botão "Abrir a Central" da extensão do Chrome usa este link).
$protocol = 'HKCU:\Software\Classes\central-analises'
New-Item -Path "$protocol\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path $protocol -Name '(default)' -Value "URL:$appName"
Set-ItemProperty -Path $protocol -Name 'URL Protocol' -Value ''
New-Item -Path "$protocol\DefaultIcon" -Force | Out-Null
Set-ItemProperty -Path "$protocol\DefaultIcon" -Name '(default)' -Value "`"$icon`""
Set-ItemProperty -Path "$protocol\shell\open" -Name 'FriendlyAppName' -Value $appName
Set-ItemProperty -Path "$protocol\shell\open\command" -Name '(default)' -Value "`"$powershell`" $psArgs"

# Atalhos na Área de Trabalho e no Menu Iniciar. Numa atualização silenciosa, só troca o atalho antigo "Pronix".
$shell = New-Object -ComObject WScript.Shell
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    $oldLink = Join-Path $folder 'Pronix.lnk'
    $hadOld = Test-Path -LiteralPath $oldLink
    if ($hadOld) { Remove-Item -LiteralPath $oldLink -Force -ErrorAction SilentlyContinue }
    if ($SemAtalhos -and -not $hadOld) { continue }
    $link = $shell.CreateShortcut((Join-Path $folder "$appName.lnk"))
    $link.TargetPath = $powershell
    $link.Arguments = $psArgs
    $link.WorkingDirectory = Join-Path $target 'pronix-beta'
    $link.IconLocation = "$icon,0"
    $link.WindowStyle = 7
    $link.Description = "$appName · Vórtex"
    $link.Save()
}
# Instalado pelo instalador .exe: mantém a versão certa em "Aplicativos instalados" depois das atualizações.
$uninstall = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\{36B15936-81CD-4F11-ACFE-F903DF35BF00}_is1'
if (Test-Path $uninstall) {
    Set-ItemProperty -Path $uninstall -Name 'DisplayVersion' -Value $version -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $uninstall -Name 'DisplayIcon' -Value $icon -ErrorAction SilentlyContinue
}
Say "$appName $version instalada."
Say "Use o atalho '$appName' na Área de Trabalho. A extensão do Chrome se conecta sozinha com o programa aberto."
if (-not $NaoIniciar) { Start-Process -FilePath $powershell -ArgumentList $psArgs -WorkingDirectory (Join-Path $target 'pronix-beta') }
