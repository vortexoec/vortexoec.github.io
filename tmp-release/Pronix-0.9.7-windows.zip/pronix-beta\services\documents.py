from __future__ import annotations

import html
import re
from pathlib import Path

LABELS = {'spend': 'Investimento em Ads', 'revenue': 'Receita atribuída', 'orders': 'Vendas atribuídas',
          'clicks': 'Cliques', 'impressions': 'Impressões', 'roas': 'ROAS', 'acos': 'ACOS',
          'ctr': 'CTR', 'cpc': 'CPC', 'cvr': 'Conversão Ads', 'tacos': 'TACOS',
          'breakEvenAcos':'ACOS de equilíbrio','breakEvenRoas':'ROAS de equilíbrio',
          'directRevenue':'Receita atribuída direta','indirectRevenue':'Receita atribuída indireta',
          'directOrders':'Vendas atribuídas diretas','indirectOrders':'Vendas atribuídas indiretas'}


def number(value, key=''):
    if value is None or value == '':
        return 'Não disponível'
    if isinstance(value, str):
        return value
    places = 0 if key in ('orders', 'clicks', 'impressions','directOrders','indirectOrders','accountOrders','accountUnits','accountVisits','accountCancelledOrders','accountReturnedOrders') else 2
    result = f'{value:,.{places}f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
    if key in ('spend', 'revenue', 'cpc', 'totalRevenue','directRevenue','indirectRevenue','accountRevenue','accountAverageTicket','accountRevenuePerDay','accountCancelledRevenue','accountReturnedRevenue'):
        return 'R$ ' + result
    return result + ('%' if key in ('acos','ctr','cvr','tacos','breakEvenAcos','accountConversion') else 'x' if key in ('roas','breakEvenRoas') else '')


def date_label(value):
    parts = value.split('-')
    return '/'.join(reversed(parts)) if len(parts) == 3 else value


def display_metrics(report):
    metrics=report.get('metrics',{})
    primary=('accountRevenue','accountOrders','accountConversion','spend','revenue','roas','acos','tacos','orders')
    main=[(k,metrics[k]) for k in primary if metrics.get(k) is not None and metrics.get(k)!='']
    other=[(k,v) for k,v in metrics.items() if k not in dict(main)]
    return main,other


def indicator_sources(report):
    result=[]
    for kind,label in [('ads','Ads'),('account','Conta')]:
        provenance=(report.get(kind) or {}).get('provenance') or {}
        if not provenance: continue
        source=str(provenance.get('filename') or 'Fonte importada')
        start,end=provenance.get('periodStart'),provenance.get('periodEnd')
        if start and end: source+=' · '+date_label(start)+' a '+date_label(end)
        result.append(label+' · Fonte: '+source)
    return result


def extract_pdf(path):
    from pypdf import PdfReader
    reader = PdfReader(path)
    if reader.is_encrypted and not reader.decrypt(''):
        raise ValueError('PDF protegido por senha. Exporte uma cópia sem senha.')
    if len(reader.pages) > 150:
        raise ValueError('O beta aceita PDFs de até 150 páginas.')
    pages = [page.extract_text() or '' for page in reader.pages]
    links=[]
    from urllib.parse import urlparse
    for page in reader.pages:
        for reference in page.get('/Annots',[]):
            annotation=reference.get_object()
            action=annotation.get('/A')
            if not action: continue
            action=action.get_object()
            uri=str(action.get('/URI',''))
            parsed=urlparse(uri)
            domain=(parsed.hostname or '').lower()
            if parsed.scheme=='https' and (domain=='mercadolivre.com.br' or domain.endswith('.mercadolivre.com.br') or domain=='mercadolibre.com' or domain.endswith('.mercadolibre.com')) and uri not in links:
                links.append(uri)
    text = '\n\n'.join(pages)
    if len(text) > 300000:
        raise ValueError('PDF muito extenso. Divida em arquivos menores.')
    warnings = []
    if len(text.strip()) < 40:
        warnings.append('Este PDF parece digitalizado: não foi possível extrair texto. Gere um PDF pesquisável antes de analisar. OCR não está incluído neste beta.')
    elif any(len(p.strip()) < 20 for p in pages):
        warnings.append('Há páginas sem texto extraível. Confira se informações importantes estão em imagens.')
    if links:
        text += '\n\nLinks de anúncios encontrados nos hiperlinks do PDF:\n'+'\n'.join(links)
    return {'text': text, 'clientName': detect_client(text, Path(path).name), 'pages': len(pages), 'links': links, 'warnings': warnings}


def detect_client(text, filename=''):
    patterns = [r'(?:Cliente(?:\s*/\s*loja)?|Nome do cliente|Razão social|Razao social|Mentorado)\s*[:：]\s*([^\n|]{3,100})',
                r'Mentorados\s*/\s*([^\n]{3,100})',
                r'DIRECIONAMENTO PRONIX\s*\n\s*([^\n|]{3,100})\s*\|']
    for pattern in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            return match.group(1).strip()
    # Do not infer a person's name from arbitrary PDF prose or reuse a different client's name.
    return ''


def render_text(report):
    from . import market_presentation
    parts = [report['title'].upper(), 'Cliente: ' + report['clientName'],
             'Data da análise: ' + date_label(report['date']), 'Especialista: ' + report['specialist']]
    if report.get('objective'):
        parts += ['Objetivo: ' + report['objective']]
    if report.get('summary'):
        parts += ['',report['summary'].get('headline',''),report['summary'].get('body','')]
    if report.get('meeting'):
        meeting=report['meeting']
        parts += ['', 'REUNIÃO DE REFERÊNCIA',meeting.get('title',''),meeting.get('date','')]
        for key,label in [('url','Reunião'),('recordingUrl','Gravação'),('transcriptUrl','Transcrição')]:
            if meeting.get(key):parts.append(label+': '+meeting[key])
    if report.get('actionCards'):
        parts += ['', 'PLANO DE AÇÃO']
        for i,card in enumerate(report['actionCards']):
            parts += ['',f'{i+1:02d}. '+card.get('title','')]
            for key,label in [('problem','O que identificamos'),('why','Por que fazer'),('metric','Como acompanhar'),('target','Resultado esperado')]:
                if card.get(key):parts.append(label+': '+card[key])
            parts += [('[x] ' if step.get('done') else '[ ] ')+step['text'] for step in card.get('steps',[])]
            if card.get('sourceQuote') or card.get('quote'):parts.append('Trecho da reunião: '+str(card.get('sourceQuote') or card.get('quote')))
            for image in card.get('images',[]):parts.append('Imagem: '+image.get('caption','')+' (arquivo '+image['id']+')')
            if card.get('source'):parts.append('Fonte dos indicadores: '+str(card['source']))
    for chart in report.get('charts',[]):
        parts += ['', 'GRÁFICO: '+chart['title'],chart.get('caption',''),'Fonte: '+str(chart.get('source') or 'Dados fornecidos')]
        parts.append('Item | '+' | '.join(s['name'] for s in chart['series']))
        for i,label in enumerate(chart['labels']):parts.append(label+' | '+' | '.join(str(s['values'][i]) if s['values'][i] is not None else 'Indisponível' for s in chart['series']))
    parts += ['', 'INDICADORES']
    for key, value in report.get('metrics', {}).items():
        parts.append(f'{report.get("metricLabels", {}).get(key, LABELS.get(key,key))}: {number(value,key)}')
    parts += indicator_sources(report)
    if market_presentation.has_market(report):
        parts += ['', market_presentation.text_report(report).strip()]
    # The print option only controls the client-facing HTML/PDF.  The TXT is a
    # complete editable source and retains the detailed analysis.
    for section in market_presentation.detail_sections(report):
        parts += ['', '=' * 60, section['title'].upper(), '', section['body']]
        for image in section.get('images',[]):parts.append('Imagem: '+image.get('caption','')+' (arquivo '+image['id']+')')
    if report.get('warnings'):
        parts += ['', 'LIMITAÇÕES E DADOS A CONFIRMAR'] + ['- ' + str(w) for w in report['warnings']]
    parts += ['', '#PronixNaPrática', 'Documento editável. Revise o conteúdo antes de enviar ao cliente.']
    return '\n'.join(parts) + '\n'


def _legacy_render_html(report):
    esc = lambda x: html.escape(str(x))
    primary,secondary=display_metrics(report)
    metrics = ''.join(f'<div class="metric"><label contenteditable="true">{esc(report.get("metricLabels",{}).get(k,LABELS.get(k,k)))}</label><strong contenteditable="true">{esc(number(v,k))}</strong></div>' for k,v in primary)
    detail=''.join(f'<p contenteditable="true">{esc(report.get("metricLabels",{}).get(k,LABELS.get(k,k)))}: <strong>{esc(number(v,k))}</strong></p>' for k,v in secondary)
    sections = ('<section><h2>Indicadores complementares</h2>'+detail+'</section>' if detail else '') + ''.join(f'<section><div class="kicker">{i+1:02d} / ANÁLISE</div><h2 contenteditable="true">{esc(s["title"])}</h2><div class="body" contenteditable="true">{esc(s["body"])}</div></section>' for i,s in enumerate(report.get('sections',[])))
    warnings = ''.join('<li contenteditable="true">'+esc(w)+'</li>' for w in report.get('warnings',[]))
    sources = ''.join('<li contenteditable="true">'+esc(s.get('name','') if isinstance(s,dict) else s)+'</li>' for s in report.get('sources',[]))
    return '''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>''' + esc(report['clientName']) + ''' | Pronix</title><style>
*{box-sizing:border-box}body{margin:0;background:#f5f4f0;color:#25221c;font:15px/1.65 'Segoe UI',Arial,sans-serif}.toolbar{background:white;border-bottom:1px solid #ddd;padding:14px;position:sticky;top:0;display:flex;gap:10px;justify-content:center}button{background:white;border:1px solid #ccc;padding:10px 16px;border-radius:8px;cursor:pointer}button.primary{background:#ffbb16;border:0}main{max-width:900px;margin:30px auto;background:white;padding:50px 60px;border:1px solid #e7e4de}.brand{font-weight:900;letter-spacing:3px;font-size:24px}.brand span{color:#b58100}.kicker{color:#a47500;font-size:10px;font-weight:700;letter-spacing:2px;margin-top:30px}h1{font-size:38px;line-height:1.14;letter-spacing:-1.5px;margin:14px 0}h2{font-size:23px;line-height:1.3;margin:8px 0 15px}.client{font-size:24px;color:#a47500}.meta{font-size:12px;color:#6e6a63}.metrics{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:28px}.metric{border:1px solid #e8e5df;padding:17px;border-radius:10px;break-inside:avoid}.metric label{display:block;font-size:11px;color:#777}.metric strong{font-size:23px}section{border-top:1px solid #ddd;margin-top:30px;padding-top:1px}.body{white-space:pre-wrap;overflow-wrap:anywhere}footer{font-size:11px;margin-top:40px;color:#777;border-top:2px solid #edb01c;padding-top:15px}[contenteditable]:focus{outline:2px solid #e6b952;background:#fffcf4}.notice{font-size:12px;color:#777}li{overflow-wrap:anywhere}@media print{@page{size:A4;margin:15mm}.toolbar,.notice{display:none}body,main{background:white;margin:0;padding:0;border:0}h1{font-size:30px}h2{break-after:avoid}section{break-inside:auto}.kicker{break-after:avoid}.metrics{grid-template-columns:repeat(3,1fr)}main{max-width:none}.body{font-size:11px;line-height:1.6}}@media(max-width:600px){main{padding:24px}.metrics{grid-template-columns:1fr 1fr}}
</style><div class="toolbar"><button class="primary" onclick="window.print()">Imprimir / salvar PDF</button><button onclick="saveCopy()">Salvar HTML editado</button></div><main><div class="brand"><span>ϟ</span> PRONIX</div><div class="kicker">INTELIGÊNCIA DE MERCADO • PERFORMANCE</div><h1 contenteditable="true">''' + esc(report['title']) + '''</h1><div class="client" contenteditable="true">''' + esc(report['clientName']) + '''</div><p class="meta" contenteditable="true">''' + esc(date_label(report['date']) + ' | Especialista: ' + report['specialist']) + '''</p><p contenteditable="true">''' + esc(report.get('objective','')) + '''</p><p class="notice">Clique nos textos para editar. Use “Salvar HTML editado” para guardar as alterações desta cópia. O relatório no programa não é alterado por esta cópia.</p><div class="metrics">''' + metrics + '</div>' + sections + '<section><h2 contenteditable="true">Limitações e dados a confirmar</h2><ul>'+warnings+'</ul><h2>Fontes</h2><ul>'+sources+'</ul></section><footer contenteditable="true">PRONIX | #PronixNaPrática</footer></main><script>function saveCopy(){const a=document.createElement("a");a.href=URL.createObjectURL(new Blob(["<!doctype html>"+document.documentElement.outerHTML],{type:"text/html;charset=utf-8"}));a.download="Relatorio_Pronix_editado.html";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}</script></html>'


def _legacy_make_pdf(report, path):
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    font = 'Helvetica'
    bold = 'Helvetica-Bold'
    fonts = Path('C:/Windows/Fonts')
    if (fonts/'segoeui.ttf').exists():
        if 'Pronix' not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont('Pronix', str(fonts/'segoeui.ttf')))
            pdfmetrics.registerFont(TTFont('PronixBold', str(fonts/'segoeuib.ttf')))
        font, bold = 'Pronix', 'PronixBold'
    styles = getSampleStyleSheet()
    gold = colors.HexColor('#a87908')
    ink = colors.HexColor('#25221c')
    muted = colors.HexColor('#6b685f')
    styles.add(ParagraphStyle('PBody', fontName=font,fontSize=9.2,leading=14,textColor=ink,spaceAfter=7,splitLongWords=True))
    styles.add(ParagraphStyle('PTitle',fontName=bold,fontSize=31,leading=35,textColor=ink,spaceAfter=14))
    styles.add(ParagraphStyle('PClient',fontName=bold,fontSize=19,leading=24,textColor=gold,spaceAfter=9))
    styles.add(ParagraphStyle('PHead',fontName=bold,fontSize=16,leading=21,textColor=ink,spaceBefore=18,spaceAfter=10,keepWithNext=True))
    styles.add(ParagraphStyle('PSub',fontName=bold,fontSize=11,leading=16,textColor=gold,spaceBefore=9,spaceAfter=7,keepWithNext=True))
    styles.add(ParagraphStyle('PSmall',fontName=font,fontSize=7.8,leading=11,textColor=muted,spaceAfter=6))
    styles.add(ParagraphStyle('PKpi',fontName=bold,fontSize=18,leading=24,textColor=ink))
    def clean(value):
        text = str(value).replace('\u2011','-').replace('\u2013','-').replace('\u2014','-')
        for symbol, replacement in [('🟢','[VIÁVEL]'),('🟡','[ATENÇÃO]'),('🔴','[RISCO]'),('✅','[OK]'),('⚠️','[ATENÇÃO]')]:
            text=text.replace(symbol,replacement)
        return ''.join(c for c in text if ord(c) < 0x10000)
    def p(value, style='PBody'):
        return Paragraph(html.escape(clean(value)).replace('\n','<br/>'),styles[style])
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    document=SimpleDocTemplate(str(path),pagesize=A4,rightMargin=43,leftMargin=43,topMargin=58,bottomMargin=48,title=report['title']+' - '+report['clientName'],author=report['specialist'])
    width=A4[0]-86
    story=[p('ANÁLISE DE MERCADO / PERFORMANCE','PSmall'),Spacer(1,8),p(report['title'],'PTitle'),p(report['clientName'],'PClient'),p(date_label(report['date'])+'  |  Especialista: '+report['specialist'],'PSmall')]
    if report.get('objective'):
        story += [p(report['objective'])]
    story += [Spacer(1,12),HRFlowable(width='100%',thickness=2,color=gold),Spacer(1,16)]
    metrics,secondary=display_metrics(report)
    for start in range(0,len(metrics),3):
        row=[]
        for key,value in metrics[start:start+3]:
            row.append([p(report.get('metricLabels',{}).get(key,LABELS.get(key,key)),'PSmall'),p(number(value,key),'PKpi')])
        while len(row)<3: row.append('')
        table=Table([row],colWidths=[width/3]*3)
        table.setStyle(TableStyle([('BOX',(0,0),(-1,-1),.5,colors.HexColor('#e4e0d8')),('INNERGRID',(0,0),(-1,-1),.5,colors.HexColor('#e4e0d8')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),12),('TOPPADDING',(0,0),(-1,-1),11),('BOTTOMPADDING',(0,0),(-1,-1),11)]))
        story += [table,Spacer(1,7)]
    if secondary:
        story += [p('Indicadores complementares','PSub')]
        detail=[]
        for start in range(0,len(secondary),2):
            row=[p(report.get('metricLabels',{}).get(k,LABELS.get(k,k))+': '+number(v,k),'PSmall') for k,v in secondary[start:start+2]]
            if len(row)<2: row.append('')
            detail.append(row)
        table=Table(detail,colWidths=[width/2]*2,hAlign='LEFT')
        table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),12),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
        story += [table,Spacer(1,8)]
    for index, section in enumerate(report.get('sections',[])):
        story += [p(f'{index+1:02d}  {section["title"]}','PHead')]
        for block in re.split(r'\n\s*\n', section['body']):
            if not block.strip(): continue
            # Text paragraphs deliberately split naturally across pages, even very long analyses.
            for line in block.splitlines():
                if re.match(r'^#{1,4}\s+',line):
                    story.append(p(re.sub(r'^#+\s*','',line),'PSub'))
                else:
                    story.append(p(line.replace('**','').replace('`','')))
    if report.get('warnings'):
        story += [p('Limitações e dados a confirmar','PHead')]
        story += [p('- '+str(w)) for w in report['warnings']]
    if report.get('sources'):
        story += [p('Fontes e rastreabilidade','PHead')]
        for source in report['sources']:
            name=source.get('name','') if isinstance(source,dict) else str(source)
            story += [p(name,'PSmall')]
    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFillColor(gold); canvas.setFont(bold,12); canvas.drawString(43,A4[1]-32,'PRONIX')
        canvas.setFillColor(muted); canvas.setFont(font,7)
        canvas.drawRightString(A4[0]-43,A4[1]-30,'INTELIGÊNCIA DE MERCADO')
        canvas.setStrokeColor(colors.HexColor('#e4e0d8')); canvas.line(43,36,A4[0]-43,36)
        canvas.drawString(43,24,'#PronixNaPrática')
        canvas.drawRightString(A4[0]-43,24,str(doc.page))
        canvas.restoreState()
    document.build(story,onFirstPage=footer,onLaterPages=footer)


def render_html(report):
    from .report_visual import render_html as visual_html
    return visual_html(report)


def make_pdf(report,path):
    from .report_visual import make_pdf as visual_pdf
    return visual_pdf(report,path)
