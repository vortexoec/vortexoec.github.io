"""Estimativa do pacote (peso e medidas) a partir do anúncio, sem IA.

Usada quando o especialista não digitou o peso e a planilha do Hub não trouxe a
linha "Embalagem". A ordem é fixa:

1. ``anuncio``: ficha do catálogo (``/products/{id}``) e descrição do anúncio
   (``/items/{id}/description``), quando informam peso e/ou medidas;
2. ``titulo``: peso ou medidas escritos no título ("500g", "30x20x10 cm");
3. ``categoria``: pacote padrão que o Mercado Livre usa para a categoria
   (``/categories/{id}/shipping_preferences``).

Quando o anúncio ou o título informam só o peso ou só as medidas, a parte que
falta é completada pelo pacote padrão da categoria (a origem continua sendo o
anúncio/título e a nota diz o que veio de onde).

O resultado é sempre uma aproximação, marcada com origem e confiança, para o
especialista conferir. Peso tarifável = maior entre o peso real e o peso cúbico
(C × L × A / 6000), como o Mercado Envios cobra.

Folga de embalagem: quando a medida é do PRODUTO (e não do pacote), soma-se
10% + 50 g ao peso e 2 cm a cada lado. É uma convenção local, não regra oficial.
"""
from __future__ import annotations

import math
import re

CUBIC_DIVISOR = 6000
PRODUCT_WEIGHT_FACTOR = 1.10
PRODUCT_WEIGHT_EXTRA_KG = 0.05
PRODUCT_DIMENSION_EXTRA_CM = 2.0
MAX_WEIGHT_KG = 150.0
MAX_DIMENSION_CM = 300.0
MAX_TEXT = 8000
ESTIMATED_SOURCES = ("anuncio", "titulo", "categoria")

_N = r"(\d{1,5}(?:[.,]\d{1,3})?)"
_WEIGHT_UNIT = r"(kg|kgs|quilos?|kilos?|quilogramas?|g|gr|grs|gramas?)"
_LENGTH_UNIT = r"(cm|mm|m|cent[ií]metros?|mil[ií]metros?|metros?)"
_WEIGHT = re.compile(r"(?<![\w.,])" + _N + r"(\s*)" + _WEIGHT_UNIT + r"\b(?!\s*/)", re.I)
# "suporta até 120 kg", "capacidade de 10 kg": peso que o produto aguenta, não o peso dele.
_CAPACITY = re.compile(r"(suport|aguent|\bat[eé]\b|capacidade|\bcarga|m[aá]xim|m[aá]x\.|limite|resist[eê]ncia)[^.;\n]{0,28}$", re.I)
_NOT_OWN_WEIGHT = re.compile(r"suport|m[aá]xim|capacidade|carga|usu[aá]rio|recomendad|corporal|aguent|limite", re.I)
_PACKAGED = re.compile(r"embalag|embalad|pacote|caixa|bruto", re.I)
_TRIPLE = re.compile(r"(?<![\w.,])" + _N + r"\s*" + _LENGTH_UNIT + r"?\s*[x×*]\s*" + _N + r"\s*" + _LENGTH_UNIT
                     + r"?\s*[x×*]\s*" + _N + r"\s*" + _LENGTH_UNIT + r"?(?![\w])", re.I)
_LABEL = r"(altura|largura|comprimento|profundidade|di[aâ]metro|espessura)"
_LABEL_VALUE = re.compile(_LABEL + r"[^\d\n]{0,25}?" + _N + r"\s*" + _LENGTH_UNIT + r"(?![\w])", re.I)
_VALUE_LABEL = re.compile(_N + r"\s*" + _LENGTH_UNIT + r"\s*(?:de\s+|\(\s*)?" + _LABEL, re.I)
_DIMENSION_LINE = re.compile(r"dimens|medida|tamanho", re.I)
_FIRST_NUMBER = re.compile(r"\d")
# Vendido montado, enviado dobrado/desmontado: a medida do produto não vale para o pacote.
_COLLAPSIBLE = re.compile(r"dobr[aá]ve|infl[aá]ve|desmont|retr[aá]t|enrol[aá]ve|para montar", re.I)
_SEGMENT = re.compile(r"[\n;]|\.\s")


def _positive(value):
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value > 0 else None


def _to_float(raw, small_unit=False):
    """"1,5" -> 1.5; "1.500" antes de g/mm -> 1500 (separador de milhar brasileiro)."""
    text = str(raw).strip()
    if small_unit and re.fullmatch(r"\d{1,3}\.\d{3}", text):
        text = text.replace(".", "")
    try:
        return float(text.replace(",", "."))
    except ValueError:
        return None


def _kg(raw, unit):
    unit = unit.lower()
    grams = not (unit.startswith("k") or unit.startswith("q"))
    value = _to_float(raw, small_unit=grams)
    if value is None:
        return None
    value = value / 1000 if grams else value
    return value if 0.005 <= value <= MAX_WEIGHT_KG else None


def _cm(raw, unit):
    unit = (unit or "cm").lower()
    millimetres = unit.startswith("mm") or unit.startswith("mil")
    value = _to_float(raw, small_unit=millimetres)
    if value is None:
        return None
    if millimetres:
        value /= 10
    elif unit in ("m", "metro", "metros"):
        value *= 100
    return value if 0.3 <= value <= MAX_DIMENSION_CM else None


def weight_in(text, labelled=False):
    """Primeiro peso plausível do texto, em kg. Ignora capacidade de carga, gramatura e "5G"."""
    text = str(text or "")
    for match in _WEIGHT.finditer(text):
        raw, gap, unit = match.group(1), match.group(2), match.group(3)
        if not labelled:
            if _CAPACITY.search(text[max(0, match.start() - 32):match.start()]):
                continue
            if unit.lower() == "g" and not gap and raw in ("2", "3", "4", "5"):
                continue  # 4G/5G: geração de rede, não gramas
        value = _kg(raw, unit)
        if value is not None:
            return value
    return None


def labelled_weight(text):
    """Peso escrito depois da palavra "peso" (descrição do anúncio). Devolve (kg, é do pacote) ou (None, False)."""
    text = str(text or "")[:MAX_TEXT]
    best = None
    for match in re.finditer(r"peso", text, re.I):
        window = text[match.start():match.start() + 70].split("\n")[0]
        value = head = None
        for found in _WEIGHT.finditer(window, 4):
            value = _kg(found.group(1), found.group(3))
            if value is not None:
                head = window[:found.start()]  # só o rótulo: "Peso bruto: ", "Peso máximo suportado: "
                break
        if value is None or _NOT_OWN_WEIGHT.search(head):
            continue
        rank = 0 if _PACKAGED.search(head) else 2 if re.search(r"l[ií]quid", head, re.I) else 1
        if best is None or rank < best[0]:
            best = (rank, value)
    return (best[1], best[0] == 0) if best else (None, False)


def _triple(text, default_unit=None):
    for match in _TRIPLE.finditer(text):
        numbers, units = match.group(1, 3, 5), match.group(2, 4, 6)
        fallback = next((unit for unit in reversed(units) if unit), default_unit)
        if not fallback:
            continue
        values = [_cm(number, unit or fallback) for number, unit in zip(numbers, units)]
        if all(values):
            return sorted(values, reverse=True)
    return None


def dimensions_in(text):
    """Três medidas em cm (maior primeiro) e se são do pacote. Devolve (lista, bool) ou (None, False)."""
    text = str(text or "")[:MAX_TEXT]
    segments = [segment for segment in _SEGMENT.split(text) if segment and segment.strip()]
    found = None
    for segment in segments:
        dims = _triple(segment, "cm" if _DIMENSION_LINE.search(segment) else None)
        if dims:
            packaged = bool(_PACKAGED.search(segment))
            if packaged:
                return dims, True
            found = found or dims
    if found:
        return found, False
    labels = {}
    for segment in segments:
        first_label = re.search(_LABEL, segment, re.I)
        if not first_label:
            continue
        first_number = _FIRST_NUMBER.search(segment)
        label_first = first_number is None or first_label.start() < first_number.start()
        for match in (_LABEL_VALUE if label_first else _VALUE_LABEL).finditer(segment):
            label, raw, unit = (match.group(1), match.group(2), match.group(3)) if label_first else (match.group(3), match.group(1), match.group(2))
            key = {"alt": "h", "lar": "w", "com": "l", "pro": "p", "di": "d", "esp": "t"}[label.lower()[:3] if not label.lower().startswith("di") else "di"]
            value = _cm(raw, unit)
            if value is not None:
                labels.setdefault(key, value)
    return _assemble(labels), False


def _assemble(labels):
    diameter = labels.get("d")
    straight = [labels[key] for key in ("h", "w", "l", "p", "t") if key in labels]
    if len(straight) >= 3:
        return sorted(straight, reverse=True)[:3]
    if diameter and len(straight) >= 1:
        return sorted([diameter, diameter, max(straight)], reverse=True)
    return None


def from_attributes(attributes):
    """Peso/medidas da ficha de catálogo do Mercado Livre (lista de {"id", "value"})."""
    values = {}
    for attribute in attributes if isinstance(attributes, list) else []:
        if isinstance(attribute, dict) and isinstance(attribute.get("id"), str) and isinstance(attribute.get("value"), str):
            values.setdefault(attribute["id"].upper(), attribute["value"])

    def weight(*ids):
        for key in ids:
            match = _WEIGHT.search(values.get(key) or "")
            value = _kg(match.group(1), match.group(3)) if match else None
            if value is not None:
                return value
        return None

    def length(*ids):
        for key in ids:
            match = re.fullmatch(r"\s*" + _N + r"\s*" + _LENGTH_UNIT + r"\s*", values.get(key) or "", re.I)
            value = _cm(match.group(1), match.group(2)) if match else None
            if value is not None:
                return value
        return None

    result = {}
    package_weight = weight("SELLER_PACKAGE_WEIGHT", "PACKAGE_WEIGHT")
    package_dims = [length(f"SELLER_PACKAGE_{side}", f"PACKAGE_{side}") for side in ("LENGTH", "WIDTH", "HEIGHT")]
    if package_weight is not None:
        result.update(weightKg=package_weight, weightPackaged=True)
    else:
        product_weight = weight("WEIGHT", "NET_WEIGHT", "UNIT_WEIGHT")
        if product_weight is not None:
            result.update(weightKg=product_weight, weightPackaged=False)
    if all(package_dims):
        result.update(dimensionsCm=sorted(package_dims, reverse=True), dimensionsPackaged=True)
    else:
        labels = {"h": length("HEIGHT", "TOTAL_HEIGHT"), "w": length("WIDTH", "TOTAL_WIDTH"),
                  "l": length("LENGTH", "TOTAL_LENGTH"), "p": length("DEPTH", "TOTAL_DEPTH"),
                  "d": length("DIAMETER"), "t": length("THICKNESS")}
        dims = _assemble({key: value for key, value in labels.items() if value is not None})
        if dims:
            result.update(dimensionsCm=dims, dimensionsPackaged=False)
    return result


def from_description(text):
    """Peso depois de "peso" e medidas escritas na descrição do anúncio."""
    result = {}
    weight, packaged = labelled_weight(text)
    if weight is not None:
        result.update(weightKg=weight, weightPackaged=packaged)
    dims, dims_packaged = dimensions_in(text)
    if dims:
        result.update(dimensionsCm=dims, dimensionsPackaged=dims_packaged)
    return result


def from_title(title):
    """Peso ("500g", "2 kg") e medidas completas ("30x20x10 cm") escritos no título."""
    title = str(title or "")[:300]
    result = {}
    weight = weight_in(title)
    if weight is not None:
        result.update(weightKg=weight, weightPackaged=False)
    dims = _triple(title)
    if dims:
        result.update(dimensionsCm=dims, dimensionsPackaged=False)
    return result


def _fill(base, extra):
    """Completa em ``base`` o que faltar (peso ou medidas) com ``extra``. Devolve o que foi aproveitado."""
    used = []
    if "weightKg" not in base and "weightKg" in extra:
        base.update(weightKg=extra["weightKg"], weightPackaged=extra.get("weightPackaged", False))
        used.append("weight")
    if "dimensionsCm" not in base and "dimensionsCm" in extra:
        base.update(dimensionsCm=extra["dimensionsCm"], dimensionsPackaged=extra.get("dimensionsPackaged", False))
        used.append("dimensions")
    return used


def billable(measures):
    """Aplica a folga de embalagem e calcula o peso tarifável. Devolve dict ou None."""
    weight = _positive(measures.get("weightKg"))
    dims = measures.get("dimensionsCm") if isinstance(measures.get("dimensionsCm"), list) and len(measures.get("dimensionsCm")) == 3 else None
    if dims and not all(_positive(value) for value in dims):
        dims = None
    if weight is None and not dims:
        return None
    padded = False
    if weight is not None and not measures.get("weightPackaged"):
        weight = weight * PRODUCT_WEIGHT_FACTOR + PRODUCT_WEIGHT_EXTRA_KG
        padded = True
    if dims and not measures.get("dimensionsPackaged"):
        dims = [value + PRODUCT_DIMENSION_EXTRA_CM for value in dims]
        padded = True
    cubic = dims[0] * dims[1] * dims[2] / CUBIC_DIVISOR if dims else None
    total = max(value for value in (weight, cubic) if value)
    return {"billableKg": round(total, 3), "realWeightKg": round(weight, 3) if weight is not None else None,
            "cubicWeightKg": round(cubic, 3) if cubic is not None else None,
            "dimensionsCm": [round(value, 1) for value in dims] if dims else None, "padded": padded}


def _fmt(value, digits=2):
    text = f"{value:.{digits}f}".rstrip("0").rstrip(".")
    return text.replace(".", ",")


def _weight_text(kg):
    return f"{_fmt(kg * 1000, 0)} g" if kg < 1 else f"{_fmt(kg)} kg"


def _dims_text(dims):
    return " × ".join(_fmt(value, 1) for value in dims) + " cm"


_ORIGIN_TEXT = {"anuncio": "pelo anúncio de referência", "titulo": "pelo título do anúncio",
                "categoria": "pelo pacote padrão do Mercado Livre para a categoria"}
_CONFIDENCE = {"anuncio": "media", "titulo": "baixa", "categoria": "baixa"}


def _result(source, measures, extra_note=""):
    pack = billable(measures)
    if pack is None or not 0 < pack["billableKg"] <= MAX_WEIGHT_KG:
        return None
    raw = []
    if "weightKg" in measures:
        raw.append("peso " + _weight_text(measures["weightKg"]) + (" do pacote" if measures.get("weightPackaged") else " do produto"))
    if "dimensionsCm" in measures:
        raw.append("medidas " + _dims_text(measures["dimensionsCm"]) + (" do pacote" if measures.get("dimensionsPackaged") else " do produto"))
    note = f"Pacote estimado {_ORIGIN_TEXT[source]}: " + " e ".join(raw) + "."
    if pack["padded"]:
        note += " Somamos uma folga de embalagem (10% + 50 g no peso, 2 cm em cada lado)."
    parts = []
    if pack["realWeightKg"] is not None:
        parts.append(f"peso real {_fmt(pack['realWeightKg'])} kg")
    if pack["cubicWeightKg"] is not None:
        parts.append(f"peso cúbico {_fmt(pack['cubicWeightKg'])} kg")
    note += " Para o frete vale o maior: " + ", ".join(parts) + f" → {_fmt(pack['billableKg'])} kg." if len(parts) > 1 else f" Peso usado no frete: {_fmt(pack['billableKg'])} kg."
    if "weightKg" not in measures:
        note += " O anúncio não informa o peso; foi usado só o volume."
    if extra_note:
        note += " " + extra_note
    note += (" É uma aproximação grosseira:" if source == "categoria" else " É uma aproximação:") + " se souber o peso do pacote, informe no campo de peso."
    return {"source": source, "confidence": _CONFIDENCE[source], "billableKg": pack["billableKg"],
            "realWeightKg": pack["realWeightKg"], "cubicWeightKg": pack["cubicWeightKg"],
            "dimensionsCm": pack["dimensionsCm"], "note": note}


def _safe(function, *args):
    """Consultas extras nunca derrubam a análise."""
    try:
        return function(*args)
    except Exception:
        return None


def _listing_measures(reference, meli):
    """Ficha de catálogo e descrição do anúncio de referência (somente leitura)."""
    measures = {}
    if meli is None:
        return measures
    texts = []
    catalog = getattr(meli, "catalog_product", None)
    if callable(catalog) and isinstance(reference.get("catalogId"), str):
        product = _safe(catalog, reference["catalogId"])
        if isinstance(product, dict):
            _fill(measures, from_attributes(product.get("attributes")))
            if isinstance(product.get("text"), str):
                texts.append(product["text"])
    describe = getattr(meli, "item_description", None)
    if callable(describe) and not ("weightKg" in measures and "dimensionsCm" in measures):
        item_id = reference.get("itemId") or reference.get("id")
        text = _safe(describe, item_id) if isinstance(item_id, str) else None
        if isinstance(text, str):
            texts.insert(0, text)
    for text in texts:
        _fill(measures, from_description(text))
    return measures


def estimate(entry, reference, meli, category_id=None):
    """Estima o pacote pelo anúncio. Devolve dict (source, confidence, billableKg, …, note) ou None."""
    entry, reference = entry or {}, reference or {}
    titles = [value for value in (reference.get("title"), (entry.get("source") or {}).get("name")) if isinstance(value, str) and value.strip()]
    collapsible = any(_COLLAPSIBLE.search(title) for title in titles)

    def usable(measures):
        if collapsible and measures.get("dimensionsCm") and not measures.get("dimensionsPackaged"):
            measures = {key: value for key, value in measures.items() if key not in ("dimensionsCm", "dimensionsPackaged")}
            usable.dropped = True
        return measures

    usable.dropped = False
    measures = usable(_listing_measures(reference, meli))
    source = "anuncio" if measures else None
    extra = ""
    for title in titles:
        from_text = usable(from_title(title))
        used = _fill(measures, from_text)
        if used and source is None:
            source = "titulo"
        elif used and source == "anuncio":
            extra = ("O peso" if used == ["weight"] else "As medidas" if used == ["dimensions"] else "Parte dos dados") + " veio do título."
    if usable.dropped:
        extra = (extra + " " if extra else "") + "Produto dobrável ou desmontável: as medidas do produto montado foram ignoradas."
    if measures and source:
        if "weightKg" not in measures or "dimensionsCm" not in measures:
            # O anúncio deu só uma parte: o que falta vem do pacote padrão da categoria, para não subestimar o frete.
            used = _fill(measures, _category_measures(meli, category_id))
            if used:
                extra = (extra + " " if extra else "") + ("O peso veio" if used == ["weight"] else "As medidas vieram") + " do pacote padrão do Mercado Livre para a categoria."
        result = _result(source, measures, extra)
        if result:
            return result
    measures = _category_measures(meli, category_id)
    if measures:
        return _result("categoria", measures, "Produto dobrável ou desmontável: as medidas do produto montado foram ignoradas." if usable.dropped else "")
    return None


def _category_measures(meli, category_id):
    """Pacote padrão da categoria no formato interno (peso e medidas já são do pacote)."""
    package = getattr(meli, "category_package", None) if meli is not None else None
    default = _safe(package, category_id) if callable(package) and isinstance(category_id, str) else None
    measures = {}
    if isinstance(default, dict):
        if _positive(default.get("weightKg")):
            measures.update(weightKg=float(default["weightKg"]), weightPackaged=True)
        dims = default.get("dimensionsCm")
        if isinstance(dims, list) and len(dims) == 3 and all(_positive(value) for value in dims):
            measures.update(dimensionsCm=sorted((float(value) for value in dims), reverse=True), dimensionsPackaged=True)
    return measures
