const element = id => document.getElementById(id);
let busy = false;
async function send(type, extra = {}) {
  const reply = await chrome.runtime.sendMessage({type, ...extra});
  if (!reply?.ok) throw new Error(reply?.error || "A extensão não respondeu. Feche e abra este painel.");
  return reply.data;
}
function render(state) {
  lastState = state;
  element("download-row").hidden = !!state.connected;
  element("status").textContent = state.connected ? "Conectado ao programa local" : state.connecting ? "Conectando…" : state.paired ? "Programa local desconectado" : "Aguardando pareamento";
  element("status-dot").className = "dot" + (state.connected ? " online" : state.connecting ? " waiting" : "");
  element("description").textContent = state.connected ? "Tudo pronto. Use os botões roxos dentro do Hub." : state.paired ? "Abra a Central de Análises neste computador. A extensão reconecta sozinha." : "Abra a Central de Análises neste computador: a conexão acontece sozinha.";
  element("pair-form").hidden = state.paired;
  element("connected-panel").hidden = !state.paired;
  element("reconnect").disabled = busy || state.connected || state.connecting;
  element("disconnect").disabled = busy;
  element("last-capture").hidden = !state.lastCaptureAt;
  if (state.lastCaptureAt) element("last-capture").textContent = "Última captura: " + new Date(state.lastCaptureAt).toLocaleString("pt-BR");
  if (!busy) showMessage(state.error || "");
}
function showMessage(text) { element("message").textContent = text; element("message").hidden = !text; }
async function refresh() { if (!busy) { try { render(await send("status")); } catch (error) { showMessage(error.message); } } }
async function action(callback) {
  if (busy) return;
  busy = true; element("pair-button").disabled = true; element("disconnect").disabled = true;
  showMessage("");
  try { const state = await callback(); busy = false; render(state); }
  catch (error) { busy = false; showMessage(error.message); }
  finally { element("pair-button").disabled = false; element("disconnect").disabled = false; }
}
element("pair-form").addEventListener("submit", event => {
  event.preventDefault();
  const code = element("pair-code").value.trim();
  element("pair-code").value = "";
  void action(() => send("pair", {code}));
});
// "Abrir a Central": leva à janela do programa (a que já está aberta ou uma nova, própria). Com o
// programa fechado, pede ao Windows para abri-lo pelo link central-analises:// (registrado pelo instalador).
export const DOWNLOAD_URL = "https://vortexoec.github.io/central/";
let lastState = null;
async function openApp() {
  const result = await send("open_app");
  if (result?.how === "launch") showMessage("Se o Chrome perguntar, clique em Abrir. Se nada acontecer, instale o programa pelo link abaixo.");
}
element("open-app").addEventListener("click", () => { openApp().catch(error => showMessage(error.message)); });
element("download-link").addEventListener("click", event => { event.preventDefault(); void chrome.tabs.create({url: DOWNLOAD_URL}); });
element("disconnect").addEventListener("click", () => void action(() => send("disconnect")));
element("reconnect").addEventListener("click", () => void action(() => send("reconnect")));
void refresh();
setInterval(refresh, 2000);
