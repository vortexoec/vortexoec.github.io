"""Print-friendly visual reports, local images and editable standalone HTML."""
from __future__ import annotations

import html
import math
import textwrap
from pathlib import Path
from . import assets, market_presentation
from .report_schema import safe_link, is_market_report

GOLD='#B7860A'
PURPLE='#6F56E6'
INK='#24231F'
MUTED='#73736C'
LINE='#E5E4DE'
SOFT='#F7F7F3'
TYPE_LABEL={'reputation':'Reputação · primeiros passos','performance':'Conta em operação · performance','market':'Análise de mercado · produtos'}


def report_type(report):
    return 'market' if is_market_report(report) else report.get('reportType','performance')
KPI_PALETTES=[('#EAF6EF','#CFE7D9','#1D6946'),('#F0ECFF','#DDD4F7','#6144B0'),
              ('#EAF2FF','#D0DFF5','#315C9C'),('#FFF3D8','#F0D9A3','#946407')]


def e(value): return html.escape(str(value or ''),quote=True)


def compact_number(value):
    if value is None: return '—'
    if not math.isfinite(value): return '—'
    if abs(value)>=1e12: return f'{value:.2e}'.replace('.',',')
    if abs(value)>=1000000: return f'{value/1000000:.1f} mi'.replace('.',',')
    if abs(value)>=1000: return f'{value/1000:.1f} mil'.replace('.',',')
    return f'{value:,.1f}'.replace(',','@').replace('.',',').replace('@','.')


def _wrap_chart_label(label,width=155):
    """Wrap the complete label using measured text width, including long tokens."""
    from reportlab.pdfbase.pdfmetrics import stringWidth
    lines=[];line=''
    for word in str(label).split():
        candidate=(line+' '+word).strip()
        if stringWidth(candidate,'Helvetica',11)<=width:
            line=candidate;continue
        if line:lines.append(line);line=''
        while stringWidth(word,'Helvetica',11)>width:
            cut=1
            while cut<len(word) and stringWidth(word[:cut+1],'Helvetica',11)<=width:cut+=1
            lines.append(word[:cut]);word=word[cut:]
        line=word
    if line:lines.append(line)
    return lines or ['']


def chart_geometry(chart,width=640,domain=None):
    """Shared geometry for SVG/print. Missing samples never become zero."""
    labels=chart.get('labels',[]);series=chart.get('series',[])
    numbers=[v for s in series for v in s['values'] if v is not None]
    if not numbers or not labels: return width,85,[('text',18,40,'Dados insuficientes para desenhar o gráfico.',12,MUTED,'start')]
    bounds=domain if domain else numbers
    scale=max(max(abs(value) for value in bounds),1)
    low=min(0,min(value/scale for value in bounds));high=max(0,max(value/scale for value in bounds))
    if high==low: high=low+1
    span=high-low
    axis_low=low-span*.04 if low<0 else low
    axis_high=high+span*.08
    normalized=lambda value:value/scale
    # Coordinates are calculated near [-1, 1], avoiding overflow for ±1e308.
    # Tick values stay inside the data domain before restoring their unit.
    ticks=[low+span*i/4 for i in range(5)]
    items=[]
    if chart['type']=='bar':
        left=180;right=width-70;top=22
        wrapped=[_wrap_chart_label(label) for label in labels]
        rows=[max(52,20+len(series)*15,18+len(lines)*13) for lines in wrapped]
        height=top+sum(rows)+45
        X=lambda v:left+(v-axis_low)/(axis_high-axis_low)*(right-left)
        for tick in ticks:
            x=X(tick)
            items += [('line',x,top-10,x,height-30,LINE,1),('text',x,height-12,compact_number(max(-1,min(1,tick))*scale),10.5,MUTED,'middle')]
        zero=X(0)
        y=top
        for i,label in enumerate(labels):
            for j,line in enumerate(wrapped[i]):items.append(('text',2,y+13+j*13,line,11,INK,'start'))
            for j,data in enumerate(series):
                value=data['values'][i]
                if value is None: continue
                x=X(normalized(value));yy=y+6+j*15
                items.append(('rect',min(zero,x),yy,max(abs(x-zero),.6),8,data.get('color',PURPLE)))
                # Exact values remain in the accessible table; the graph uses concise labels.
                items.append(('text',x+4 if value>=0 else zero+6,yy+8,compact_number(value),10.5,MUTED,'start'))
            y+=rows[i]
        return width,height,items
    left=82 if scale>=1e12 else 54;right=width-20;top=16;bottom=207;height=253
    X=lambda i:left+(right-left)*i/max(1,len(labels)-1)
    Y=lambda v:bottom-(v-axis_low)/(axis_high-axis_low)*(bottom-top)
    for tick in ticks:
        y=Y(tick)
        items += [('line',left,y,right,y,LINE,1),('text',left-8,y+3,compact_number(max(-1,min(1,tick))*scale),10.5,MUTED,'end')]
    shown=set(round(i*(len(labels)-1)/min(6,max(1,len(labels)-1))) for i in range(min(7,len(labels))))
    for i in sorted(shown):
        items.append(('text',X(i),bottom+21,str(labels[i]),10.5,MUTED,'middle'))
    for data in series:
        segment=[];color=data.get('color',PURPLE)
        for i,value in enumerate(data['values']):
            if value is None:
                if segment: items.append(('polyline',segment,color,2))
                segment=[];continue
            point=(X(i),Y(normalized(value)));segment.append(point)
            items.append(('circle',*point,2.3 if len(labels)<40 else 1.7,color))
        if segment:items.append(('polyline',segment,color,2))
    return width,height,items


def chart_svg(chart,domain=None):
    width,height,items=chart_geometry(chart,domain=domain)
    shapes=[]
    for item in items:
        kind,*v=item
        if kind=='text':
            x,y,text,size,color,anchor=v;shapes.append(f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" fill="{color}" text-anchor="{anchor}">{e(text)}</text>')
        elif kind=='rect':
            x,y,w,h,color=v;shapes.append(f'<rect x="{x:.2f}" y="{y:.2f}" width="{w:.2f}" height="{h}" rx="2" fill="{color}"/>')
        elif kind=='line':
            x,y,x2,y2,color,stroke=v;shapes.append(f'<line x1="{x:.2f}" y1="{y:.2f}" x2="{x2:.2f}" y2="{y2:.2f}" stroke="{color}" stroke-width="{stroke}"/>')
        elif kind=='circle':
            x,y,r,color=v;shapes.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r}" fill="{color}"/>')
        elif kind=='polyline':
            points,color,stroke=v;coords=' '.join(f'{x:.2f},{y:.2f}' for x,y in points)
            shapes.append(f'<polyline points="{coords}" fill="none" stroke="{color}" stroke-width="{stroke}"/>')
    return f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="{e(chart.get("title"))}" xmlns="http://www.w3.org/2000/svg">'+''.join(shapes)+'</svg>'


def image_html(images):
    result=[]
    for image in images:
        url=assets.data_url(image['id'])
        result.append(f'<figure><img src="{url}" alt="{e(image.get("caption") or image.get("name") or "Print de apoio")}"><figcaption contenteditable="true">{e(image.get("caption"))}</figcaption></figure>')
    return ''.join(result)


def render_html(report):
    from .documents import display_metrics, number, LABELS, date_label, indicator_sources
    main,secondary=display_metrics(report)
    cards=report.get('actionCards',[]);summary=report.get('summary',{})
    steps=[step for card in cards for step in card.get('steps',[])]
    done=sum(s.get('done',False) for s in steps)
    metrics=''.join(f'<div class="kpi"><label contenteditable="true">{e(report.get("metricLabels",{}).get(k,LABELS.get(k,k)))}</label><strong contenteditable="true">{e(number(v,k))}</strong></div>' for k,v in main)
    charts=[]
    for chart in report.get('charts',[]):
        legend=''.join(f'<span><i style="background:{s.get("color",PURPLE)}"></i>{e(s["name"])}</span>' for s in chart['series'])
        table='<tr><th>Período / item</th>'+''.join('<th>'+e(s['name'])+'</th>' for s in chart['series'])+'</tr>'
        for i,label in enumerate(chart['labels']):table+='<tr><td>'+e(label)+'</td>'+''.join('<td>'+e('Indisponível' if s['values'][i] is None else f'{s["values"][i]:.2f}'.replace('.',','))+'</td>' for s in chart['series'])+'</tr>'
        source_html='<p class="caption">Fonte: '+e(chart.get('source'))+'</p>' if chart.get('source') else ''
        values=[value for series in chart['series'] for value in series['values'] if value is not None]
        domain=(min(values),max(values)) if values else None
        parts=[{**chart,'labels':chart['labels'][start:start+6], 'series':[{**series,'values':series['values'][start:start+6]} for series in chart['series']]} for start in range(0,len(chart['labels']),6)] if chart['type']=='bar' and len(chart['labels'])>6 else [chart]
        for index,part in enumerate(parts,1):
            title=chart['title']+(f' ({index}/{len(parts)})' if len(parts)>1 else '')
            charts.append(f'<section class="chart"><h2 contenteditable="true">{e(title)}</h2><div class="legend">{legend}<span>{e(chart.get("unit",""))}</span></div>{chart_svg(part,domain)}<p class="caption" contenteditable="true">{e(chart.get("caption"))}</p>{source_html}'+(f'<details><summary>Valores usados no gráfico</summary><table>{table}</table></details>' if index==len(parts) else '')+'</section>')
    actions=[]
    priority={'alta':'Alta','media':'Média','baixa':'Baixa'}
    for i,card in enumerate(cards):
        checklist=''.join(f'<label class="step"><input type="checkbox" {"checked" if step.get("done") else ""} onchange="this.toggleAttribute(\'checked\',this.checked);updateProgress()"><span contenteditable="true">{e(step["text"])}</span></label>' for step in card.get('steps',[]))
        detail=''
        for key,label in [('problem','O que identificamos'),('why','Por que fazer'),('metric','Como acompanhar'),('target','Resultado esperado')]:
            if card.get(key):detail+=f'<div class="card-detail"><label>{label}</label><div contenteditable="true">{e(card[key])}</div></div>'
        quote=card.get('sourceQuote') or card.get('quote')
        if quote:detail+=f'<blockquote contenteditable="true">{e(quote)}</blockquote>'
        actions.append(f'<section class="action"><div class="card-top"><span class="index">{i+1:02d}</span><span class="priority">Prioridade {priority.get(card.get("priority"),"Média")}</span></div><h2 contenteditable="true">{e(card.get("title"))}</h2>{detail}<h3>Passo a passo</h3><div class="checklist">{checklist}</div>{image_html(card.get("images",[]))}<p class="caption">{e('Fonte dos indicadores: '+str(card['source'])) if card.get('source') else ''}</p></section>')
    sections=''
    detail_sections=market_presentation.detail_sections(report)
    if report.get('showDetails',False) and detail_sections:
        sections='<div class="chapter">Detalhamento da análise</div>'+''.join(f'<section class="detail"><div class="card-top"><span class="index">{i+1:02d}</span><span class="kicker">ANÁLISE</span></div><h2 contenteditable="true">{e(s["title"])}</h2><div class="body" contenteditable="true">{e(s["body"])}</div>{image_html(s.get("images",[]))}</section>' for i,s in enumerate(detail_sections))
    market_html=market_presentation.render_html(report)
    meeting=report.get('meeting',{});meeting_html=''
    if meeting:
        links=''.join(f'<a href="{e(safe_link(meeting.get(key)))}" target="_blank" rel="noopener">{label}</a>' for key,label in [('url','Evento / reunião'),('recordingUrl','Assistir gravação'),('transcriptUrl','Ler transcrição')] if safe_link(meeting.get(key)))
        meeting_html=f'<section class="meeting"><div class="kicker">REUNIÃO DE REFERÊNCIA</div><h2 contenteditable="true">{e(meeting.get("title") or "Alinhamento com o cliente")}</h2><p contenteditable="true">{e(meeting.get("date"))}</p><div class="meeting-links">{links}</div></section>'
    warnings=''.join('<li contenteditable="true">'+e(w)+'</li>' for w in report.get('warnings',[]))
    metric_sources=''.join('<p class="caption">'+e(source)+'</p>' for source in indicator_sources(report))
    extras=''.join('<p contenteditable="true">'+e(report.get('metricLabels',{}).get(k,LABELS.get(k,k)))+': <strong>'+e(number(v,k))+'</strong></p>' for k,v in secondary)
    metadata=[]
    for kind,label in [('ads','Ads'),('account','Conta')]:
        provenance=(report.get(kind) or {}).get('provenance',{})
        start,end=provenance.get('periodStart'),provenance.get('periodEnd')
        if start and end:metadata.append(f'<p class="meta">{label}: {e(date_label(start))} a {e(date_label(end))}</p>')
    if report.get('objective'):metadata.append('<p contenteditable="true"><strong>Objetivo:</strong> '+e(report['objective'])+'</p>')
    meta_html=''.join(metadata)
    charts_html=('<div class="chapter">Os dados em perspectiva</div>'+''.join(charts)) if charts else ''
    actions_html=('<div class="chapter">Seu plano de ação</div><div class="progress"><strong id="progress-text">'+str(done)+' de '+str(len(steps))+' passos concluídos</strong><span>Marque cada passo após concluir.</span></div><div class="actions">'+''.join(actions)+'</div>') if actions else ''
    css=Path(__file__).with_name('report-print.css').read_text(encoding='utf-8')
    return f'''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{e(report['clientName'])} · Pronix</title><style>{css}</style><div class="toolbar"><span>Seu relatório editável</span><button onclick="saveCopy()">Salvar HTML editado</button><button class="primary" onclick="window.print()">Imprimir / salvar PDF</button></div><main><header><div class="brand">ϟ PRONIX</div><span>{e(TYPE_LABEL.get(report_type(report),'Performance'))}</span></header><div class="hero"><div class="kicker">CLAREZA PARA O PRÓXIMO PASSO</div><h1 contenteditable="true">{e(report['title'])}</h1><div class="client" contenteditable="true">{e(report['clientName'])}</div><p class="meta" contenteditable="true">{e(date_label(report['date']))}</p>{meta_html}</div><section class="summary"><span class="kicker">LEITURA DO ESPECIALISTA</span><h2 contenteditable="true">{e(summary.get('headline','Seu próximo passo começa aqui.'))}</h2><p contenteditable="true">{e(summary.get('body') or report.get('objective'))}</p></section><div class="metrics">{metrics}</div>{metric_sources}{meeting_html}{market_html}{charts_html}{actions_html}{sections}<section class="details-end"><h2>Indicadores complementares</h2><div class="extras">{extras}</div><h2 contenteditable="true">Observações e dados a confirmar</h2><ul>{warnings}</ul> </section><footer>Especialista: {e(report.get('specialist'))} · PRONIX · #PronixNaPrática</footer></main><script>function updateProgress(){{const boxes=[...document.querySelectorAll('.step input')];document.getElementById('progress-text').textContent=boxes.filter(b=>b.checked).length+' de '+boxes.length+' passos concluídos'}}function saveCopy(){{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['<!doctype html>'+document.documentElement.outerHTML],{{type:'text/html;charset=utf-8'}}));a.download='Direcionamento_Pronix_editado.html';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}}</script></html>'''


def make_pdf(report,path):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, Flowable, KeepTogether
    from .documents import number, date_label, display_metrics, LABELS, indicator_sources
    font,bold='Helvetica','Helvetica-Bold'
    fontdir=Path('C:/Windows/Fonts')
    if (fontdir/'segoeui.ttf').exists():
        if 'Pronix' not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont('Pronix',str(fontdir/'segoeui.ttf')))
            pdfmetrics.registerFont(TTFont('PronixBold',str(fontdir/'segoeuib.ttf')))
        font,bold='Pronix','PronixBold'
    symbols_available=(fontdir/'seguisym.ttf').exists()
    if symbols_available and 'PronixSymbols' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('PronixSymbols',str(fontdir/'seguisym.ttf')))
    W=A4[0]-88
    C=lambda color:colors.HexColor(color)
    styles={
        'body':ParagraphStyle('VBody',fontName=font,fontSize=11.5,leading=18.5,textColor=C(INK),spaceAfter=9),
        'checklist':ParagraphStyle('VChecklist',fontName=font,fontSize=12,leading=19.5,textColor=C(INK)),
        'small':ParagraphStyle('VSmall',fontName=font,fontSize=9.5,leading=14.5,textColor=C(MUTED),spaceAfter=7),
        'kicker':ParagraphStyle('VKicker',fontName=bold,fontSize=9,leading=13,textColor=C(GOLD),spaceAfter=10),
        'title':ParagraphStyle('VTitle',fontName=bold,fontSize=29,leading=34,textColor=C(INK),spaceAfter=14),
        'client':ParagraphStyle('VClient',fontName=bold,fontSize=20,leading=26,textColor=C(GOLD),spaceAfter=10),
        'chapter':ParagraphStyle('VChapter',fontName=bold,fontSize=21,leading=27,textColor=C(INK),spaceBefore=12,spaceAfter=15,keepWithNext=True),
        'head':ParagraphStyle('VHead',fontName=bold,fontSize=17,leading=23,textColor=C(INK),spaceAfter=12,keepWithNext=True),
        'sub':ParagraphStyle('VSub',fontName=bold,fontSize=10,leading=15,textColor=C(PURPLE),spaceBefore=9,spaceAfter=6,keepWithNext=True),
        'kpi':ParagraphStyle('VKpi',fontName=bold,fontSize=21,leading=28,textColor=C(INK)),
    }
    def clean(text):
        text=str(text or '').replace('\u2011','-').replace('\u2013','-').replace('\u2014','-')
        for x,y in [('🟢','[Viável]'),('🟡','[Atenção]'),('🔴','[Risco]'),('✅','[OK]')]:text=text.replace(x,y)
        return ''.join(c for c in text if ord(c)<65536)
    def p(text,style='body'):
        escaped=html.escape(clean(text))
        if symbols_available:
            escaped=escaped.replace('⚡','<font name="PronixSymbols">⚡</font>')
        return Paragraph(escaped.replace('\n','<br/>'),styles[style])
    def link(url,label):
        return Paragraph(f'<link href="{e(safe_link(url))}" color="{PURPLE}">{e(label)}</link>',styles['body'])
    def block(rows,bg='#FFFFFF',accent=None,padding=18,repeat=0):
        table=Table([[row] for row in rows],colWidths=[W],repeatRows=repeat,splitByRow=1,splitInRow=1,cornerRadii=[12]*4)
        commands=[('BACKGROUND',(0,0),(-1,-1),C(bg)),('BOX',(0,0),(-1,-1),.6,C(LINE)),
            ('LEFTPADDING',(0,0),(-1,-1),padding),('RIGHTPADDING',(0,0),(-1,-1),padding),
            ('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),4),
            ('TOPPADDING',(0,0),(-1,0),padding),('BOTTOMPADDING',(0,-1),(-1,-1),padding),
            ('VALIGN',(0,0),(-1,-1),'TOP')]
        if accent:commands.append(('BOX',(0,0),(-1,-1),.8,C(accent)))
        table.setStyle(TableStyle(commands));return table
    class Check(Flowable):
        def __init__(self,checked=False):Flowable.__init__(self);self.width=17;self.height=19;self.checked=checked
        def draw(self):
            c=self.canv;c.setStrokeColor(C('#16845A' if self.checked else '#B8B8AE'));c.setLineWidth(.8);c.roundRect(1,3,12,12,3,stroke=1,fill=0)
            if self.checked:
                c.setStrokeColor(C('#16845A'));c.setLineWidth(1.3);c.line(3,9,6,6);c.line(6,6,11,12)
    class Chart(Flowable):
        def __init__(self,chart,width,domain=None):
            Flowable.__init__(self);self.gw,self.gh,self.items=chart_geometry(chart,domain=domain);self.width=width;self.height=self.gh*width/self.gw
        def draw(self):
            c=self.canv;c.saveState();scale=self.width/self.gw;c.scale(scale,scale)
            Y=lambda y:self.gh-y
            for item in self.items:
                kind,*v=item
                if kind=='text':
                    x,y,text,size,color,anchor=v;c.setFont(font,size);c.setFillColor(C(color));method=c.drawRightString if anchor=='end' else c.drawCentredString if anchor=='middle' else c.drawString;method(x,Y(y),clean(text))
                elif kind=='rect':
                    x,y,w,h,color=v;c.setFillColor(C(color));c.roundRect(x,Y(y)-h,w,h,1.5,stroke=0,fill=1)
                elif kind=='line':
                    x,y,x2,y2,color,stroke=v;c.setStrokeColor(C(color));c.setLineWidth(stroke);c.line(x,Y(y),x2,Y(y2))
                elif kind=='circle':
                    x,y,r,color=v;c.setFillColor(C(color));c.circle(x,Y(y),r,stroke=0,fill=1)
                elif kind=='polyline':
                    points,color,stroke=v;c.setStrokeColor(C(color));c.setLineWidth(stroke)
                    if len(points)>1:
                        shape=c.beginPath();shape.moveTo(points[0][0],Y(points[0][1]))
                        for x,y in points[1:]:shape.lineTo(x,Y(y))
                        c.drawPath(shape)
            c.restoreState()
    def pictures(images,width=W-36):
        result=[]
        for asset in images:
            image=Image(str(assets.get_path(asset['id'])))
            ratio=min(width/image.imageWidth,245/image.imageHeight)
            image.drawWidth=image.imageWidth*ratio;image.drawHeight=image.imageHeight*ratio
            image.hAlign='LEFT'
            result += [image,p(asset.get('caption'),'small')]
        return result
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    document=SimpleDocTemplate(str(path),pagesize=A4,leftMargin=44,rightMargin=44,topMargin=55,bottomMargin=45,title=report['title']+' | '+report['clientName'],author=report['specialist'])
    cards=report.get('actionCards',[]);summary=report.get('summary',{});meeting=report.get('meeting',{})
    story=[p(TYPE_LABEL.get(report_type(report),'Performance').upper(),'kicker'),Spacer(1,4),p(report['title'],'title'),p(report['clientName'],'client'),p(date_label(report['date']),'small'),Spacer(1,5)]
    for kind,label in [('ads','Ads'),('account','Conta')]:
        provenance=(report.get(kind) or {}).get('provenance',{})
        start,end=provenance.get('periodStart'),provenance.get('periodEnd')
        if start and end:story.append(p(label+': '+date_label(start)+' a '+date_label(end),'small'))
    if report.get('objective'):story += [p('OBJETIVO','kicker'),p(report['objective']),Spacer(1,8)]
    if summary:
        story+=[block([p('LEITURA DO ESPECIALISTA','kicker'),p(summary.get('headline'),'head'),p(summary.get('body'))],SOFT,GOLD),Spacer(1,12)]
    main,secondary=display_metrics(report)
    tile_width=(W-20)/3
    metric_rows=[]
    for start in range(0,len(main),3):
        row=[]
        for index,(key,value) in enumerate(main[start:start+3],start):
            bg,border,ink=KPI_PALETTES[index%len(KPI_PALETTES)]
            label_style=ParagraphStyle('MetricLabel',parent=styles['small'],textColor=C(ink),fontSize=9.5,leading=14)
            value_style=ParagraphStyle('MetricValue',parent=styles['kpi'],textColor=C(ink))
            label=Paragraph(e(report.get('metricLabels',{}).get(key,LABELS.get(key,key))),label_style)
            value_p=Paragraph(e(number(value,key)),value_style)
            tile=Table([[label],[value_p]],colWidths=[tile_width],minRowHeights=[30,42],cornerRadii=[11]*4)
            tile.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),C(bg)),('BOX',(0,0),(-1,-1),.7,C(border)),
                ('LEFTPADDING',(0,0),(-1,-1),13),('RIGHTPADDING',(0,0),(-1,-1),13),
                ('TOPPADDING',(0,0),(-1,0),13),('BOTTOMPADDING',(0,0),(-1,0),4),
                ('TOPPADDING',(0,1),(-1,1),2),('BOTTOMPADDING',(0,1),(-1,1),13)]))
            row.append(tile)
        while len(row)<3:row.append('')
        table=Table([[row[0],'',row[1],'',row[2]]],colWidths=[tile_width,10,tile_width,10,tile_width])
        table.setStyle(TableStyle([('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),0),('TOPPADDING',(0,0),(-1,-1),0),('BOTTOMPADDING',(0,0),(-1,-1),0),('VALIGN',(0,0),(-1,-1),'TOP')]))
        metric_rows += [table,Spacer(1,10)]
    if metric_rows:story.append(KeepTogether(metric_rows))
    story += [p(source,'small') for source in indicator_sources(report)]
    if meeting:
        rows=[p('REUNIÃO DE REFERÊNCIA','kicker'),p(meeting.get('title') or 'Alinhamento com o cliente','head'),p(meeting.get('date'),'small')]
        for key,label in [('url','Abrir evento / reunião'),('recordingUrl','Assistir gravação'),('transcriptUrl','Abrir transcrição')]:
            if safe_link(meeting.get(key)):rows.append(link(meeting[key],label))
        story += [Spacer(1,12),block(rows,SOFT,PURPLE)]
    story += market_presentation.pdf_flowables(report,W,font,bold)
    if report.get('charts'):
        story += [PageBreak()]
        chapter_pending=True
        for chart in report['charts']:
            legend='  ·  '.join(f'<font color="{s.get("color",PURPLE)}">■ {e(s["name"])}</font>' for s in chart['series'])+'  |  '+e(chart.get('unit',''))
            values=[value for series in chart['series'] for value in series['values'] if value is not None]
            domain=(min(values),max(values)) if values else None
            def core_rows(part,title):
                return [p(title,'head'),Paragraph(legend,styles['small']),Chart(part,W-36,domain)]
            parts=[]
            if chart['type']=='bar' and chart['labels']:
                start=0
                while start<len(chart['labels']):
                    end=min(start+6,len(chart['labels']))
                    while True:
                        part={**chart,'labels':chart['labels'][start:end],
                              'series':[{**series,'values':series['values'][start:end]} for series in chart['series']]}
                        _,height=block(core_rows(part,chart['title']+' (parte)')).wrap(W,10000)
                        if height<=540 or end-start==1:break
                        end-=1
                    parts.append(part);start=end
            else:parts=[chart]
            for index,part in enumerate(parts,1):
                title=chart['title']+(f' ({index}/{len(parts)})' if len(parts)>1 else '')
                group=([p('01  Os dados em perspectiva','chapter')] if chapter_pending else [])
                group += [block(core_rows(part,title))]
                # The chapter and first graph travel together; captions can split
                # naturally. All chunks retain the original common value scale.
                story += [KeepTogether(group),Spacer(1,8)]
                chapter_pending=False
            if len(parts)>1:story.append(p('Gráfico dividido em partes, mantendo a mesma escala e todas as séries.','small'))
            if chart.get('caption'):story.append(p(chart['caption'],'small'))
            if chart.get('source'):story.append(p('Fonte: '+str(chart['source']),'small'))
            story.append(Spacer(1,15))
    if cards:
        steps=[step for card in cards for step in card.get('steps',[])]
        story += [PageBreak(),p('Seu plano de ação','chapter'),p(f'{sum(step.get("done",False) for step in steps)} de {len(steps)} passos concluídos. Marque cada passo após concluir.','small'),Spacer(1,8)]
        for i,card in enumerate(cards):
            priority={'alta':'ALTA','media':'MÉDIA','baixa':'BAIXA'}.get(card.get('priority'),'MÉDIA')
            rows=[p(f'{i+1:02d}  /  PRIORIDADE {priority}','kicker'),p(card.get('title'),'head')]
            for key,label in [('problem','O QUE IDENTIFICAMOS'),('why','POR QUE FAZER')]:
                if card.get(key):rows += [p(label,'sub'),p(card[key])]
            rows += [p('PASSO A PASSO','sub')]
            for step in card.get('steps',[]):
                step_table=Table([[Check(step.get('done')),p(step['text'],'checklist')]],colWidths=[24,W-60],splitByRow=1,splitInRow=1)
                step_table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),0),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
                rows.append(step_table)
            for key,label in [('metric','COMO ACOMPANHAR'),('target','RESULTADO ESPERADO')]:
                if card.get(key):rows += [p(label,'sub'),p(card[key])]
            quote=card.get('sourceQuote') or card.get('quote')
            if quote:rows += [p('TRECHO DA REUNIÃO - CONFIRA O CONTEXTO','sub'),p(quote,'small')]
            rows += pictures(card.get('images',[]))
            if card.get('source'):rows += [p('Fonte dos indicadores: '+str(card['source']),'small')]
            card_table=block(rows,accent=GOLD if card.get('priority')=='alta' else PURPLE,repeat=2)
            # Keep ordinary cards together; long text and screenshots may continue on a new page.
            _,height=card_table.wrap(W,10000)
            story += [KeepTogether([card_table,Spacer(1,16)]) if height<650 else card_table]
            if height>=650:story.append(Spacer(1,16))
    detail_sections=market_presentation.detail_sections(report)
    if report.get('showDetails',False) and detail_sections:
        story += [PageBreak(),p('Detalhamento da análise','chapter')]
        for i,section in enumerate(detail_sections):
            rows=[p(f'{i+1:02d}  {section["title"]}','head')]
            for paragraph in re_split(section['body']):rows.append(p(paragraph.replace('**','').replace('`','')))
            rows += pictures(section.get('images',[]))
            story += [block(rows,repeat=1),Spacer(1,15)]
    if secondary or report.get('warnings'):
        story += [PageBreak(),p('Observações da análise','chapter')]
    if secondary:
        story += [p('Indicadores complementares','head')]
        data=[]
        for start in range(0,len(secondary),2):
            row=[p(report.get('metricLabels',{}).get(k,LABELS.get(k,k))+': '+number(v,k),'small') for k,v in secondary[start:start+2]]
            if len(row)==1:row.append('')
            data.append(row)
        table=Table(data,colWidths=[W/2]*2);table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),12)]));story += [table,Spacer(1,14)]
    if report.get('warnings'):
        story += [p('Pontos que precisam de conferência','head')]+[p('• '+str(w),'small') for w in report['warnings']]
    def footer(canvas,doc):
        canvas.saveState();canvas.setFillColor(C(GOLD))
        x,y=44,A4[1]-36
        bolt=canvas.beginPath();bolt.moveTo(x+8,y+18);bolt.lineTo(x,y+7);bolt.lineTo(x+6,y+7);bolt.lineTo(x+3,y);bolt.lineTo(x+15,y+12);bolt.lineTo(x+8,y+12);bolt.close()
        canvas.drawPath(bolt,stroke=0,fill=1)
        canvas.setFont(bold,12);canvas.drawString(66,A4[1]-31,'PRONIX')
        canvas.setFont(font,7);canvas.setFillColor(C(MUTED));canvas.drawRightString(A4[0]-44,A4[1]-29,{'market':'ANÁLISE DE MERCADO','reputation':'DIRECIONAMENTO · REPUTAÇÃO'}.get(report_type(report),'DIRECIONAMENTO · PERFORMANCE'))
        canvas.setStrokeColor(C(LINE));canvas.line(44,38,A4[0]-44,38)
        footer_style=ParagraphStyle('VFooter',fontName=font,fontSize=8.5,leading=10,textColor=C(MUTED))
        specialist=Paragraph(html.escape('Especialista: '+str(report.get('specialist') or '')),footer_style)
        _,height=specialist.wrap(W-35,30);specialist.drawOn(canvas,44,12)
        canvas.drawRightString(A4[0]-44,18,str(doc.page));canvas.restoreState()
    document.build(story,onFirstPage=footer,onLaterPages=footer)


def re_split(text):
    import re
    return [block for block in re.split(r'\n\s*\n',text) if block.strip()]
