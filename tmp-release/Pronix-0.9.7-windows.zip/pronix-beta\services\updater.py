"""Atualização automática pelo GitHub Releases.

O repositório ("dono/nome") fica em Preferências ou vem no pacote da equipe. A
verificação lê a última release; a atualização baixa o ZIP e o .sha256
publicados pelo script instalador/publicar-release.ps1, confere o hash e roda o
instalador do próprio pacote em segundo plano (ele fecha o Pronix, copia e abre
de novo). Dados, relatórios e conexões não são tocados.

Repositório privado: a leitura usa uma chave de acesso do GitHub só de leitura
(token "fine-grained" com permissão Contents: Read-only, apenas nesse
repositório). Ela fica no cofre DPAPI deste usuário do Windows
(%USERPROFILE%\\.pronix-beta\\atualizacao.dpapi) ou vem embaralhada no pacote da
equipe (resources/conexoes.bin). A chave só é enviada para api.github.com e
nunca segue um redirecionamento; o valor nunca aparece na tela nem em respostas.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import threading
import time
import zipfile
from pathlib import Path
from urllib import error, parse, request

from . import bundled, storage
from .version import VERSION

API = "https://api.github.com/repos/{repo}/releases/latest"
REPO = re.compile(r"[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}")
TOKEN = re.compile(r"(?:github_pat_|ghp_)[A-Za-z0-9_]{20,250}")
ALLOWED_HOSTS = {"github.com", "api.github.com", "objects.githubusercontent.com", "release-assets.githubusercontent.com"}
TOKEN_HOST = "api.github.com"
MAX_PACKAGE = 200 * 1024 * 1024
_LOCK = threading.Lock()
_STATE = {"checkedAt": None, "latest": None, "available": False, "error": None, "notes": "", "applying": False}


class _NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # redirecionamentos são seguidos à mão, sem a chave


def _version_tuple(value):
    numbers = re.findall(r"\d+", str(value or ""))[:3]
    return tuple(int(n) for n in numbers) + (0,) * (3 - len(numbers))


# ---------- chave de leitura e repositório ----------
def _vault() -> Path:
    from .secure_dir import secure_dir
    return secure_dir() / "atualizacao.dpapi"


def _bundled() -> dict:
    data = bundled.load().get("atualizacao") or {}
    return data if isinstance(data, dict) else {}


def save_access(token: str | None) -> None:
    """Guarda (ou apaga, com vazio) a chave de leitura neste usuário do Windows."""
    from .mercadolivre import _dpapi
    path = _vault()
    value = str(token or "").strip()
    if not value:
        path.unlink(missing_ok=True)
        return
    if not TOKEN.fullmatch(value):
        raise ValueError("Cole a chave do GitHub completa (começa com github_pat_).")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_bytes(_dpapi(json.dumps({"token": value}).encode("utf-8"), decrypt=False))
    os.replace(temporary, path)


def access_token() -> str | None:
    """Chave salva neste computador; senão, a do pacote da equipe."""
    try:
        path = _vault()
        if path.is_file():
            from .mercadolivre import _dpapi
            value = json.loads(_dpapi(path.read_bytes(), decrypt=True)).get("token")
            if isinstance(value, str) and TOKEN.fullmatch(value):
                return value
    except Exception:
        pass
    value = _bundled().get("token")
    if not (isinstance(value, str) and TOKEN.fullmatch(value)):
        return None
    try:
        save_access(value)        # copia para o cofre: uma atualização troca a pasta do programa e leva o conexoes.bin junto
    except Exception:
        pass
    return value


def access_source() -> str | None:
    try:
        if _vault().is_file():
            return "computador"
    except Exception:
        pass
    return "pacote" if _bundled().get("token") else None


def repo_from_settings(settings):
    value = str((settings or {}).get("updateRepo") or "").strip()
    if not value and "updateRepo" not in (settings or {}):
        value = str(_bundled().get("repo") or "")          # pacote da equipe já vem apontando para o repositório
    return value if REPO.fullmatch(value) else ""


# ---------- rede ----------
def _get(url, limit=1024 * 1024, token=None, binary=False):
    """GET em endereço do GitHub; a chave vai só para api.github.com e não acompanha redirecionamentos."""
    opener = request.build_opener(_NoRedirect())
    for _ in range(4):
        parts = parse.urlsplit(url)
        host = parts.hostname or ""
        if parts.scheme != "https" or host not in ALLOWED_HOSTS:
            raise ValueError("Endereço de atualização fora do GitHub.")
        headers = {"User-Agent": "Pronix-updater",
                   "Accept": "application/octet-stream" if binary else "application/vnd.github+json"}
        if token and host == TOKEN_HOST:
            headers["Authorization"] = "Bearer " + token
            headers["X-GitHub-Api-Version"] = "2022-11-28"
        try:
            with opener.open(request.Request(url, headers=headers), timeout=60) as response:
                data = response.read(limit + 1)
        except error.HTTPError as exc:
            if exc.code in (301, 302, 303, 307, 308) and exc.headers.get("Location"):
                url = parse.urljoin(url, exc.headers["Location"])
                token = None                                  # nunca reenviar a chave
                continue
            if exc.code in (401, 403, 404) and host == TOKEN_HOST:
                raise ValueError("O GitHub não liberou o repositório de atualizações. Confira a chave de leitura em Preferências.") from None
            raise ValueError(f"O GitHub respondeu {exc.code}.") from None
        if len(data) > limit:
            raise ValueError("Arquivo de atualização maior que o esperado.")
        return data
    raise ValueError("Redirecionamentos demais na atualização.")


def status():
    return {"current": VERSION, **{k: v for k, v in _STATE.items() if k not in ("package", "checksum")},
            "access": access_source()}


def check(repo):
    """Consulta a última release. Nunca instala nada sozinho."""
    if not repo:
        _STATE.update(error=None, available=False, latest=None)
        return status()
    token = access_token()
    try:
        release = json.loads(_get(API.format(repo=repo), token=token))
        tag = str(release.get("tag_name") or "")
        # Com chave, o arquivo vem pela API (funciona em repositório privado); sem chave, pelo link público.
        assets = {a.get("name"): (a.get("url") if token and a.get("url") else a.get("browser_download_url"))
                  for a in release.get("assets") or [] if isinstance(a, dict)}
        package = next((n for n in assets if re.fullmatch(r"Pronix-[\d.]+-windows\.zip", str(n))), None)
        _STATE.update(checkedAt=time.time(), latest=tag.lstrip("v") or None, error=None,
                      notes=str(release.get("body") or "")[:2000],
                      available=bool(package and assets.get(package + ".sha256") and _version_tuple(tag) > _version_tuple(VERSION)),
                      package=assets.get(package) if package else None,
                      checksum=assets.get(package + ".sha256") if package else None)
    except Exception as exc:
        _STATE.update(checkedAt=time.time(), error="Não foi possível verificar atualizações: " + str(exc)[:200])
    return status()


def installer_command(command: str) -> list[str]:
    powershell = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    return [str(powershell) if powershell.is_file() else "powershell.exe",
            "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", command]


def apply(repo):
    """Baixa, confere e instala a versão nova em segundo plano."""
    with _LOCK:
        if _STATE.get("applying"):
            raise ValueError("A atualização já está em andamento.")
        check(repo)
        if not _STATE.get("available"):
            raise ValueError("Nenhuma versão nova disponível.")
        _STATE["applying"] = True
    try:
        token = access_token()
        folder = storage.RUNTIME / "updates"
        folder.mkdir(parents=True, exist_ok=True)
        zip_path = folder / f"Pronix-{_STATE['latest']}-windows.zip"
        data = _get(_STATE["package"], MAX_PACKAGE, token=token, binary=True)
        expected = _get(_STATE["checksum"], 4096, token=token, binary=True).decode("ascii", "ignore").split()[0].lower()
        if hashlib.sha256(data).hexdigest() != expected:
            raise ValueError("O pacote baixado não confere com o hash publicado. Nada foi instalado.")
        zip_path.write_bytes(data)
        target = folder / f"Pronix-{_STATE['latest']}"
        with zipfile.ZipFile(zip_path) as archive:
            for name in archive.namelist():
                if name.startswith(("/", "\\")) or ".." in Path(name).parts:
                    raise ValueError("Pacote com caminho inválido.")
            archive.extractall(target)
        installer = target / "instalar.ps1"
        if not installer.is_file():
            raise ValueError("O pacote não contém o instalador.")
        destination = storage.ROOT.parent
        log = folder / "ultima-atualizacao.log"
        # CREATE_NO_WINDOW (console oculto). Com DETACHED_PROCESS o PowerShell fica sem console e
        # não chega a rodar o instalador: era o "Atualizar agora" que girava e não instalava (0.9.0–0.9.4).
        command = ("& { try { & '" + str(installer).replace("'", "''") + "' -Silencioso -SemAtalhos -Destino '"
                   + str(destination).replace("'", "''") + "' *>&1 | Out-File -LiteralPath '" + str(log).replace("'", "''")
                   + "' -Encoding utf8; exit 0 } catch { $_ | Out-File -LiteralPath '" + str(log).replace("'", "''")
                   + "' -Append -Encoding utf8; exit 1 } }")
        subprocess.Popen(installer_command(command),
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
                         close_fds=True, cwd=str(target))
        return {"started": True, "version": _STATE["latest"]}
    except Exception:
        _STATE["applying"] = False
        raise


def start_background(settings_reader, interval=6 * 3600):
    def loop():
        while True:
            try:
                check(repo_from_settings(settings_reader()))
            except Exception:
                pass
            time.sleep(interval)
    threading.Thread(target=loop, name="pronix-update-check", daemon=True).start()
