"""Gera resources/conexoes.bin dentro do pacote, a partir das conexões deste computador.

Uso (feito pelo montar-pacote.ps1):  python instalador/embutir_conexoes.py <pasta pronix-beta do pacote>
Lê o aplicativo do Mercado Livre, o Client ID da JoomPulse, o cliente OAuth do Google e a chave de leitura das
atualizações (GitHub) já configurados
neste Windows (cofres DPAPI em %USERPROFILE%\\.pronix-beta) e grava o arquivo
embaralhado. Não imprime nenhum valor. Tokens de conta NÃO são incluídos.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services import bundled, updater  # noqa: E402
from services.storage import read_json  # noqa: E402
from services.joompulse import JoomPulseClient  # noqa: E402
from services.mercadolivre import MercadoLivreClient  # noqa: E402


def main() -> int:
    target = Path(sys.argv[1]) / "resources" / "conexoes.bin"
    data, included = {}, []
    meli = MercadoLivreClient()
    app = dict(meli._app)
    if app.get("client_id") and app.get("client_secret") and app.get("redirect_uri"):
        data["mercadolivre"] = {key: app[key] for key in ("client_id", "client_secret", "redirect_uri")}
        included.append("Mercado Livre")
    joom = JoomPulseClient()
    client_id = dict(joom._config).get("client_id")
    if client_id and not dict(joom._config).get("client_secret"):
        data["joompulse"] = {"client_id": client_id}
        included.append("JoomPulse")
    from services.google_meet import GoogleMeetClient
    google = dict(GoogleMeetClient()._config)
    if google.get("client_id"):
        data["google"] = {"client_id": google["client_id"], "client_secret": google.get("client_secret", ""),
                          "drive_access": google.get("drive_access", "meet")}
        included.append("Google")
    from services.secure_dir import secure_dir
    uso = secure_dir() / "uso-formulario.json"     # endereço do formulário de uso (não é segredo)
    if uso.is_file():
        import json
        data["uso"] = json.loads(uso.read_text(encoding="utf-8"))
        included.append("registro de uso")
    token = updater.access_token()
    repo = updater.repo_from_settings(read_json(ROOT / "runtime" / "settings.json", {})) or "vortexoec/central-analises"
    if token:
        data["atualizacao"] = {"repo": repo, "token": token}
        included.append("atualização automática (" + repo + ")")
    if not data:
        print("Conexões embutidas: nenhuma (configure Mercado Livre e JoomPulse neste computador antes).")
        return 0
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(bundled.encode(data))
    print("Conexões embutidas no pacote: " + ", ".join(included) + " (somente dados do aplicativo, sem contas).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
