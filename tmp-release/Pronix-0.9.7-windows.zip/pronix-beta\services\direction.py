"""Editable, deterministic direction cards and charts; no external requests or AI.

Templates adapt the supplied Pronix playbook and checklist structure. They do not
carry over account-specific promises, platform eligibility or invented targets.
"""
from __future__ import annotations

import copy
import hashlib
import math
import re
import unicodedata
from datetime import date, timedelta
from .report_schema import is_market_report

PURPLE = "#6F56E6"
GOLD = "#C88C00"
GREEN = "#16845A"


def _num(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if math.isfinite(value) else None


def _ratio(a, b):
    a, b = _num(a), _num(b)
    return round(a / b, 6) if a is not None and b is not None and b > 0 else None


def _fmt(value, unit=""):
    if _num(value) is None:
        return "não disponível"
    rendered = f"{value:,.2f}".replace(",", "~").replace(".", ",").replace("~", ".")
    return "R$ " + rendered if unit == "BRL" else rendered + unit


def _normal(text):
    return "".join(c for c in unicodedata.normalize("NFKD", str(text)) if not unicodedata.combining(c)).lower()


def _id(prefix, name):
    return prefix + "-" + hashlib.sha256(str(name).encode("utf-8")).hexdigest()[:10]


def _card(key, title, problem, why, steps, metric, target, priority="media", section=None):
    result = {"id": key, "title": title, "problem": problem, "why": why,
              "steps": [{"id": f"{key}-step-{i}", "text": text, "done": False} for i, text in enumerate(steps, 1)],
              "owner": "", "due": "", "priority": priority, "metric": metric,
              "target": target, "status": "pending", "images": []}
    if section:
        result["sectionId"] = section
    return result


def _reputation_cards():
    return [
        _card("start-listing", "1. Preparar o anúncio e o título",
              "Confirmar os dados do primeiro anúncio antes de publicar.",
              "Um título fiel e a categoria correta ajudam o comprador a reconhecer o produto.",
              ["Escolher um produto disponível e anotar marca, modelo, medidas e conteúdo da embalagem.",
               "Iniciar um anúncio na conta e conferir se a categoria sugerida corresponde ao produto.",
               "Escrever um título com produto, marca/modelo e característica relevante, sem informações não comprovadas.",
               "Conferir o identificador original do produto, quando solicitado; revisar a prévia antes de publicar."],
              "Dados de identificação revisados", "Título e categoria conferidos para cada anúncio inicial", "alta"),
        _card("start-images", "2. Mostrar o produto com fotos claras",
              "Conferir se as imagens explicam o que será entregue.",
              "Fotos coerentes com o produto ajudam a esclarecer características e evitar expectativas erradas.",
              ["Separar imagens próprias ou autorizadas do produto real e da variação anunciada.",
               "Selecionar uma capa nítida e conferir as orientações de imagem exibidas para a categoria.",
               "Adicionar ângulos, detalhes e medidas verificadas; revisar a legibilidade no celular.",
               "Anexar neste card a imagem ou o print aprovado como referência."],
              "Anúncios com imagens revisadas", "Fotos compatíveis com cada produto e variação"),
        _card("start-specs", "3. Completar ficha, descrição e variações",
              "Conferir se o comprador encontra as informações necessárias para escolher.",
              "A ficha e a descrição devem corresponder ao estoque real e às características confirmadas.",
              ["Preencher os atributos solicitados usando a embalagem, o fornecedor ou a especificação do fabricante.",
               "Descrever uso, dimensões e itens inclusos; informar limitações relevantes sem promessas não comprovadas.",
               "Vincular fotos, estoque e identificação à variação correta, quando ela existir.",
               "Revisar a prévia e registrar quais dados ainda dependem de confirmação."],
              "Atributos e variações conferidos", "Ficha consistente com o produto e com o estoque"),
        _card("start-pricing", "4. Conferir preço e custos antes de vender",
              "Validar a margem disponível antes de descontos ou publicidade.",
              "Faturamento e ROAS não demonstram lucro sem os custos da operação.",
              ["Anotar custo do produto, embalagem, impostos aplicáveis e demais despesas reais.",
               "Consultar as tarifas e condições de envio exibidas para o anúncio na própria conta.",
               "Calcular o valor que sobra após os custos e comparar preço mais frete com ofertas equivalentes.",
               "Definir com o especialista o preço e a margem mínima; registrar a conta usada."],
              "Margem antes de Ads por produto", "Preço validado com custos reais; valor a definir com o cliente", "alta"),
        _card("start-shipping", "5. Preparar estoque e rotina de envio",
              "Confirmar a capacidade de cumprir o prazo de cada venda.",
              "Estoque conferido, embalagem e rotina de despacho reduzem falhas operacionais evitáveis.",
              ["Contar o estoque disponível e conferir a quantidade anunciada em cada variação.",
               "Separar a embalagem e conferir peso e dimensões do pacote preparado.",
               "Verificar as modalidades disponíveis e os prazos mostrados na conta; planejar quem fará o despacho.",
               "Ao receber uma venda, seguir as instruções do pedido e conferir documentação e etiqueta antes do envio."],
              "Estoque conferido e pedidos enviados no prazo", "Cumprir os prazos exibidos em cada pedido", "alta"),
        _card("start-service", "6. Acompanhar atendimento e reputação",
              "Criar uma rotina de acompanhamento desde os primeiros pedidos.",
              "A evolução deve ser conferida no painel real, com registro dos problemas e suas causas.",
              ["Definir um horário diário para consultar perguntas, mensagens, pedidos e ocorrências.",
               "Responder com informações confirmadas e acompanhar a resolução de problemas do pedido.",
               "Consultar o painel de reputação e registrar os indicadores disponíveis e a data da leitura.",
               "Revisar cancelamentos, atrasos e reclamações com o especialista e combinar a próxima checagem."],
              "Pedidos, ocorrências e indicadores do painel", "Registrar a situação inicial e acompanhar sua evolução"),
    ]


def _context(report):
    return {**((report.get("ads") or {}).get("provenance", {}).get("context") or {}), **(report.get("context") or {})}


def _period_days(data):
    provenance = data.get("provenance") or {}
    try:
        return (date.fromisoformat(provenance["periodEnd"]) - date.fromisoformat(provenance["periodStart"])).days + 1
    except (ValueError, TypeError, KeyError):
        return None


def _performance_cards(report):
    ads, account, context = report.get("ads") or {}, report.get("account") or {}, _context(report)
    margin = _num(context.get("marginPercent"))
    if margin is not None and margin > 100:
        margin = None
    candidates = []

    def add(rank, spend, card):
        candidates.append((rank, -(_num(spend) or 0), card))

    for campaign in ads.get("campaigns", []):
        name = str(campaign.get("name") or "Campanha sem nome")
        m = campaign.get("metrics") or {}
        spend, revenue, orders = (_num(m.get(key)) for key in ("spend", "revenue", "orders"))
        roas, acos = _num(m.get("roas")), _num(m.get("acos"))
        target = _num(campaign.get("targetRoas")) or _num(context.get("targetRoas"))
        if margin is not None and acos is not None and acos >= margin:
            add(0, spend, _card(_id("margin", name), f"Revisar a margem de {name}",
                f"ACOS de {_fmt(acos, '%')} frente à margem antes de Ads informada de {_fmt(margin, '%')}.",
                "O custo publicitário alcança ou supera a referência de margem. Custos por SKU precisam confirmar essa leitura agregada.",
                [f"Separar os produtos de {name} e validar custo, comissão, frete e impostos por SKU.",
                 "Comparar o ACOS de cada produto com sua margem disponível antes da publicidade.",
                 "Revisar preço e oferta; decidir com o especialista se algum produto precisa de ajuste ou pausa.",
                 "Registrar a mudança e comparar o próximo período equivalente, considerando a atualização da atribuição."],
                "ACOS e margem antes de Ads", f"ACOS abaixo da margem validada; referência informada: {_fmt(margin, '%')}" if margin > 0 else "Rever preço e custos para obter margem positiva antes de Ads", "alta", "ads-campaigns"))
        elif spend is not None and spend > 0 and (orders == 0 or revenue == 0):
            fact = "nenhuma venda atribuída" if orders == 0 else "receita atribuída igual a zero"
            add(3, spend, _card(_id("no-sales", name), f"Investigar a oferta de {name}",
                f"Investimento de {_fmt(spend, 'BRL')} com {fact} na fonte importada.",
                "A ausência de resultado atribuído pede investigação. Preço, frete, prazo e anúncio são hipóteses, não causas comprovadas.",
                [f"Conferir o intervalo e a atualização da atribuição de {name}; registrar cliques e vendas disponíveis.",
                 "Abrir os anúncios da campanha e comparar preço mais frete e prazo com produtos equivalentes.",
                 "Conferir fotos, título, ficha, disponibilidade e dúvidas de compradores; escolher a correção sustentada pela revisão.",
                 "Registrar o teste e revisar vendas atribuídas, receita e conversão no próximo intervalo equivalente."],
                "Vendas atribuídas, receita e conversão", "Validar a causa e definir a meta após conferir oferta e amostra", "media", "ads-campaigns"))
        elif roas is not None and target is not None and target > 0 and roas < target:
            add(3, spend, _card(_id("roas", name), f"Revisar o retorno de {name}",
                f"ROAS realizado de {_fmt(roas, 'x')} abaixo do objetivo informado de {_fmt(target, 'x')}.",
                "A distância para a meta orienta a revisão; a duração da amostra e a margem determinam quais mudanças fazem sentido.",
                [f"Confirmar se a meta de {_fmt(target, 'x')} ainda representa os custos e o objetivo dos produtos de {name}.",
                 "Separar produtos com e sem vendas e conferir os dados do mesmo período.",
                 "Revisar competitividade e qualidade dos anúncios antes de alterar a estratégia de investimento.",
                 "Escolher uma mudança com o especialista, registrar a data e acompanhar retorno e margem."],
                "ROAS e ACOS", f"Referência declarada de ROAS: {_fmt(target, 'x')}; validar com a margem", "media", "ads-campaigns"))
        elif (campaign.get("status") == "Possível oportunidade de escala"
              and margin is not None and acos is not None and acos < margin
              and target is not None and roas is not None and roas >= target
              and context.get("stockConfirmed") is True and context.get("priceCompetitive") is True
              and (_period_days(ads) or 0) >= 7):
            # The Ads engine gates this finding on period, margin, stock, price and lost budget.
            add(5, spend, _card(_id("scale", name), f"Validar um teste de escala em {name}",
                f"A análise da campanha aponta possível oportunidade de escala; ROAS de {_fmt(roas, 'x')} e ACOS de {_fmt(acos, '%')}.",
                "O achado depende dos custos, estoque e competitividade informados. Não é garantia de venda ou lucro.",
                ["Reconfirmar margem por produto, estoque e capacidade de atendimento antes do teste.",
                 "Conferir a perda por orçamento e se o período observado continua representativo.",
                 "Definir com o especialista o tamanho, a duração e a condição de interrupção do teste.",
                 "Acompanhar investimento, ACOS, ROAS e estoque; registrar o resultado antes de uma nova decisão."],
                "ACOS, ROAS e estoque", "Manter retorno e margem acordados; incremento a definir", "media", "ads-campaigns"))
        else:
            incomplete = any(value is None for value in (spend, revenue, orders))
            no_spend = spend == 0
            add(6 if incomplete else 7, spend, _card(_id("monitor", name), f"Acompanhar {name}",
                str(campaign.get('status') or ('Dados da campanha a completar' if incomplete else 'Campanha sem gatilho crítico nas regras atuais')) + '.',
                "Os dados ausentes precisam ser conferidos antes de interpretar eficiência." if incomplete else
                "Sem investimento registrado, não há base para avaliar retorno pago ou decidir aumento de verba." if no_spend else
                "A ausência de alerta não confirma lucro. Acompanhe a campanha com custos e períodos comparáveis.",
                [f"Conferir as métricas e o período de {name}; completar os campos indisponíveis na fonte." if incomplete else
                 f"Conferir se {name} estava ativa e se os anúncios tinham estoque e elegibilidade no período." if no_spend else
                 f"Conferir os produtos que contribuíram para o resultado de {name} no período.",
                 "Comparar receita atribuída, investimento e conversões com o próximo período equivalente.",
                 "Validar margem e estoque antes de mudar orçamento; registrar o ajuste somente quando houver evidência."],
                "Investimento, receita atribuída, vendas, ROAS e ACOS", "Acompanhar a campanha e validar os dados antes de decidir mudanças",
                "media" if incomplete else "baixa", "ads-campaigns"))
        card = candidates[-1][2]
        card['campaignName'] = name
        card['campaignKey'] = _id('campaign', name)
        card['source'] = _source(ads)
        card['problem'] = (f"Investimento: {_fmt(spend, 'BRL')} | Receita atribuída: {_fmt(revenue, 'BRL')} | "
                           f"Vendas: {_fmt(orders)} | ROAS: {_fmt(roas, 'x')} | ACOS: {_fmt(acos, '%')}.\n" + card['problem'])

    am = account.get("metrics") or {}
    cancelled, returned = _num(am.get("accountCancelledOrders")), _num(am.get("accountReturnedOrders"))
    if (cancelled is not None and cancelled > 0) or (returned is not None and returned > 0):
        add(2, 0, _card("account-occurrences", "Revisar cancelamentos e devoluções",
            f"A fonte registra {_fmt(cancelled)} vendas canceladas e {_fmt(returned)} devolvidas.",
            "Esses eventos merecem revisão dos pedidos. O total agregado não informa a causa nem comprova perda de reputação.",
            ["Localizar os pedidos correspondentes no mesmo período do relatório.",
             "Registrar os motivos documentados e separar problemas de produto, anúncio, estoque e envio.",
             "Corrigir o problema confirmado com o responsável pela operação.",
             "Comparar a quantidade e os motivos no próximo período equivalente."],
            "Cancelamentos e devoluções", "Definir redução após identificar as causas", "alta", "account-cancellations"))
    windows = {w.get("days"): w for w in account.get("windows", []) if w.get("complete") is True}
    if 7 in windows and 30 in windows:
        recent = _ratio((windows[7].get("metrics") or {}).get("accountRevenue"), 7)
        baseline = _ratio((windows[30].get("metrics") or {}).get("accountRevenue"), 30)
        if recent is not None and baseline is not None and baseline > 0 and recent < baseline * .8:
            add(4, 0, _card("account-recent", "Investigar a diferença na média diária",
                f"Vendas brutas por dia: {_fmt(recent, 'BRL')} nos últimos 7 dias e {_fmt(baseline, 'BRL')} nos últimos 30 dias.",
                "O desvio supera 20% da referência de 30 dias, critério interno Pronix. As janelas se sobrepõem e não confirmam uma tendência estrutural.",
                ["Conferir se todos os dias estão encerrados e se o calendário do período afeta a comparação.",
                 "Comparar visitas e vendas por dia para localizar onde a diferença começou.",
                 "Consultar os anúncios afetados e verificar estoque, oferta e ocorrências documentadas.",
                 "Registrar a hipótese e a correção escolhida; acompanhar a próxima janela completa."],
                "Vendas brutas, visitas e conversão", "Explicar o desvio e definir a meta após a investigação", "media", "account-windows"))
    if ads and margin is None and (_num((ads.get("metrics") or {}).get("spend")) or 0) > 0:
        add(1, 0, _card("validate-costs", "Completar a margem antes de decidir a verba",
            "Há investimento em Ads, mas a margem antes de Ads não foi validada.",
            "ROAS e faturamento, isoladamente, não permitem confirmar rentabilidade.",
            ["Reunir custo, comissão, embalagem, frete, impostos e descontos por produto anunciado.",
             "Calcular a margem antes de Ads e registrar as premissas usadas.",
             "Comparar ACOS com a margem disponível e definir a meta de retorno com o especialista."],
            "Margem antes de Ads e ACOS", "Preencher custos reais antes de recomendar escala", "alta", "ads-limits"))
    if not candidates:
        has_metrics = bool(ads or account)
        add(6, 0, _card("next-review", "Preparar a próxima revisão" if has_metrics else "Completar a base do diagnóstico",
            "A base atual não gerou uma prioridade específica pelas regras disponíveis." if has_metrics else "Não há relatório de conta ou Ads para sustentar um diagnóstico numérico.",
            "O próximo direcionamento precisa de fontes comparáveis e de um objetivo validado com o cliente.",
            ["Definir o objetivo e o período da próxima leitura com o cliente.",
             "Importar os relatórios de conta e Ads disponíveis, cobrindo o mesmo intervalo.",
             "Registrar os custos, as mudanças realizadas e as pendências para revisar os resultados."],
            "Cobertura de dados e objetivo do cliente", "Fontes e metas confirmadas para a próxima revisão", "media"))
    return [item[2] for item in sorted(candidates, key=lambda item: (item[0], item[1], item[2]["id"]))]


def _source(data):
    provenance = data.get("provenance") or {}
    filename = str(provenance.get("filename") or "Fonte importada")
    start, end = provenance.get("periodStart"), provenance.get("periodEnd")
    return filename + (f" · {start} a {end}" if start and end else " · período não comprovado")


def _charts(report):
    result = []
    ads, account = report.get("ads") or {}, report.get("account") or {}
    campaigns = list(ads.get("campaigns", []))
    campaigns.sort(key=lambda c: _num((c.get("metrics") or {}).get("spend")) if _num((c.get("metrics") or {}).get("spend")) is not None else -1, reverse=True)
    chosen = campaigns
    if chosen:
        labels = [str(c.get("name") or "Sem nome") for c in chosen]
        caption = "Valores do período por campanha. Receita atribuída não representa lucro."
        caption += f" Todas as {len(campaigns)} campanhas estão incluídas; a divisão em partes serve apenas à leitura."
        result.append({"id": "ads-value", "type": "bar", "title": "Investimento e receita atribuída", "labels": labels,
            "series": [{"name": "Investimento", "values": [_num(c["metrics"].get("spend")) for c in chosen], "color": GOLD},
                       {"name": "Receita atribuída", "values": [_num(c["metrics"].get("revenue")) for c in chosen], "color": PURPLE}],
            "unit": "BRL", "caption": caption, "source": _source(ads)})
        values = [_ratio(c["metrics"].get("revenue"), c["metrics"].get("spend")) for c in chosen]
        if any(value is not None for value in values):
            series = [{"name": "ROAS realizado (x)", "values": values, "color": PURPLE}]
            targets = [_num(c.get("targetRoas")) for c in chosen]
            if any(value is not None and value > 0 for value in targets):
                series.append({"name": "ROAS objetivo (x)", "values": [value if value is not None and value > 0 else None for value in targets], "color": GOLD})
            result.append({"id": "ads-return", "type": "bar", "title": "Retorno atribuído por R$ 1 investido", "labels": labels,
                "series": series, "unit": "number", "caption": "ROAS = receita atribuída ÷ investimento. Mesmas campanhas do gráfico de valores; investimento zero ou ausente não gera ROAS. Não mede lucro.", "source": _source(ads)})
    dates = {}
    for row in account.get("daily", []):
        try:
            day = date.fromisoformat(str(row.get("date")))
        except (ValueError, TypeError):
            continue
        # Ambiguous duplicated dates must not be silently aggregated.
        dates[day] = None if day in dates else _num(row.get("accountRevenue"))
    if len(dates) >= 2 and any(value is not None for value in dates.values()):
        start, end = max(min(dates), max(dates) - timedelta(days=89)), max(dates)
        timeline = [start + timedelta(days=n) for n in range((end - start).days + 1)]
        result.append({"id": "account-daily", "type": "line", "title": "Vendas brutas da conta por dia",
            "labels": [day.isoformat() for day in timeline], "series": [{"name": "Vendas brutas", "values": [dates.get(day) for day in timeline], "color": PURPLE}],
            "unit": "BRL", "caption": "Datas ausentes, duplicadas ou sem valor ficam como lacunas, nunca como zero. Exibição limitada aos últimos 90 dias disponíveis; não é uma projeção.", "source": _source(account)})
    else:
        windows = sorted([w for w in account.get("windows", []) if w.get("complete") is True and _num(w.get("days")) is not None and w["days"] > 0], key=lambda w: w["days"])
        windows = [w for w in windows if _ratio((w.get("metrics") or {}).get("accountRevenue"), w["days"]) is not None]
        if len(windows) >= 2:
            result.append({"id": "account-windows", "type": "bar", "title": "Média diária em janelas completas",
                "labels": [f"{w['days']} dias" for w in windows], "series": [{"name": "Vendas brutas por dia", "values": [_ratio(w["metrics"]["accountRevenue"], w["days"]) for w in windows], "color": PURPLE}],
                "unit": "BRL", "caption": "Janelas sobrepostas, normalizadas por duração. Não são semanas consecutivas nem uma série cronológica. Janelas incompletas foram omitidas.", "source": _source(account)})
    return result[:3]


def _summary(report):
    if report["reportType"] == "reputation":
        return {"headline": "Preparar a operação e acompanhar os primeiros resultados", "body": "Checklist inicial para revisar anúncios, custos, envio e atendimento. Confirme as etapas aplicáveis à conta antes da execução. A situação de reputação deve ser conferida no painel da conta."}
    if report["reportType"] == "market":
        return {"headline": "Viabilidade dos produtos", "body": "Revise os dados comerciais, as evidências e os custos de cada produto. Pareceres calculados e revisões do especialista permanecem separados."}
    ads, account = (report.get("ads") or {}).get("metrics") or {}, (report.get("account") or {}).get("metrics") or {}
    parts = []
    if _num(account.get("accountRevenue")) is not None:
        parts.append(f"A conta registrou {_fmt(account['accountRevenue'], 'BRL')} em vendas brutas no período da fonte de negócio.")
    if _num(ads.get("spend")) is not None:
        parts.append(f"Em Ads, o investimento foi de {_fmt(ads['spend'], 'BRL')} no período publicitário.")
    if _num(ads.get("revenue")) is not None:
        parts.append(f"A receita atribuída a Ads foi de {_fmt(ads['revenue'], 'BRL')}.")
    parts.append("As prioridades abaixo partem dos dados importados; valide custos, hipóteses e período antes de alterar a operação." if parts else "Complete os dados de conta, Ads e custos para sustentar prioridades e metas numéricas. Os textos e encaminhamentos permanecem editáveis.")
    count = len((report.get('ads') or {}).get('campaigns', []))
    if count: parts.append(f"Todas as {count} campanhas têm direcionamento individual. As prioridades e o investimento ordenam a leitura, sem excluir campanhas.")
    return {"headline": "Transformar os achados em um plano de execução", "body": " ".join(parts)}


def enrich_report(report, force=False):
    """Return a copy, preserving manual edits (including intentionally empty arrays).

    force=True regenerates summary, cards and charts; sections and source data are
    always retained. A missing type defaults to performance for legacy reports.
    """
    result = copy.deepcopy(report)
    if is_market_report(result): result['reportType']='market'
    if result.get("reportType") not in ("reputation", "performance", "market"):
        result["reportType"] = "performance"
    for key, build in (("summary", lambda: _summary(result)),
                       ("actionCards", lambda: _reputation_cards() if result["reportType"] == "reputation" else [] if result['reportType']=='market' else _performance_cards(result)),
                       ("charts", lambda: [] if result['reportType']=='market' else _charts(result))):
        if force or key not in result:
            result[key] = build()
    return result


def upgrade_performance_report(report, refreshed_ads=None):
    """Expand a legacy performance report without replacing reviewed content.

    Pure function: the caller recalculates Ads from its original spreadsheet and
    saves the returned copy through storage (which owns backup/version handling).
    Existing card text, step state, images, ordering and manual charts survive.
    Only unchanged generated sections/metrics are refreshed. Generated Ads
    charts keep presentation edits while receiving all campaign data. The
    campaignCoverage object describes the upgrade; no network or file I/O occurs.
    """
    if is_market_report(report) or report.get('reportType') == 'reputation':
        raise ValueError('A atualização de campanhas só se aplica a relatórios de performance.')
    result = copy.deepcopy(report)
    old_ads = copy.deepcopy(report.get('ads') or {})
    if refreshed_ads is not None:
        old_hash = (old_ads.get('provenance') or {}).get('sha256')
        new_hash = (refreshed_ads.get('provenance') or {}).get('sha256')
        if old_hash and new_hash and old_hash != new_hash:
            raise ValueError('A atualização deve usar a mesma planilha de origem do relatório.')
        result['ads'] = copy.deepcopy(refreshed_ads)
        # Editable headline values and prose are not replaced if they differ
        # from the previous generated baseline stored under report.ads.
        metrics = result.setdefault('metrics', {})
        for key, value in (refreshed_ads.get('metrics') or {}).items():
            if key not in metrics or metrics[key] == (old_ads.get('metrics') or {}).get(key):
                metrics[key] = copy.deepcopy(value)
        old_sections = {s['id']: s for s in old_ads.get('sections', [])}
        new_sections = {s['id']: s for s in refreshed_ads.get('sections', [])}
        for section in result.get('sections', []):
            old, new = old_sections.get(section.get('id')), new_sections.get(section.get('id'))
            if old and new:
                for key in ('title', 'body'):
                    if section.get(key) == old.get(key):
                        section[key] = copy.deepcopy(new.get(key, ''))
        old_warnings = old_ads.get('warnings') or []
        warnings = [w for w in result.get('warnings', []) if w not in old_warnings]
        for warning in refreshed_ads.get('warnings', []):
            if warning not in warnings: warnings.append(copy.deepcopy(warning))
        result['warnings'] = warnings
    result['reportType'] = 'performance'
    result['showDetails'] = False
    cards = result.setdefault('actionCards', [])
    generated = [c for c in _performance_cards(result) if c.get('campaignName')]
    added, covered = [], []
    for fresh in generated:
        name, key = fresh['campaignName'], fresh['campaignKey']
        legacy_ids = {_id(prefix, name) for prefix in ('margin', 'no-sales', 'roas', 'scale', 'monitor')}
        matches = [c for c in cards if c.get('campaignKey') == key or c.get('campaignName') == name or c.get('id') in legacy_ids]
        if matches:
            for card in matches:
                card.setdefault('campaignName', name)
                card.setdefault('campaignKey', key)
                card.setdefault('source', fresh['source'])
        else:
            cards.append(fresh)
            added.append(fresh['id'])
        covered.append(name)
    charts = result.setdefault('charts', [])
    updated = []
    old_caption = re.compile(r'Valores do período por campanha\. Receita atribuída não representa lucro\. Exibidas as \d+ campanhas de maior investimento; \d+ outras não aparecem neste gráfico\.')
    for fresh in _charts(result):
        if fresh['id'] not in ('ads-value', 'ads-return'): continue
        matches = [c for c in charts if c.get('id') == fresh['id']]
        if not matches:
            charts.append(fresh)
        for chart in matches:
            old_labels = chart.get('labels') or []
            old_series = chart.get('series') or []
            series = []
            for index, new_series in enumerate(fresh['series']):
                item = copy.deepcopy(old_series[index] if index < len(old_series) else new_series)
                item['values'] = copy.deepcopy(new_series['values'])
                series.append(item)
            # Preserve any additional manually added series. Missing new-label
            # observations remain null rather than copying a different campaign.
            for old_series_item in old_series[len(fresh['series']):]:
                item = copy.deepcopy(old_series_item)
                values = dict(zip(old_labels, item.get('values') or []))
                item['values'] = [values.get(label) for label in fresh['labels']]
                series.append(item)
            chart['labels'], chart['series'] = copy.deepcopy(fresh['labels']), series
            chart['source'] = fresh['source']
            if not chart.get('caption') or old_caption.fullmatch(chart['caption']):
                chart['caption'] = fresh['caption']
        updated.append(fresh['id'])
    result['campaignCoverage'] = {
        'version': 1, 'totalCampaigns': len((result.get('ads') or {}).get('campaigns', [])),
        'coveredCampaigns': len(covered), 'addedCardIds': added, 'updatedChartIds': updated,
        'preservedExistingCards': len(report.get('actionCards') or []),
        'note': 'Todas as campanhas têm direcionamento. Cards existentes e textos revisados foram preservados; campanhas ausentes foram acrescentadas.'}
    # Replace only the known obsolete generated suffix, never regenerate a
    # specialist's summary. Keeping this exact six-card claim would contradict
    # the explicitly requested expansion to every campaign.
    summary = result.get('summary') or {}
    old_suffix = ('O plano visual resume até seis ações. Dentro das revisões de campanhas, '
                  'o maior investimento recebe precedência; demais achados permanecem no detalhamento.')
    body = summary.get('body', '')
    if isinstance(body, str) and body.endswith(old_suffix):
        summary['body'] = body[:-len(old_suffix)] + f'Todas as {len(covered)} campanhas têm direcionamento individual. Os cards existentes foram preservados e as campanhas ausentes foram acrescentadas.'
    return result


ACTION_VERBS = r"(?:criar|revisar|verificar|conferir|enviar|preencher|completar|corrigir|atualizar|separar|selecionar|registrar|acompanhar|monitorar|responder|preparar|fotografar|gravar|publicar|analisar|comparar|calcular|definir|organizar|habilitar|configurar|avaliar|agendar|validar|solicitar|ajustar|testar|importar|baixar|incluir|fazer|entregar|adicionar|providenciar)"


def extract_meeting_actions(text):
    """Find explicit Portuguese action phrases, never infer a meeting decision.

    Exact quotes are retained. Speaker labels are not automatically responsible
    parties; only first-person commitments or explicit assignments name an owner.
    Relative dates stay verbatim because no meeting date/timezone is assumed.
    """
    raw = str(text or "")
    warnings = ["Extração local por regras: revise os trechos antes de tratá-los como decisões ou compromissos. Ações implícitas podem não ser detectadas."]
    if len(raw) > 500000:
        raw = raw[:500000]
        warnings.append("Texto limitado aos primeiros 500.000 caracteres para extração; revise o restante da transcrição.")
    actions, seen = [], set()
    for line in raw.splitlines():
        for quote in re.split(r"(?<=[.!?])\s+(?=[A-ZÀ-Ý])", line.strip()):
            quote = quote.strip()
            if not quote:
                continue
            body = re.sub(r"^\[?\d{1,2}:\d{2}(?::\d{2})?\]?\s*[-–]?\s*", "", quote)
            body = re.sub(r"^\s*(?:[-*•]|\d+[.)])\s*", "", body)
            speaker = None
            label = re.match(r"^([^:;.!?]{1,70}):\s*(.+)$", body)
            if label and _normal(label[1]) not in ("acao", "tarefa", "combinado", "encaminhamento"):
                speaker, body = label[1].strip(), label[2]
            body = re.sub(r"^(?:Ação|Acao|Tarefa|Combinado|Encaminhamento):\s*", "", body, flags=re.I)
            normal = _normal(body)
            if "?" in body or re.search(r"\b(?:nao|talvez|poderia|poderiamos|hipotese|se|sugestao)\b", normal):
                continue
            first_person = re.match(rf"^(?:eu\s+)?vou\s+{ACTION_VERBS}\b", normal)
            named_owner = r"[A-ZÀ-Ý][A-Za-zÀ-ÿ]+(?:\s+(?:(?:da|de|do|das|dos)\s+)?[A-ZÀ-Ý][A-Za-zÀ-ÿ]+){0,5}"
            assignment = re.match(rf"^({named_owner}|(?:[OoAa]\s+)?(?:cliente|especialista|equipe))\s+(?i:(?:vai|deverá|devera|ficou de)\s+({ACTION_VERBS}))\b", body)
            direct = re.match(rf"^(?:{ACTION_VERBS}\b|(?:vamos|precisamos)\s+{ACTION_VERBS}\b|(?:ficou combinado|combinamos)\s+(?:que\s+)?{ACTION_VERBS}\b)", normal)
            if not (first_person or assignment or direct):
                continue
            if len(body.split()) < 3 or body in seen:
                continue
            seen.add(body)
            action = {"quote": quote, "text": body}
            explicit_owner = re.search(r"\bRespons[aá]vel\s*:\s*([^;.!?]+?)(?=\s+(?:Prazo|Data)\s*:|[;.!?]|$)", quote, re.I)
            if explicit_owner:
                action["owner"] = explicit_owner[1].strip()
            elif first_person and speaker:
                action["owner"] = speaker
            elif assignment and _normal(assignment[1]) not in ("ele", "ela", "a gente", "conta", "campanha", "anuncio", "produto"):
                action["owner"] = assignment[1].strip()
            due = re.search(r"\b(?:Prazo|Data)\s*:\s*([^;.!?]+)", quote, re.I)
            if due and _normal(due[1].strip()) not in ("a definir", "nao definido", "pendente"):
                action["due"] = due[1].strip()
            else:
                date_value = r"(?:\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}(?:/\d{2,4})?)"
                weekday = r"(?:(?:segunda|ter[cç]a|quarta|quinta|sexta)(?:-feira)?|s[aá]bado|domingo)"
                due = re.search(rf"\bat[eé]\s+(?:(?:o|a)\s+)?(?:dia\s+)?(?:{date_value}|{weekday}|amanh[ãa]|hoje)\b|\b(?:no dia|para)\s+{date_value}\b|\b(?:na|no)\s+{weekday}\b|\b(?:amanh[ãa]|hoje)\b|\bem\s+\d+\s+dias\b", body, re.I)
                if due:
                    action["due"] = due[0]
            actions.append(action)
    if len(actions) > 20:
        actions = actions[:20]
        warnings.append("Exibidas as primeiras 20 ações explícitas; revise os demais encaminhamentos na transcrição.")
    if not actions:
        warnings.append("Nenhuma frase de ação explícita reconhecida. Inclua encaminhamentos manualmente ou use frases como 'Ação: revisar as fotos'.")
    if any("due" in action for action in actions):
        warnings.append("Prazos mantidos como foram escritos; datas relativas não foram convertidas em datas de calendário.")
    excerpt = raw.strip()[:600]
    summary = "Trecho inicial da transcrição (sem resumo semântico):\n" + excerpt + ("…" if len(raw.strip()) > 600 else "") if excerpt else "Transcrição vazia."
    return {"summary": summary, "actions": actions, "warnings": warnings}
