"""Short operational review for the market workspace, separate from financial proof.

Attention is a review queue, not automatic approval. Historical Hub opinions
never replace the new calculation or confirm fees/identity implicitly.
"""
from copy import deepcopy
import math

LABELS = {'validado':'Validado','atencao':'Atenção','invalidado':'Invalidado',
          'nao_concluido':'Não concluído','nao_correspondente':'Não correspondente'}
MAP = {'viable':'validado','adjust':'atencao','invalid':'invalidado',
       'insufficient':'nao_concluido','not_matching':'nao_correspondente'}
AUTOMATIC_MESSAGE_LIMIT = 1000


def _number(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)


def _fmt(value, money=False):
    if not _number(value): return 'não informado'
    text=f'{value:,.2f}'.replace(',','_').replace('.',',').replace('_','.')
    return 'R$ '+text if money else text.rstrip('0').rstrip(',')


def _pack_messages(parts):
    """Keep complete, priority-ranked statements; never slice an unfinished phrase.

    Parts stay in their reading order. A lower rank reserves space first, so
    optional context cannot displace a financial caveat or a critical pending item.
    """
    chosen = {}
    size = 0
    for index, (priority, text) in sorted(enumerate(parts), key=lambda part: (part[1][0], part[0])):
        text = ' '.join(str(text or '').split())
        if not text:
            continue
        if text[-1] not in '.!?':
            text += '.'
        extra = len(text) + bool(chosen)
        if size + extra <= AUTOMATIC_MESSAGE_LIMIT:
            chosen[index] = text
            size += extra
    return ' '.join(chosen[index] for index in sorted(chosen))


def _critical_pending(entry):
    analysis = entry.get('analysis') or {}
    financial = analysis.get('financial') or {}
    market = analysis.get('market') or {}
    reference = (entry.get('evidence') or {}).get('reference') or {}
    checks = {item.get('id'): item for item in analysis.get('checklist') or [] if isinstance(item, dict)}
    pending = []
    # Workflow keeps raw provider evidence immutable and applies the user's
    # identity confirmation only to the calculation. Use that calculation's
    # checklist, otherwise a confirmed product would still appear pending.
    identity_ok = checks['identity'].get('status') == 'complete' if 'identity' in checks else (
        reference.get('referenceValidated') is True and reference.get('identityValidated') is True)
    if not identity_ok:
        pending.append('a identidade exata do produto')
    if not financial.get('complete'):
        pending.append('taxas, frete e demais custos aplicáveis')
    if not market.get('competitorCount'):
        pending.append('concorrentes idênticos com preços atuais')
    if market.get('periodComplete') is not True or market.get('unitsTotal') is None:
        pending.append('vendas em período comparável')
    if checks.get('logistics', {}).get('status') == 'missing':
        pending.append('a modalidade logística')
    return 'Antes de validar, confirme '+', '.join(pending)+'.' if pending else ''


def _automatic_message(entry, status, observed, commercial):
    analysis = entry.get('analysis') or {}
    financial, market = analysis.get('financial') or {}, analysis.get('market') or {}
    inventory, pricing = analysis.get('inventory') or {}, analysis.get('pricing') or {}
    comparison, inputs = analysis.get('comparison') or {}, entry.get('inputs') or {}
    parts = []
    if status == 'nao_concluido':
        parts.append((0, 'Não concluído: '+('confira a referência e conclua a consulta antes de decidir.' if not observed else 'complete o custo de compra e o preço de venda antes de decidir.')))
    elif status == 'invalidado':
        parts.append((0, 'Invalidado neste cenário: o preço não supera os custos conhecidos. Reveja o custo de compra ou o preço antes de aprovar.'))
    elif status == 'validado':
        parts.append((0, 'Validado no cenário informado: margem, preço e vendas observadas atendem aos critérios configurados.'))
    else:
        parts.append((0, 'Atenção: revise as pendências e os critérios deste cenário antes de aprovar a compra.'))

    profit, margin = financial.get('profit'), financial.get('marginPercent')
    if _number(profit) and financial.get('complete'):
        parts.append((1, 'Lucro unitário '+('estimado ' if financial.get('estimated') else '')+'de '+_fmt(profit, True)+
                      (' e margem de '+_fmt(margin)+'% sobre a venda' if _number(margin) else '')+
                      ', no escopo dos custos confirmados.'))
    elif commercial and _number(profit):
        parts.append((1, 'Saldo máximo antes dos custos pendentes: '+_fmt(profit, True)+'. Esse valor ainda não é lucro líquido.'))
    if financial.get('estimated') and _number(financial.get('commissionPercent')):
        parts.append((2, 'Comissão estimada pela tabela oficial do Mercado Livre: '+_fmt(financial['commissionPercent'])+'%'+
                      (' e frete estimado de '+_fmt(financial['shipping'], True) if _number(financial.get('shipping')) else '')+'.'))

    average, count = market.get('priceAverage'), market.get('competitorCount')
    if commercial and _number(average) and average > 0 and _number(count) and count > 0:
        premium = comparison.get('premiumPercent')
        relative = ''
        if _number(premium):
            relative = ('; '+_fmt(abs(premium))+'% '+('acima' if premium > 0 else 'abaixo')+' da média' if premium else '; igual à média')
        parts.append((3, 'Preço pretendido: '+_fmt(inputs['salePrice'], True)+'; média de '+_fmt(count)+' concorrente(s) confirmado(s): '+_fmt(average, True)+relative+'.'))

    target = pricing.get('desiredMarginPercent')
    if _number(target) and _number(margin) and financial.get('complete') and margin < target:
        parts.append((2, 'A margem fica abaixo da meta informada de '+_fmt(target)+'%; revise custos ou preço.'))

    purchase, sales = inventory.get('purchaseQuantity'), inventory.get('salesQuantity')
    investment = inventory.get('stockInvestment')
    if _number(purchase) and _number(investment):
        parts.append((4, 'Compra informada: '+_fmt(purchase)+' unidade(s), com '+_fmt(investment, True)+' destinados à aquisição do estoque.'))
        projected, roi = inventory.get('projectedProfit'), inventory.get('roiPercent')
        if financial.get('complete') and not inventory.get('profitIsUpperBound') and not inventory.get('salesExceedPurchase') and _number(sales) and _number(projected):
            parts.append((4, 'Se vender as '+_fmt(sales)+' unidade(s) informadas, o lucro no cenário será '+_fmt(projected, True)+
                          (' e o ROI sobre o custo de compra do lote, '+_fmt(roi)+'%' if _number(roi) else '')+
                          '; isso não garante vendas.'))
        elif inventory.get('salesExceedPurchase'):
            parts.append((2, 'A venda pretendida excede a compra; confirme estoque ou reposição antes de assumir o retorno.'))

    pending = _critical_pending(entry)
    if pending:
        parts.append((2, pending))
    elif status == 'atencao':
        reasons = (analysis.get('verdict') or {}).get('calculated', {}).get('reasons') or []
        # A single original rule explanation is useful when all evidence is
        # complete. An oversized explanation is omitted whole, never clipped.
        reason = next((reason for reason in reasons if isinstance(reason, str) and len(reason.strip()) <= 220), None)
        parts.append((5, reason or 'Confira os critérios sinalizados nos detalhes antes de validar.'))

    observed_days = market.get('observedDays')
    if _number(observed_days) and market.get('windowComplete') is False:
        window = market.get('requestedWindowDays')
        if _number(window) and window > 0:
            parts.append((3, 'A comparação cobre '+_fmt(observed_days)+' dos '+_fmt(window)+' dias solicitados; não representa todo o período.'))

    if commercial:
        parts.append((6, 'Custo de compra: '+_fmt(inputs['cost'], True)+'; venda pretendida: '+_fmt(inputs['salePrice'], True)+'.'))
    if status == 'validado' and not any('não garante vendas' in text for _, text in parts):
        parts.append((2, 'A avaliação não garante vendas nem o lucro de toda a operação.'))
    return _pack_messages(parts)


def decision_for(entry):
    analysis=entry.get('analysis') or {}
    verdict=analysis.get('verdict') or {}
    calc=verdict.get('calculated') or {}
    reference=(entry.get('evidence') or {}).get('reference') or {}
    inputs=entry.get('inputs') or {}
    observed=reference.get('referenceValidated') is True
    commercial=all(_number(inputs.get(k)) for k in ('cost','salePrice'))
    status=MAP.get(calc.get('status'),'nao_concluido')
    # An incomplete unit evaluation is useful triage once a reference and the
    # commercial scenario exist. It is never silently promoted to "Validado".
    if status=='nao_concluido' and observed and commercial:
        status='atencao'
    reasons=list(calc.get('reasons') or [])
    calculated={'status':status,'label':LABELS[status],
                'message':_automatic_message(entry,status,observed,commercial)}
    result={**calculated,'source':'local_rules','preliminary':calc.get('status')=='insufficient',
            'reasons':reasons,'calculated':deepcopy(calculated),'specialistOverride':False}
    override=verdict.get('override')
    if override:
        chosen=MAP.get(override.get('status'),'nao_concluido')
        # Only the automatic copy has a 1,000-character budget. Prefer the
        # original reviewed text when the engine's validated override is present.
        original=((entry.get('review') or {}).get('override') or {})
        reason=original.get('reason') if original.get('status')==override.get('status') and str(original.get('reason') or '').strip() else override.get('reason')
        result.update(status=chosen,label=LABELS[chosen],message=str(reason or ''),
                      source='specialist_review',specialistOverride=True,preliminary=False)
    return result
