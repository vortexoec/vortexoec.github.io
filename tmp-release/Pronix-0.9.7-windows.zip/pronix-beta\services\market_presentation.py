"""Shared 16-section market narrative and print layouts from saved calculations.

No recalculation, downloads, or model calls occur during rendering. Local cached
imageId assets are embedded; uncached images remain ordinary source links.
"""
from __future__ import annotations

import html
import math
import re

from . import assets
from .report_schema import safe_link


TITLES = ("Produto identificado", "Anúncios idênticos", "Imagens e links dos anúncios",
          "Diagnóstico rápido de viabilidade", "Categoria e subcategoria", "Taxas e custos aplicáveis",
          "Métricas do mercado", "Dados do cliente", "Investimento", "Preço necessário para atingir a margem",
          "Comparação com concorrentes", "Cenários alternativos de margem", "Análise financeira",
          "Análise de demanda e estoque", "Resumo executivo", "Parecer final")
MISSING = "Não disponível"
KPI_COLORS = (("#EAF6EF", "#CFE7D9", "#1D6946"), ("#F0ECFF", "#DDD4F7", "#6144B0"),
              ("#EAF2FF", "#D0DFF5", "#315C9C"))
VERDICT_COLORS = {"viable": ("#EAF6EF", "#CFE7D9", "#1D6946"),
                  "adjust": ("#FFF5DF", "#EAD7A8", "#825D13"),
                  "invalid": ("#FFF0EE", "#EECBC5", "#994B42"),
                  "insufficient": ("#F0ECFF", "#DDD4F7", "#6144B0")}


def fmt(value, unit="", decimals=2):
    if value is None or value == "":
        return MISSING
    if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value):
        return str(value)
    if abs(value) >= 1e12:
        text = f"{value:.3e}"
    else:
        if unit == "number" and float(value).is_integer():
            decimals = 0
        text = f"{value:,.{decimals}f}".replace(",", "_").replace(".", ",").replace("_", ".")
    return "R$ " + text if unit == "BRL" else text + "%" if unit == "percent" else text


def _text(value):
    return str(value) if value not in (None, "") else MISSING


def _period(data):
    start, end = data.get("periodStart"), data.get("periodEnd")
    return f"{start} a {end}" if start and end else "Período não disponível"


def _rows(pairs):
    return [[label, str(value)] for label, value in pairs]


def products(report):
    envelope = report.get("marketAnalysis") or {}
    return envelope.get("products") or [] if isinstance(envelope, dict) else []


def has_market(report):
    return bool(products(report))


def detail_sections(report):
    return [section for section in report.get("sections", [])
            if not (has_market(report) and section.get("id") == "market-analysis")]


def _entry(entry):
    analysis = entry.get("analysis") or {}
    source = entry.get("source") or analysis.get("product") or {}
    inputs = entry.get("inputs") or analysis.get("inputs") or {}
    evidence = entry.get("evidence") or {}
    return analysis, source, inputs, evidence, entry.get("review") or {}


def _offers(entry):
    analysis, _, _, evidence, _ = _entry(entry)
    accepted = (analysis.get("market") or {}).get("competitors") or []
    candidates = list(evidence.get("competitors") or []) + list(evidence.get("candidates") or [])
    original = {str(row.get("id") or row.get("itemId") or ""): row for row in candidates if isinstance(row, dict)}
    merged = [{**original.get(str(row.get("id")), {}), **row} for row in accepted]
    seen = {str(row.get("id")) for row in accepted}
    pending = []
    for row in candidates:
        if not isinstance(row, dict):
            continue
        identity = str(row.get("id") or row.get("itemId") or "")
        if identity not in seen:
            seen.add(identity)
            pending.append(row)
    return merged, pending


def _images(rows, pending=False):
    result = []
    for row in rows:
        image_id = row.get("imageId")
        if isinstance(image_id, str) and re.fullmatch(r"[a-f0-9]{32}", image_id):
            caption = ("Candidato — equivalência pendente (fora das métricas). " if pending else "")
            caption += str(row.get("title") or row.get("id") or "Anúncio")
            result.append({"id": image_id, "caption": caption,
                           "url": row.get("url") or row.get("meliUrl") or ""})
            if len(result) == 5:
                break
    return result


def _kpis(entry):
    analysis, _, inputs, _, _ = _entry(entry)
    financial = analysis.get("financial") or {}
    return [("Custo unitário", fmt(inputs.get("cost"), "BRL")),
            ("Preço pretendido", fmt(inputs.get("salePrice"), "BRL")),
            ("Saldo unitário parcial" if financial.get("upperBound") else "Lucro unitário",
             fmt(financial.get("profit"), "BRL"))]


def sections_for_product(entry, context=None):
    """Return the same 16 ordered sections for TXT, HTML, and PDF.

    Each section has index/title/body and optional table{headers,rows}, links,
    images and tone. Stored specialist summary/notes are preserved verbatim.
    """
    context = context or {}
    analysis, source, inputs, evidence, review = _entry(entry)
    reference = evidence.get("reference") or {}
    market, financial = analysis.get("market") or {}, analysis.get("financial") or {}
    pricing, inventory = analysis.get("pricing") or {}, analysis.get("inventory") or {}
    verdict = analysis.get("verdict") or {}
    calculated, final = verdict.get("calculated") or {}, verdict.get("final") or {}
    final = final or calculated
    fees = entry.get("fees") or evidence.get("fees") or {}
    accepted, pending = _offers(entry)
    sections = [{"index": i, "title": title, "body": ""} for i, title in enumerate(TITLES, 1)]
    def body(index, *parts):
        sections[index-1]["body"] = "\n".join(str(part) for part in parts if part not in (None, ""))
    def table(index, headers, rows):
        if rows:
            sections[index-1]["table"] = {"headers": headers, "rows": rows}
    name = source.get("name") or entry.get("name") or reference.get("title") or "Produto"
    body(1, name, "Identificação na fonte: " + _text(reference.get("title")),
         "Código: " + _text(reference.get("id")) + " | Marca: " + _text(reference.get("brand")),
         "Identidade exata: " + ("confirmada na revisão" if review.get("referenceIdentityConfirmed") is True or reference.get("identityValidated") is True else "pendente de confirmação de modelo, variação e kit"))
    source_url = source.get("reference") or entry.get("reference") or reference.get("url")
    sections[0]["links"] = [{"label": "Referência do produto", "url": source_url}] if source_url else []
    body(2, f"{len(accepted)} oferta(s) idêntica(s), ativa(s) e atual(is) usada(s) nos cálculos. A amostra não foi completada com produtos semelhantes.")
    table(2, ["Anúncio", "Preço", "Unidades*", "Faturamento*", "Período"],
          [[str(row.get("title") or row.get("id")), fmt(row.get("price"), "BRL"),
            fmt((row.get("metrics") or {}).get("units"), "number"), fmt((row.get("metrics") or {}).get("revenue"), "BRL"),
            _period(row.get("metrics") or {})] for row in accepted])
    if pending:
        excluded_reasons = {str(row.get("id")): row.get("reason") for row in market.get("excluded", [])}
        body(2, sections[1]["body"], "Candidatos fora dos cálculos (equivalência/condições ainda pendentes ou oferta excluída):",
             *[f"- {row.get('title') or row.get('id')}: {fmt(row.get('price'), 'BRL')} | código {_text(row.get('id'))}. " +
               str(excluded_reasons.get(str(row.get('id'))) or 'Revisão das condições pendente.') for row in pending])
    displayed = [(row, True) for row in accepted] + [(row, False) for row in pending]
    sections[2]["images"] = _images(accepted) if accepted else _images(pending, pending=True)
    links = []
    for row, confirmed in displayed:
        identity = str(row.get("id") or row.get("itemId") or "")
        url = row.get("url") or row.get("meliUrl")
        if url:
            links.append({"label": ("Anúncio confirmado " if confirmed else "Candidato fora dos cálculos ") + identity, "url": url})
        if row.get("imageUrl") and not row.get("imageId"):
            links.append({"label": "Imagem na fonte " + identity + " (não incorporada)", "url": row["imageUrl"]})
    sections[2]["links"] = links
    body(3, ("As imagens incorporadas são cópias locais das ofertas confirmadas; abra os links para conferir características e condições." if accepted else
             "Fotos dos candidatos para revisão. A equivalência de modelo, variação e kit ainda está pendente; estes anúncios estão fora das métricas.") if sections[2]["images"] else
         "Nenhuma imagem local disponível para este produto. Os links disponíveis permanecem para conferência; a exportação não baixa imagens.")
    body(4, _text(calculated.get("label")), *(calculated.get("reasons") or ["Cálculos ainda não disponíveis."])[:2])
    sections[3]["tone"] = calculated.get("status", "insufficient")
    sections[3]["calloutLabel"] = "Parecer calculado: " + _text(calculated.get("label"))
    body(5, "Categoria: " + _text(reference.get("categoryName") or reference.get("categoryId")),
         "Tipo de anúncio: " + _text(reference.get("listingType")),
         "Condições e fonte das taxas: " + _text(fees.get("source")))
    category_path = reference.get("categoryPath")
    if isinstance(category_path, list) and category_path:
        body(5, sections[4]["body"], "Caminho da categoria: " + " > ".join(str(value) for value in category_path if value))
    if reference.get("categoryName") and reference.get("categoryId"):
        body(5, sections[4]["body"], "Código da categoria: " + str(reference["categoryId"]))
    table(6, ["Componente unitário", "Valor considerado"], _rows([
        ("Comissão", fmt(financial.get("commissionPercent"), "percent") + " / " + fmt(financial.get("commissionAmount"), "BRL")),
        ("Tarifa fixa", fmt(financial.get("fixedFee"), "BRL")), ("Imposto do CNPJ", fmt(financial.get("taxPercent"), "percent") + " / " + fmt(financial.get("taxAmount"), "BRL")),
        ("Logística suportada pelo vendedor", fmt(financial.get("shipping"), "BRL")), ("Outros custos", fmt(financial.get("otherCosts"), "BRL"))]))
    body(6, "Preço da cotação: " + fmt(fees.get("quotedPrice"), "BRL"), analysis.get("logisticsExplanation"),
         "Faixa declarada: " + fmt(fees.get("validPriceMin"), "BRL") + " a " + fmt(fees.get("validPriceMax"), "BRL") if fees.get("validPriceMin") is not None else "")
    table(7, ["Métrica da amostra", "Valor"], _rows([
        ("Menor / maior preço", fmt(market.get("priceMin"), "BRL") + " / " + fmt(market.get("priceMax"), "BRL")),
        ("Preço médio", fmt(market.get("priceAverage"), "BRL")),
        ("Unidades totais / média por anúncio*", fmt(market.get("unitsTotal"), "number") + " / " + fmt(market.get("unitsAverage"), "number")),
        ("Faturamento total / médio por anúncio*", fmt(market.get("revenueTotal"), "BRL") + " / " + fmt(market.get("revenueAverage"), "BRL")),
        ("Vendas / faturamento por dia da amostra*", fmt(market.get("unitsPerDay"), "number") + " / " + fmt(market.get("revenuePerDay"), "BRL")),
        ("Exposição média do anúncio", fmt(market.get("exposureDaysAverage"), "number") + (" dias" if market.get("exposureDaysAverage") is not None else ""))]))
    requested_days = market.get("requestedWindowDays")
    requested_window = (str(market.get("windowStart")) + " a " + str(market.get("windowEnd"))) if market.get("windowStart") and market.get("windowEnd") else "datas não disponíveis"
    observed_days = market.get("observedDays")
    coverage = (fmt(observed_days, "number") + " de " + fmt(requested_days, "number") + " dias; " + fmt(market.get("coveragePercent"), "percent")) if observed_days is not None else "ainda não disponível para a amostra de concorrentes"
    body(7, "Janela principal solicitada: " + fmt(requested_days, "number") + " dias (" + requested_window + ").",
         "Intervalo comum efetivamente observado: " + _period(market), "Cobertura temporal: " + coverage + ".",
         "A janela solicitada está integralmente coberta." if market.get("windowComplete") else "Cobertura parcial ou ausente: dias sem dados não foram tratados como zero nem estimados por rateio.",
         "Atualidade de preços e ofertas: conferência separada, com recência de até 30 dias.",
         "* Estimativas da fonte, não transações confirmadas. " + str(market.get("dailyScope") or ""))
    ref_metrics = market.get("referenceMetrics") or {}
    if ref_metrics.get("units") is not None or ref_metrics.get("revenue") is not None:
        body(7, sections[6]["body"], "Referência única, em escopo separado: " + _period(ref_metrics) + "; unidades " + fmt(ref_metrics.get("units"), "number") +
             "; faturamento " + fmt(ref_metrics.get("revenue"), "BRL") + ". Não adicionada novamente ao total de concorrentes.",
             "Cobertura temporal da referência: " + fmt(ref_metrics.get("observedDays"), "number") + " de " + fmt(ref_metrics.get("requestedWindowDays"), "number") +
             " dias (" + fmt(ref_metrics.get("coveragePercent"), "percent") + "). " + ("Janela integral." if ref_metrics.get("windowComplete") else "Janela parcial; sem extrapolar vendas para os 120 dias."),
             "A referência ainda depende da confirmação de identidade/equivalência e não valida automaticamente uma amostra de concorrentes." if not (reference.get("identityValidated") is True or review.get("referenceIdentityConfirmed") is True) else "")
        trend = ref_metrics.get("trend") or {}
        if trend.get("available"):
            previous, latest = trend.get("previous") or {}, trend.get("latest") or {}
            body(7, sections[6]["body"], "Comparação pontual do faturamento da referência: " + _period(previous) + " = " + fmt(previous.get("revenue"), "BRL") +
                 "; " + _period(latest) + " = " + fmt(latest.get("revenue"), "BRL") + ". Variação: " + fmt(trend.get("revenueChange"), "BRL") +
                 (" (" + fmt(trend.get("revenueChangePercent"), "percent") + ")." if trend.get("revenueChangePercent") is not None else "; variação percentual não calculável com base zero."), trend.get("note"))
    historical = reference.get("historicalAverages")
    if isinstance(historical, dict) and historical.get("basis") == "creation_date_average" and historical.get("periodSpecific") is False:
        monthly_lines = []
        for scope, label in (("item", "Anúncio de referência"), ("catalog", "Catálogo da referência, em escopo separado")):
            group = historical.get(scope)
            month = group.get("month") if isinstance(group, dict) else None
            if isinstance(month, dict) and (month.get("units") is not None or month.get("revenue") is not None):
                monthly_lines.append(label + " — média mensal histórica: " + fmt(month.get("units"), "number") +
                                     " unidades; faturamento " + fmt(month.get("revenue"), "BRL") + ".")
        if monthly_lines:
            body(7, sections[6]["body"], "Contexto histórico da referência (fonte JoomPulse):", *monthly_lines,
                 "Médias calculadas pela fonte com base na data de criação. Não são vendas observadas nos 120 dias; não foram multiplicadas para completar a janela nem somadas entre anúncio e catálogo.")
    body(8, "Custo unitário: " + fmt(inputs.get("cost"), "BRL") + " | Preço pretendido: " + fmt(inputs.get("salePrice"), "BRL"),
         "Comprar: " + fmt(inputs.get("purchaseQuantity"), "number") + " | Vender: " + fmt(inputs.get("salesQuantity"), "number") + " | Meta: " + fmt(inputs.get("desiredMarginPercent"), "percent"),
         "Operação: " + _text(context.get("logistics")) + " | " + _text(context.get("cityState")) + " | Imposto: " + fmt(context.get("taxPercent"), "percent"))
    original_fields = source.get("fields") or {}
    if original_fields:
        body(8, sections[7]["body"], "Campos originais do documento: " + "; ".join(str(label) + ": " + _text(value) for label, value in original_fields.items()))
    body(9, "Investimento em compra de estoque: " + fmt(inventory.get("stockInvestment"), "BRL"), inventory.get("note"))
    body(10, "Meta informada: " + fmt(pricing.get("desiredMarginPercent"), "percent") + " | Preço necessário: " + fmt(pricing.get("requiredPrice"), "BRL"),
         "Preço condicional: revalidar tarifas e logística na nova faixa." if pricing.get("requiredPrice") is not None and pricing.get("conditional") else "",
         pricing.get("formula"), "Pendências: " + "; ".join(pricing.get("missing") or []) if pricing.get("missing") else "")
    comparison = analysis.get("comparison") or {}
    body(11, "Preço pretendido: " + fmt(inputs.get("salePrice"), "BRL") + " | Média da amostra: " + fmt(market.get("priceAverage"), "BRL"),
         "Diferença relativa: " + fmt(comparison.get("premiumPercent"), "percent") + " | Tolerância configurada: " + fmt(comparison.get("maxPricePremiumPercent"), "percent"),
         (analysis.get("policy") or {}).get("explanation"))
    scenarios = pricing.get("scenarios") or []
    table(12, ["Margem", "Preço calculado", "Versus média", "Condição"],
          [[fmt(row.get("marginPercent"), "percent"), fmt(row.get("price"), "BRL"), fmt(row.get("comparisonPercent"), "percent"),
            ("Meta" if row.get("kind") == "desired" else "Alternativa") + (" / revalidar custos" if row.get("conditional") else " / faixa declarada")]
           for row in scenarios])
    body(12, pricing.get("note"), *[row.get("note") for row in scenarios if row.get("price") is None],
         "Nenhum cenário adicional foi calculado sem margens e custos informados." if not scenarios else "")
    partial = " (teto parcial)" if financial.get("upperBound") else ""
    table(13, ["Resultado", "Valor"], _rows([
        ("Custos conhecidos por unidade", fmt(financial.get("knownCosts"), "BRL")),
        ("Recebimento após taxas/logística, antes da compra" + partial, fmt(financial.get("netProceeds"), "BRL")),
        ("Lucro unitário" + partial, fmt(financial.get("profit"), "BRL")),
        ("Margem unitária" + partial, fmt(financial.get("marginPercent"), "percent")),
        ("Faturamento do cenário informado", fmt(inventory.get("projectedRevenue"), "BRL")),
        ("Lucro do cenário" + partial, fmt(inventory.get("projectedProfit"), "BRL")),
        ("Retorno sobre a compra de estoque" + partial, fmt(inventory.get("roiPercent"), "percent"))]))
    body(13, financial.get("note"), financial.get("scope"),
         "Custos a confirmar: " + "; ".join(financial.get("missing") or []) if financial.get("missing") else "")
    body(14, "Demanda: " + _text(market.get("demandLabel")) + " | " + str(market.get("demandObservation") or ""),
         "Estoque equivalente ao ritmo médio da amostra: " + fmt(inventory.get("quantityCoverageDays"), "number") + (" dias." if inventory.get("quantityCoverageDays") is not None else "."),
         inventory.get("coverageNote"),
         "A quantidade de venda informada supera a compra. Conferir estoque existente ou reposição." if inventory.get("salesExceedPurchase") else "")
    executive = analysis.get("executiveSummary") or {}
    specialist_summary = str(review.get("executiveSummary") or "").strip()
    body(15, "Texto revisado pelo especialista:" if specialist_summary else "", specialist_summary or executive.get("text") or "Resumo não calculado.",
         *executive.get("limitations", []))
    body(16, "Veredito calculado: " + _text(calculated.get("label")), *["- " + str(reason) for reason in calculated.get("reasons", [])],
         "Veredito do especialista: " + _text(final.get("label")) if verdict.get("override") else "",
         "Motivo da alteração: " + str((verdict.get("override") or {}).get("reason") or "") if verdict.get("override") else "",
         str(review.get("notes") or ""), calculated.get("scope"))
    sections[15]["tone"] = final.get("status", "insufficient")
    sections[15]["calloutLabel"] = "Parecer final: " + _text(final.get("label"))
    checks = analysis.get("checklist") or []
    table(16, ["Conferência", "Estado / detalhe"], [[str(row.get("label", "")),
        {"complete": "Conferido", "missing": "Pendente", "attention": "Atenção"}.get(row.get("status"), "Pendente") + ": " + str(row.get("detail") or "")] for row in checks])
    source_info = evidence.get("provenance") or {}
    if isinstance(source_info,list):
        source_info=next((row for row in source_info if isinstance(row,dict) and
                          (row.get('collectedAt') or row.get('completedAt') or row.get('observedAt'))),{})
    warnings = list(analysis.get("warnings") or []) + list(evidence.get("limitations") or [])
    if warnings:
        body(16, sections[15]["body"], "Limitações desta coleta:", *["- " + str(warning) for warning in dict.fromkeys(warnings)])
    collected_at = source_info.get("collectedAt") or source_info.get("completedAt") or source_info.get('observedAt') or reference.get("observedAt")
    body(16, sections[15]["body"], "Origem: dados comerciais informados; evidências JoomPulse quando coletadas; revisão do especialista. Coleta: " + _text(collected_at),
         "Atualização da referência na fonte: " + _text(reference.get("sourceRefreshedAt")))
    return sections


def text_report(report):
    envelope = report.get("marketAnalysis") or {}
    context = envelope.get("context") or {}
    parts = ["ANÁLISE DE MERCADO E VIABILIDADE", "Cliente: " + str(report.get("clientName") or ""),
             "Data da análise: " + str(report.get("date") or ""),
             "Cálculos locais por produto. Estimativas e revisões permanecem identificadas."]
    from .market_methods import METHODS
    method=(envelope.get('methodology') or {}).get('mode','gabriel')
    parts.append('Forma de análise: '+METHODS.get(method,method))
    for index, entry in enumerate(products(report), 1):
        _, source, _, _, _ = _entry(entry)
        parts.extend(["", "=" * 64, f"PRODUTO {index} - {source.get('name') or entry.get('name') or 'Produto'}"])
        analysis=entry.get('analysis') or {}
        if analysis.get('decision'):
            decision=analysis['decision']
            parts.extend(['','PARECER: '+decision['label'],entry.get('review',{}).get('notes') or decision['message']])
        if method!='gabriel' and analysis.get('dvp'):
            dvp=analysis['dvp']; demand=dvp.get('demand') or {}; pricing=dvp.get('pricing') or {}
            parts.extend(['','MÉTODO ANDRÉ / DVP',
                '10% do faturamento acumulado: '+fmt(demand.get('tenPercent'),'BRL'),
                'Preço médio dos anúncios: '+fmt(pricing.get('priceAverage'),'BRL'),
                'Esta fração de 10% não é uma previsão de vendas do cliente.'])
            parts.extend(check['label']+': '+check['detail'] for check in dvp.get('checklist',[]))
            parts.extend(['','DETALHAMENTO DO MÉTODO GABRIEL (comparação independente)'])
        for section in sections_for_product(entry, context):
            parts.extend(["", f"{section['index']}. {section['title']}", section["body"]])
            table = section.get("table")
            if table:
                parts.append(" | ".join(table["headers"]))
                parts.extend(" | ".join(str(cell) for cell in row) for row in table["rows"])
            parts.extend(str(link["label"]) + ": " + str(link["url"]) for link in section.get("links", []) if link.get("url"))
            parts.extend("Imagem local: " + image["id"] + " | " + image["caption"] for image in section.get("images", []))
    return "\n".join(parts).strip() + "\n"


_CSS = """
.market-product{margin:34px 0;border-top:2px solid #e6d6ac;padding-top:26px}.market-product h2{margin:6px 0 16px}
.market-section{margin:18px 0;padding:0;break-inside:auto}.market-section h3{margin:16px 0 7px;color:#64513a;break-after:avoid}
.market-section .market-copy{white-space:pre-wrap;font-size:15px;line-height:1.65;overflow-wrap:anywhere}
.market-section table,.market-overview table{width:100%;border-collapse:collapse;font-size:14px;line-height:1.5;table-layout:fixed;margin:10px 0}
.market-section th,.market-section td,.market-overview td,.market-overview th{padding:8px;vertical-align:top;overflow-wrap:anywhere}
.market-section th,.market-overview th{background:#f5f3ed;color:#675b43}.market-section tr{break-inside:avoid}
.market-gallery{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.market-gallery figure{margin:10px 0;min-width:0}
.market-gallery img{width:100%;height:150px;object-fit:contain;background:#fff}.market-gallery figcaption{font-size:13px;line-height:1.5;margin:7px 0}
.market-links{font-size:14px;display:flex;flex-wrap:wrap;gap:8px 18px;margin:10px 0}.market-overview{margin:25px 0}
.market-kpis{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin:20px 0}.market-kpi{border:1px solid;border-radius:14px;padding:18px;break-inside:avoid}
.market-kpi label{display:block;font-size:13px;line-height:1.5;margin-bottom:10px}.market-kpi strong{font-size:25px;line-height:1.3;overflow-wrap:anywhere}
.market-kpi-note{font-size:13px;line-height:1.5;color:#6c685e}.market-callout{border:1px solid;border-radius:14px;padding:18px;margin:10px 0}.market-callout strong{display:block;font-size:17px;margin-bottom:12px}
@media print{.market-product{break-before:page}.market-section .market-copy{font-size:11pt;line-height:1.5}.market-section table,.market-overview table{font-size:10pt}.market-gallery img{height:100px}.market-gallery figcaption{font-size:10pt}.market-section h3{font-size:12pt}.market-links{font-size:10pt}.market-kpi label,.market-kpi-note{font-size:10pt}.market-kpi strong{font-size:18pt}.market-callout strong{font-size:13pt}.market-kpi,.market-callout{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
"""


def render_html(report):
    if not has_market(report):
        return ""
    esc = lambda value: html.escape(str(value), quote=True)
    context = (report.get("marketAnalysis") or {}).get("context") or {}
    fragments = ["<style>" + _CSS + "</style><div class='chapter'>Produtos e viabilidade</div><div class='market-overview'><table><thead><tr><th>Produto</th><th>Parecer final</th><th>Lucro unitário</th></tr></thead><tbody>"]
    for index, entry in enumerate(products(report), 1):
        analysis, source, _, _, _ = _entry(entry)
        final = (analysis.get("verdict") or {}).get("final") or {}
        financial = analysis.get("financial") or {}
        fragments.append(f'<tr><td><a href="#market-product-{index}">{index}. {esc(source.get("name") or entry.get("name") or "Produto")}</a></td><td>{esc(final.get("label") or "Pendente")}</td><td>{esc(fmt(financial.get("profit"), "BRL"))}{" (parcial)" if financial.get("upperBound") else ""}</td></tr>')
    fragments.append("</tbody></table></div>")
    for index, entry in enumerate(products(report), 1):
        _, source, _, _, _ = _entry(entry)
        fragments.append(f'<article class="market-product" id="market-product-{index}"><span class="kicker">PRODUTO {index:02d}</span><h2 contenteditable="true">{esc(source.get("name") or entry.get("name") or "Produto")}</h2>')
        fragments.append('<div class="market-kpis">')
        for (label, value), (bg, border, ink) in zip(_kpis(entry), KPI_COLORS):
            fragments.append(f'<div class="market-kpi" style="background:{bg};border-color:{border};color:{ink}"><label contenteditable="true">{esc(label)}</label><strong contenteditable="true">{esc(value)}</strong></div>')
        fragments.append('</div><p class="market-kpi-note">Valores por unidade no cenário informado. Um saldo parcial é um teto antes dos custos pendentes; não é lucro confirmado.</p>')
        for section in sections_for_product(entry, context):
            tone = section.get("tone")
            fragments.append(f'<section class="market-section"><h3 contenteditable="true">{section["index"]:02d} · {esc(section["title"])}</h3>')
            if tone:
                bg, border, ink = VERDICT_COLORS.get(tone, VERDICT_COLORS['insufficient'])
                fragments.append(f'<div class="market-callout" style="background:{bg};border-color:{border}"><strong style="color:{ink}" contenteditable="true">{esc(section["calloutLabel"])}</strong>')
            fragments.append(f'<div class="market-copy" contenteditable="true">{esc(section["body"])}</div>')
            if tone:
                fragments.append('</div>')
            table = section.get("table")
            if table:
                fragments.append("<table><thead><tr>" + "".join("<th>" + esc(cell) + "</th>" for cell in table["headers"]) + "</tr></thead><tbody>")
                for row in table["rows"]:
                    fragments.append("<tr>" + "".join('<td contenteditable="true">' + esc(cell) + "</td>" for cell in row) + "</tr>")
                fragments.append("</tbody></table>")
            if section.get("images"):
                fragments.append('<div class="market-gallery">')
                for image in section["images"]:
                    try:
                        url = assets.data_url(image["id"])
                        fragments.append(f'<figure><img src="{url}" alt="{esc(image["caption"])}"><figcaption contenteditable="true">{esc(image["caption"])}</figcaption></figure>')
                    except (ValueError, OSError):
                        fragments.append('<p class="caption">Imagem local indisponível: ' + esc(image["caption"]) + '</p>')
                fragments.append('</div>')
            links = [f'<a href="{esc(safe_link(link.get("url")))}" target="_blank" rel="noopener noreferrer">{esc(link["label"])}</a>' for link in section.get("links", []) if safe_link(link.get("url"))]
            if links:
                fragments.append('<div class="market-links">' + ''.join(links) + '</div>')
            fragments.append('</section>')
        fragments.append('</article>')
    return ''.join(fragments)


def pdf_flowables(report, width, font="Helvetica", bold="Helvetica-Bold"):
    """Readable flowables for report_visual; asset reads are local only."""
    if not has_market(report):
        return []
    from reportlab.lib import colors
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.platypus import Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
    styles = {
        "body": ParagraphStyle("MPBody", fontName=font, fontSize=11, leading=16.5, spaceAfter=8, textColor=colors.HexColor("#39372F")),
        "small": ParagraphStyle("MPSmall", fontName=font, fontSize=10, leading=14.5, spaceAfter=6, textColor=colors.HexColor("#6C685E")),
        "head": ParagraphStyle("MPHead", fontName=bold, fontSize=19, leading=25, spaceAfter=14, keepWithNext=True),
        "sub": ParagraphStyle("MPSub", fontName=bold, fontSize=12, leading=18, spaceBefore=13, spaceAfter=8, keepWithNext=True, textColor=colors.HexColor("#8C6B24")),
    }
    def p(value, kind="body"):
        text = html.escape(str(value).replace("\u2011", "-").replace("–", "-").replace("—", "-"))
        if "PronixSymbols" in pdfmetrics.getRegisteredFontNames():
            text = text.replace("⚡", '<font name="PronixSymbols">⚡</font>')
        return Paragraph(text.replace("\n", "<br/>"), styles[kind])
    def table(headers, rows, widths=None):
        data = [[p(cell, "small") for cell in headers]] + [[p(cell, "small") for cell in row] for row in rows]
        widths = widths or ([width * .46, width * .54] if len(headers) == 2 else [width / len(headers)] * len(headers))
        value = Table(data, colWidths=widths, repeatRows=1, splitByRow=1, splitInRow=1)
        value.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F5F2E9')),
            ('LINEBELOW', (0, 0), (-1, -1), .35, colors.HexColor('#E8E4DA')),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 7),
            ('RIGHTPADDING', (0, 0), (-1, -1), 7), ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5)]))
        return value

    def kpi_cards(entry):
        tile_width = (width - 20) / 3
        tiles = []
        for (label, value), (bg, border, ink) in zip(_kpis(entry), KPI_COLORS):
            label_style = ParagraphStyle('MPKpiLabel', parent=styles['small'], textColor=colors.HexColor(ink))
            value_style = ParagraphStyle('MPKpiValue', fontName=bold, fontSize=19, leading=25, textColor=colors.HexColor(ink))
            tile = Table([[Paragraph(html.escape(label), label_style)], [Paragraph(html.escape(value), value_style)]],
                         colWidths=[tile_width], minRowHeights=[43, 44], cornerRadii=[12] * 4)
            tile.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), colors.HexColor(bg)),
                ('BOX', (0, 0), (-1, -1), .7, colors.HexColor(border)),
                ('LEFTPADDING', (0, 0), (-1, -1), 12), ('RIGHTPADDING', (0, 0), (-1, -1), 12),
                ('TOPPADDING', (0, 0), (-1, 0), 13), ('BOTTOMPADDING', (0, 0), (-1, 0), 5),
                ('TOPPADDING', (0, 1), (-1, 1), 2), ('BOTTOMPADDING', (0, 1), (-1, 1), 13),
                ('VALIGN', (0, 0), (-1, -1), 'TOP')]))
            tiles.append(tile)
        row = Table([[tiles[0], '', tiles[1], '', tiles[2]]], colWidths=[tile_width, 10, tile_width, 10, tile_width])
        row.setStyle(TableStyle([('LEFTPADDING', (0, 0), (-1, -1), 0), ('RIGHTPADDING', (0, 0), (-1, -1), 0),
                                ('TOPPADDING', (0, 0), (-1, -1), 0), ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
                                ('VALIGN', (0, 0), (-1, -1), 'TOP')]))
        return KeepTogether([row, Spacer(1, 9), p('Valores por unidade no cenário informado. Um saldo parcial é um teto antes dos custos pendentes; não é lucro confirmado.', 'small')])

    def callout(section):
        bg, border, ink = VERDICT_COLORS.get(section.get('tone'), VERDICT_COLORS['insufficient'])
        label_style = ParagraphStyle('MPVerdict', fontName=bold, fontSize=13, leading=19,
                                     textColor=colors.HexColor(ink), spaceAfter=6)
        rows = [[Paragraph(html.escape(section['calloutLabel']), label_style)]]
        rows += [[p(paragraph)] for paragraph in section['body'].split('\n') if paragraph]
        box = Table(rows, colWidths=[width], splitByRow=1, splitInRow=1, repeatRows=1, cornerRadii=[12] * 4)
        box.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), colors.HexColor(bg)),
            ('BOX', (0, 0), (-1, -1), .7, colors.HexColor(border)),
            ('LEFTPADDING', (0, 0), (-1, -1), 16), ('RIGHTPADDING', (0, 0), (-1, -1), 16),
            ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('TOPPADDING', (0, 0), (-1, 0), 13), ('BOTTOMPADDING', (0, -1), (-1, -1), 12),
            ('VALIGN', (0, 0), (-1, -1), 'TOP')]))
        return box
    story = [Spacer(1, 20), p("Produtos e viabilidade", "head")]
    overview = []
    for index, entry in enumerate(products(report), 1):
        analysis, source, _, _, _ = _entry(entry)
        final = (analysis.get("verdict") or {}).get("final") or {}
        financial = analysis.get("financial") or {}
        overview.append([f"{index}. {source.get('name') or entry.get('name') or 'Produto'}", final.get("label") or "Pendente",
                         fmt(financial.get("profit"), "BRL") + (" (parcial)" if financial.get("upperBound") else "")])
    story += [table(["Produto", "Parecer final", "Lucro unitário"], overview, [width*.50, width*.30, width*.20]),
              Spacer(1, 10), p("A leitura considera cada produto separadamente. Os próximos blocos preservam a ordem das 16 etapas e distinguem cálculo de revisão profissional.", "small")]
    context = (report.get("marketAnalysis") or {}).get("context") or {}
    for index, entry in enumerate(products(report), 1):
        _, source, _, _, _ = _entry(entry)
        story += [PageBreak(), p(f"PRODUTO {index:02d}", "sub"), p(source.get("name") or entry.get("name") or "Produto", "head")]
        story += [kpi_cards(entry), Spacer(1, 8)]
        for section in sections_for_product(entry, context):
            story.append(p(f"{section['index']:02d}. {section['title']}", "sub"))
            if section.get('tone'):
                story += [callout(section), Spacer(1, 8)]
            elif section["body"]:
                for paragraph in section["body"].split("\n"):
                    if paragraph:
                        story.append(p(paragraph))
            data = section.get("table")
            if data:
                widths = [width*.36, width*.13, width*.11, width*.17, width*.23] if len(data["headers"]) == 5 else None
                story += [table(data["headers"], data["rows"], widths), Spacer(1, 5)]
            pictures = []
            for image in section.get("images", [])[:5]:
                try:
                    picture = Image(str(assets.get_path(image["id"])))
                    ratio = min((width/3 - 20)/picture.imageWidth, 105/picture.imageHeight)
                    picture.drawWidth, picture.drawHeight = picture.imageWidth*ratio, picture.imageHeight*ratio
                    pictures.append([picture, p(image["caption"], "small")])
                except (ValueError, OSError):
                    story.append(p("Imagem local indisponível: " + image["caption"], "small"))
            for start in range(0, len(pictures), 3):
                picture_row = pictures[start:start+3]
                gallery = Table([picture_row], colWidths=[width/3] * len(picture_row))
                gallery.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 4), ('RIGHTPADDING', (0, 0), (-1, -1), 4)]))
                story += [gallery, Spacer(1, 5)]
            for link in section.get("links", []):
                url = safe_link(link.get("url"))
                if url:
                    story.append(Paragraph(f'<link href="{html.escape(url, quote=True)}" color="#6452A1">{html.escape(link["label"])}</link>', styles["small"]))
    return story
