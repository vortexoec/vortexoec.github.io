$ErrorActionPreference = 'Stop'
$pronixRoot = $PSScriptRoot
$pronixUrl = 'http://127.0.0.1:8765'
$pronixHealth = $null
try { $pronixHealth = Invoke-RestMethod -Uri ($pronixUrl + '/api/health') -TimeoutSec 3 } catch { }
if ($pronixHealth) {
    if ($pronixHealth.app -ne 'pronix-beta') { throw 'A porta 8765 pertence a outro programa. Nenhum processo foi encerrado.' }
    if ($pronixHealth.activeJobs -gt 0) { throw 'Uma analise ainda esta em andamento. Aguarde a conclusao antes de reiniciar.' }
    $pronixBoot = Invoke-RestMethod -Uri ($pronixUrl + '/api/bootstrap') -TimeoutSec 4
    $pronixExpectedOutput = Join-Path (Split-Path $pronixRoot -Parent) 'analise de mercado'
    if ($pronixBoot.outputDirectory -ne $pronixExpectedOutput) { throw 'Esta instancia pertence a outra pasta. Nenhum processo foi encerrado.' }
    $pronixListeners = @(Get-NetTCPConnection -LocalPort 8765 -State Listen)
    if ($pronixListeners.Count -ne 1 -or $pronixListeners[0].LocalAddress -ne '127.0.0.1') { throw 'Nao foi possivel identificar uma unica instancia local.' }
    $pronixPid = $pronixListeners[0].OwningProcess
    $pronixProcess = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $pronixPid)
    if ($pronixProcess.CommandLine -notmatch 'python(?:w)?\.exe.*app\.py') { throw 'O processo nao corresponde ao servidor Python do Pronix.' }
    Stop-Process -Id $pronixPid -ErrorAction Stop
    for ($pronixAttempt = 0; $pronixAttempt -lt 30; $pronixAttempt++) {
        if (-not (Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue)) { break }
        Start-Sleep -Milliseconds 200
    }
}
& (Join-Path $pronixRoot 'iniciar.ps1') -NoBrowser
