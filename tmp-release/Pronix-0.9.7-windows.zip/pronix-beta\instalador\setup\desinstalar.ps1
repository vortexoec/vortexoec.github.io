﻿# Desinstala a Central de Análises (chamado pelo desinstalador do Windows).
# Remove o programa, os atalhos e o link central-analises://. Guarda os relatórios exportados
# ("analise de mercado") e as conexões (%USERPROFILE%\.pronix-beta) para uma reinstalação.
param([Parameter(Mandatory = $true)][string]$Destino)
$ErrorActionPreference = 'Continue'
$app = Join-Path $Destino 'pronix-beta'

# Pasta de desenvolvimento (com .git): nunca apaga.
if (Test-Path -LiteralPath (Join-Path $app '.git')) { exit 0 }

# Fecha o programa desta pasta.
$listener = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($listener) {
    $process = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $listener.OwningProcess)
    if ($process.ExecutablePath -and $process.ExecutablePath.StartsWith($Destino, [StringComparison]::OrdinalIgnoreCase)) {
        Stop-Process -Id $listener.OwningProcess -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1
    }
}

foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    Remove-Item -LiteralPath (Join-Path $folder 'Central de Análises.lnk') -Force -ErrorAction SilentlyContinue
}
$protocol = 'HKCU:\Software\Classes\central-analises'
if (Test-Path $protocol) {
    $command = (Get-ItemProperty -Path "$protocol\shell\open\command" -ErrorAction SilentlyContinue).'(default)'
    if (-not $command -or $command -like "*$Destino*") { Remove-Item $protocol -Recurse -Force -ErrorAction SilentlyContinue }
}
foreach ($name in 'pronix-beta', 'python') {
    Remove-Item -LiteralPath (Join-Path $Destino $name) -Recurse -Force -ErrorAction SilentlyContinue
}
foreach ($name in 'Abrir Central de Analises.bat', 'Reiniciar Central de Analises.bat') {
    Remove-Item -LiteralPath (Join-Path $Destino $name) -Force -ErrorAction SilentlyContinue
}
exit 0
