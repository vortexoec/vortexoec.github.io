"""Local report screenshots. Re-encode uploads; never render arbitrary SVG/HTML."""
import base64
import io
import uuid
from pathlib import Path
from PIL import Image, ImageOps, UnidentifiedImageError
from . import storage

MAX_BYTES = 5 * 1024 * 1024


def directory():
    return storage.RUNTIME / 'assets'


def get_path(asset_id):
    path=directory()/(storage.identifier(asset_id)+'.png')
    if not path.exists():
        raise FileNotFoundError('Imagem não encontrada. Adicione o print novamente.')
    return path


def save_image(data):
    raw=base64.b64decode(str(data.get('data','')).split(',')[-1],validate=True)
    if not raw or len(raw)>MAX_BYTES:
        raise ValueError('Use uma imagem PNG, JPEG ou WebP de até 5 MB.')
    try:
        with Image.open(io.BytesIO(raw)) as source:
            if source.format not in ('PNG','JPEG','WEBP'):
                raise ValueError('Formato não suportado. Use PNG, JPEG ou WebP.')
            if source.width*source.height>25_000_000:
                raise ValueError('A imagem é muito grande. Reduza para até 25 megapixels.')
            source.load()
            image=ImageOps.exif_transpose(source).convert('RGBA')
            image.thumbnail((2200,2200),Image.Resampling.LANCZOS)
            background=Image.new('RGB',image.size,'white')
            background.paste(image,mask=image.getchannel('A'))
    except (UnidentifiedImageError,OSError,Image.DecompressionBombError):
        raise ValueError('Não foi possível ler esta imagem. Exporte como PNG ou JPEG.') from None
    asset_id=uuid.uuid4().hex
    directory().mkdir(parents=True,exist_ok=True)
    path=directory()/(asset_id+'.png')
    background.save(path,format='PNG',optimize=True)
    result={'id':asset_id,'url':'/api/assets/'+asset_id,'name':Path(str(data.get('name','Print'))).name,
            'width':background.width,'height':background.height,'caption':''}
    storage.write_json(directory()/(asset_id+'.json'),result)
    return result


def data_url(asset_id):
    return 'data:image/png;base64,'+base64.b64encode(get_path(asset_id).read_bytes()).decode('ascii')
