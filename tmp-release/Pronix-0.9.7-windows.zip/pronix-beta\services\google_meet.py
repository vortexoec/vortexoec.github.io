"""Read-only Google Meet/Drive import with desktop OAuth PKCE and Windows DPAPI.

No media transcription, folder guessing or video download is performed here.
The only selected content downloaded is a Google Doc or TXT/VTT/SRT (at most 4 MiB).
"""
from __future__ import annotations

import base64
from datetime import datetime
import hashlib
import html
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import secrets
import threading
import time
from urllib import error, parse, request

from .joompulse import _crypt_blob

AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
MEET_URL = "https://meet.googleapis.com/v2/"
DRIVE_URL = "https://www.googleapis.com/drive/v3/files/"
DEFAULT_REDIRECT_URI = "http://localhost:8765/api/google/callback"
MEET_SCOPE = "https://www.googleapis.com/auth/meetings.space.readonly"
DRIVE_MEET_SCOPE = "https://www.googleapis.com/auth/drive.meet.readonly"
DRIVE_ALL_SCOPE = "https://www.googleapis.com/auth/drive.readonly"
CALENDAR_EVENTS_SCOPE = "https://www.googleapis.com/auth/calendar.events.readonly"
CALENDAR_LIST_SCOPE = "https://www.googleapis.com/auth/calendar.calendarlist.readonly"
CALENDAR_URL = "https://www.googleapis.com/calendar/v3/"
MAX_TEXT_BYTES = 4 * 1024 * 1024
MAX_JSON_BYTES = 2 * 1024 * 1024
MAX_CONFERENCES = 20
DOC_MIME = "application/vnd.google-apps.document"
_ID = re.compile(r"[A-Za-z0-9_-]{1,200}\Z")
_RECORD = re.compile(r"conferenceRecords/[A-Za-z0-9_-]{1,200}\Z")
_TEXT_MIMES = {"text/plain", "text/vtt", "application/x-subrip", "text/srt"}


class GoogleMeetError(RuntimeError):
    """Safe message for the local UI; excludes tokens and Google's raw errors."""

    def __init__(self, message: str, code: str = "google_error"):
        super().__init__(message)
        self.code = code


class _NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # Never forward a bearer token or OAuth code to another URL.


def _redirect_uri(uri: str) -> str:
    try:
        parsed = parse.urlsplit(uri)
        valid = (parsed.scheme == "http" and parsed.hostname in ("localhost", "127.0.0.1")
                 and parsed.path == "/api/google/callback" and parsed.port is not None
                 and 1024 <= parsed.port <= 65535 and not parsed.query and not parsed.fragment
                 and not parsed.username and not parsed.password)
    except (ValueError, TypeError):
        valid = False
    if not valid:
        raise GoogleMeetError("Use o retorno local http://localhost:8765/api/google/callback.", "config")
    return uri


def _parse_link(url: str) -> dict:
    """Parse links only; never make an HTTP request to an input URL."""
    if not isinstance(url, str) or len(url) > 4096 or any(ord(c) < 32 for c in url):
        raise GoogleMeetError("Informe um link de reunião Meet ou arquivo Drive/Docs.", "link")
    try:
        parsed = parse.urlsplit(url.strip())
        if (parsed.scheme != "https" or parsed.hostname not in
                {"meet.google.com", "drive.google.com", "docs.google.com"}
                or parsed.port not in (None, 443) or parsed.username or parsed.password):
            raise ValueError()
        query = parse.parse_qs(parsed.query)
        if parsed.hostname == "meet.google.com":
            match = re.fullmatch(r"/([a-z]{3}-[a-z]{4}-[a-z]{3})/?", parsed.path)
            if not match:
                raise ValueError()
            return {"provider": "meet", "meetingCode": match[1],
                    "url": "https://meet.google.com/" + match[1]}
        if parsed.hostname == "docs.google.com":
            match = re.fullmatch(r"/document/(?:u/\d+/)?d/([A-Za-z0-9_-]{1,200})(?:/[^?#]*)?", parsed.path)
        else:
            match = re.fullmatch(r"/file/(?:u/\d+/)?d/([A-Za-z0-9_-]{1,200})(?:/[^?#]*)?", parsed.path)
        file_id = match[1] if match else ""
        if not file_id and parsed.hostname == "drive.google.com" and parsed.path in ("/open", "/uc"):
            values = query.get("id", [])
            file_id = values[0] if len(values) == 1 else ""
        resource_keys = query.get("resourcekey", [])
        resource_key = resource_keys[0] if len(resource_keys) == 1 else ""
        if not _ID.fullmatch(file_id) or (resource_key and not _ID.fullmatch(resource_key)):
            raise ValueError()
        canonical = ("https://docs.google.com/document/d/" + file_id + "/view"
                     if parsed.hostname == "docs.google.com" else
                     "https://drive.google.com/file/d/" + file_id + "/view")
        if resource_key:
            canonical += "?" + parse.urlencode({"resourcekey": resource_key})
        return {"provider": "drive", "fileId": file_id, "resourceKey": resource_key, "url": canonical}
    except (ValueError, TypeError):
        raise GoogleMeetError("Link não reconhecido. Use o link HTTPS da sala Meet, do Google Doc ou de um arquivo Drive; pastas não são aceitas.", "link") from None


def _is_text_file(metadata: dict) -> bool:
    mime = str(metadata.get("mimeType", "")).split(";", 1)[0].lower()
    if mime == DOC_MIME or mime in _TEXT_MIMES:
        return True
    return (mime == "application/octet-stream"
            and Path(str(metadata.get("name", ""))).suffix.lower() in {".txt", ".vtt", ".srt"})


def _decode_text(raw: bytes) -> tuple[str, list[str]]:
    warnings = []
    try:
        if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
            text = raw.decode("utf-16")
        else:
            text = raw.decode("utf-8-sig")
    except UnicodeError:
        try:
            text = raw.decode("cp1252")
            warnings.append("A transcrição foi lida como Windows-1252. Confira os acentos na revisão.")
        except UnicodeError:
            raise GoogleMeetError("Não foi possível ler a codificação do texto. Exporte como TXT UTF-8.", "format") from None
    if any(ord(c) < 32 and c not in "\r\n\t" for c in text):
        raise GoogleMeetError("O arquivo contém dados binários; envie uma transcrição TXT, VTT, SRT ou Google Doc.", "format")
    text = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    if not text:
        raise GoogleMeetError("A transcrição está vazia.", "empty")
    return text, warnings


class _DescriptionParser(HTMLParser):
    """Calendar descriptions can be HTML; extract text and links without rendering."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.links = [], []
        self.anchor, self.anchor_parts = None, []
        self.ignored = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.ignored += 1
        if self.ignored:
            return
        if tag in ("br", "p", "div", "li"):
            self.parts.append("\n")
        if tag == "a":
            self.anchor = dict(attrs).get("href", "")
            self.anchor_parts = []

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self.ignored:
            self.ignored -= 1
            return
        if self.ignored:
            return
        if tag == "a" and self.anchor:
            self.links.append((self.anchor, "".join(self.anchor_parts).strip(), ""))
            self.anchor, self.anchor_parts = None, []
        if tag in ("p", "div", "li"):
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.ignored:
            self.parts.append(data)
            if self.anchor is not None:
                self.anchor_parts.append(data)


def _event_payload(event: dict, calendar_id: str) -> dict:
    parser = _DescriptionParser()
    parser.feed(str(event.get("description", ""))[:200000])
    description = re.sub(r"\n{3,}", "\n\n", "".join(parser.parts)).strip()
    raw_links = list(parser.links)
    for match in re.finditer(r"https://[^\s<>\"']+", description):
        url = match[0].rstrip(".,;:!?)】]")
        # Nearby label is a hint only, never proof of a file's contents.
        line_start = description.rfind("\n", 0, match.start()) + 1
        label = description[line_start:match.start()].strip()[-120:]
        raw_links.append((url, label, ""))
    official_meeting = ""
    raw_links.append((event.get("hangoutLink", ""), "Sala Meet", "meeting"))
    official_urls = [event.get("hangoutLink", "")]
    for point in event.get("conferenceData", {}).get("entryPoints", []):
        if isinstance(point, dict) and point.get("entryPointType") == "video":
            raw_links.append((point.get("uri", ""), "Sala Meet", "meeting"))
            official_urls.append(point.get("uri", ""))
    for official_url in official_urls:
        try:
            official = _parse_link(official_url)
            if official["provider"] == "meet":
                official_meeting = official["url"]
                break
        except GoogleMeetError:
            continue
    for attachment in event.get("attachments", []):
        if isinstance(attachment, dict):
            raw_links.append((attachment.get("fileUrl", ""), attachment.get("title", "Arquivo anexado"), attachment.get("mimeType", "")))
    links, by_url = [], {}
    for raw_url, label, mime in raw_links:
        try:
            link = _parse_link(html.unescape(str(raw_url)))
        except GoogleMeetError:
            continue
        label = str(label)[:300]
        if link["provider"] == "meet":
            kind, classification = "meeting", "url"
        elif str(mime).startswith(("video/", "audio/")):
            kind, classification = "recording", "attachment-mime"
        elif re.search(r"transcri[çc][aã]o|transcript|\.srt\b|\.vtt\b", label, flags=re.I):
            kind, classification = "transcript", "label-suggestion"
        elif re.search(r"grava[çc][aã]o|recording|\.mp4\b", label, flags=re.I):
            kind, classification = "recording", "label-suggestion"
        elif "docs.google.com/" in link["url"] or mime == DOC_MIME:
            kind, classification = "document", "url"
        else:
            kind, classification = "file", "url"
        item = {"url": link["url"], "kind": kind, "name": label or "Arquivo vinculado", "classification": classification}
        previous = by_url.get(link["url"])
        if previous is None:
            links.append(item)
            by_url[link["url"]] = item
        elif previous["kind"] in ("document", "file") and kind in ("transcript", "recording"):
            previous.update(item)
    title = str(event.get("summary", "Sem título"))[:1000]
    start, end = event.get("start", {}), event.get("end", {})
    return {"id": str(event.get("id", "")), "calendarId": calendar_id,
            "title": title, "start": start.get("dateTime", start.get("date", "")),
            "end": end.get("dateTime", end.get("date", "")), "allDay": "date" in start,
            "timeZone": start.get("timeZone", ""), "description": description,
            "meetingUrl": official_meeting or next((x["url"] for x in links if x["kind"] == "meeting"), ""),
            "recordingUrls": [x["url"] for x in links if x["kind"] == "recording"],
            "transcriptUrls": [x["url"] for x in links if x["kind"] == "transcript"],
            "links": links, "sellerSuggestion": title[:180], "sellerSuggestionNeedsReview": True,
            "sellerSuggestionSource": "Título do evento; confirme o nome do cliente antes de salvar.",
            "warnings": (["Tipos de links na descrição são sugestões pelo rótulo; confira o arquivo antes de importar."]
                         if any(x["classification"] == "label-suggestion" for x in links) else [])}


class GoogleMeetClient:
    def __init__(self, storage_dir: Path | str | None = None):
        from .secure_dir import secure_dir
        self.storage_dir = Path(storage_dir) if storage_dir is not None else secure_dir()
        self.secrets_path = self.storage_dir / "google.dpapi"
        self._lock = threading.RLock()
        self._config: dict = {}
        self._tokens: dict = {}
        self._pending: dict = {}
        self._candidates: dict[str, dict] = {}
        self._load_error = None
        if self.secrets_path.exists():
            try:
                saved = json.loads(_crypt_blob(self.secrets_path.read_bytes(), decrypt=True))
                if not isinstance(saved.get("config"), dict) or not isinstance(saved.get("tokens"), dict):
                    raise ValueError()
                self._config, self._tokens = saved["config"], saved["tokens"]
            except Exception:
                self._load_error = "A conexão Google salva não pôde ser aberta. Desconecte e configure novamente."

    def _save(self):
        try:
            blob = _crypt_blob(json.dumps({"config": self._config, "tokens": self._tokens}).encode())
            self.storage_dir.mkdir(parents=True, exist_ok=True)
            temporary = self.secrets_path.with_suffix(".tmp")
            temporary.write_bytes(blob)
            os.replace(temporary, self.secrets_path)
            self._load_error = None
        except Exception:
            raise GoogleMeetError("Não foi possível guardar a conexão Google protegida neste usuário do Windows.", "storage") from None

    def _scopes(self) -> list[str]:
        return [MEET_SCOPE, DRIVE_ALL_SCOPE if self._config.get("drive_access") == "all" else DRIVE_MEET_SCOPE,
                CALENDAR_EVENTS_SCOPE, CALENDAR_LIST_SCOPE]

    def status(self) -> dict:
        with self._lock:
            has_token = bool(self._tokens.get("access_token"))
            expired = self._tokens.get("expires_at", 0) <= time.time()
            return {"configured": bool(self._config.get("client_id")),
                    "connected": has_token and (not expired or bool(self._tokens.get("refresh_token"))),
                    "client_id": self._config.get("client_id", ""),
                    "has_client_secret": bool(self._config.get("client_secret")),
                    "driveAccess": self._config.get("drive_access", "meet"),
                    "scopes": self._scopes(), "needs_login": bool(has_token and expired and not self._tokens.get("refresh_token")),
                    "redirect_uri": DEFAULT_REDIRECT_URI,
                    "setup_url": "https://console.cloud.google.com/apis/credentials",
                    "storage": "Conexão protegida por usuário do Windows, fora do projeto.",
                    "error": self._load_error}

    def configure(self, config: dict) -> dict:
        if not isinstance(config, dict):
            raise GoogleMeetError("Informe as configurações do cliente Google Desktop.", "config")
        client_id = str(config.get("clientId", config.get("client_id", ""))).strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,250}\.apps\.googleusercontent\.com", client_id):
            raise GoogleMeetError("Informe um ID OAuth de aplicativo para computador do Google, terminado em .apps.googleusercontent.com.", "config")
        with self._lock:
            same_id = client_id == self._config.get("client_id")
            old_secret = self._config.get("client_secret", "") if same_id else ""
            secret = str(config.get("clientSecret", config.get("client_secret", old_secret)) or "").strip()
            drive_access = config.get("driveAccess", config.get("drive_access", self._config.get("drive_access", "meet")))
            if drive_access not in ("meet", "all") or len(secret) > 8192 or any(ord(c) < 32 for c in secret):
                raise GoogleMeetError("Configuração Google inválida.", "config")
            if not same_id or drive_access != self._config.get("drive_access", "meet"):
                self._tokens = {}
            self._config = {"client_id": client_id, "client_secret": secret, "drive_access": drive_access}
            self._pending, self._candidates = {}, {}
            self._save()
            return self.status()

    def authorization_url(self, redirect_uri: str = DEFAULT_REDIRECT_URI) -> str:
        with self._lock:
            if not self._config.get("client_id"):
                raise GoogleMeetError("Configure o ID OAuth Google Desktop antes de conectar.", "config")
            redirect_uri = _redirect_uri(redirect_uri)
            verifier = secrets.token_urlsafe(64)
            challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
            state = secrets.token_urlsafe(32)
            self._pending = {"state": state, "verifier": verifier, "redirect_uri": redirect_uri, "created_at": time.time()}
            return AUTH_URL + "?" + parse.urlencode({
                "client_id": self._config["client_id"], "redirect_uri": redirect_uri,
                "response_type": "code", "scope": " ".join(self._scopes()), "state": state,
                "code_challenge": challenge, "code_challenge_method": "S256",
                "access_type": "offline", "prompt": "consent"})

    def _http(self, url: str, body: bytes | None = None, headers: dict | None = None,
              max_bytes: int = MAX_JSON_BYTES) -> bytes:
        try:
            parsed = parse.urlsplit(url)
            official = (parsed.scheme == "https" and parsed.hostname in
                        {"oauth2.googleapis.com", "meet.googleapis.com", "www.googleapis.com"}
                        and parsed.port in (None, 443) and not parsed.username
                        and not parsed.password and not parsed.fragment)
        except ValueError:
            official = False
        if not official:
            raise GoogleMeetError("Endereço da API Google não reconhecido.", "link")
        req = request.Request(url, data=body, headers=headers or {})
        try:
            with request.build_opener(_NoRedirect()).open(req, timeout=45) as response:
                declared = response.headers.get("Content-Length", "")
                if declared.isdigit() and int(declared) > max_bytes:
                    raise GoogleMeetError("O texto excede o limite local de 4 MiB. Importe um trecho menor.", "size")
                raw = response.read(max_bytes + 1)
                if len(raw) > max_bytes:
                    raise GoogleMeetError("A resposta excede o limite local. Reduza a transcrição ou consulta.", "size")
                return raw
        except error.HTTPError as exc:
            reasons = set()
            try:
                remote = json.loads(exc.read(8192)).get("error", {})
                if isinstance(remote, str):
                    reasons.add(remote)
                elif isinstance(remote, dict):
                    reasons.update(x.get("reason", "") for x in remote.get("errors", []) if isinstance(x, dict))
                    reasons.update(x.get("reason", "") for x in remote.get("details", []) if isinstance(x, dict))
            except (ValueError, OSError, AttributeError, TypeError):
                pass
            if "invalid_grant" in reasons or exc.code == 401:
                raise GoogleMeetError("A autorização Google expirou ou foi revogada. Conecte novamente.", "auth") from None
            if "invalid_client" in reasons:
                raise GoogleMeetError("O Google não reconheceu o cliente OAuth. Confira o ID e o segredo do aplicativo Desktop.", "config") from None
            if exc.code == 429 or reasons.intersection({"rateLimitExceeded", "userRateLimitExceeded", "quotaExceeded", "RATE_LIMIT_EXCEEDED"}):
                raise GoogleMeetError("O limite de consultas Google foi atingido. Aguarde e tente novamente.", "quota") from None
            if reasons.intersection({"accessNotConfigured", "SERVICE_DISABLED"}):
                raise GoogleMeetError("Ative Google Meet API, Google Drive API e Google Calendar API no projeto do cliente OAuth.", "api_disabled") from None
            if exc.code == 403:
                raise GoogleMeetError("O Google negou o acesso. Confira a conta, as permissões do arquivo e os escopos autorizados. No modo Meet, Docs/TXT externos exigem acesso ampliado ao Drive.", "forbidden") from None
            if exc.code == 404:
                raise GoogleMeetError("Arquivo ou reunião não encontrado para esta conta. Confira o link, o acesso e a retenção do Meet.", "not_found") from None
            raise GoogleMeetError(f"O Google não concluiu a solicitação (HTTP {exc.code}). Tente novamente.", "http") from None
        except (error.URLError, TimeoutError, OSError):
            raise GoogleMeetError("Não foi possível alcançar o Google. Confira a internet e tente novamente.", "network") from None

    @staticmethod
    def _json(raw: bytes) -> dict:
        try:
            result = json.loads(raw)
            if not isinstance(result, dict):
                raise ValueError()
            return result
        except (ValueError, UnicodeError):
            raise GoogleMeetError("A API Google retornou uma resposta inesperada.", "response") from None

    def _token_request(self, fields: dict) -> dict:
        fields = dict(fields, client_id=self._config["client_id"])
        if self._config.get("client_secret"):
            fields["client_secret"] = self._config["client_secret"]
        token = self._json(self._http(TOKEN_URL, parse.urlencode(fields).encode(),
                                    {"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"}))
        try:
            if not isinstance(token.get("access_token"), str) or not token["access_token"]:
                raise ValueError()
            if str(token.get("token_type", "Bearer")).lower() != "bearer":
                raise ValueError()
            expiry = float(token.get("expires_in", 3600))
            if not 0 < expiry <= 365 * 86400:
                raise ValueError()
            granted = set(str(token.get("scope", " ".join(self._scopes()))).split())
            if not set(self._scopes()).issubset(granted):
                raise GoogleMeetError("Nem todas as permissões de leitura foram autorizadas. Conecte novamente e selecione os escopos necessários.", "scope")
            token["expires_at"] = time.time() + expiry
            return token
        except (ValueError, TypeError):
            raise GoogleMeetError("O Google retornou uma autorização incompleta. Conecte novamente.", "auth") from None

    def complete_oauth(self, code: str, state: str, redirect_uri: str = DEFAULT_REDIRECT_URI) -> dict:
        with self._lock:
            pending = self._pending
            if (not pending or not isinstance(state, str) or not state.isascii() or len(state) > 200
                    or not secrets.compare_digest(state, pending["state"])
                    or time.time() - pending["created_at"] > 600 or redirect_uri != pending["redirect_uri"]):
                raise GoogleMeetError("Esta autorização expirou ou não corresponde à conexão iniciada. Conecte novamente.", "state")
            if not isinstance(code, str) or not code or len(code) > 16384:
                raise GoogleMeetError("O Google não enviou um código válido.", "auth")
            self._pending = {}
            tokens = self._token_request({"grant_type": "authorization_code", "code": code,
                                          "redirect_uri": redirect_uri, "code_verifier": pending["verifier"]})
            self._tokens, self._candidates = tokens, {}
            self._save()
            return self.status()

    def _access_token(self) -> str:
        if not self._tokens.get("access_token"):
            raise GoogleMeetError("Conecte sua conta Google para importar a transcrição.", "auth")
        if self._tokens.get("expires_at", 0) <= time.time() + 60:
            refresh = self._tokens.get("refresh_token")
            if not refresh:
                raise GoogleMeetError("A conexão Google expirou. Conecte novamente.", "auth")
            try:
                tokens = self._token_request({"grant_type": "refresh_token", "refresh_token": refresh})
            except GoogleMeetError as exc:
                if exc.code == "auth":
                    self._tokens, self._candidates = {}, {}
                    self._save()
                raise
            tokens.setdefault("refresh_token", refresh)
            self._tokens = tokens
            self._save()
        return self._tokens["access_token"]

    def disconnect(self) -> dict:
        with self._lock:
            self._config, self._tokens, self._pending, self._candidates = {}, {}, {}, {}
            self._load_error = None
            try:
                self.secrets_path.unlink(missing_ok=True)
            except OSError:
                raise GoogleMeetError("Não foi possível remover a conexão Google salva do computador.", "storage") from None
            return self.status()

    def _api(self, url: str, headers: dict | None = None, max_bytes: int = MAX_JSON_BYTES) -> bytes:
        try:
            return self._http(url, headers=dict(headers or {}, Authorization="Bearer " + self._access_token()), max_bytes=max_bytes)
        except GoogleMeetError as exc:
            if exc.code == "auth" and self._tokens:
                self._tokens, self._candidates = {}, {}
                self._save()
            raise

    def _calendar_pages(self, path: str, params: dict, limit: int = 200) -> tuple[list, bool]:
        items, page_token, seen = [], "", set()
        for _ in range(20):
            query = dict(params, maxResults=min(limit, 200))
            if page_token:
                query["pageToken"] = page_token
            page = self._json(self._api(CALENDAR_URL + path + "?" + parse.urlencode(query)))
            batch = page.get("items", [])
            if not isinstance(batch, list) or any(not isinstance(item, dict) for item in batch):
                raise GoogleMeetError("Lista inesperada retornada pelo Google Calendar.", "response")
            items.extend(batch)
            page_token = page.get("nextPageToken", "")
            if len(items) >= limit:
                return items[:limit], bool(page_token or len(items) > limit)
            if not page_token:
                return items, False
            if not isinstance(page_token, str) or page_token in seen:
                raise GoogleMeetError("A paginação da agenda não foi concluída. Consulte um período menor.", "response")
            seen.add(page_token)
        return items, True

    def list_calendars(self) -> dict:
        with self._lock:
            calendars, partial = self._calendar_pages("users/me/calendarList", {
                "minAccessRole": "reader", "showDeleted": "false", "showHidden": "true",
                "fields": "items(id,summary,summaryOverride,primary,timeZone,accessRole),nextPageToken"})
            return {"calendars": [{"id": c["id"], "name": c.get("summaryOverride", c.get("summary", c["id"])),
                                    "primary": bool(c.get("primary")), "timeZone": c.get("timeZone", ""),
                                    "accessRole": c.get("accessRole", "")} for c in calendars if c.get("id")],
                    "warnings": ["A lista foi limitada a 200 agendas."] if partial else []}

    def list_events(self, calendar_id: str, time_min: str, time_max: str) -> dict:
        if not isinstance(calendar_id, str) or not calendar_id or len(calendar_id) > 1024 or any(ord(c) < 32 for c in calendar_id):
            raise GoogleMeetError("Selecione uma agenda válida.", "calendar")
        try:
            dates = []
            for value in (time_min, time_max):
                if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})", value):
                    raise ValueError()
                dates.append(datetime.fromisoformat(value.replace("Z", "+00:00")))
            if not 0 < (dates[1] - dates[0]).total_seconds() <= 366 * 86400:
                raise ValueError()
        except (ValueError, TypeError):
            raise GoogleMeetError("Informe início e fim com horário/fuso RFC3339, em um intervalo de até 366 dias.", "dates") from None
        with self._lock:
            fields = "items(id,status,summary,description,start,end,hangoutLink,conferenceData(entryPoints),attachments(fileUrl,title,mimeType)),nextPageToken"
            events, partial = self._calendar_pages("calendars/" + parse.quote(calendar_id, safe="") + "/events", {
                "timeMin": time_min, "timeMax": time_max, "singleEvents": "true", "orderBy": "startTime",
                "showDeleted": "false", "fields": fields})
            return {"events": [_event_payload(event, calendar_id) for event in events if event.get("status") != "cancelled"],
                    "warnings": ["A busca foi limitada a 200 eventos. Reduza o período para encontrar os demais."] if partial else [],
                    "calendarId": calendar_id, "timeMin": time_min, "timeMax": time_max}

    def _list(self, path: str, field: str, limit: int, params: dict | None = None) -> tuple[list, bool]:
        items, page_token = [], ""
        seen_tokens = set()
        for _ in range(10):
            query = dict(params or {}, pageSize=min(limit, 100))
            if page_token:
                query["pageToken"] = page_token
            page = self._json(self._api(MEET_URL + path + "?" + parse.urlencode(query)))
            batch = page.get(field, [])
            if not isinstance(batch, list) or any(not isinstance(item, dict) for item in batch):
                raise GoogleMeetError("Lista inesperada retornada pelo Google Meet.", "response")
            items.extend(batch)
            page_token = page.get("nextPageToken", "")
            if len(items) >= limit:
                return items[:limit], bool(page_token or len(items) > limit)
            if not page_token:
                return items, False
            if not isinstance(page_token, str) or page_token in seen_tokens:
                raise GoogleMeetError("A paginação do Google Meet não foi concluída. Tente novamente.", "response")
            seen_tokens.add(page_token)
        return items, True

    def _metadata(self, file_id: str, resource_key: str = "") -> dict:
        if not _ID.fullmatch(file_id) or (resource_key and not _ID.fullmatch(resource_key)):
            raise GoogleMeetError("Identificador de arquivo Google inválido.", "link")
        fields = "id,name,mimeType,size,webViewLink,modifiedTime,trashed,capabilities(canDownload),resourceKey"
        params = parse.urlencode({"fields": fields, "supportsAllDrives": "true"})
        headers = {"X-Goog-Drive-Resource-Keys": file_id + "/" + resource_key} if resource_key else {}
        metadata = self._json(self._api(DRIVE_URL + file_id + "?" + params, headers))
        if metadata.get("id") != file_id or metadata.get("trashed"):
            raise GoogleMeetError("O arquivo não está disponível no Drive.", "not_found")
        return metadata

    def _remember(self, candidate: dict, resource_key: str = "") -> dict:
        self._candidates[candidate["id"]] = dict(candidate, _resource_key=resource_key)
        return candidate

    def resolve_link(self, url: str) -> dict:
        link = _parse_link(url)
        with self._lock:
            # Bound memory to this consultation (at most 20 * 50 * 2 artifacts),
            # without invalidating early candidates while building its result.
            self._candidates = {}
            warnings, candidates = [], []
            if link["provider"] == "drive":
                metadata = self._metadata(link["fileId"], link["resourceKey"])
                mime = metadata.get("mimeType", "")
                if _is_text_file(metadata):
                    kind = "transcript"
                    warnings.append("Confirme que este documento é a transcrição da reunião desejada antes de importar.")
                elif mime.startswith(("video/", "audio/")):
                    kind = "recording"
                    warnings.append("Este link contém uma gravação. O beta guarda o vínculo, mas não baixa nem transcreve mídia. Informe também o Google Doc, TXT, VTT ou SRT da transcrição.")
                else:
                    raise GoogleMeetError("O link não é um Google Doc, TXT, VTT, SRT ou gravação. Use o link do arquivo de transcrição; pastas e atalhos não são importados.", "format")
                candidate = {"id": "drive:" + link["fileId"], "name": metadata.get("name", "Arquivo do Drive"),
                             "kind": kind, "provider": "drive", "url": link["url"], "fileId": link["fileId"],
                             "mimeType": mime, "modifiedTime": metadata.get("modifiedTime", ""),
                             "available": metadata.get("capabilities", {}).get("canDownload", True),
                             "size": metadata.get("size")}
                candidates.append(self._remember(candidate, link["resourceKey"] or metadata.get("resourceKey", "")))
            else:
                records, partial = self._list("conferenceRecords", "conferenceRecords", MAX_CONFERENCES,
                                              {"filter": 'space.meeting_code = "' + link["meetingCode"] + '"'})
                if partial:
                    warnings.append("Foram consultadas somente as 20 ocorrências mais recentes. Para outra ocorrência, informe o link direto da transcrição.")
                if len(records) > 1:
                    warnings.append("Esta sala foi usada mais de uma vez. Selecione a ocorrência pela data; as transcrições não serão combinadas automaticamente.")
                for record in records:
                    parent = record.get("name", "")
                    if not _RECORD.fullmatch(parent):
                        raise GoogleMeetError("Identificador de reunião inesperado na resposta Google.", "response")
                    for collection, kind, dest_name, id_name in (
                            ("transcripts", "transcript", "docsDestination", "document"),
                            ("recordings", "recording", "driveDestination", "file")):
                        artifacts, partial_artifacts = self._list(parent + "/" + collection, collection, 50)
                        if partial_artifacts:
                            warnings.append("Uma ocorrência tem mais de 50 artefatos; informe o link direto para consultar os restantes.")
                        for artifact in artifacts:
                            name = artifact.get("name", "")
                            if not re.fullmatch(re.escape(parent + "/" + collection + "/") + r"[A-Za-z0-9_-]{1,200}", name):
                                raise GoogleMeetError("Artefato inesperado na resposta Google Meet.", "response")
                            dest = artifact.get(dest_name, {})
                            file_id = dest.get(id_name, "")
                            if file_id and not _ID.fullmatch(file_id):
                                raise GoogleMeetError("Arquivo de reunião inesperado na resposta Google.", "response")
                            start = artifact.get("startTime", record.get("startTime", ""))
                            target_url = link["url"]
                            if file_id:
                                target_url = ("https://docs.google.com/document/d/" if kind == "transcript" else "https://drive.google.com/file/d/") + file_id + "/view"
                            candidate = {"id": "meet:" + name, "name": ("Transcrição" if kind == "transcript" else "Gravação") + " · " + start,
                                         "kind": kind, "provider": "meet", "url": target_url, "fileId": file_id,
                                         "conferenceRecord": parent, "meetingCode": link["meetingCode"],
                                         "startTime": start, "endTime": artifact.get("endTime", ""),
                                         "conferenceStartTime": record.get("startTime", ""), "state": artifact.get("state", ""),
                                         "available": bool(file_id and artifact.get("state") == "FILE_GENERATED")}
                            candidates.append(self._remember(candidate))
                if not candidates:
                    warnings.append("Nenhuma gravação/transcrição acessível foi encontrada. O link da sala não garante que existam arquivos. Confira a conta, permissões e se a transcrição foi ativada; registros da API Meet expiram 30 dias após o fim. Um link direto do Drive pode continuar funcionando.")
                elif not any(c["kind"] == "transcript" and c["available"] for c in candidates):
                    warnings.append("Nenhuma transcrição pronta foi encontrada. Uma gravação, por si só, não fornece o texto da reunião.")
            return {"candidates": candidates, "warnings": list(dict.fromkeys(warnings)), "sourceUrl": link["url"]}

    def fetch_transcript(self, candidate: dict | str) -> dict:
        with self._lock:
            candidate_id = candidate.get("id") if isinstance(candidate, dict) else candidate
            selected = self._candidates.get(candidate_id) if isinstance(candidate_id, str) else None
            if not selected:
                raise GoogleMeetError("Consulte o link novamente e selecione uma transcrição da lista.", "selection")
            if selected["kind"] != "transcript":
                raise GoogleMeetError("Uma gravação não contém uma transcrição importável. Informe o Google Doc, TXT, VTT ou SRT.", "format")
            if not selected.get("available") or not selected.get("fileId"):
                raise GoogleMeetError("Esta transcrição ainda não está disponível para importar. Consulte novamente mais tarde.", "pending")
            file_id, resource_key = selected["fileId"], selected.get("_resource_key", "")
            metadata = self._metadata(file_id, resource_key)
            if not _is_text_file(metadata):
                raise GoogleMeetError("O arquivo selecionado não é mais uma transcrição de texto compatível.", "format")
            if metadata.get("capabilities", {}).get("canDownload") is False:
                raise GoogleMeetError("O proprietário não permite baixar/exportar este documento.", "forbidden")
            try:
                if int(metadata.get("size", 0)) > MAX_TEXT_BYTES:
                    raise GoogleMeetError("A transcrição excede o limite local de 4 MiB. Importe um trecho menor.", "size")
            except (ValueError, TypeError):
                raise GoogleMeetError("Tamanho de arquivo inesperado na resposta Google.", "response") from None
            resource_key = resource_key or metadata.get("resourceKey", "")
            if resource_key and not _ID.fullmatch(resource_key):
                raise GoogleMeetError("Chave de arquivo inesperada na resposta Google.", "response")
            headers = {"X-Goog-Drive-Resource-Keys": file_id + "/" + resource_key} if resource_key else {}
            if metadata["mimeType"] == DOC_MIME:
                endpoint = DRIVE_URL + file_id + "/export?" + parse.urlencode({"mimeType": "text/plain"})
            else:
                endpoint = DRIVE_URL + file_id + "?alt=media&supportsAllDrives=true"
            text, warnings = _decode_text(self._api(endpoint, headers, max_bytes=MAX_TEXT_BYTES))
            source = {key: value for key, value in selected.items() if not key.startswith("_")}
            source.update(name=metadata.get("name", selected["name"]), mimeType=metadata["mimeType"],
                          modifiedTime=metadata.get("modifiedTime", ""))
            return {"text": text, "source": source, "warnings": warnings}
