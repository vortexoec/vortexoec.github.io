﻿param([switch]$NoBrowser, [switch]$Janela)
# Abre a Central de Análises: sobe o servidor local (se ainda não estiver no ar) e abre o navegador.
# -Janela: usado pelo atalho e pelo link "central-analises://". Mostra uma janelinha de "Abrindo…"
#          e, se algo der errado, uma mensagem com o motivo (em vez de falhar escondido).
$ErrorActionPreference = 'Stop'
$appRoot = $PSScriptRoot
$appUrl = 'http://localhost:8765'
$healthUrl = 'http://127.0.0.1:8765/api/health'
$runDir = Join-Path $appRoot 'runtime'
$splash = $null

function Show-Splash {
    if (-not $Janela) { return }
    try {
        Add-Type -AssemblyName System.Windows.Forms, System.Drawing
        $form = New-Object System.Windows.Forms.Form
        $form.Text = 'Central de Análises'
        $form.FormBorderStyle = 'FixedDialog'; $form.ControlBox = $false; $form.StartPosition = 'CenterScreen'
        $form.Size = New-Object System.Drawing.Size(360, 130); $form.TopMost = $true; $form.ShowInTaskbar = $true
        $form.BackColor = [System.Drawing.Color]::FromArgb(18, 16, 28)
        $icon = Join-Path $appRoot 'static\central.ico'
        if (Test-Path -LiteralPath $icon) { $form.Icon = New-Object System.Drawing.Icon($icon) }
        $label = New-Object System.Windows.Forms.Label
        $label.Text = "Abrindo a Central de Análises…`nNa primeira vez pode levar até um minuto."
        $label.ForeColor = [System.Drawing.Color]::White
        $label.Font = New-Object System.Drawing.Font('Segoe UI', 10)
        $label.Dock = 'Fill'; $label.TextAlign = 'MiddleCenter'
        $form.Controls.Add($label)
        $form.Show(); [System.Windows.Forms.Application]::DoEvents()
        $script:splash = $form
    } catch { $script:splash = $null }
}
function Pump { if ($script:splash) { [System.Windows.Forms.Application]::DoEvents() } }
function Close-Splash { if ($script:splash) { try { $script:splash.Close() } catch { }; $script:splash = $null } }
function Find-Browser([string]$exe) {
    $keys = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe",
            "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe",
            "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\$exe"
    foreach ($key in $keys) {
        try {
            $path = [string](Get-ItemProperty -Path $key -ErrorAction Stop).'(default)'
            if ($path -and (Test-Path -LiteralPath $path.Trim('"'))) { return $path.Trim('"') }
        } catch { }
    }
    return $null
}
# Abre em janela própria (sem abas nem barra de endereço), como um programa. Usa o Chrome, onde a
# extensão está, e cai para o Edge ou para o navegador padrão.
function Open-App {
    if ($NoBrowser) { return }
    $browser = Find-Browser 'chrome.exe'
    if (-not $browser) { $browser = Find-Browser 'msedge.exe' }
    if ($browser) { Start-Process -FilePath $browser -ArgumentList @("--app=$appUrl", '--window-size=1440,900') }
    else { Start-Process $appUrl }
}
function Test-App {
    try { return (Invoke-RestMethod -Uri $healthUrl -TimeoutSec 2).app -eq 'pronix-beta' } catch { return $false }
}
function Fail([string]$reason) {
    Close-Splash
    $log = Join-Path $runDir 'server-error.log'
    $tail = ''
    if (Test-Path -LiteralPath $log) { $tail = ((Get-Content -LiteralPath $log -Tail 8 -ErrorAction SilentlyContinue) -join "`n").Trim() }
    $text = "A Central de Análises não abriu.`n`n$reason"
    if ($tail) { $text += "`n`nÚltimas linhas do registro:`n$tail" }
    $text += "`n`nTire um print desta mensagem e mande para o suporte."
    try { New-Item -ItemType Directory -Force -Path $runDir | Out-Null; Set-Content -LiteralPath (Join-Path $runDir 'ultimo-erro.txt') -Value $text -Encoding utf8 } catch { }
    if ($Janela) {
        Add-Type -AssemblyName System.Windows.Forms
        [void][System.Windows.Forms.MessageBox]::Show($text, 'Central de Análises', 'OK', 'Error')
        exit 1
    }
    throw $reason
}

try {
    if (Test-App) { Open-App; exit 0 }
    Show-Splash

    $candidatePaths = @(
        (Join-Path (Split-Path $appRoot -Parent) 'python/python.exe'),
        (Join-Path $appRoot '.venv/Scripts/python.exe')
    )
    $pythonCommand = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($pythonCommand -and $pythonCommand.Source -notlike '*WindowsApps*') { $candidatePaths += $pythonCommand.Source }
    $pythonExe = $candidatePaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if (-not $pythonExe) { Fail 'O Python do programa não foi encontrado. Rode o instalador de novo (depois de extrair o ZIP inteiro).' }
    & $pythonExe -c 'import pypdf, openpyxl, reportlab, PIL, websockets' 2>$null
    if ($LASTEXITCODE -ne 0) { Fail 'Faltam bibliotecas do programa. Rode o instalador de novo (depois de extrair o ZIP inteiro).' }
    Pump

    $busy = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($busy) {
        $owner = (Get-Process -Id $busy.OwningProcess -ErrorAction SilentlyContinue).ProcessName
        Fail "A porta 8765 está ocupada por outro programa ($owner). Feche esse programa ou reinicie o computador e tente de novo."
    }

    New-Item -ItemType Directory -Path $runDir -Force | Out-Null
    $process = Start-Process -FilePath $pythonExe -ArgumentList @('app.py') -WorkingDirectory $appRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $runDir 'server.log') -RedirectStandardError (Join-Path $runDir 'server-error.log')
    $process.Id | Set-Content -LiteralPath (Join-Path $runDir 'server.pid')
    # Primeira abertura pode demorar (antivírus conferindo o Python, bibliotecas carregando).
    $deadline = (Get-Date).AddSeconds(90)
    while ((Get-Date) -lt $deadline) {
        for ($i = 0; $i -lt 5; $i++) { Start-Sleep -Milliseconds 100; Pump }
        if (Test-App) { Close-Splash; Open-App; exit 0 }
        if ($process.HasExited) { Fail "O programa fechou logo ao abrir (código $($process.ExitCode))." }
    }
    Fail 'O programa demorou demais para responder (mais de 90 segundos).'
} catch {
    Fail $_.Exception.Message
}
