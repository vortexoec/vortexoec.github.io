// Central de Análises - Vórtex · botões dentro do Hub (lista de planilhas e revisão).
// Só envia ao programa local o endereço da planilha e lê sugestões de parecer.
// "Inserir" preenche o parecer na tela; nunca clica em "Enviar validação".
// Tudo o que a extensão desenha é roxo, para não se confundir com os botões do próprio Hub.
(() => {
  if (window.__pronixHubUi) return;
  window.__pronixHubUi = true;
  const SHEET = /^https:\/\/pronixhub\.com\.br\/validacao-planilhas\/[A-Za-z0-9_-]{1,128}\/?$/;
  const LIST = /^https:\/\/pronixhub\.com\.br\/validacao-planilhas\/?$/;
  const MARK = "data-pronix-ui";
  const APP_URL = "http://localhost:8765/";
  const ICONS = {validado: "🟢", atencao: "🟡", invalidado: "🔴"};
  const LABELS = {validado: "Validado", atencao: "Atenção", invalidado: "Invalidado"};
  const STEPS = [["open", "Abrindo a planilha"], ["read", "Lendo os produtos"], ["send", "Enviando à Central"], ["analyze", "Analisando o mercado"]];
  let lastUrl = "", suggestionTimer = null, suggestions = null, suggestionsFor = "";

  const cleanUrl = value => String(value || "").split(/[?#]/)[0];
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  const send = message => new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage(message, reply => {
        if (chrome.runtime.lastError) return reject(new Error("A extensão foi atualizada. Recarregue esta página (F5)."));
        if (!reply?.ok) return reject(new Error(reply?.error || "Não foi possível concluir."));
        resolve(reply.data);
      });
    } catch { reject(new Error("A extensão foi atualizada. Recarregue esta página (F5).")); }
  });
  const el = (tag, className = "", text = "") => { const node = document.createElement(tag); if (className) node.className = className; if (text) node.textContent = text; node.setAttribute(MARK, "1"); return node; };
  // Ícones próprios (raio, visto, relógio), sempre na cor do texto do botão.
  const SHAPES = {bolt: "M7.4 0 1.6 7.2h3.6L4.2 12l6.2-7.4H6.6L7.4 0z", check: "M4.6 9.6 1.4 6.4l1.2-1.2 2 2 4.8-4.8 1.2 1.2-6 6z", clock: "M6 1a5 5 0 1 0 0 10A5 5 0 0 0 6 1zm.6 5.3 2 1.2-.6 1-2.6-1.6V3.4h1.2v2.9z", redo: "M6 2a4 4 0 0 1 3.6 2.2l1-1V6.4H7.4l1.3-1.3A2.8 2.8 0 1 0 8.7 7.4h1.3A4 4 0 1 1 6 2z"};
  function glyph(name) {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 12 12"); svg.setAttribute("width", "12"); svg.setAttribute("height", "12"); svg.setAttribute("aria-hidden", "true"); svg.setAttribute(MARK, "1");
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", SHAPES[name] || SHAPES.bolt); path.setAttribute("fill", "currentColor");
    svg.appendChild(path); svg.style.flex = "0 0 12px";
    return svg;
  }
  const label = (node, text, icon = "") => { node.replaceChildren(...(icon ? [glyph(icon)] : []), text); };

  const style = document.createElement("style");
  style.textContent = `
  .pronix-btn{all:unset;box-sizing:border-box;display:inline-flex;align-items:center;gap:6px;cursor:pointer;font:600 12px/1.2 "Segoe UI",Arial,sans-serif;
    color:#fff;background:#7030ff;border:1px solid #6226e6;border-radius:8px;padding:6px 11px;white-space:nowrap;box-shadow:0 1px 2px #7030ff33}
  .pronix-btn:hover{background:#5f22e6}.pronix-btn[disabled]{opacity:.65;cursor:wait}
  .pronix-btn.done,.pronix-btn.soft{background:#f3eeff;border-color:#d9c8ff;color:#5a22d6;box-shadow:none}.pronix-btn.done:hover,.pronix-btn.soft:hover{background:#e9e0ff}
  .pronix-btn.error{background:#fff1f0;border-color:#efd5d2;color:#a4544d;box-shadow:none}.pronix-btn.small{padding:4px 9px;font-size:11px}
  .pronix-btn.plain{background:#fff;border-color:#d9d0ee;color:#4a2fa8;box-shadow:none}.pronix-btn.plain:hover{background:#f7f3ff}
  .pronix-tip{box-sizing:border-box;margin:10px 0;padding:12px 14px;border-radius:12px;border:1px solid #d9c8ff;background:#f8f5ff;font:13px/1.55 "Segoe UI",Arial,sans-serif;color:#3d3654;position:relative}
  .pronix-tip:before{content:"";position:absolute;left:22px;top:-7px;width:12px;height:12px;background:#f8f5ff;border-left:1px solid #d9c8ff;border-top:1px solid #d9c8ff;transform:rotate(45deg)}
  .pronix-tip-head{display:flex;align-items:center;gap:8px;margin-bottom:6px;font-weight:650;color:#5a22d6}
  .pronix-tip-head .pronix-btn{margin-left:auto}.pronix-tip-msg{white-space:pre-wrap;color:#3d3654}
  .pronix-tip.wait{border-color:#e4def2;background:#faf9fd;color:#77718a}.pronix-tip.wait:before{background:#faf9fd;border-color:#e4def2}.pronix-tip.wait .pronix-tip-head{color:#77718a;margin-bottom:0}
  .pronix-panel{all:initial;position:fixed;right:22px;bottom:22px;z-index:2147483000;box-sizing:border-box;width:340px;max-width:calc(100vw - 24px);background:#fff;border:1px solid #e4def2;border-top:3px solid #7030ff;border-radius:16px;
    box-shadow:0 18px 60px rgba(40,20,100,.28);padding:15px 18px 16px;font:13px/1.5 "Segoe UI",Arial,sans-serif;color:#34304a}
  .pronix-panel *{box-sizing:border-box;font-family:inherit}
  .pronix-panel-head{display:flex;align-items:center;gap:8px;font-size:14px;font-weight:700;color:#2a1b5e}
  .pronix-panel-head svg{color:#7030ff;width:14px;height:14px}
  .pronix-panel-close{all:unset;margin-left:auto;cursor:pointer;width:24px;height:24px;border-radius:7px;text-align:center;font-size:18px;line-height:22px;color:#8a84a0}
  .pronix-panel-close:hover{background:#f3eeff}
  .pronix-panel-name{color:#77718a;font-size:12px;margin-top:1px}
  .pronix-panel-steps{list-style:none;margin:12px 0 0;padding:0}
  .pronix-panel-steps li{display:flex;align-items:flex-start;gap:10px;padding:5px 0;color:#a9a3bd}
  .pronix-panel-steps li.run{color:#2a1b5e;font-weight:650}.pronix-panel-steps li.done{color:#5a22d6}.pronix-panel-steps li.error{color:#a83b35;font-weight:650}
  .pronix-panel-ico{flex:0 0 20px;height:20px;border-radius:50%;border:1.5px solid currentColor;font-size:11px;line-height:17px;text-align:center;font-weight:700}
  .pronix-panel-steps li.run .pronix-panel-ico{border-color:#d9c8ff;border-top-color:#7030ff;animation:pronix-spin .8s linear infinite}
  .pronix-panel-steps li.done .pronix-panel-ico{background:#f3eeff;border-color:#d9c8ff}
  .pronix-panel-note{margin:10px 0 0;color:#77718a;font-size:12px}
  .pronix-panel-error{margin:10px 0 0;padding:9px 11px;border-radius:10px;background:#fff1f0;border:1px solid #efd5d2;color:#8f3a34;font-size:12.5px}
  .pronix-panel-result{margin:12px 0 0;padding:10px 12px;border-radius:10px;background:#f3eeff;border:1px solid #d9c8ff;color:#4a1fc0;font-weight:650}
  .pronix-panel-actions{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap}
  .pronix-panel-actions a{text-decoration:none}
  @keyframes pronix-spin{to{transform:rotate(360deg)}}
  .pronix-coach-dim{position:fixed;inset:0;z-index:2147482985;pointer-events:none;background:rgba(18,10,40,.6)}
  .pronix-coach-ring{position:fixed;z-index:2147482990;pointer-events:none;border-radius:10px;box-shadow:0 0 0 3px #7030ff,0 0 0 8px rgba(112,48,255,.3)}
  .pronix-coach{all:initial;position:fixed;z-index:2147482995;box-sizing:border-box;width:300px;max-width:calc(100vw - 24px);background:#fff;border-radius:14px;border-top:3px solid #7030ff;padding:14px 16px;
    box-shadow:0 18px 60px rgba(40,20,100,.3);font:13px/1.5 "Segoe UI",Arial,sans-serif;color:#3d3654}
  .pronix-coach strong{display:block;font-size:15px;color:#2a1b5e;margin-bottom:4px}
  .pronix-coach .pronix-btn{margin-top:10px}`;
  document.documentElement.appendChild(style);

  function button(text, onClick, extra = "", icon = "") {
    const b = document.createElement("button");
    b.type = "button"; b.className = "pronix-btn " + extra; b.setAttribute(MARK, "1");
    label(b, text, icon);
    b.addEventListener("click", event => { event.preventDefault(); event.stopPropagation(); onClick(b); });
    return b;
  }

  // ── Painel de andamento: mostra cada etapa da importação e avisa quando a análise termina. ──
  const job = {url: "", stage: "", error: "", done: false, detail: "", message: "", name: "", counts: null, timer: null, misses: 0, idle: 0, button: null};
  let panel = null;
  const jobBusy = () => !!job.url && !job.done && !job.error;
  // A importação continua visível se a pessoa trocar de página no Hub (lista → planilha).
  const JOB_KEY = "pronix-import-job";
  const jobSave = () => { try { jobBusy() && job.stage === "analyze" ? sessionStorage.setItem(JOB_KEY, JSON.stringify({url: job.url, name: job.name, detail: job.detail, at: Date.now()})) : sessionStorage.removeItem(JOB_KEY); } catch { /* opcional */ } };
  function jobRestore() {
    let saved = null;
    try { saved = JSON.parse(sessionStorage.getItem(JOB_KEY) || "null"); } catch { /* ignora */ }
    if (!saved || !SHEET.test(saved.url) || Date.now() - saved.at > 30 * 60000 || job.url) return;
    Object.assign(job, {url: saved.url, stage: "analyze", error: "", done: false, detail: saved.detail || "", message: "", name: saved.name || "", counts: null, misses: 0, idle: 0, button: null});
    panelRender(); pollJob();
  }
  // Mensagens do programa em linguagem simples (sem nomes internos de consultas).
  const plain = text => String(text || "").replace(/(JoomPulse):\s*[a-z0-9_]+\s*$/i, "$1…").slice(0, 160);

  function panelClose() { panel?.remove(); panel = null; if (!jobBusy()) { job.url = ""; jobSave(); } }

  function panelRender() {
    if (!job.url) return;
    if (!panel) { panel = el("div", "pronix-panel"); panel.setAttribute("role", "status"); panel.setAttribute("aria-live", "polite"); document.documentElement.appendChild(panel); }
    panel.replaceChildren();
    const head = el("div", "pronix-panel-head");
    head.append(glyph(job.done ? "check" : "bolt"), job.done ? "Planilha analisada pela Central" : job.error ? "Importação interrompida" : "Importando para a Central");
    const close = el("button", "pronix-panel-close", "×"); close.type = "button"; close.title = "Fechar este aviso"; close.addEventListener("click", panelClose);
    head.append(close); panel.append(head);
    if (job.name) panel.append(el("div", "pronix-panel-name", job.name));
    const list = el("ol", "pronix-panel-steps"), at = STEPS.findIndex(step => step[0] === job.stage);
    STEPS.forEach(([, text], index) => {
      const state = job.done || index < at ? "done" : index === at ? (job.error ? "error" : "run") : "todo";
      const item = el("li", state);
      item.append(el("span", "pronix-panel-ico", state === "done" ? "✓" : state === "error" ? "!" : state === "run" ? "" : String(index + 1)),
        el("span", "", text + (index === at && job.detail && !job.done && !job.error ? " · " + job.detail : "")));
      list.append(item);
    });
    panel.append(list);
    const actions = el("div", "pronix-panel-actions");
    if (job.error) {
      panel.append(el("p", "pronix-panel-error", job.error));
      const url = job.url, source = job.button;
      actions.append(button("Tentar de novo", () => { job.url = ""; importSheet(url, source?.isConnected ? source : button("", () => {})); }, "small", "redo"));
    } else if (job.done) {
      const c = job.counts || {};
      const parts = [["validado", "🟢"], ["atencao", "🟡"], ["invalidado", "🔴"]].filter(([key]) => c[key]).map(([key, icon]) => `${c[key]} ${icon}`);
      panel.append(el("p", "pronix-panel-result", "Análise pronta" + (parts.length ? ": " + parts.join(" · ") : ".")));
      if (cleanUrl(location.href) === job.url) panel.append(el("p", "pronix-panel-note", "As sugestões já aparecem em cada produto, com o botão Inserir."));
      else { const open = el("a", "pronix-btn small", "Abrir a planilha"); open.href = job.url; actions.append(open); }
    } else {
      if (job.message) panel.append(el("p", "pronix-panel-note", job.message));
      panel.append(el("p", "pronix-panel-note", job.stage === "analyze" ? "Pode continuar usando o Hub. Este painel avisa quando terminar." : "Aguarde alguns segundos, sem fechar esta página."));
    }
    if (job.done || job.error || job.stage === "analyze") { const app = el("a", "pronix-btn small plain", "Abrir a Central"); app.href = APP_URL; app.target = "_blank"; app.rel = "noopener noreferrer";
      // Vai para a janela do programa em vez de abrir a Central como aba do Chrome.
      app.addEventListener("click", event => { event.preventDefault(); send({type: "hub_open_app"}).catch(() => { window.open(APP_URL, "_blank", "noopener"); }); });
      actions.append(app); }
    if (actions.childElementCount) panel.append(actions);
  }

  async function importSheet(url, b) {
    if (jobBusy()) { panelRender(); return; }
    clearTimeout(job.timer);
    Object.assign(job, {url, stage: "open", error: "", done: false, detail: "", message: "", name: "", counts: null, misses: 0, idle: 0, button: b});
    b.disabled = true; b.className = "pronix-btn small soft"; label(b, "Importando…", "clock");
    panelRender();
    try {
      const data = await send({type: "hub_import", url});
      const amount = `${data.products} produto${data.products === 1 ? "" : "s"}`;
      job.stage = "analyze"; job.name = data.clientName || ""; job.detail = amount;
      b.disabled = false; b.dataset.pronixState = "running";
      label(b, `Na Central · ${amount} em análise`, "clock");
      panelRender(); jobSave();
      if (cleanUrl(location.href) === url) scheduleSuggestions(4000);
      job.timer = setTimeout(pollJob, 3000);
    } catch (error) {
      job.error = error.message; panelRender();
      b.className = "pronix-btn small error"; label(b, "Não importou");
      setTimeout(() => {
        if (!b.isConnected) return;
        delete b.dataset.pronixPainted;
        if (b.dataset.pronixSheet) { b.disabled = false; b.className = "pronix-btn small"; label(b, "Importar na Central", "bolt"); } else paintButton(b, sheetStates[url]);
      }, 4000);
    }
  }

  async function pollJob() {
    clearTimeout(job.timer);
    if (!jobBusy()) return;
    try {
      const data = await send({type: "hub_suggestions", url: job.url});
      job.misses = 0;
      if (data?.running) {
        const progress = data.progress || {};
        job.message = plain(progress.message);
        if (progress.total && progress.completed) job.detail = `${progress.completed} de ${progress.total} produtos`;
      } else if (data?.found && data.collected) {
        job.done = true; job.message = ""; job.counts = {};
        for (const product of data.products || []) if (product.status) job.counts[product.status] = (job.counts[product.status] || 0) + 1;
        sheetStates[job.url] = {collected: true, running: false, counts: job.counts};
        if (job.button?.isConnected && !job.button.dataset.pronixSheet) { delete job.button.dataset.pronixPainted; paintButton(job.button, sheetStates[job.url]); }
        if (cleanUrl(location.href) === job.url) scheduleSuggestions(200);
      } else if (data?.failed) job.error = data.failed;
      else if (++job.idle > 5) job.error = "A análise não começou. Abra a Central e confira se a JoomPulse está conectada.";
    } catch (error) {
      if (++job.misses > 4) job.error = error.message || "A Central parou de responder.";
    }
    panelRender(); jobSave();
    if (jobBusy()) job.timer = setTimeout(pollJob, 4000);
  }

  // Etapas enviadas pela extensão enquanto abre, lê e envia a planilha.
  chrome.runtime.onMessage.addListener(message => {
    if (message?.type !== "pronix_import_stage" || message.url !== job.url || !jobBusy()) return;
    const next = STEPS.findIndex(step => step[0] === message.stage), now = STEPS.findIndex(step => step[0] === job.stage);
    if (next > now) { job.stage = message.stage; panelRender(); }
  });

  // ── Primeira vez na lista: destaca o botão e explica o que ele faz. ──
  let coachTimer = null;
  const FRESH = 'tbody tr .pronix-btn:not([data-pronix-state="done"]):not([data-pronix-state="running"])';   // planilha ainda não importada
  function coach() {
    try { if (localStorage.getItem("pronix-coach-import")) return; } catch { return; }
    if (coachTimer || jobBusy()) return;
    const dim = el("div", "pronix-coach-dim"), ring = el("div", "pronix-coach-ring"), balloon = el("div", "pronix-coach");
    balloon.append(el("strong", "", "Importe com um clique"),
      el("span", "", "Os botões roxos são da Central de Análises. Este envia a planilha para a Central: a análise começa sozinha e um painel no canto da tela mostra o andamento."));
    const close = () => { clearInterval(coachTimer); coachTimer = -1; dim.remove(); ring.remove(); balloon.remove(); try { localStorage.setItem("pronix-coach-import", "1"); } catch { /* opcional */ } };
    const ok = button("Entendi", close, "small"); ok.style.display = "flex"; ok.style.width = "fit-content";
    balloon.append(ok);
    document.documentElement.append(dim, ring, balloon);
    const position = () => {
      const target = document.querySelector(FRESH);
      if (!target || !LIST.test(cleanUrl(location.href))) { dim.style.display = ring.style.display = balloon.style.display = "none"; return; }
      if (target.disabled) return close();
      const r = target.getBoundingClientRect();
      const x1 = Math.floor(r.left - 6), y1 = Math.floor(r.top - 6), x2 = Math.ceil(r.right + 6), y2 = Math.ceil(r.bottom + 6);
      // Tela escurecida com um recorte no lugar do botão.
      dim.style.display = "";
      dim.style.clipPath = `polygon(evenodd, 0 0, 100% 0, 100% 100%, 0 100%, 0 0, ${x1}px ${y1}px, ${x2}px ${y1}px, ${x2}px ${y2}px, ${x1}px ${y2}px, ${x1}px ${y1}px)`;
      ring.style.cssText = `left:${x1}px;top:${y1}px;width:${x2 - x1}px;height:${y2 - y1}px`;
      const top = r.bottom + 14 + balloon.offsetHeight > window.innerHeight ? Math.max(8, r.top - 14 - balloon.offsetHeight) : r.bottom + 14;
      balloon.style.left = Math.max(12, Math.min(r.left, window.innerWidth - 312)) + "px"; balloon.style.top = top + "px"; balloon.style.display = "";
    };
    coachTimer = setInterval(position, 200); position();
  }

  // ── Lista: cada planilha em aberto mostra se já foi analisada pela Central. ──
  let sheetStates = {}, statesAt = 0, statesBusy = false;

  function paintButton(b, state) {
    if (b === job.button && jobBusy()) return;
    const next = state?.collected ? "done" : state?.running ? "running" : "";
    if (b.dataset.pronixState === next && b.dataset.pronixPainted) return;
    b.dataset.pronixState = next; b.dataset.pronixPainted = "1"; b.disabled = false;
    if (next === "done") {
      const c = state.counts || {};
      const parts = [["validado", "🟢"], ["atencao", "🟡"], ["invalidado", "🔴"], ["pendente", "⏳"]].filter(([key]) => c[key]).map(([key, icon]) => `${c[key]}${icon}`);
      b.className = "pronix-btn small done"; b.title = "Abrir a planilha com as sugestões da Central";
      label(b, "Analisado pela Central" + (parts.length ? " · " + parts.join(" ") : ""), "check");
    } else if (next === "running") {
      b.className = "pronix-btn small soft"; b.title = "A Central está analisando esta planilha"; label(b, "Central analisando…", "clock");
    } else {
      b.className = "pronix-btn small"; b.title = "Enviar esta planilha para a Central de Análises"; label(b, "Importar na Central", "bolt");
    }
  }

  async function refreshStates(force = false) {
    if (statesBusy || document.hidden || (!force && Date.now() - statesAt < 30000)) return;
    const urls = [...new Set([...document.querySelectorAll("tbody tr [data-pronix-url]")].map(b => b.dataset.pronixUrl))];
    if (!urls.length) return;
    statesBusy = true; statesAt = Date.now();
    try { sheetStates = (await send({type: "hub_sheets", urls})).sheets || {}; } catch { /* Central fechada: os botões continuam como Importar */ }
    statesBusy = false;
    for (const b of document.querySelectorAll("tbody tr [data-pronix-url]")) paintButton(b, sheetStates[b.dataset.pronixUrl]);
  }

  function openSheet(url, row) {
    const link = row?.querySelector('a[href*="/validacao-planilhas/"]');
    if (link) link.click(); else location.assign(url);
  }

  // Lista: um botão em cada planilha ainda não concluída, na coluna do prazo.
  function decorateList() {
    let added = false;
    for (const row of document.querySelectorAll("tbody tr")) {
      if (row.querySelector(`[${MARK}]`)) continue;
      const cells = row.children, link = row.querySelector('a[href*="/validacao-planilhas/"]');
      if (cells.length < 5 || !link) continue;
      if (/conclu/i.test(cells[1].textContent)) continue;
      const url = cleanUrl(new URL(link.getAttribute("href"), location.origin).href);
      if (!SHEET.test(url)) continue;
      // Ao lado da data do prazo, no espaço vazio até "Avaliados" (sem mexer nos elementos do Hub).
      const cell = cells[3];
      cell.style.whiteSpace = "nowrap";
      for (const child of cell.children) if (!child.hasAttribute(MARK) && getComputedStyle(child).display === "block") child.style.display = "inline-block";
      const holder = document.createElement("span");
      holder.setAttribute(MARK, "1");
      holder.style.cssText = "display:inline-flex;vertical-align:middle;margin-left:14px";
      // Já analisada: o clique abre a planilha com os balões. Senão, importa.
      const b = button("Importar na Central", node => (node.dataset.pronixState === "done" || node.dataset.pronixState === "running" ? openSheet(url, node.closest("tr")) : importSheet(url, node)), "small", "bolt");
      b.dataset.pronixUrl = url; b.title = "Enviar esta planilha para a Central de Análises";
      if (sheetStates[url]) paintButton(b, sheetStates[url]);
      holder.appendChild(b); cell.appendChild(holder); added = true;
    }
    void refreshStates(added);
    if (statesAt && !statesBusy && document.querySelector(FRESH)) coach();
  }

  // Planilha: botão ao lado do revisor + balões de sugestão em cada produto.
  function decorateSheet() {
    const url = cleanUrl(location.href);
    const reviewer = [...document.querySelectorAll("header p")].find(p => /revisor:/i.test(p.textContent));
    if (reviewer && !reviewer.parentElement.querySelector(`[${MARK}]`)) {
      const b = button("Importar na Central", node => importSheet(url, node), "small", "bolt");
      b.dataset.pronixSheet = "1"; b.style.marginLeft = "12px"; b.style.verticalAlign = "middle";
      reviewer.appendChild(b);
    }
    if (suggestionsFor !== url) { suggestionsFor = url; suggestions = null; scheduleSuggestions(500); }
    renderTips();
  }

  function scheduleSuggestions(delay) {
    clearTimeout(suggestionTimer);
    suggestionTimer = setTimeout(loadSuggestions, delay);
  }

  async function loadSuggestions() {
    const url = cleanUrl(location.href);
    if (!SHEET.test(url)) return;
    try {
      suggestions = await send({type: "hub_suggestions", url});
    } catch { suggestions = {found: false, offline: true}; }
    if (suggestionsFor !== url) return;
    renderTips();
    // Com análise pronta, o botão do cabeçalho passa a oferecer uma nova análise.
    const again = document.querySelector("[data-pronix-sheet]");
    if (again && !(again === job.button && jobBusy())) {
      const ready = suggestions?.found && suggestions.collected && !suggestions.running;
      again.className = "pronix-btn small" + (ready ? " plain" : ""); again.disabled = false;
      label(again, ready ? "Analisar de novo na Central" : "Importar na Central", ready ? "redo" : "bolt");
    }
    if (suggestions?.running || (suggestions?.found && !suggestions.collected)) scheduleSuggestions(8000);
  }

  const mlId = value => (String(value || "").match(/MLB-?(\d{6,15})/i) || [])[1] || "";

  function setTextarea(textarea, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set;
    setter.call(textarea, value);
    textarea.dispatchEvent(new Event("input", {bubbles: true}));
    textarea.dispatchEvent(new Event("change", {bubbles: true}));
  }

  // Marca o parecer e só depois escreve o texto: se os dois forem juntos, o Hub perde a marcação.
  async function insertReview(article, product, node) {
    const text = product.message.slice(0, 1000);
    const pick = () => [...article.querySelectorAll("button[aria-pressed]")].find(b => b.textContent.includes(LABELS[product.status]));
    const pressed = () => pick()?.getAttribute("aria-pressed") === "true";
    const area = () => article.querySelector("textarea");
    node.disabled = true; label(node, "Inserindo…", "clock");
    for (let attempt = 0; attempt < 2 && !pressed(); attempt++) {
      pick()?.click();
      for (let i = 0; i < 20 && !pressed(); i++) await wait(100);
    }
    await wait(350);                       // o Hub pode escrever o próprio texto sugerido ao marcar o parecer
    for (let attempt = 0; attempt < 3; attempt++) {
      if (area() && area().value !== text) setTextarea(area(), text);
      await wait(500);
      if (area()?.value === text && pressed()) break;
      if (!pressed()) { pick()?.click(); await wait(400); }
    }
    const ok = area()?.value === text && pressed();
    node.disabled = false; node.className = "pronix-btn small " + (ok ? "done" : "error");
    label(node, ok ? "Inserido" : "Confira o parecer e o texto", ok ? "check" : "");
    if (ok) area().focus();
  }

  function renderTips() {
    const articles = [...document.querySelectorAll("article")];
    articles.forEach((article, position) => {
      const textarea = article.querySelector("textarea");
      if (!textarea) return;
      let tip = article.querySelector(".pronix-tip");
      const products = suggestions?.products || [];
      const tag = [...article.querySelectorAll("span")].find(s => /^Produto\s+\d+$/i.test(s.textContent.trim()));
      const index = tag ? Number(tag.textContent.replace(/\D/g, "")) : position + 1;
      let product = products.find(p => p.index === index);
      const refLink = [...article.querySelectorAll("a")].map(a => a.href).find(h => /mercadolivre|mercadolibre/.test(h));
      if (product && mlId(product.reference) && mlId(refLink) && mlId(product.reference) !== mlId(refLink)) product = null;
      if (!suggestions?.found) { tip?.remove(); return; }
      if (!tip) {
        tip = document.createElement("div");
        tip.className = "pronix-tip"; tip.setAttribute(MARK, "1"); tip.setAttribute("aria-hidden", "true");
        textarea.parentElement.insertBefore(tip, textarea);
      }
      const ready = product && product.status && product.message && suggestions.collected && !suggestions.running;
      const signature = JSON.stringify([ready, product?.status, product?.message, !!suggestions.running, product?.pending]);
      if (tip.dataset.sig === signature) return;
      tip.dataset.sig = signature;
      tip.className = "pronix-tip" + (ready ? "" : " wait");
      tip.replaceChildren();
      const head = document.createElement("div"); head.className = "pronix-tip-head";
      if (!ready) {
        head.append(glyph("clock"), suggestions.running ? "A Central está analisando este produto…" : product?.pending === "quota" ? "Central: limite de consultas por hora atingido. Este produto será analisado sozinho na próxima hora." : "Central: sugestão ainda não disponível para este produto.");
        tip.appendChild(head); return;
      }
      head.append(glyph("bolt"), `Sugestão da Central: ${ICONS[product.status] || ""} ${LABELS[product.status] || product.label || ""}`);
      head.appendChild(button("Inserir", node => void insertReview(article, product, node), "small"));
      const msg = document.createElement("div"); msg.className = "pronix-tip-msg"; msg.textContent = product.message;
      tip.append(head, msg);
    });
  }

  function tick() {
    const url = cleanUrl(location.href);
    if (url !== lastUrl) { lastUrl = url; }
    if (LIST.test(url)) decorateList();
    else if (SHEET.test(url)) decorateSheet();
  }
  new MutationObserver(() => { clearTimeout(tick.t); tick.t = setTimeout(tick, 250); }).observe(document.documentElement, {childList: true, subtree: true});
  setInterval(tick, 1500);
  tick();
  jobRestore();
})();
