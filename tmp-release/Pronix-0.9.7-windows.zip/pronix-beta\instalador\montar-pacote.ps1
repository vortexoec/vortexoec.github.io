﻿# Monta o pacote de instalação do Pronix para Windows (64 bits).
# Uso (na pasta pronix-beta):  powershell -ExecutionPolicy Bypass -File instalador\montar-pacote.ps1
# Resultado: dist\Pronix-<versão>-windows.zip (+ .sha256), com Python próprio e bibliotecas.
# Só entram arquivos versionados no Git: nada de runtime, relatórios de clientes ou credenciais.
param([string]$PythonVersion = '3.12.10')
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$version = (Get-Content -LiteralPath (Join-Path $root 'VERSION') -Raw).Trim()
$dist = Join-Path $root 'dist'
$cache = Join-Path $dist 'cache'
$name = "Pronix-$version-windows"
$stage = Join-Path $dist $name
New-Item -ItemType Directory -Force -Path $cache | Out-Null
if (Test-Path $stage) { Remove-Item -Recurse -Force $stage }
New-Item -ItemType Directory -Force -Path $stage | Out-Null

# 1) Python oficial (pacote "embeddable"), conferindo a assinatura da Python Software Foundation.
$embed = Join-Path $cache "python-$PythonVersion-embed-amd64.zip"
if (-not (Test-Path $embed)) {
    Write-Host "Baixando Python $PythonVersion de python.org…"
    Invoke-WebRequest -UseBasicParsing -Uri "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-embed-amd64.zip" -OutFile $embed
}
$py = Join-Path $stage 'python'
Expand-Archive -LiteralPath $embed -DestinationPath $py
foreach ($file in 'python.exe', 'pythonw.exe', 'python312.dll') {
    $sig = Get-AuthenticodeSignature (Join-Path $py $file)
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Python Software Foundation') { throw "Assinatura inválida em $file. Pacote cancelado." }
}
# O Python embutido só enxerga o que está no arquivo ._pth: bibliotecas + pasta do programa.
$pth = Get-ChildItem $py -Filter 'python*._pth' | Select-Object -First 1
$lines = (Get-Content $pth.FullName) | ForEach-Object { if ($_ -eq '#import site') { 'import site' } else { $_ } }
$lines += 'Lib\site-packages'; $lines += '..\pronix-beta'
Set-Content -LiteralPath $pth.FullName -Value $lines -Encoding ascii

# 2) Bibliotecas do requirements.txt, em versões binárias para Windows/Python 3.12.
# Precisa de um Python com pip instalado no Windows (qualquer versão 3.x); ele só baixa as bibliotecas.
$builder = $null
foreach ($candidate in @((Get-Command python.exe -ErrorAction SilentlyContinue | Where-Object { $_.Source -notlike '*WindowsApps*' } | Select-Object -First 1 -ExpandProperty Source), (Join-Path $root '.venv\Scripts\python.exe'))) {
    if ($candidate -and (Test-Path $candidate)) {
        & $candidate -m pip --version *> $null
        if ($LASTEXITCODE -eq 0) { $builder = $candidate; break }
    }
}
if (-not $builder) { throw 'Instale o Python (python.org) com pip para montar o pacote.' }
& $builder -m pip install --disable-pip-version-check --quiet --target (Join-Path $py 'Lib\site-packages') `
    --only-binary=:all: --platform win_amd64 --python-version 3.12 --implementation cp -r (Join-Path $root 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Falha ao instalar as bibliotecas.' }

# 3) Programa: somente arquivos versionados, sem testes.
$app = Join-Path $stage 'pronix-beta'
New-Item -ItemType Directory -Force -Path $app | Out-Null
$tar = Join-Path $dist 'app.tar'
git -C $root archive --format=tar -o $tar HEAD -- . ':(exclude)tests' ':(exclude)extension/pronix-hub/tests' ':(exclude)PARA-CONTINUAR-NO-CLAUDE.md'
if ($LASTEXITCODE -ne 0) { throw 'Falha ao exportar os arquivos do Git (faça commit antes de montar o pacote).' }
& (Join-Path $env:SystemRoot 'System32\tar.exe') -xf $tar -C $app
if ($LASTEXITCODE -ne 0 -or -not (Test-Path (Join-Path $app 'app.py'))) { throw 'Falha ao extrair os arquivos do programa.' }
Remove-Item $tar

# 4) Instalador e atalhos.
Copy-Item (Join-Path $PSScriptRoot 'Instalar Central de Analises.cmd') $stage
Copy-Item (Join-Path $PSScriptRoot 'instalar.ps1') $stage
Copy-Item (Join-Path $PSScriptRoot 'LEIA-ME.txt') $stage

# 5) Teste rápido: o Python do pacote carrega o programa e as bibliotecas.
& (Join-Path $py 'python.exe') -c "import pypdf, openpyxl, reportlab, PIL, websockets, jwt, cryptography; import services.market_auto, services.mercadolivre; print('ok')"
if ($LASTEXITCODE -ne 0) { throw 'O Python do pacote não conseguiu carregar o programa.' }

# 6) Compacta em dois pacotes:
#    - Pronix-<versão>-windows.zip: sem dados de aplicativo. É o que vai para o GitHub (atualizações).
#    - Pronix-<versão>-windows-equipe.zip: com os aplicativos do Mercado Livre e da JoomPulse embutidos,
#      para a primeira instalação. Entregue só para a equipe; não publique.
$zip = Join-Path $dist "$name.zip"
if (Test-Path $zip) { Remove-Item $zip }
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -CompressionLevel Optimal
$hash = (Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
Set-Content -LiteralPath "$zip.sha256" -Value "$hash  $name.zip" -Encoding ascii
Write-Host "Pacote de atualização (GitHub): $zip"
Write-Host "SHA256: $hash"

& $builder (Join-Path $PSScriptRoot 'embutir_conexoes.py') $app
if ($LASTEXITCODE -ne 0) { throw 'Falha ao embutir as conexões.' }
if (Test-Path (Join-Path $app 'resources\conexoes.bin')) {
    $team = Join-Path $dist "Central-de-Analises-$version-equipe.zip"
    if (Test-Path $team) { Remove-Item $team }
    Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $team -CompressionLevel Optimal
    Write-Host "Pacote da equipe (primeira instalação, não publicar): $team"

    # Instalador .exe (Inno Setup), com as conexões embutidas: é o que vai para o link de download.
    $iscc = @("$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe", "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
    if ($iscc) {
        & $iscc /Q "/DVersao=$version" "/DPacote=$stage" "/DSaida=$dist" (Join-Path $PSScriptRoot 'setup\central.iss')
        if ($LASTEXITCODE -ne 0) { throw 'Falha ao gerar o instalador .exe.' }
        Write-Host "Instalador .exe (link de download da equipe): $(Join-Path $dist "Instalar-Central-de-Analises-$version.exe")"
    } else {
        Write-Host 'Inno Setup não encontrado: o instalador .exe não foi gerado (winget install JRSoftware.InnoSetup).'
    }
}
