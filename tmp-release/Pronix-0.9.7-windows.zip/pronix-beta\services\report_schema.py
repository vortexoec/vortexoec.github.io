"""Validation for editable visual blocks and charts, without touching source data."""
import math
import re
import uuid
from urllib.parse import urlsplit


def safe_link(url):
    if not url: return ''
    try:
        if len(str(url))>4096 or any(ord(c)<32 for c in str(url)): return ''
        p=urlsplit(str(url))
        if p.scheme=='https' and p.hostname and not p.username and not p.password and (p.port is None or 1<=p.port<=65535):
            return str(url)
    except ValueError: pass
    return ''


def _text(value,limit=12000):
    return str(value or '')[:limit]


def _images(items):
    if not isinstance(items,list) or len(items)>6:
        raise ValueError('Cada card ou seção aceita até 6 imagens.')
    for image in items:
        if not isinstance(image,dict) or not re.fullmatch(r'[a-f0-9]{32}',str(image.get('id',''))):
            raise ValueError('Referência de imagem inválida.')
        image['url']='/api/assets/'+image['id']
        image['caption']=_text(image.get('caption'),2000)
    return items


def is_market_report(report):
    return report.get('reportType') == 'market' or (report.get('reportType') != 'reputation'
        and bool((report.get('marketAnalysis') or {}).get('products'))
        and not report.get('sheetId') and not report.get('accountId'))


def validate_visual(report):
    report.setdefault('reportType','performance')
    if is_market_report(report): report['reportType']='market'
    if report['reportType'] not in ('reputation','performance','market'):
        raise ValueError('Escolha Mercado, Reputação ou Conta em operação.')
    report['showDetails']=report.get('showDetails',False) is True
    if 'summary' in report:
        if not isinstance(report['summary'],dict): raise ValueError('Resumo inválido.')
        report['summary']={'headline':_text(report['summary'].get('headline'),400),'body':_text(report['summary'].get('body'),6000)}
    cards=report.get('actionCards',[])
    if not isinstance(cards,list) or len(cards)>1000: raise ValueError('O relatório aceita até 1.000 cards; divida a fonte para analisar todos sem cortes.')
    for card in cards:
        if not isinstance(card,dict): raise ValueError('Card inválido.')
        card.setdefault('id',uuid.uuid4().hex)
        for key in ('title','problem','why','owner','due','metric','target','quote','sourceQuote'):
            if key in card: card[key]=_text(card.get(key))
        if card.get('priority','media') not in ('alta','media','baixa'): raise ValueError('Prioridade inválida.')
        if card.get('status','pending') not in ('pending','doing','done'): raise ValueError('Status do card inválido.')
        steps=card.setdefault('steps',[])
        if not isinstance(steps,list) or len(steps)>40: raise ValueError('Use até 40 passos em um card.')
        for step in steps:
            if not isinstance(step,dict): raise ValueError('Passo inválido.')
            step.setdefault('id',uuid.uuid4().hex);step['text']=_text(step.get('text'),6000)
            step['done']=step.get('done') is True
        card['images']=_images(card.get('images',[]))
    charts=report.get('charts',[])
    if not isinstance(charts,list) or len(charts)>12: raise ValueError('Use até 12 gráficos no relatório.')
    for chart in charts:
        if not isinstance(chart,dict) or chart.get('type') not in ('bar','line'): raise ValueError('Tipo de gráfico inválido.')
        chart.setdefault('id',uuid.uuid4().hex)
        chart['title']=_text(chart.get('title'),300);chart['caption']=_text(chart.get('caption'),1500)
        labels=chart.get('labels',[])
        series=chart.get('series',[])
        limit=1000 if chart['type']=='bar' else 100
        if not isinstance(labels,list) or len(labels)>limit: raise ValueError(f'Este gráfico aceita até {limit} períodos ou itens.')
        chart['labels']=[_text(label,150) for label in labels]
        if not isinstance(series,list) or len(series)>4: raise ValueError('Use até quatro séries por gráfico.')
        for data in series:
            if not isinstance(data,dict): raise ValueError('Série do gráfico inválida.')
            values=data.get('values')
            if not isinstance(values,list) or len(values)!=len(labels): raise ValueError('Cada série precisa de um valor para cada rótulo; use vazio/null para dado ausente.')
            try:
                invalid=any(v is not None and (isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v)) for v in values)
            except (OverflowError,ValueError): invalid=True
            if invalid: raise ValueError('Os valores dos gráficos precisam ser números finitos ou vazios.')
            data['name']=_text(data.get('name'),150)
            if not re.fullmatch(r'#[0-9a-fA-F]{6}',str(data.get('color',''))): data['color']='#6F56E6'
    for section in report.get('sections',[]):
        section['images']=_images(section.get('images',[]))
    meeting=report.get('meeting')
    if meeting is not None:
        if not isinstance(meeting,dict): raise ValueError('Dados da reunião inválidos.')
        if len(str(meeting.get('transcriptText','')))>500000: raise ValueError('A transcrição ultrapassa 500 mil caracteres. Divida em trechos.')
        for key in ('url','recordingUrl','transcriptUrl'):
            if meeting.get(key) and not safe_link(meeting[key]): raise ValueError('Use links HTTPS válidos para a reunião e os materiais.')
    return report
