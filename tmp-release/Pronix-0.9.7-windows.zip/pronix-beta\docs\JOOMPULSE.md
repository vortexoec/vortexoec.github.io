# Conectar a sua JoomPulse

O beta usa o conector MCP oficial, diretamente do programa local. Cada usuário conecta sua própria conta e usa os limites do seu plano. A conexão existente no ChatGPT ou Claude não é transferida para o programa.

## Configuração no beta

1. Abra [Configurações MCP da JoomPulse](https://joompulse.com/dashboard/settings/mcp) e entre na sua conta.
2. Na área de ferramenta personalizada/aplicações OAuth, crie uma aplicação com o nome **Pronix Beta**.
3. Prefira o tipo **Público** para este aplicativo local. O fluxo usa OAuth Authorization Code com PKCE S256. Se a sua conta oferecer apenas aplicação confidencial, o beta aceita também o segredo do cliente.
4. Cadastre exatamente esta URL de redirecionamento: `http://localhost:8765/api/joompulse/callback`.
5. Copie o **ID do cliente** para Integrações no Pronix. O ID do cliente identifica a aplicação OAuth, não é o ID da loja Mercado Livre. Aplicações públicas não precisam de segredo.
6. Salve e clique em conectar. O navegador abre a autenticação oficial da JoomPulse. Conclua o login e a autorização; o retorno será para o programa local.
7. Teste a conexão. O programa consulta as ferramentas realmente disponíveis nessa conta. Somente ferramentas declaradas como consulta, com `readOnlyHint: true`, podem ser executadas no beta.

A tela de configuração da JoomPulse informa que URLs HTTP são aceitas para localhost. A URL cadastrada e a usada pelo programa precisam coincidir, inclusive porta e caminho. Se a JoomPulse negar o tipo público ou o retorno local, obtenha a configuração aprovada pelo suporte; o programa não contorna essa restrição.

## Renovação e avisos de conexão

Com o programa local em execução, a autorização é renovada automaticamente quando há uma credencial de renovação utilizável. O processo de manutenção confere essa necessidade periodicamente, sem iniciar análises nem consultar produtos. Não é necessário manter a tela de Integrações aberta. Se o programa estiver fechado, a manutenção não será executada; ao abri-lo novamente, o acesso será conferido.

Em **Integrações**, o contador mostra o momento previsto para a **renovação automática**. Ele não informa quanto falta para um novo login manual: esse prazo não é presumido. O navegador atualiza os números a cada segundo, sem requisições nesse intervalo. A leitura do status ocorre a cada 30 segundos enquanto a página está visível e ao voltar à janela.

| Aviso | O que significa |
| --- | --- |
| **Conectada** | A autorização está disponível. Quando aplicável, o contador mostra a próxima renovação prevista. |
| **Renovando acesso / Aguardando renovação** | O programa está renovando ou aguardando a tentativa. Isso, sozinho, não exige um novo login. |
| **Nova tentativa agendada** | Uma dificuldade temporária, como rede ou limite de requisições, adiou a renovação. A autorização é preservada para uma nova tentativa. |
| **Reconectar JoomPulse** | A autorização foi recusada, venceu sem possibilidade de renovação ou não pode ser lida. Use **Reconectar minha conta** e conclua o login oficial. |

O badge no topo e o card da visão geral acompanham esses estados. Um aviso de reconexão prevalece sobre um estado antigo de conexão. Se a autorização não oferecer renovação automática, a tela explica a validade e a necessidade de login após o vencimento; não mostra um contador de renovação. No modo técnico `on_use`, a renovação fica para a próxima consulta, sem prometer uma tentativa automática em horário específico.

`GET /api/joompulse/status` é somente leitura: não renova tokens, não consulta o MCP e não abre autenticação. Ele fornece horários e mensagens públicas, sem credenciais. A renovação é feita pelo processo de manutenção separado. Atualizar o status não recria os formulários nem substitui rascunhos ou resultados de análises.

## O que está implementado e o que depende de validação

- Cliente HTTP MCP com inicialização, sessão, descoberta paginada de ferramentas e chamadas de consulta.
- Autenticação individual OAuth, validação de `state`, PKCE, renovação de token e desconexão local.
- Respostas JSON e Server-Sent Events (SSE).
- Erros de expiração, ausência de acesso, limite de consultas e falha de rede.
- Os endpoints públicos foram verificados em 30/10/2026. A inicialização sem token retorna 401, como esperado.
- Em 30/10/2026, o usuário autorizou a criação da aplicação pública Pronix Beta Local e a conexão foi concluída no programa: OAuth, inicialização e catálogo reais verificados, com 42 ferramentas (40 declaradas de leitura). A consulta gratuita de limites também retornou sucesso. Esses números podem mudar por conta ou versão do provedor.
- O repositório público da JoomPulse descreve as funções de pesquisa, mas não publica nomes estáveis ou schemas das ferramentas. O programa os descobre em `tools/list`; não há nomes inventados nem consulta a interfaces internas.
- A conexão MCP fornece dados. Uma análise em linguagem natural pode usar um modelo de IA configurado separadamente. Ads, cálculos, edição e exportação local não dependem dessa conexão.

## Coleta de mercado sem IA adicional

O modo de coleta local extrai links e códigos MLB do documento, consulta a JoomPulse e monta um texto editável nas 16 etapas da metodologia. Aceita até 30 produtos e respeita o orçamento de consultas e a cota disponível, registrando limitações. Não chama um modelo de linguagem: usa diretamente os dados que a JoomPulse disponibiliza. As próprias estimativas do fornecedor continuam sendo estimativas produzidas pela JoomPulse.

Os links podem trazer a oferta escolhida em `wid`, `item_id`, `itemId` ou dentro de `pdp_filters`, tanto nos parâmetros quanto após `#`. O programa consulta o código MLB dessa oferta e confere o identificador retornado. Agrupamentos `/up/MLBU...` não substituem o anúncio selecionado. Um link de anúncio não é substituído silenciosamente por um catálogo. Links conflitantes, resultados ambíguos ou identificadores ausentes/divergentes ficam pendentes de revisão, sem associar métricas de outro produto. Códigos MLB isolados não informam o tipo: uma consulta alternativa só é permitida quando não há resultado e o código retornado coincide exatamente.

No modo com IA, todas as referências identificáveis do PDF precisam de uma consulta exata validada antes de a análise ser aceita. Resultados de consultas com identidade divergente são devolvidos como erro, sem entregar ao modelo os dados do outro produto. Uma busca por título, sozinha, não atende essa condição. A confirmação do código também não elimina a revisão humana do conteúdo gerado.

Confirmar o anúncio não confirma que a variação ou o kit do documento corresponde à oferta. Nos PDFs, os hyperlinks são extraídos em uma lista e a associação com os custos exige revisão. O HTML da tela **Revisão de planilha** do Hub preserva os cards: o importador associa o nome, o primeiro conjunto de campos comerciais e o link dentro de cada produto. Campos ausentes permanecem ausentes. As avaliações do robô e os pareceres anteriores são excluídos dos dados para a nova consulta.

Para salvar, abra a planilha completa no Hub, espere todos os produtos carregarem e use **Ctrl+S → Página da Web, completa**. Importe o arquivo `.html` ou `.htm` em Documento de produtos e confira a lista antes de gerar a análise. O programa lê esse arquivo localmente, sem executar scripts nem carregar recursos externos. Uma página de login ou uma página sem os cards completos é recusada. Links que abrem uma busca, em vez de um anúncio, ficam pendentes; você pode corrigi-los na importação local sem modificar o Hub. PDFs continuam aceitos.

O programa mantém separadas as vendas de um anúncio e as do catálogo inteiro, exclui as linhas de média histórica da tabela de períodos e não soma a demanda repetida em várias ofertas de um catálogo. Séries mensais e semanais são verificadas separadamente. A janela solicitada é de até 120 dias, com cobertura real identificada; períodos ausentes ou fora dos limites não são completados com valores inventados.

Os candidatos da busca precisam de conferência de marca, modelo, variação e quantidade/kit. Mesmo catálogo não basta para o beta declarar equivalência completa. Enquanto isso, não é calculada média de preço de concorrentes confirmados. Também não há parecer de viabilidade, lucro ou preço final sem custos e taxas confirmados. O texto indica essas lacunas e pode ser complementado no editor; a IA opcional permite uma elaboração adicional.

## Dados e credenciais

As credenciais ficam em `%LOCALAPPDATA%\PronixBeta\joompulse.dpapi`, protegidas por Windows DPAPI para o usuário atual. Não ficam na pasta iCloud, no relatório, no navegador ou no repositório. Não copie esse arquivo para distribuir o programa. Cada instalação deve iniciar sua própria conexão.

Ao clicar em desconectar, o programa apaga a autorização local. Para revogar o consentimento no provedor também, use as configurações da JoomPulse. Não há endpoint público de revogação anunciado pelos metadados consultados.

O cliente MCP só envia consultas de mercado quando essa função é acionada; a manutenção da autorização OAuth é separada. O suporte a ferramentas de escrita fica bloqueado. Esse cliente não utiliza cookies, senhas ou a sessão do navegador. A consulta opcional da calculadora descrita abaixo usa o DOM visível por uma extensão própria, sem acesso a cookies ou APIs internas. A conexão individual com o plano ChatGPT é outra integração, independente das credenciais JoomPulse.

## Contrato técnico confirmado

| Item | Valor confirmado |
| --- | --- |
| MCP HTTP | `https://joompulse.com/mcp` |
| Metadados do recurso | `https://joompulse.com/.well-known/oauth-protected-resource` |
| Metadados OAuth | `https://joompulse.com/.well-known/oauth-authorization-server` |
| Autorização | `https://joompulse.com/oauth2/authorize` |
| Token | `https://joompulse.com/noauth/oauth2/token` |
| Escopo | `mcp` |
| Grants | `authorization_code`, `refresh_token` |
| PKCE | `S256` |
| Autenticação de token anunciada | `none`, `client_secret_post`, `client_secret_basic` |

Os endereços de autorização e token são lidos dos metadados oficiais ao iniciar o fluxo. O programa exige HTTPS e o domínio oficial. O cadastro dinâmico de clientes não é anunciado; por isso é necessário criar o aplicativo nas configurações da conta.

Um GET simples no endereço MCP pode retornar 404. O teste válido usa POST com o protocolo MCP; não confundir o GET com indisponibilidade do serviço.

## Cuidados na interpretação dos resultados

A documentação pública da JoomPulse distingue vendas e faturamento **estimados** de preços, avaliações e contagens observados no marketplace. Os resultados do relatório devem preservar essa distinção e o período de referência. Nenhum dado de vendas estimadas prova a margem líquida do cliente. O prompt fornecido exige produtos idênticos, dados recentes e custos confirmados; similaridade por título ou imagem, sozinha, não confirma equivalência.

O site ainda anuncia API convencional como futura. O caminho disponível para este beta é MCP. Para distribuição comercial posterior, confirme com a JoomPulse as condições de uso e distribuição dos dados; os termos tratam separadamente acesso autorizado e revenda de informações. Isso não impede validar agora a conexão individual documentada.

## Fontes oficiais

- [Conector MCP e ferramenta personalizada](https://www.joompulse.com/mcp-connector)
- [Configuração MCP do repositório oficial](https://github.com/joomcode/joompulse-skills/blob/main/.mcp.json)
- [Instruções oficiais de conexão](https://github.com/joomcode/joompulse-skills#connect-the-joompulse-mcp-required)
- [Análise de produto e natureza dos dados](https://github.com/joomcode/joompulse-skills/blob/main/skills/ml-product-analysis/SKILL.md)
- [Correspondência de produtos idênticos](https://github.com/joomcode/joompulse-skills/blob/main/skills/pulse-find-exact-same-product/SKILL.md)
- [Política de privacidade do conector](https://joompulse.com/politica-de-privacidade)
- [Termos de serviço](https://joompulse.com/termos-de-servico)

## Comissões

A calculadora da JoomPulse deixou de ser usada (a leitura pela extensão era instável). As comissões agora vêm da API oficial do Mercado Livre; veja [MERCADO-LIVRE.md](MERCADO-LIVRE.md). O frete continua pela tabela oficial local.

## Testes locais

Execute `python -m unittest discover -s tests -p test_joompulse.py -v` na pasta do programa. Os testes cobrem o fluxo PKCE, retorno OAuth, estado expirado, renovação, paginação e sessão MCP, SSE, bloqueio de ferramentas mutáveis e proteção DPAPI real no Windows. Os testes HTTP usam respostas controladas e não gastam consultas da conta.

Em 04/11/2026, os 22 testes focais da conexão JoomPulse e uma rodada completa de 612 testes Python passaram. O comando `node runtime/qa/joompulse-auth-ui-smoke.cjs` verifica, sem navegador ou rede, o contador local, os avisos, a precedência da reconexão, as falhas temporárias, a ausência de requisições sobrepostas e a preservação dos campos, rascunhos e jobs. Esses testes controlados não demonstram quanto tempo uma autorização real permanecerá renovável em cada conta.
