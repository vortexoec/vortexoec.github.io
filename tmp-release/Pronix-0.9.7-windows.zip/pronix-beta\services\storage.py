from __future__ import annotations

import json
import hashlib
import os
import re
import shutil
import tempfile
import threading
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
RUNTIME = ROOT / 'runtime'
UPLOADS = RUNTIME / 'uploads'
REPORTS = RUNTIME / 'reports'
OUTPUT = WORKSPACE / 'analise de mercado'
LOCK = threading.RLock()
MAX_OUTPUT_PATH = 240


def now():
    return datetime.now(timezone(timedelta(hours=-3))).isoformat(timespec='seconds')


def today():
    return now()[:10]


def init():
    for directory in (RUNTIME, UPLOADS, REPORTS, OUTPUT):
        directory.mkdir(parents=True, exist_ok=True)


def atomic_text(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.writing-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as stream:
            stream.write(text)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def write_json(path, data):
    atomic_text(path, json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False))


def read_json(path, default=None):
    if not Path(path).exists():
        return default
    return json.loads(Path(path).read_text(encoding='utf-8'))


def identifier(value):
    if not re.fullmatch(r'[a-f0-9]{32}', str(value)):
        raise ValueError('Identificador de arquivo inválido.')
    return value


def safe_name(value):
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', ' ', str(value))
    value = re.sub(r'\s+', ' ', value).strip(' .')[:90].rstrip(' .') or 'Cliente'
    if value.upper().split('.')[0] in {'CON', 'PRN', 'AUX', 'NUL', *('COM'+str(i) for i in range(1,10)), *('LPT'+str(i) for i in range(1,10))}:
        value = '_' + value
    return value


def validate_report(report):
    if not isinstance(report, dict):
        raise ValueError('Relatório inválido.')
    report = json.loads(json.dumps(report, ensure_ascii=False, allow_nan=False))
    if not str(report.get('clientName', '')).strip():
        raise ValueError('Informe o nome do cliente.')
    if not str(report.get('specialist', '')).strip():
        raise ValueError('Informe o especialista responsável antes de salvar.')
    try:
        datetime.strptime(report.get('date', ''), '%Y-%m-%d')
    except (ValueError, TypeError):
        raise ValueError('A data da análise deve ser válida (AAAA-MM-DD).')
    report['id'] = identifier(report.get('id') or uuid.uuid4().hex)
    report.setdefault('title', 'Análise de mercado e performance')
    sections = report.setdefault('sections', [])
    if not isinstance(sections, list) or len(sections) > 200:
        raise ValueError('Relatório deve conter até 200 seções.')
    for section in sections:
        if not isinstance(section, dict):
            raise ValueError('Seção inválida.')
        section.setdefault('id', uuid.uuid4().hex)
        section['title'] = str(section.get('title', ''))[:500]
        section['body'] = str(section.get('body', ''))[:200000]
    report.setdefault('metrics', {})
    report.setdefault('warnings', [])
    report.setdefault('sources', [])
    report.setdefault('createdAt', now())
    report['updatedAt'] = now()
    from .report_schema import validate_visual
    return validate_visual(report)


def paths_for(report):
    original_client = str(report['clientName'])
    client = safe_name(original_client)
    date = report['date']
    report_id = identifier(report['id'])
    def build(name):
        base = OUTPUT / name / (date + '_' + report_id[:8])
        return {kind: base / (name + '_' + date + '.' + kind) for kind in ('json', 'txt', 'html', 'pdf')}
    def units(path):
        return len(str(Path(path).absolute()).encode('utf-16-le')) // 2
    def longest(paths):
        # Budget for both atomic text saves and the PDF export's temporary file.
        return max(*(units(p) for p in paths.values()),units(paths['pdf'].with_suffix('.pdf.tmp')),
                   units(paths['json'].parent / '.writing-12345678'))
    paths = build(client)
    if longest(paths) <= MAX_OUTPUT_PATH:
        return paths
    digest = hashlib.sha256(original_client.encode('utf-8')).hexdigest()[:8]
    fixed = units(build('x')['pdf'].with_suffix('.pdf.tmp')) - 2
    budget = (MAX_OUTPUT_PATH-fixed) // 2
    while budget >= 10:
        remaining = budget-9
        prefix = ''
        for char in client:
            char_units = len(char.encode('utf-16-le')) // 2
            if char_units > remaining: break
            prefix += char
            remaining -= char_units
        short_client = (prefix.rstrip(' ._-') or 'C') + '_' + digest
        paths = build(short_client)
        if longest(paths) <= MAX_OUTPUT_PATH:
            return paths
        budget -= 1
    raise ValueError('A pasta do programa está em um caminho muito longo. Coloque a pasta do programa em um local mais curto para salvar os arquivos; o nome do cliente pode ser mantido.')


def folder_for(report_id=None):
    """Pasta que o botão "Abrir pasta" mostra: a do cliente da análise ou a geral. Sempre dentro de OUTPUT."""
    init()
    folder = OUTPUT
    if report_id:
        try:
            report = get_report(identifier(report_id))
            candidate = paths_for(report)['json'].parent
            client = candidate.parent
            folder = candidate if candidate.is_dir() else client if client.is_dir() else OUTPUT
        except (FileNotFoundError, ValueError, KeyError):
            folder = OUTPUT
    resolved = folder.resolve()
    if resolved != OUTPUT.resolve() and OUTPUT.resolve() not in resolved.parents:
        raise ValueError('Pasta fora da área de análises.')
    return resolved


def _report_candidate(file, expected_id=None):
    """Read a canonical or sync-conflict copy without changing either file."""
    try:
        report = read_json(file)
        if not isinstance(report, dict):
            return None
        report_id = identifier(report.get('id'))
        if (expected_id is not None and report_id != expected_id) or not file.stem.startswith(report_id):
            return None
        try:
            updated = datetime.fromisoformat(str(report.get('updatedAt', '')).replace('Z', '+00:00'))
            if updated.tzinfo is None:
                updated = updated.replace(tzinfo=timezone.utc)
            updated_time = updated.timestamp()
        except (ValueError, TypeError, OverflowError, OSError):
            updated_time = float('-inf')
        # Resolve exact timestamp ties by filesystem modification time, then
        # prefer the canonical file. The final name makes ties deterministic.
        rank = (updated_time, file.stat().st_mtime_ns,
                file.name == report_id + '.json', file.name.casefold())
        return report, rank
    except (ValueError, TypeError, OSError):
        return None


def get_report(report_id):
    report_id = identifier(report_id)
    candidates = [_report_candidate(file, report_id) for file in REPORTS.glob(report_id + '*.json')]
    candidates = [candidate for candidate in candidates if candidate is not None]
    if not candidates:
        raise FileNotFoundError('Relatório não encontrado.')
    return max(candidates, key=lambda candidate: candidate[1])[0]


def list_reports():
    from .report_schema import is_market_report
    init()
    winners = {}
    for file in REPORTS.glob('*.json'):
        candidate = _report_candidate(file)
        if candidate is None:
            continue
        report, rank = candidate
        previous = winners.get(report['id'])
        if previous is None or rank > previous[1]:
            winners[report['id']] = candidate
    ordered = sorted(winners.values(), key=lambda candidate: candidate[1], reverse=True)
    def market_summary(report):
        counts = {}
        for entry in (report.get('marketAnalysis') or {}).get('products') or []:
            status = ((entry.get('analysis') or {}).get('decision') or {}).get('status') or 'nao_concluido'
            counts[status] = counts.get(status, 0) + 1
        return counts
    return [{**{key: report.get(key) for key in ('id', 'clientName', 'date', 'title', 'updatedAt')},
             'reportType':'market' if is_market_report(report) else report.get('reportType','performance'),
             'hubUrl': ((report.get('productSource') or {}).get('hubSource') or {}).get('url'),
             'statusCounts': market_summary(report) if is_market_report(report) else None}
            for report, _ in ordered]


def get_upload(upload_id):
    result = read_json(UPLOADS / (identifier(upload_id) + '.json'))
    if result is None:
        raise FileNotFoundError('Arquivo de origem não encontrado. Importe novamente.')
    result['path'] = str(UPLOADS / (upload_id + result['extension']))
    return result


def save_report(report):
    from .documents import render_html, render_text
    from .direction import enrich_report
    report = enrich_report(report)
    report = validate_report(report)
    paths = paths_for(report)
    with LOCK:
        try:
            old = get_report(report['id'])
        except FileNotFoundError:
            old = None
        if old and old != report:
            revision = RUNTIME / 'revisions' / report['id'] / (uuid.uuid4().hex + '.json')
            write_json(revision, old)
            # A PDF is a snapshot. Preserve the old export as a revision rather than
            # leaving a stale deliverable next to freshly edited TXT/HTML/JSON.
            old_content={k:v for k,v in old.items() if k not in ('updatedAt','createdAt')}
            new_content={k:v for k,v in report.items() if k not in ('updatedAt','createdAt')}
            previous_pdf=paths_for(old)['pdf']
            if old_content!=new_content and previous_pdf.exists():
                shutil.move(str(previous_pdf),str(revision.with_suffix('.pdf')))
        write_json(paths['json'], report)
        atomic_text(paths['txt'], render_text(report))
        atomic_text(paths['html'], render_html(report))
        write_json(REPORTS / (report['id'] + '.json'), report)
    return report, {key: str(path) for key, path in paths.items()}


def clear_history(include_exports=False):
    """Apaga o histórico local: análises, arquivos importados, revisões e caches.

    Ficam: preferências, conexões (cofre do Windows), modelos e imagens de marca.
    Com include_exports=True apaga também os arquivos exportados na pasta "analise de mercado".
    """
    targets = [REPORTS, UPLOADS, RUNTIME / 'revisions', RUNTIME / 'market-images', RUNTIME / 'updates']
    if include_exports:
        targets.append(OUTPUT)
    removed = {'reports': len(list_reports()), 'files': 0}
    with LOCK:
        for folder in targets:
            folder = Path(folder)
            if not folder.exists():
                continue
            base = folder.resolve()
            if base not in (WORKSPACE.resolve() / 'analise de mercado',) and RUNTIME.resolve() not in base.parents:
                raise ValueError('Pasta fora do programa; nada foi apagado.')
            for child in folder.iterdir():
                if child.is_dir() and not child.is_symlink():
                    removed['files'] += sum(1 for p in child.rglob('*') if p.is_file())
                    shutil.rmtree(child)
                else:
                    removed['files'] += 1
                    child.unlink()
    init()
    return removed
