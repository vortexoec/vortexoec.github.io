"""Versão do Pronix, lida do arquivo VERSION na raiz do programa."""
from pathlib import Path

_FILE = Path(__file__).resolve().parents[1] / "VERSION"


def current() -> str:
    try:
        value = _FILE.read_text(encoding="utf-8").strip()
        return value if value and len(value) <= 20 else "0.0.0"
    except OSError:
        return "0.0.0"


VERSION = current()
