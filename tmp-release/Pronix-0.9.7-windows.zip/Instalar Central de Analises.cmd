@echo off
title Instalar Central de Analises
if not exist "%~dp0python\python.exe" (
  echo.
  echo  Os arquivos do programa nao estao ao lado deste instalador.
  echo  Feche esta janela, clique com o botao direito no arquivo ZIP,
  echo  escolha "Extrair tudo..." e rode o instalador de dentro da pasta extraida.
  echo.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
if errorlevel 1 pause
