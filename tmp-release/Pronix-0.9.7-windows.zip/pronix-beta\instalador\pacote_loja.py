"""Monta o ZIP da extensão para enviar à Chrome Web Store.

Uso (na pasta pronix-beta):  python instalador/pacote_loja.py [pasta de saída]
Resultado: central-de-analises-vortex-<versão>.zip, com o manifest.json na raiz.
Ficam de fora os testes e o README; nenhum dado de cliente ou credencial entra.
"""
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EXTENSION = ROOT / 'extension' / 'pronix-hub'
SKIP_DIRS = {'tests'}
SKIP_FILES = {'README.md'}


def main():
    out_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'dist' / 'loja'
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((EXTENSION / 'manifest.json').read_text(encoding='utf-8'))
    if 'update_url' in manifest or 'key' in manifest:
        raise SystemExit('O manifesto não pode ter update_url nem key para a loja.')
    if len(manifest['description']) > 132:
        raise SystemExit('A descrição do manifesto passa de 132 caracteres.')
    target = out_dir / f"central-de-analises-vortex-{manifest['version']}.zip"
    files = sorted(p for p in EXTENSION.rglob('*') if p.is_file()
                   and not (set(p.relative_to(EXTENSION).parts[:-1]) & SKIP_DIRS) and p.name not in SKIP_FILES)
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(EXTENSION).as_posix())
    with zipfile.ZipFile(target) as archive:
        names = archive.namelist()
        assert 'manifest.json' in names and not any(n.startswith('tests/') or n.endswith('.dpapi') for n in names)
    print(f'{target} · {len(names)} arquivos · {target.stat().st_size // 1024} KB')
    print('\n'.join('  ' + n for n in names))


if __name__ == '__main__':
    main()
