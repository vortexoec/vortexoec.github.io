# Validação do beta — 30/10/2026

## Verificado

- 53 testes automatizados de importação, números brasileiros, totais e componentes, datas, cobertura, períodos agregados, indicadores ausentes, OAuth/PKCE, DPAPI, MCP, limites, edições, exportação e execução de IA com respostas simuladas.
- Interface testada no navegador: CSV fictício → mapeamento → análise → edição de título e texto → prévia → exportação nos quatro formatos.
- Interface responsiva verificada em largura de 390 px, sem rolagem horizontal.
- Conexão OAuth real com a aplicação pública JoomPulse autorizada pelo usuário. 42 ferramentas descobertas; 40 declaradas como consultas e 2 mutáveis bloqueadas.
- Consulta real de referência de produto presente no material Pronix: leitura de guias, produto, estimativas e ofertas. Campos ausentes permaneceram indisponíveis.
- Relatórios reais do Mercado Livre baixados pela interface autorizada e preservados em `fontes/relatorios-mercado-livre`.
- Importação integrada testada pela API local: relatório diário de Ads e relatório mensal da conta, ambos de 29/09 a 29/10/2026. TACOS calculado sobre períodos comprovados e iguais.
- Arquivos de validação interna exportados em PDF, TXT, HTML e JSON. PDF com nove páginas renderizado e revisado visualmente; texto e rodapés legíveis, sem cortes observados.
- Identificação automática do cliente reconhece os rótulos explícitos do PDF, incluindo a estrutura `Mentorados / Nome`. Hiperlinks Mercado Livre de anotações PDF também são coletados.

## Conferência independente dos arquivos reais

| Indicador | Resultado |
|---|---:|
| Investimento Ads | R$ 3.426,96 |
| Receita atribuída Ads | R$ 20.025,86 |
| Vendas atribuídas | 234 |
| Cliques | 8.338 |
| Impressões | 2.930.269 |
| Vendas brutas da conta | R$ 31.866,00 |
| Vendas da conta | 362 |
| Unidades vendidas | 415 |
| ROAS | 5,843622x |
| ACOS | 17,112673% |
| TACOS | 10,754284% |

Esses valores descrevem os arquivos de teste autorizados; não constituem uma avaliação final de rentabilidade do cliente. O relatório gerado usa identificação de **validação interna**, não a identidade final de um cliente.

## Limites da validação

- A extensão do navegador impediu uma segunda tentativa de upload real pela interface; a importação real completa foi verificada pelas rotas locais do mesmo aplicativo. O upload CSV e a edição/exportação foram testados no navegador anteriormente.
- Não foi usada chave OpenAI real. O protocolo e o processamento foram cobertos por testes simulados; disponibilidade do modelo, cobrança e desempenho precisam ser verificados com a configuração do usuário.
- O modo JoomPulse sem IA consulta e organiza evidências. Não valida automaticamente custos, variantes, margens ou viabilidade comercial ausentes.
- Nenhuma API Mercado Livre foi conectada. A carteira de clientes e a coleta automática estão em `MELHORIAS-FUTURAS.md`.
- Instalador, assinatura, atualização automática e publicação GitHub dependem da validação do beta e de uma próxima etapa.

## Arquivos de trabalho

Os registros técnicos e PDFs de teste estão em `runtime/qa` e `analise de mercado`. Os relatórios de teste têm nomes que indicam sua finalidade e devem ser tratados como internos.

## Atualização — 04/11/2026

O registro de 30/10 acima foi preservado como histórico. Os itens abaixo descrevem a validação posterior do fluxo de mercado.

### Confirmado

- Login oficial com o plano ChatGPT, listagem de modelos e resposta real de teste concluídos. A conexão JoomPulse e as consultas diretas também foram testadas. Isso não equivale à aprovação da análise comercial integral.
- **578 testes automatizados da suíte completa passaram.** Depois dos ajustes de diagnóstico da calculadora, **42 testes focais passaram**. São rodadas de verificação com escopos sobrepostos, não uma soma de testes distintos.
- O coordenador processa até **três produtos em paralelo**, isolando seus dados e histórico. O limite é de **20 rodadas por produto** e **40 consultas MCP de dados por tentativa**, compartilhadas por todos os produtos. A franquia da conta continua aplicável; não há autorização implícita para excedê-la.
- Com respostas simuladas, um lote de oito produtos preservou sete resultados validados quando o oitavo falhou. O progresso foi salvo em armazenamento temporário, reaberto e revalidado; a retomada consultou somente o oitavo. Outro caso alterou os dados de um produto concluído e confirmou sua nova análise junto com o pendente.
- O progresso em `runtime/jobs` vale por uma hora desde o início original, sem renovação silenciosa na retomada. Conta, provedor, modelo e documento são conferidos; dados e evidências de cada produto são revalidados. Escrita atômica, falha de gravação, retomada após reinício, rejeição de credenciais e remoção limitada aos arquivos próprios foram cobertas.
- Nenhum parecer parcial é apresentado como resultado completo. A tela acompanha contagem e progresso; no erro, oferece **Retomar produtos pendentes** quando possível e **Abrir revisão anterior**. A aplicação do lote completo preserva a revisão manual.
- A ponte da calculadora aceita explicitamente as versões 0.3.0, 0.3.1 e 0.3.2, preservando a importação do Hub 0.2. Após acrescentar a compatibilidade 0.3.2, 25 testes focais da ponte passaram. As consultas de taxas ocorrem uma por vez, com fila limitada e timeout próprio. Respostas de outra referência, outro preço ou data inválida são recusadas. Erros conhecidos da extensão são traduzidos em diagnóstico; mensagens arbitrárias e possíveis segredos não são reproduzidos.
- A tabela oficial de frete local foi conferida em 04/11, com vigência desde 24/08/2026 e prazo local de revisão até 04/12/2026. Os testes verificaram faixas, valores, teto abaixo de R$ 19, envio rápido exclusivo e exceções. A política de tarifa fixa zero permanece restrita às modalidades ME2 documentadas, separada da comissão e do custo de envio.
- **Calculadora 0.3.3, um caso real confirmado:** após as correções de carregamento e preenchimento, uma consulta de cesto a R$ 80 retornou Cestos de Roupa, comissão Clássico 11,5% e Premium 16,5%. A aba temporária foi fechada automaticamente. Evidência: `runtime/qa/joom-calculator-real-cesto.json`. O resultado continua identificado como estimativa para aquele anúncio/preço.
- **Proteção contra revisão antiga:** 71 testes focais passaram, incluindo rejeição do rascunho com custo 44 quando o salvo já contém 999, sem depender de horários diferentes, preservação do checkpoint e fluxo recálculo → aplicação do resultado → salvar → analisar novamente. Uma rodada posterior da suíte executou 595 testes: 594 passaram e um teste HTTP local do Google foi interrompido por `WinError 10053`; a repetição isolada dos dez testes desse módulo passou. Essa rodada não é registrada como 595 aprovações numa única execução.

### Renovação da conexão — 04/11/2026

- Uma rodada posterior passou pelos **612 testes da suíte Python**. Os números anteriores foram mantidos como histórico; não devem ser somados a essa rodada.
- Os 22 testes focais JoomPulse cobriram a manutenção automática da autorização, o status somente leitura, renovação recusada, autorização vencida sem renovação e falhas temporárias com nova tentativa. A renovação depende de o programa local estar em execução e de o provedor aceitar a autorização.
- A interface mostra um contador de **renovação automática**, não uma contagem para refazer o login. O contador é atualizado localmente a cada segundo; a leitura de status ocorre a cada 30 segundos enquanto a página está visível e ao retornar à janela. Essa leitura não chama ferramentas MCP nem renova tokens.
- O teste offline `runtime/qa/joompulse-auth-ui-smoke.cjs` passou: aviso de reconexão sobrepõe um estado antigo de conexão, falhas temporárias permanecem distintas de autorização recusada, mensagens são escapadas e requisições não se sobrepõem. Um token sem renovação tem explicação de validade/login, sem contador de renovação.
- A atualização altera apenas as regiões de conexão da interface. Os testes preservaram os campos ainda não salvos, o rascunho do relatório, a revisão manual e o job em andamento. Também passaram `chatgpt-ui-smoke.cjs`, `market-ai-ui-smoke.cjs` e a verificação de sintaxe do JavaScript.
- Esses testes usam respostas controladas e DOM simulado. Não demonstram um prazo de validade da autorização real nem garantem que o provedor aceitará renovações futuras em todas as contas. A conferência visual desta atualização no navegador é uma etapa separada.

### Evidências por concorrente e cenários parciais — 04/11/2026

- Uma rodada posterior passou pelos **634 testes da suíte Python**, em 36,8 segundos. Também passaram os três testes offline da interface: conexão JoomPulse, conexão ChatGPT e análise de mercado. São rodadas com escopos sobrepostos aos números anteriores, não somas de testes distintos.
- A última tentativa real da análise do cesto foi interrompida pela validação de período/escopo e logística. **Nenhum parecer dessa tentativa substituiu o relatório salvo.** As correções foram verificadas com testes e reprodução local das evidências já recebidas; uma nova análise comercial real ainda não foi executada para confirmá-las.
- Séries mensais e semanais passam a ser verificadas separadamente. A reprodução do histórico completo confirmou três somas semanais antes recusadas por misturar linhas mensais. Permanecem as rejeições de lacunas, conflitos, sobreposição dentro de uma série, conversão de ausência em zero e faturamento de catálogo repetido em ofertas diferentes.
- A IA recebe opções verificadas por anúncio: preços, período, vendas/faturamento, identificação de anúncio ou catálogo e logística comprovada. O catálogo usa a logística e o preço da oferta principal quando essa origem está comprovada; não herda o preço de outro vendedor. Confirmar uma opção numérica não confirma equivalência entre os produtos.
- Os erros dos concorrentes são reunidos numa solicitação de correção, com identificação do campo e opções da fonte. Textos privados do modelo não são guardados no diagnóstico. O conjunto focal inicial de análise passou por 90 testes; a ponte e as rotas da calculadora passaram por 31. A revisão independente posterior acrescentou casos de logística de outra oferta, períodos aninhados e médias de anúncio/catálogo com o mesmo rótulo: **94 testes focais passaram após essas correções**. Esses ajustes posteriores não estão incluídos no registro de 634 testes.
- Quando apenas os demais custos estão ausentes, o programa calcula o **saldo antes dos custos não informados**. Custo de compra, comissão, tarifa fixa, frete e imposto precisam estar preenchidos. O saldo não substitui lucro líquido, não preenche os custos ausentes com zero e não autoriza aprovação sozinho. Premissas de peso/frete continuam visíveis e condicionais.
- Na reprodução local, os quatro cenários do cesto tinham saldos de R$ 12,35, R$ 10,35, R$ 6,35 e −R$ 1,02 antes dos custos não informados. São cálculos sobre as premissas daquele teste, não cotações nem resultados finais aprovados para um cliente.
- O bloco de fatos do caso examinado tinha **35 identificadores, 20 opções de métricas e 5.975 bytes**, no JSON compacto enviado por rodada. É um retrato atualizado, sem cópias acumuladas desse bloco no histórico. Não foi feita medição de tokens do provedor nem um benchmark de todos os produtos.
- A compatibilidade da extensão **0.3.5** está pronta. A extensão passou por 55 testes próprios, incluindo a releitura das comissões após mudança de preço e rejeição de valores que continuam variando. O diagnóstico `commission_changed` usa somente campos conhecidos e limitados. **A versão ainda não foi ativada no Chrome nesta etapa**; sua conferência real posterior continua pendente.

### Ainda em validação

- **Cobertura da calculadora JoomPulse:** o primeiro caso real passou na versão 0.3.3. Outras categorias, condições, preços e execuções em lote continuam em conferência. As falhas anteriores, incluindo `INPUT_NOT_READY (input_unavailable)` na versão 0.3.1, motivaram as correções; o sucesso de um caso não é uma validação universal.
- **Análise comercial integral pelo plano ChatGPT:** permanece em validação. Login, resposta de teste e testes simulados não comprovam a qualidade completa dos pareceres em produção.
- **Oito produtos reais:** não houve benchmark integral de tempo, custo ou qualidade. O teste de concorrência e retomada usa respostas simuladas, sem consultas pagas ou contas reais.
- O caminho opcional de API com chave não foi validado de ponta a ponta. Instalador, distribuição e atualizações automáticas continuam para etapa posterior à aprovação do beta.

Veja [ANALISE_MERCADO.md](ANALISE_MERCADO.md) para uso, limites, fontes e condições dos cenários.

### Conferência real posterior de conexão e calculadora — 04/11/2026

- Após as correções da revisão independente, a suíte completa passou novamente: **640 testes Python em 131,388 segundos**. Essa é uma rodada posterior aos 634 testes registrados acima; os totais não devem ser somados. Os três testes de interface e os 55 da extensão também passaram em suas rodadas próprias.
- A interface de Integrações foi conferida no Chrome: contador local decrescente, conexão individual e explicação de renovação automática. Registro: `runtime/qa/joompulse-renovacao-contador.png`.
- A renovação ocorreu sem novo login: a validade observada passou de `2026-11-04T20:40:35.628677Z` para `2026-11-04T20:54:45.389093Z`, mantendo `connected=true`, `requiresReconnect=false` e nenhum erro de autorização. Isso comprova essa renovação real; não garante que a JoomPulse aceitará todas as futuras renovações.
- O reinício do servidor agora usa `iniciar.ps1 -NoBrowser`, para não abrir uma nova aba a cada atualização do beta. O início normal continua abrindo o aplicativo.
- A versão **0.3.5 foi recarregada e confirmada pelo usuário**. A verificação completa da consulta ainda está pendente: uma chamada retornou `product_not_found`; a repetição terminou pelo limite de 90 segundos. Em seguida, a ferramenta de navegação também não respondeu em duas tentativas. Não foi produzido um novo parecer nem alterado um relatório real por esses testes.
- Antes disso, a conferência manual revelou que mudar o preço para R$ 150 podia manter Clássico em 11,5% até alternar para Premium e voltar a Clássico, quando passou a 10,5%. Premium exibiu 13,5%. A 0.3.5 força a alternância e reconfere as leituras; seus 55 testes offline passaram. A evidência manual está em `runtime/qa/joom-classico-150-conferido.png`. A resposta antiga 0.3.4 com 11,5% a R$ 150 não deve ser usada como taxa validada desse cenário.
