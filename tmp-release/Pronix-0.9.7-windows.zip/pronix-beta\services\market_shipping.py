"""Offline, scoped estimate from the verified Mercado Livre 48392 table.

This is not a shipping quote and does not infer package weight, cubic weight,
seller reputation, eligibility, taxes, commission or handling/storage costs.
The copied artifact contains numeric tariffs and concise applicability metadata.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_DOWN
import json
from pathlib import Path
import re

RESOURCE_FILE = Path(__file__).resolve().parents[1] / 'resources' / 'market' / 'shipping-48392-2026-08-24.json'
SOURCE_URL = 'https://www.mercadolivre.com.br/ajuda/custos-envio-reputacao-verde-sem-reputacao_48392'
FIXED_FEE_SOURCE_URL = 'https://developers.mercadolivre.com.br/pt_br/descricao-de-produtos/comissao-por-vender'
REFERENCE_ID = 'ml-shipping-48392-2026-08-24'
PRICE_MINIMA = (0, 19, 49, 79, 100, 120, 150, 200)
MAX_NUMBER = Decimal('1000000000000')  # Numeric safety bound, not an official package/price limit.


class ShippingReferenceError(ValueError):
    def __init__(self, message, code='shipping_reference'):
        super().__init__(message)
        self.code = code


def _number(value, label, *, positive=False, cents=False):
    if isinstance(value, bool) or not isinstance(value, (int, float, str, Decimal)):
        raise ShippingReferenceError(f'Informe {label} como número válido.', 'input')
    try:
        result = Decimal(str(value))
    except InvalidOperation:
        raise ShippingReferenceError(f'Informe {label} como número válido.', 'input') from None
    if not result.is_finite() or result < 0 or result > MAX_NUMBER or (positive and result == 0):
        raise ShippingReferenceError(f'Informe {label} dentro do limite numérico permitido.', 'input')
    if cents and result != result.quantize(Decimal('.01')):
        raise ShippingReferenceError('Informe o preço em reais com no máximo duas casas decimais.', 'input')
    return result


def _date(value):
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if not isinstance(value, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
        raise ShippingReferenceError('Informe a data da análise no formato AAAA-MM-DD.', 'date')
    try:
        return date.fromisoformat(value)
    except ValueError:
        raise ShippingReferenceError('A data da análise não é válida.', 'date') from None


def _load():
    try:
        data = json.loads(RESOURCE_FILE.read_text(encoding='utf-8'))
        source = data['source']
        if (data['schemaVersion'] != 1 or data['id'] != REFERENCE_ID or data['currency'] != 'BRL'
                or data['country'] != 'BR' or source['url'] != SOURCE_URL
                or source['effectiveFrom'] != '2026-08-24' or source['verifiedAt'] != '2026-11-04'
                or source['verificationMaxAgeDays'] != 30
                or not re.fullmatch(r'[a-f0-9]{64}', source['snapshotSha256'])):
            raise ValueError()
        if _date(source['validThrough']) != _date(source['verifiedAt']) + timedelta(days=30):
            raise ValueError()
        fixed = data['fixedFeePolicy']
        if (fixed['source'] != FIXED_FEE_SOURCE_URL or fixed['verifiedAt'] != source['verifiedAt']
                or fixed['documentUpdatedAt'] != '2026-09-03' or fixed['validThrough'] != source['validThrough']
                or fixed['shippingMode'] != 'me2' or fixed['fixedFee'] != 0
                or fixed['logistics'] != ['fulfillment', 'cross_docking', 'xd_drop_off']
                or fixed['excludedLogistics'] != ['flex', 'correios', 'other']):
            raise ValueError()
        if data['scope'] != {'sellerReputations': ['mercado_lider', 'green', 'unrated'],
                'productConditions': ['new'], 'logistics': ['full', 'collection', 'agency'],
                'excludedLogistics': ['correios', 'flex'],
                'excludedCategoryRules': ['full_super', 'books', 'special_categories', 'pet_food', 'used_products', 'free_listing']}:
            raise ValueError()
        if data['under19CapPercent'] != 50 or data['fastShippingUnder79'] != {'columnIndex': 3, 'exclusiveAlternative': True}:
            raise ValueError()
        if data['roundingPolicy']['under19CapRounding'] != 'ROUND_DOWN':
            raise ValueError()
        bands = data['priceBands']
        if len(bands) != 8:
            raise ValueError()
        for index, band in enumerate(bands):
            if band != {'minInclusive': PRICE_MINIMA[index],
                        'maxExclusive': PRICE_MINIMA[index + 1] if index < 7 else None}:
                raise ValueError()
        rows = data['weightBands']
        if len(rows) != 30:
            raise ValueError()
        previous = Decimal(0)
        for index, row in enumerate(rows):
            if _number(row['minExclusiveKg'], 'limite de peso') != previous or len(row['costs']) != 8:
                raise ValueError()
            upper = row['maxInclusiveKg']
            if upper is None:
                if index != len(rows) - 1 or previous != 150:
                    raise ValueError()
            else:
                upper = _number(upper, 'limite de peso', positive=True)
                if upper <= previous:
                    raise ValueError()
                previous = upper
            for value in row['costs']:
                _number(value, 'tarifa', positive=True, cents=True)
        return data
    except (OSError, ValueError, TypeError, KeyError, InvalidOperation):
        raise ShippingReferenceError('A referência local de frete não passou na validação. Confira a tabela oficial antes de calcular.', 'invalid_source') from None


def reference_data(analysis_date):
    """Return metadata and tariffs only while this verified snapshot is usable.

    Dates before publication or after the 30-day review window have no tariff
    matrix in the result, preventing accidental automatic reuse by an agent.
    """
    target = _date(analysis_date)
    data = _load()
    source = data['source']
    reason = None
    if target < _date(source['effectiveFrom']):
        reason = 'A tabela ainda não estava vigente na data desta análise.'
    elif target > _date(source['validThrough']):
        reason = 'A conferência da tabela venceu. Atualize a referência oficial antes de aplicar tarifas automaticamente.'
    common = {key: deepcopy(data[key]) for key in ('id', 'currency', 'country', 'source', 'scope', 'assumptions', 'roundingPolicy')}
    common.update(available=reason is None, analysisDate=target.isoformat(), basis='estimate', confirmed=False,
                  reason=reason, operationalEligibilityConfirmed=False)
    if reason is None:
        common.update({key: deepcopy(data[key]) for key in ('priceBands', 'weightBands', 'fastShippingUnder79', 'under19CapPercent')})
        # This separately dated rule is not applied to earlier analysis dates.
        if target >= _date(data['fixedFeePolicy']['documentUpdatedAt']):
            common['fixedFeePolicy'] = deepcopy(data['fixedFeePolicy'])
    return common


def _scope_check(scope, reference):
    if scope is None:
        return ['Reputação, condição do produto, logística e exceções de categoria ainda precisam ser conferidas.']
    if not isinstance(scope, dict):
        raise ShippingReferenceError('As condições de aplicação do frete devem ser um objeto.', 'scope')
    allowed = {'sellerReputation': reference['scope']['sellerReputations'],
               'productCondition': reference['scope']['productConditions'], 'logistics': reference['scope']['logistics']}
    pending = []
    for key, values in allowed.items():
        value = scope.get(key)
        if value is None:
            pending.append(key)
        elif value not in values:
            raise ShippingReferenceError('A tabela 48392 não se aplica à condição informada: ' + key + '.', 'scope')
    for key in ('specialCategory', 'freeListing'):
        value = scope.get(key)
        if value is None:
            pending.append(key)
        elif value is not False:
            raise ShippingReferenceError('A tabela padrão não cobre categoria especial ou anúncio gratuito.', 'scope')
    return ['Condições ainda não confirmadas: ' + ', '.join(pending) + '.'] if pending else []


def estimate_shipping(price, billable_weight_kg, fast_shipping=False, analysis_date=None, *, scope=None):
    """Estimate one mutually exclusive shipping charge, never a complete quote.

    Price bands are lower-inclusive/upper-exclusive. Weight bands are
    lower-exclusive/upper-inclusive, so exactly 0.3 kg remains in the first row.
    Above 150 kg uses the published open-ended row, without claiming acceptance.
    scope optionally validates known applicability; missing scope stays assumed.
    """
    price = _number(price, 'o preço', cents=True)
    weight = _number(billable_weight_kg, 'o peso faturável em kg', positive=True)
    if type(fast_shipping) is not bool:
        raise ShippingReferenceError('A opção de frete rápido deve ser verdadeiro ou falso.', 'input')
    reference = reference_data(analysis_date if analysis_date is not None else date.today())
    if not reference['available']:
        raise ShippingReferenceError(reference['reason'], 'source_outdated')
    warnings = _scope_check(scope, reference)
    row = next(row for row in reference['weightBands'] if row['maxInclusiveKg'] is None or weight <= Decimal(str(row['maxInclusiveKg'])))
    price_index = next((index for index in range(7) if price < Decimal(str(reference['priceBands'][index]['maxExclusive']))), 7)
    fast_alternative = fast_shipping and price < 79
    charge_index = reference['fastShippingUnder79']['columnIndex'] if fast_alternative else price_index
    tariff = Decimal(str(row['costs'][charge_index]))
    cap = (price / 2).quantize(Decimal('.01'), rounding=ROUND_DOWN) if price < 19 else None
    amount = min(tariff, cap) if cap is not None else tariff
    if weight > 150:
        warnings.append('Foi usada a faixa acima de 150 kg. Confirme os limites operacionais de aceitação do pacote.')
    if price == 0:
        warnings.append('Preço zero é apenas uma simulação; não confirma que exista um anúncio elegível.')
    if cap is not None and cap < tariff:
        warnings.append('Aplicado o teto de 50% do preço, arredondado para baixo em centavos por política conservadora local.')
    return {'shipping': float(amount), 'basis': 'estimate', 'confirmed': False,
            'price': float(price), 'billableWeightKg': float(weight), 'fastShipping': fast_shipping,
            'fastAlternativeApplied': fast_alternative, 'capApplied': cap is not None and cap < tariff,
            'uncappedTariff': float(tariff), 'weightBand': {key: row[key] for key in ('minExclusiveKg', 'maxInclusiveKg')},
            'priceBand': deepcopy(reference['priceBands'][price_index]),
            'tariffPriceBand': deepcopy(reference['priceBands'][charge_index]),
            'chargeMode': 'fast_shipping_under_79' if fast_alternative else 'standard_price_table',
            'source': deepcopy(reference['source']), 'referenceId': reference['id'],
            'analysisDate': reference['analysisDate'], 'scope': deepcopy(reference['scope']),
            'assumptions': deepcopy(reference['assumptions']), 'warnings': warnings,
            'allApplicableCostsConfirmed': False, 'operationalEligibilityConfirmed': False}


def estimar_shipping(price, billableWeightKg, fastShipping=False, analysis_date=None, *, scope=None):
    """Portuguese/camel-case adapter for the local function-call contract."""
    return estimate_shipping(price, billableWeightKg, fastShipping, analysis_date, scope=scope)


def price_neighbors(price, analysis_date):
    """Nearby table boundaries are simulation options, never recommendations."""
    value = _number(price, 'o preço', positive=True, cents=True)
    reference = reference_data(analysis_date)
    if not reference['available']:
        return []
    lower = max((Decimal(str(band['minInclusive'])) for band in reference['priceBands']
                 if Decimal(str(band['minInclusive'])) <= value), default=Decimal(0))
    if lower <= 0:
        return []
    return [{'boundary': float(lower), 'priceBelow': float(lower - Decimal('.01')),
             'reason': 'Opção para comparar a faixa anterior da tabela vigente; não é recomendação de preço.'}]


def shipping_sensitivity(prices, weights, conditions, fast_shipping, analysis_date):
    """Compare explicit hypothetical billable weights, without measured claims.

    weights: 1..3 {kg,label,reason}; prices: 1..4. All results remain estimates,
    including when applicability conditions were supplied. No customer data is
    mutated; published table values and estimate_shipping arithmetic are reused.
    """
    if not isinstance(prices, list) or not 1 <= len(prices) <= 4:
        raise ShippingReferenceError('Compare de um a quatro preços por simulação.', 'input')
    if not isinstance(weights, list) or not 1 <= len(weights) <= 3:
        raise ShippingReferenceError('Informe de uma a três hipóteses de peso para este produto.', 'input')
    normalized_prices = [_number(price, 'o preço', positive=True, cents=True) for price in prices]
    if len(set(normalized_prices)) != len(normalized_prices):
        raise ShippingReferenceError('Não repita preços na mesma simulação.', 'input')
    reference = reference_data(analysis_date)
    if not reference['available']:
        raise ShippingReferenceError(reference['reason'], 'source_outdated')
    if not isinstance(conditions, dict) or set(conditions) - {
            'sellerReputation', 'productCondition', 'logistics', 'specialCategory', 'freeListing'}:
        raise ShippingReferenceError('Informe as condições hipotéticas de aplicação da tabela.', 'scope')
    _scope_check(conditions, reference)
    hypothesis = []
    for weight in weights:
        if not isinstance(weight, dict) or set(weight) != {'kg', 'label', 'reason'}:
            raise ShippingReferenceError('Cada hipótese precisa de peso, título e fundamento.', 'input')
        kg = _number(weight['kg'], 'o peso hipotético em kg', positive=True)
        if any(not isinstance(weight[key], str) or not weight[key].strip() or len(weight[key]) > limit
               for key, limit in (('label', 100), ('reason', 1000))):
            raise ShippingReferenceError('Descreva e fundamente a hipótese de peso para este produto.', 'input')
        hypothesis.append({'kg': float(kg), 'label': weight['label'].strip(), 'reason': weight['reason'].strip()})
    if len({weight['kg'] for weight in hypothesis}) != len(hypothesis):
        raise ShippingReferenceError('Não repita o mesmo peso na comparação.', 'input')
    labels = {'sellerReputation': 'reputação', 'productCondition': 'condição do produto',
              'logistics': 'modalidade', 'specialCategory': 'categoria especial', 'freeListing': 'anúncio gratuito'}
    values = {'green': 'verde', 'unrated': 'sem reputação', 'mercado_lider': 'Mercado Líder',
              'new': 'novo', 'agency': 'Agência', 'collection': 'Coleta', 'full': 'Full'}
    condition_text = 'Condições hipotéticas da tabela: ' + ', '.join(
        labels[key] + ': ' + (('sim' if value else 'não') if isinstance(value, bool) else values.get(value, str(value)))
        for key, value in sorted(conditions.items()) if value is not None) + '.'
    if not any(value is not None for value in conditions.values()):
        condition_text = 'Simulação supondo condições elegíveis à tabela; reputação, produto, modalidade e exceções não foram conferidos.'
    common_assumptions = [condition_text,
        'O pacote completo pode ser cobrado por peso físico ou volumétrico; não foram calculadas nem confirmadas dimensões ou cubagem.']
    common_assumptions.extend(text for text in reference['assumptions']
                              if not text.startswith('O peso informado é o peso faturável'))
    rows, warnings = [], []
    for price in normalized_prices:
        for weight in hypothesis:
            estimated = estimate_shipping(price, weight['kg'], fast_shipping, analysis_date, scope=conditions)
            weight_text = ('Peso faturável HIPOTÉTICO de ' + format(Decimal(str(weight['kg'])), 'f').replace('.', ',')
                           + ' kg para comparação; não é peso medido, provável ou conferido. ' + weight['reason'])
            rows.append({key: deepcopy(estimated[key]) for key in (
                'price', 'shipping', 'billableWeightKg', 'weightBand', 'priceBand', 'tariffPriceBand',
                'fastShipping', 'fastAlternativeApplied', 'capApplied', 'chargeMode')} |
                {'weightLabel': weight['label'], 'weightReason': weight['reason'], 'assumptions': [weight_text]})
            warnings.extend(estimated['warnings'])
    return {'basis': 'estimate', 'confirmed': False, 'weightBasis': 'hypothetical',
            'source': deepcopy(reference['source']), 'referenceId': reference['id'],
            'analysisDate': reference['analysisDate'], 'conditions': deepcopy(conditions),
            'rows': rows, 'assumptions': common_assumptions, 'warnings': list(dict.fromkeys(warnings)),
            'priceAlternatives': [{'price': float(price), 'neighbors': price_neighbors(price, analysis_date)}
                                  for price in normalized_prices],
            'operationalEligibilityConfirmed': False, 'allApplicableCostsConfirmed': False}
