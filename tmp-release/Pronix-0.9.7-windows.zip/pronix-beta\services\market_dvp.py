"""Pure DVP method evaluation. No I/O, provider calls, fee defaults or projections.

See docs/DVP_CONTRACT.json. `financial` is the scoped financial calculation from
market_rules, not its exact-product verdict. DVP comparisons and confirmations
are independent of Gabriel's exactMatch. Unresolved document rules remain
visible; they only prevent approval when material to the case being evaluated.
"""
from copy import deepcopy
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import re
import unicodedata


DEFAULT_POLICY = {
    'demandMinimumProfile': None, 'customDemandMinimum': None,
    'ageRevenueBands': None, 'recentReviewsRequirement': None,
    'recentReviewsScope': None, 'priceSpreadMethod': None,
    'logisticsGroup': None, 'ticket79Boundary': None,
    'nearPmmTolerance': None, 'minMarginPercent': None, 'revenueBasis': 'lifetime',
}
STATUSES = ('validated', 'not_validated', 'pending', 'risk_review')


def _num(value):
    if value is None or value == '' or isinstance(value, bool): return None
    try:
        raw = str(value).strip().replace('R$', '').replace('%', '').replace(' ', '')
        if ',' in raw: raw = raw.replace('.', '').replace(',', '.')
        number = Decimal(raw)
        return number if number.is_finite() and abs(number) <= Decimal('1e15') else None
    except (InvalidOperation, ValueError): return None


def _nonnegative(value):
    value = _num(value)
    return value if value is not None and value >= 0 else None


def _integer(value):
    value = _nonnegative(value)
    return int(value) if value is not None and value == value.to_integral_value() else None


def _out(value, places=4):
    return float(value.quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP)) if value is not None else None


def _day(value):
    try: return date.fromisoformat(str(value)[:10])
    except (ValueError, TypeError): return None


def _id(value):
    return re.sub(r'[- ]', '', str(value or '')).upper()


def _normal(value):
    return ''.join(c for c in unicodedata.normalize('NFKD', str(value)) if not unicodedata.combining(c)).lower()


def _logistics(value):
    value = _normal(value)
    if 'flex' in value: return None  # Flex has no corresponding table in pages 13/14/17.
    groups = []
    if 'correio' in value: groups.append('correios')
    if 'full' in value: groups.append('full')
    if any(word in value for word in ('agencia', 'coleta', 'places')): groups.append('agency_collection')
    return groups[0] if len(groups) == 1 else None


def _policy(value):
    if value is not None and not isinstance(value, dict): raise ValueError('Confira as regras escolhidas para o método DVP.')
    result = deepcopy(DEFAULT_POLICY)
    result.update({k: deepcopy(v) for k, v in (value or {}).items() if k in result})
    enums = {'demandMinimumProfile': (None, 'page9', 'page17', 'custom'),
             'recentReviewsScope': (None, 'each_listing', 'sample_total'),
             'priceSpreadMethod': (None, 'range'),
             'logisticsGroup': (None, 'correios', 'agency_collection', 'full'),
             'ticket79Boundary': (None, 'allow', 'reject')}
    labels = {'demandMinimumProfile': 'valor mínimo de faturamento', 'recentReviewsScope': 'contagem de avaliações por anúncio ou no total',
              'priceSpreadMethod': 'comparação entre os preços', 'logisticsGroup': 'forma de envio',
              'ticket79Boundary': 'regra para produtos de R$79 nos Correios', 'customDemandMinimum': 'faturamento mínimo personalizado',
              'nearPmmTolerance': 'diferença aceita em relação ao preço médio', 'minMarginPercent': 'margem mínima'}
    for key, choices in enums.items():
        if result[key] not in choices: raise ValueError('Confira a escolha de ' + labels[key] + '.')
    if result['recentReviewsRequirement'] is not None and not isinstance(result['recentReviewsRequirement'], bool):
        raise ValueError('Confirme se as avaliações recentes são obrigatórias.')
    for key in ('customDemandMinimum', 'nearPmmTolerance', 'minMarginPercent'):
        raw = result[key]
        if raw is not None:
            number = _nonnegative(raw)
            if number is None or (key == 'minMarginPercent' and number >= 100): raise ValueError('Confira o valor de ' + labels[key] + '. Use um número não negativo' + (' e menor que 100%' if key == 'minMarginPercent' else '') + '.')
            result[key] = _out(number)
    bands = result['ageRevenueBands']
    if bands is not None:
        if not isinstance(bands, list) or len(bands) > 20: raise ValueError('Faixas de idade DVP inválidas.')
        previous_max, normalized = -1, []
        for band in bands:
            if not isinstance(band, dict): raise ValueError('Faixa de idade DVP inválida.')
            low, high = _integer(band.get('minDays')), _integer(band.get('maxDays'))
            minimum, maximum = _nonnegative(band.get('minRevenue')), _nonnegative(band.get('maxRevenue'))
            if low is None or high is None or low > high or low <= previous_max or minimum is None or (band.get('maxRevenue') is not None and maximum is None) or (maximum is not None and maximum < minimum):
                raise ValueError('Defina faixas de idade ordenadas, sem sobreposição e com limites válidos.')
            previous_max = high
            normalized.append({'minDays': low, 'maxDays': high, 'minRevenue': _out(minimum, 2), 'maxRevenue': _out(maximum, 2)})
        result['ageRevenueBands'] = normalized
    return result


def _age(row, today):
    age, observed = _integer(row.get('ageDays')), _day(row.get('ageObservedAt'))
    if (row.get('ageConfirmed') is True and row.get('ageScope') == 'item' and age is not None
            and row.get('ageSource') and observed and today and observed <= today):
        return age + (today - observed).days, str(row['ageSource'])
    dates = [d for d in (row.get('createdDates') or []) if isinstance(d, dict)
             and d.get('scope') == 'item' and _id(d.get('entityId')) == _id(row.get('itemId') or row.get('id'))
             and d.get('source') and _day(d.get('date')) and today and _day(d['date']) <= today]
    if dates:
        earliest = min(dates, key=lambda d: _day(d['date']))
        if earliest.get('precision') == 'day': return (today - _day(earliest['date'])).days, str(earliest['source'])
    return None, None


def _reviews(record, today, identity=None, sample_ids=None):
    if not isinstance(record, dict): return None
    count = _integer(record.get('count'))
    start, end = _day(record.get('start')), _day(record.get('end'))
    if (count is None or not today or not start or not end or end not in (today, today - timedelta(days=1))
            or (end - start).days != 59 or record.get('complete') is not True or not record.get('source')):
        return None
    if identity is not None and (record.get('scope') != 'item' or _id(record.get('entityId')) != identity): return None
    if sample_ids is not None and (record.get('scope') != 'sample' or
            set(map(_id, record.get('listingIds') or [])) != set(sample_ids)): return None
    return count


def analyze_dvp(product, context, evidence, financial=None, policy=None, override=None):
    """Return computed metrics, exact pending decisions and a separate DVP verdict.

    Money is numeric BRL, ratios are percentage points, missing values are None.
    Metrics can be provisional while first-page or equivalence checks are pending.
    A validated result is method compliance in the declared scenario, never a
    stock-buying instruction or a forecast of the client's revenue.
    """
    if not all(isinstance(x, dict) for x in (product, context, evidence)):
        raise ValueError('Confira os dados do produto, da operação e dos anúncios escolhidos.')
    configured = _policy(policy)
    today = _day(context.get('analysisDate'))
    search, selection = evidence.get('search') or {}, evidence.get('selection') or {}
    if not isinstance(search, dict) or not isinstance(selection, dict): raise ValueError('Confira os dados da busca e os anúncios escolhidos.')
    listings = evidence.get('listings') or []
    if not isinstance(listings, list) or len(listings) > 500: raise ValueError('A comparação aceita até 500 anúncios da página capturada.')
    warnings, pending, checks, failures, cautions = [], [], [], [], []

    def unresolved(key, detail, pages, blocks=True):
        if key not in {p['id'] for p in pending}: pending.append({'id': key, 'detail': detail, 'sourcePages': pages, 'blocksApproval': blocks})

    def check(key, label, passed, detail, pages):
        checks.append({'id': key, 'label': label, 'status': 'complete' if passed is True else 'attention' if passed is False else 'missing', 'detail': detail, 'sourcePages': pages})
        if passed is False: failures.append(detail)
        elif passed is None: unresolved(key, detail, pages)

    if not today: unresolved('analysis-date', 'Informar a data da análise para conferir idade e avaliações recentes.', [8, 9])
    rows, conflicting = {}, set()
    for row in listings:
        if not isinstance(row, dict): raise ValueError('Anúncio DVP inválido.')
        identity = _id(row.get('itemId') or row.get('id'))
        if not identity: continue
        if identity in rows and row != rows[identity]: conflicting.add(identity)
        else: rows[identity] = row
    for identity in conflicting: rows.pop(identity, None)
    if conflicting: warnings.append('Anúncios repetidos com informações diferentes foram retirados da comparação: ' + ', '.join(sorted(conflicting)))
    raw_ids = selection.get('demandIds') or []
    price_ids = selection.get('priceIds') or []
    if not isinstance(raw_ids, list) or not isinstance(price_ids, list): raise ValueError('Selecione os IDs dos anúncios em listas separadas.')
    ids = list(dict.fromkeys(map(_id, raw_ids)))
    pids = list(dict.fromkeys(map(_id, price_ids)))
    five = len(raw_ids) == len(ids) == 5 and all(identity in rows for identity in ids)
    first_page = (search.get('page') == 1 and not isinstance(search.get('page'), bool)
                  and search.get('firstPageConfirmed') is True and bool(search.get('query'))
                  and bool(search.get('url')) and bool(search.get('source'))
                  and bool(today and _day(search.get('observedAt')) == today))
    excluded, eligible = [], []
    for identity in ids:
        row = rows.get(identity) or {}
        reason = None
        if not row: reason = 'Código do anúncio ausente ou com informações diferentes entre os registros.'
        elif row.get('kind') != 'item' or not re.fullmatch(r'MLB\d{5,16}', identity): reason = 'A seleção precisa identificar um anúncio, não um catálogo ou agrupador.'
        elif row.get('active') is False or row.get('current') is False: reason = 'Atividade ou atualidade não confirmada, ou negativa na fonte; conferir novamente.'
        elif row.get('firstPageConfirmed') is not True: reason = 'Presença na primeira página não confirmada.'
        elif row.get('comparison') not in ('equal', 'direct_similar') or row.get('comparisonConfirmed') is not True: reason = 'Produto igual ou similar direto ainda não confirmado para DVP.'
        if reason: excluded.append({'id': identity, 'reason': reason})
        else: eligible.append(identity)
    sample_ok = five and len(eligible) == 5 and first_page and selection.get('confirmed') is True
    check('sample', 'Cinco anúncios confirmados da primeira página', True if sample_ok else None,
          'Cinco anúncios únicos, iguais ou similares diretos, selecionados e confirmados.' if sample_ok else
          'Confira a primeira página na data desta análise e escolha cinco anúncios diferentes, ativos e comparáveis. A busca automática, sozinha, não confirma a posição dos anúncios na página.', [7, 10])

    revenues, known_revenues, revenue_observations, catalog, ages, age_checks = {}, {}, [], {}, [], []
    basis_ok = configured['revenueBasis'] == 'lifetime'
    for identity in ids:
        row = rows.get(identity) or {}
        item = row.get('lifetimeRevenue') or {}
        item = item if isinstance(item, dict) else {}
        value, observed = _nonnegative(item.get('value')), _day(item.get('observedAt'))
        sourced = value is not None and item.get('basis') == 'lifetime' and item.get('source') and observed and today and observed <= today
        if sourced and item.get('scope') == 'item' and _id(item.get('entityId')) == identity and row.get('kind') == 'item':
            known_revenues[identity] = value
            current_revenue = observed == today
            if current_revenue: revenues[identity] = value
            revenue_observations.append({'id': identity, 'value': _out(value, 2), 'scope': 'item', 'entityId': identity,
                'observedAt': observed.isoformat(), 'source': str(item['source']), 'current': current_revenue,
                'usedInTotal': current_revenue and basis_ok})
            if not current_revenue:
                unresolved('revenue-date-' + identity, 'O faturamento acumulado de ' + identity + ' foi consultado em ' + observed.strftime('%d/%m/%Y') + '. Confira o valor atualizado na data desta análise.', [8, 10])
        elif sourced and item.get('scope') == 'catalog' and _id(item.get('entityId')):
            cat_id = _id(item['entityId'])
            if cat_id not in catalog: catalog[cat_id] = {'id': cat_id, 'revenue': _out(value, 2), 'listingIds': [], 'source': item['source'], 'observedAt': observed.isoformat(), 'conflicting': False}
            if catalog[cat_id]['revenue'] != _out(value, 2): catalog[cat_id].update(revenue=None, conflicting=True)
            catalog[cat_id]['listingIds'].append(identity)
        age, age_source = _age(row, today)
        if age is not None: ages.append(age)
        bands = []
        if age is not None:
            definitions = [(age <= 30, 'Até 30 dias', 5000, None), (age <= 60, 'Até 60 dias', 7000, 20000),
                           (age <= 90, 'Até 90 dias', 20000, None), (age > 120, 'Acima de 120 dias', 40000, None)]
            for matches, label, low, high in definitions:
                if matches: bands.append({'label': label, 'minRevenue': low, 'maxRevenue': high,
                    'passed': revenues[identity] >= low and (high is None or revenues[identity] <= high) if identity in revenues else None})
            if 91 <= age <= 120: unresolved('age-91-120', 'A página 8 não define a faixa de 91 a 120 dias; a idade continua informativa.', [8], False)
        age_checks.append({'id': identity, 'ageDays': age, 'source': age_source, 'documentRules': bands, 'informational': configured['ageRevenueBands'] is None})
        if configured['ageRevenueBands'] is not None:
            selected_bands = [b for b in configured['ageRevenueBands'] if age is not None and b['minDays'] <= age <= b['maxDays']]
            ok = (revenues[identity] >= _num(selected_bands[0]['minRevenue']) and
                  (selected_bands[0].get('maxRevenue') is None or revenues[identity] <= _num(selected_bands[0]['maxRevenue']))) if selected_bands and identity in revenues else None
            check('age-' + identity, 'Faixa de idade e receita configurada', ok, 'Comparação da faixa de idade configurada para ' + identity + '.', [8])
    if configured['ageRevenueBands'] is None:
        unresolved('age-bands', 'As faixas de idade da página 8 se sobrepõem; são informativas até confirmação dos intervalos.', [8], False)
    check('age-coverage', 'Idade dos cinco anúncios e média de dias', True if five and len(ages) == 5 else None,
          'Idade do anúncio específico conhecida nos cinco itens; média calculada sem idade de catálogo.' if five and len(ages) == 5 else
          'Informar a idade verificável dos cinco anúncios para a média de dias e a seleção por menor tempo; mês aproximado e idade do primeiro item do catálogo não são idade exata da oferta.', [7, 8, 10])
    total = sum(revenues.values(), Decimal(0)) if five and len(revenues) == 5 and basis_ok else None
    share = total / 10 if total is not None else None
    check('lifetime-revenue', 'Faturamento acumulado dos cinco anúncios', True if total is not None else None,
          'Faturamento acumulado de cada anúncio conferido na data da análise, com a origem registrada. Os 10% são apenas uma parcela desse total, não uma previsão de vendas.' if total is not None else
          'Falta conferir, na data desta análise, o faturamento acumulado desde a criação de cada um dos cinco anúncios. Médias, faixas de quantidade vendida, totais repetidos do catálogo e vendas de apenas 120 dias não mostram esse valor.', [7, 8, 10])
    group = configured['logisticsGroup'] or _logistics(context.get('logistics'))
    price = _nonnegative(product.get('salePrice'))
    low_ticket = price <= 79 if price is not None and price > 0 else None
    check('logistics', 'Forma de envio identificada', True if group else None,
          'Forma de envio: ' + {'correios':'Correios','agency_collection':'Agências / Coleta','full':'Full Mercado Livre'}[group] if group else
          'Confirme a forma de envio. O material não define como avaliar Flex ou combinações de formas de envio.', [5, 13, 14, 17])
    minimum9 = Decimal(5000 if low_ticket else 10000) if low_ticket is not None else None
    minimum17 = Decimal((5000 if low_ticket else 7000) if group == 'correios' else (7000 if low_ticket else 10000)) if low_ticket is not None and group else None
    comparisons = [{'profile': name, 'minimum': _out(minimum, 2), 'passed': share >= minimum if share is not None and minimum is not None else None}
                   for name, minimum in [('page9', minimum9), ('page17', minimum17)]]
    profile = configured['demandMinimumProfile']
    if profile == 'custom':
        minimum = _num(configured['customDemandMinimum'])
        minimum_passed = share >= minimum if share is not None and minimum is not None else None
        comparisons.append({'profile': 'custom', 'minimum': _out(minimum, 2), 'passed': minimum_passed})
    elif profile: minimum_passed = next(c['passed'] for c in comparisons if c['profile'] == profile)
    else:
        values = [c['passed'] for c in comparisons]
        minimum_passed = values[0] if None not in values and values[0] == values[1] else None
        if share is not None and values[0] != values[1]:
            unresolved('demand-minimum-profile', 'Os valores mínimos das páginas 9 e 17 levam a resultados diferentes neste caso. Escolha qual regra usar.', [9, 17])
    check('demand-minimum', '10% do acumulado frente ao mínimo', minimum_passed if sample_ok else None,
          'A fração de 10% atende ao mínimo aplicável.' if minimum_passed is True else
          'Os 10% ficam abaixo do valor mínimo escolhido.' if minimum_passed is False else 'Confirme o faturamento, o preço do produto e o valor mínimo a usar quando as páginas indicam regras diferentes.', [9, 17])

    review_counts = {identity: _reviews((rows.get(identity) or {}).get('recentReviews'), today, identity=identity) for identity in ids}
    each = all(v >= 30 for v in review_counts.values()) if five and all(v is not None for v in review_counts.values()) else None
    sample_count = _reviews(search.get('recentReviews'), today, sample_ids=ids) if five else None
    if sample_count is None and five and all(v is not None for v in review_counts.values()): sample_count = sum(review_counts.values())
    sample_reviews_passed = sample_count >= 30 if sample_count is not None else None
    review_scope = configured['recentReviewsScope']
    review_passed = each if review_scope == 'each_listing' else sample_reviews_passed if review_scope == 'sample_total' else each if each is not None and each == sample_reviews_passed else None
    requirement = configured['recentReviewsRequirement']
    if requirement is True:
        check('recent-reviews', 'Avaliações recentes obrigatórias', review_passed, 'Confirme se há 30 avaliações nos últimos 60 dias, contando por anúncio ou no total, conforme a regra escolhida.' if review_passed is None else 'A quantidade exigida de avaliações recentes foi atingida.' if review_passed else 'A quantidade obrigatória de avaliações recentes não foi atingida.', [7, 9, 18])
    elif requirement is None and review_passed is not True:
        unresolved('reviews-requirement', 'A página 9 trata as avaliações como confirmação extra, e a página 18 inclui essa checagem antes da compra. Defina se ela é obrigatória e se as 30 avaliações são por anúncio ou no total.', [7, 9, 18])

    price_values = [_nonnegative(rows[identity].get('price')) for identity in pids if identity in rows]
    valid_prices = [p for p in price_values if p is not None and p > 0]
    price_observations = []
    for identity in pids:
        row = rows.get(identity) or {}
        observed = _day(row.get('observedAt'))
        price_source = row.get('source') or ('Conferido pelo especialista' if row.get('confirmationSource') == 'specialist' else None)
        current_price = bool(today and observed == today and price_source and row.get('current') is not False and row.get('active') is not False)
        price_observations.append({'id': identity, 'price': _out(_nonnegative(row.get('price')), 2),
            'observedAt': observed.isoformat() if observed else None, 'source': price_source, 'current': current_price})
    average = sum(valid_prices, Decimal(0)) / len(valid_prices) if valid_prices else None
    price_confirmed = bool(pids) and len(price_values) == len(pids) == len(valid_prices) and first_page and all(p['current'] for p in price_observations) and all(
        rows[identity].get('kind') == 'item' and rows[identity].get('firstPageConfirmed') is True and
        rows[identity].get('active') is not False and rows[identity].get('current') is not False and
        rows[identity].get('comparison') in ('equal', 'direct_similar') and rows[identity].get('comparisonConfirmed') is True for identity in pids)
    check('pmm', 'Preço médio de mercado', True if price_confirmed else None,
          'Preço médio calculado dos anúncios escolhidos, com preços conferidos na data da análise. Eles podem ser diferentes dos cinco usados para comparar faturamento.' if price_confirmed else 'Confira os preços de cada anúncio na data desta análise, registre onde consultou e confirme se os produtos são iguais ou similares diretos. Confirmar a primeira página não confirma o preço.', [12])
    spread = max(valid_prices) - min(valid_prices) if valid_prices else None
    spread_limit = Decimal(30 if low_ticket else 70) if low_ticket is not None else None
    discrepancy = spread > spread_limit if spread is not None and spread_limit is not None else None
    if configured['priceSpreadMethod'] is None:
        unresolved('spread-method', 'A tela mostra a diferença entre o maior e o menor preço. O material não define como medir essa diferença.' +
                   (' Como ela é alta neste caso, confirme a regra antes de aprovar.' if discrepancy is True and minimum_passed is True else ''),
                   [12], discrepancy is True and minimum_passed is True)
    if configured['priceSpreadMethod'] == 'range' and discrepancy is True and minimum_passed is True:
        cautions.append('Há uma diferença grande entre os preços e o faturamento mínimo foi atingido. Vale investigar se há concorrência excessiva; esses números sozinhos não confirmam isso.')
    position_passed, reference_min, reference_max, direct_price = None, None, None, None
    if group and average is not None and price is not None:
        if group == 'full': reference_max, position_passed = average, price <= average
        elif group == 'agency_collection':
            tolerance = _nonnegative(configured['nearPmmTolerance'])
            if price == average: reference_min = reference_max = average; position_passed = True
            elif tolerance is not None:
                reference_min, reference_max = average - tolerance, average + tolerance
                position_passed = reference_min <= price <= reference_max
            else: unresolved('near-pmm', 'Para Agências/Coleta, defina quanto o seu preço pode ficar acima ou abaixo do preço médio. Se forem iguais, essa diferença já é zero.', [13])
        else:
            reference_min, reference_max = average - 30, average - 20
            position_passed = reference_min <= price <= reference_max
            direct = search.get('superiorLogisticsReference') or {}
            if isinstance(direct, dict):
                candidate_price = _nonnegative(direct.get('price'))
                observed = _day(direct.get('observedAt'))
                if (candidate_price is not None and candidate_price > 0 and direct.get('confirmed') is True
                        and direct.get('turnoverConfirmed') is True and direct.get('source') and observed and today and observed <= today
                        and direct.get('logisticsGroup') in ('agency_collection', 'full')):
                    direct_price = candidate_price
            if direct_price is None:
                unresolved('correios-direct-reference', 'Para Correios, confira também o menor preço entre concorrentes que já vendem e têm entrega mais competitiva.', [13])
    check('price-position', 'Preço conforme a logística', position_passed if price_confirmed else None,
          'Seu preço está dentro da faixa indicada para sua forma de envio.' if position_passed is True else 'Seu preço está fora da faixa indicada para sua forma de envio.' if position_passed is False else 'Confirme o preço médio, o preço pretendido e a diferença aceita para sua forma de envio.', [13])
    if group == 'correios' and price is not None:
        if price < 79 or (price == 79 and configured['ticket79Boundary'] == 'reject'):
            check('correios-ticket', 'Preço do produto enviado por Correios', False, 'O método não recomenda vender nesta faixa de preço usando Correios.', [5, 18])
        elif price == 79 and configured['ticket79Boundary'] != 'allow':
            unresolved('ticket-79', 'Confirmar o limite de R$79 exatos: página 5 exclui abaixo de R$79 e página 18 pede acima.', [5, 18])

    full_count, listings_count = _integer(search.get('fullCount')), _integer(search.get('totalListings'))
    counts_ok = (first_page and search.get('countsComplete') is True and full_count is not None
                 and listings_count is not None and full_count <= listings_count and listings_count >= len(set(ids + pids)))
    full_limit = None if group == 'full' or low_ticket is None else 35 if group == 'agency_collection' else (0 if low_ticket else 20) if group == 'correios' else None
    full_passed = True if group == 'full' else full_count <= full_limit if counts_ok and full_limit is not None else None
    check('full-competition', 'Concorrência Full na primeira página', full_passed,
          'A tabela dispensa limite Full para quem já opera no Full.' if group == 'full' else 'Contagem Full dentro do limite documental.' if full_passed else 'Contagem Full supera o limite documental.' if full_passed is False else 'Conferir a contagem completa de anúncios Full na primeira página.', [17])

    f = financial if isinstance(financial, dict) else {}
    profit, margin = _num(f.get('profit')), _num(f.get('marginPercent'))
    financial_complete = (f.get('complete') is True and f.get('upperBound') is not True and price is not None and
        _num(f.get('salePrice')) == price and all(_num(f.get(k)) is not None for k in
        ('cost', 'commissionAmount', 'fixedFee', 'taxAmount', 'shipping', 'otherCosts', 'profit', 'marginPercent')))
    check('costs', 'Custos da operação conferidos', True if financial_complete else None,
          'Todos os custos foram conferidos para o preço de venda informado.' if financial_complete else 'Confirme custo, comissão, tarifa, imposto, frete e outras despesas no preço pretendido. O material do método não substitui a cotação real do frete.', [11, 14])
    quantity = _integer(product.get('purchaseQuantity'))
    doc_margin = None
    if quantity is not None and 0 < quantity <= 30 and group:
        doc_margin = -10 if group == 'correios' else 0
    elif quantity is not None and 50 <= quantity <= 100 and group in ('agency_collection', 'full'): doc_margin = 3
    effective_margin = _num(configured['minMarginPercent']) if configured['minMarginPercent'] is not None else Decimal(doc_margin) if doc_margin is not None else None
    margin_passed = margin >= effective_margin if financial_complete and margin is not None and effective_margin is not None else None
    check('margin', 'Margem no lote informado', margin_passed,
          'A margem atende ao valor de referência. Quando a conta apenas empata, não há lucro.' if margin_passed is True else
          'A margem fica abaixo do valor de referência para a quantidade de compra.' if margin_passed is False else 'Defina a quantidade de compra e a margem mínima. O material não traz uma regra para compras de 31 a 49 ou acima de 100 unidades; você pode informar uma margem mínima própria.', [14])
    negative = profit is not None and profit < 0
    if negative: cautions.append('O cenário tem prejuízo unitário. A orientação de até −10% para Correios nunca autoriza aprovação automática ou compra de estoque.')
    elif financial_complete and profit == 0: cautions.append('A conta empata, sem lucro por unidade. Antes da primeira compra, revise o risco e o dinheiro necessário para manter a operação.')
    if negative: status = 'risk_review'
    elif failures: status = 'not_validated'
    elif any(p['blocksApproval'] for p in pending): status = 'pending'
    elif cautions: status = 'risk_review'
    else: status = 'validated'
    reasons = list(dict.fromkeys(cautions + failures + [p['detail'] for p in pending if p['blocksApproval']]))
    if not reasons: reasons = ['Os critérios DVP aplicáveis foram atendidos no cenário informado; isso não garante vendas, margem futura ou posição na primeira página.']
    calculated = {'status': status, 'reasons': reasons}
    final, manual = deepcopy(calculated), None
    if override is not None:
        if not isinstance(override, dict) or override.get('status') not in STATUSES or not str(override.get('reason') or '').strip():
            raise ValueError('Informe um status DVP válido e o motivo da revisão do especialista.')
        manual = {'status': override['status'], 'reason': str(override['reason']).strip()[:2000]}
        final = {'status': manual['status'], 'reasons': [manual['reason']], 'source': 'specialist_override'}
    return {'method': 'dvp', 'version': 1,
        'sample': {'requestedCount': 5, 'selectedCount': len(raw_ids), 'uniqueCount': len(ids), 'confirmed': sample_ok,
                   'firstPageConfirmed': first_page, 'eligibleCount': len(eligible), 'selectedIds': ids, 'excluded': excluded},
        'demand': {'revenueBasis': configured['revenueBasis'], 'revenueTotal': _out(total, 2),
            'knownRevenueTotal': _out(sum(known_revenues.values(), Decimal(0)), 2) if known_revenues else None,
            'revenueCount': len(revenues), 'tenPercent': _out(share, 2), 'minimumComparisons': comparisons,
            'revenueObservations': revenue_observations,
            'minimumPassed': minimum_passed, 'selectedProfile': profile,
            'ageDaysAverage': _out(Decimal(sum(ages)) / len(ages)) if ages else None, 'ageCount': len(ages), 'ageChecks': age_checks,
            'reviews': {'sampleCount': sample_count, 'samplePassed': sample_reviews_passed, 'eachListingPassed': each,
                        'required': requirement, 'scope': review_scope, 'passed': review_passed}, 'catalogContext': list(catalog.values())},
        'pricing': {'sampleCount': len(pids), 'priceCount': len(valid_prices), 'sampleConfirmed': price_confirmed,
            'priceCurrentCount': sum(p['current'] for p in price_observations), 'priceObservations': price_observations,
            'priceAverage': _out(average, 2), 'priceMin': _out(min(valid_prices), 2) if valid_prices else None,
            'priceMax': _out(max(valid_prices), 2) if valid_prices else None, 'priceSpread': _out(spread, 2),
            'spreadThreshold': _out(spread_limit, 2), 'discrepancyAboveThreshold': discrepancy,
            'positioning': {'status': 'validated' if position_passed is True else 'not_validated' if position_passed is False else 'pending',
                'referenceMin': _out(reference_min, 2), 'referenceMax': _out(reference_max, 2),
                'directReferencePrice': _out(direct_price, 2), 'note': 'Referência de preço do método, não cotação de frete nem garantia de venda. A referência direta de logística superior é exibida separadamente; o documento não define outra fórmula de desconto sobre ela.'}},
        'viability': {'financialComplete': financial_complete, 'profit': _out(profit, 2), 'marginPercent': _out(margin),
            'purchaseQuantity': quantity, 'documentMarginReference': doc_margin, 'minimumMarginPercent': _out(effective_margin),
            'marginPassed': margin_passed, 'negativeProfit': negative, 'note': 'Custos vêm do motor financeiro no cenário confirmado; frete grátis ao comprador não implica frete zero ao vendedor.'},
        'positioning': {'logisticsGroup': group, 'fullCount': full_count, 'totalListings': listings_count,
            'fullLimit': full_limit, 'fullPassed': full_passed, 'countsConfirmed': counts_ok, 'note': 'Limites internos do documento DVP, página 17; não são regras da plataforma.'},
        'checklist': checks, 'pendingDecisions': pending, 'verdict': {'calculated': calculated, 'final': final, 'override': manual},
        'policy': configured, 'provenance': {'methodDocument': 'Reunião de Análise de Mercado · Método DVP',
            'sourcePages': [5, 7, 8, 9, 10, 12, 13, 14, 16, 17, 18], 'analysisDate': context.get('analysisDate'),
            'revenueBasis': configured['revenueBasis'], 'note': 'Acumulado desde criação é a base documental atual. Não é receita de 120 dias, previsão de participação ou validação de condições comerciais atuais da plataforma.'},
        'warnings': warnings + ['A fração de 10% não é previsão de faturamento do cliente.', 'DVP aceita similares diretos confirmados; essa confirmação não altera o critério exato do método Gabriel.']}
