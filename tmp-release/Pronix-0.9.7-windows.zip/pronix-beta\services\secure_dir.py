"""Pasta única das conexões protegidas (DPAPI) do Pronix.

Fica em ``%USERPROFILE%\\.pronix-beta``: fora do iCloud e fora do AppData, que o
Windows redireciona para uma área privada quando o servidor é iniciado por um
app da loja (Codex, Claude). Pode ser trocada pela variável PRONIX_DATA_DIR.
"""
from __future__ import annotations

import os
from pathlib import Path
import shutil

FILES = ("joompulse.dpapi", "hub-bridge.dpapi", "google.dpapi", "mercadolivre.dpapi", "atualizacao.dpapi")


def secure_dir() -> Path:
    override = os.environ.get("PRONIX_DATA_DIR")
    if override:
        return Path(override)
    home = os.environ.get("USERPROFILE") or str(Path.home())
    return Path(home) / ".pronix-beta"


def legacy_dirs() -> list[Path]:
    """Locais usados pelas versões anteriores (AppData real e áreas isoladas de apps)."""
    home = Path(os.environ.get("USERPROFILE") or Path.home())
    local = Path(os.environ.get("LOCALAPPDATA") or home / "AppData" / "Local")
    found = [local / "PronixBeta"]
    packages = home / "AppData" / "Local" / "Packages"
    if packages.is_dir():
        found.extend(sorted(packages.glob("*/LocalCache/Local/PronixBeta")))
    return [path for path in found if path.is_dir()]


def migrate_legacy(target: Path | None = None) -> list[str]:
    """Copia (nunca move) cada conexão ausente na pasta nova, escolhendo a cópia mais recente."""
    target = target or secure_dir()
    copied = []
    for name in FILES:
        if (target / name).exists():
            continue
        candidates = [folder / name for folder in legacy_dirs() if (folder / name).is_file()]
        if not candidates:
            continue
        newest = max(candidates, key=lambda path: path.stat().st_mtime)
        target.mkdir(parents=True, exist_ok=True)
        temporary = target / (name + ".migrating")
        shutil.copy2(newest, temporary)
        os.replace(temporary, target / name)
        copied.append(name)
    return copied
