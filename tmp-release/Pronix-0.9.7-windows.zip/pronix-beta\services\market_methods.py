"""Choose or compare deterministic methods without changing the specialist's review."""
from copy import deepcopy
import json
import math

from .market_decision import LABELS, MAP, _pack_messages, _fmt, decision_for

METHODS = {'gabriel':'Gabriel', 'dvp':'André · Pronix DVP', 'combined':'Gabriel + DVP'}
COMBINATION_RULE = ('Os dois métodos precisam concordar para validar ou invalidar automaticamente. '
                    'Quando discordam, ou falta uma conferência, o resultado fica em Atenção. '
                    'A decisão do especialista continua disponível e não apaga os cálculos.')


def normalize_methodology(value=None, default='gabriel'):
    if value is None:
        value = {'mode':default}
    if isinstance(value,str): value={'mode':value}
    if not isinstance(value,dict): raise ValueError('Escolha uma forma de análise válida.')
    mode=value.get('mode',default)
    if mode not in METHODS: raise ValueError('Escolha Gabriel, André / DVP ou os dois métodos.')
    policy=value.get('dvpPolicy') or {}
    if not isinstance(policy,dict): raise ValueError('Confira os critérios da análise DVP.')
    try:
        encoded=json.dumps(policy,allow_nan=False,ensure_ascii=False)
    except (ValueError,TypeError): raise ValueError('Os critérios DVP contêm um valor inválido.') from None
    if len(encoded)>30000: raise ValueError('Os critérios DVP ultrapassam o tamanho permitido.')
    return {'version':1,'mode':mode,'dvpPolicy':deepcopy(policy)}


def _finite(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)


def dvp_decision(result, entry):
    verdict=(result.get('verdict') or {}).get('calculated') or {}
    raw=verdict.get('status','pending')
    available=bool((entry.get('evidence') or {}).get('reference') or (entry.get('dvpReview') or {}).get('listings'))
    status={'validated':'validado','not_validated':'invalidado','risk_review':'atencao',
            'pending':'atencao' if available else 'nao_concluido'}.get(raw,'nao_concluido')
    reason=list(verdict.get('reasons') or [])
    demand=result.get('demand') or {}; pricing=result.get('pricing') or {}; finance=result.get('viability') or {}
    opening={'validado':'Validado pelos critérios DVP escolhidos para esta análise.',
             'invalidado':'O produto não atende aos critérios DVP conferidos neste cenário.',
             'atencao':'Atenção: confira os pontos indicados pelo método DVP antes de decidir a compra.',
             'nao_concluido':'Ainda faltam os anúncios e as informações necessários para concluir o DVP.'}[status]
    parts=[(0,opening)]
    if _finite(demand.get('tenPercent')):
        parts.append((2,'Os 10% do faturamento acumulado dos cinco anúncios somam '+_fmt(demand['tenPercent'],True)+
                      '; essa conta não é uma previsão de vendas do cliente.'))
    if _finite(pricing.get('priceAverage')):
        parts.append((3,'Preço médio dos anúncios usados na comparação: '+_fmt(pricing['priceAverage'],True)+'.'))
    if _finite(demand.get('ageDaysAverage')):
        parts.append((4,'Tempo médio desde a criação dos anúncios: '+_fmt(demand['ageDaysAverage'])+' dias; não é prazo para vender o estoque.'))
    if finance.get('financialComplete') and _finite(finance.get('profit')):
        parts.append((1,'Resultado por unidade: '+_fmt(finance['profit'],True)+' e margem de '+_fmt(finance.get('marginPercent'))+'%, considerando os custos conferidos.'))
    elif not finance.get('financialComplete'):
        parts.append((1,'A margem final depende de completar e conferir as taxas, o frete e os demais custos.'))
    if finance.get('negativeProfit'):
        parts.append((0,'Há prejuízo por unidade neste cenário. O programa não recomenda a compra automaticamente.'))
    for text in reason[:3]: parts.append((2,str(text)))
    return {'status':status,'label':LABELS[status],'message':_pack_messages(parts),'source':'dvp_rules',
            'preliminary':raw=='pending','reasons':reason,'specialistOverride':False,'method':'dvp'}


def combine_decisions(gabriel,dvp):
    a,b=gabriel['status'],dvp['status']
    if a==b and a in ('validado','invalidado','nao_concluido'): status=a
    else: status='atencao'
    title={'validado':'Os dois métodos concordam: produto validado nos critérios conferidos.',
           'invalidado':'Os dois métodos apontam que o produto não está validado neste cenário.',
           'nao_concluido':'Os dois métodos ainda precisam de dados para concluir.',
           'atencao':'Atenção: os resultados dos dois métodos precisam ser conferidos em conjunto.'}[status]
    parts=[(0,title),(0,'Gabriel: '+gabriel['label']+'. André / DVP: '+dvp['label']+'.')]
    for name,decision in (('Gabriel',gabriel),('DVP',dvp)):
        if decision.get('reasons'): parts.append((1,name+': '+str(decision['reasons'][0])))
    if status=='validado': parts.append((1,'A análise não garante vendas; mantenha os custos e os anúncios usados na comparação atualizados.'))
    return {'status':status,'label':LABELS[status],'message':_pack_messages(parts),'source':'combined_rules',
            'preliminary':gabriel.get('preliminary') is True or dvp.get('preliminary') is True,
            'reasons':[COMBINATION_RULE,*gabriel.get('reasons',[]),*dvp.get('reasons',[])],
            'specialistOverride':False,'method':'combined','combinationRule':COMBINATION_RULE}


def apply_methods(entry, context, methodology):
    from .market_dvp import analyze_dvp
    analysis=entry['analysis']
    original=decision_for(entry)
    gabriel=deepcopy(original.get('calculated') or original)
    gabriel.update(method='gabriel',source='local_rules',specialistOverride=False,
                   preliminary=original.get('preliminary',False),reasons=deepcopy(original.get('reasons') or []))
    # Manual overrides cannot change either method's independent comparison.
    gabriel['preliminary']=(analysis.get('verdict') or {}).get('calculated',{}).get('status')=='insufficient'
    result=analyze_dvp({**entry['source'],**entry['inputs']},context,entry['dvpReview'],
                       financial=analysis.get('financial'),policy=methodology['dvpPolicy'])
    dvp=dvp_decision(result,entry)
    combined=combine_decisions(gabriel,dvp)
    analysis['dvp']=result
    analysis['methods']={'selected':methodology['mode'],'gabriel':gabriel,'dvp':dvp,'combined':combined,
                         'combinationRule':COMBINATION_RULE}
    selected=deepcopy(analysis['methods'][methodology['mode']])
    selected['calculated']=deepcopy(selected)
    override=(analysis.get('verdict') or {}).get('override')
    if override:
        status=MAP.get(override.get('status'),'nao_concluido')
        reviewed=(entry.get('review') or {}).get('override') or {}
        selected.update(status=status,label=LABELS[status],message=str(reviewed.get('reason') or override.get('reason') or ''),
                        source='specialist_review',specialistOverride=True,preliminary=False)
    analysis['decision']=selected
