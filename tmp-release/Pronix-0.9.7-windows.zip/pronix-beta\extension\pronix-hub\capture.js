// Both functions are self-contained: chrome.scripting serializes their bodies.
// They run in Chrome's ISOLATED world and only read the rendered page DOM.
export function readClientName(expectedUrl) {
  if (location.href !== expectedUrl ||
      !/^https:\/\/pronixhub\.com\.br\/validacao-planilhas\/[A-Za-z0-9_-]{1,128}\/?$/.test(expectedUrl)) {
    throw new Error("A aba mudou. Atualize a lista no aplicativo.");
  }
  const heading = document.querySelector("main header h1, main h1");
  const name = (heading?.innerText || "").replace(/\s+/g, " ").trim().slice(0, 180);
  if (location.href !== expectedUrl) throw new Error("A aba mudou durante a leitura.");
  return {url: location.href, name};
}

export function capturePage(expectedUrl, maxBytes = 2097152) {
  const validUrl = value => typeof value === "string" && /^https:\/\/pronixhub\.com\.br\/validacao-planilhas\/[A-Za-z0-9_-]{1,128}\/?$/.test(value);
  if (!validUrl(expectedUrl) || location.href !== expectedUrl) {
    throw new Error("A aba mudou. Atualize a lista e selecione novamente o cliente.");
  }
  const ignored = "script,style,template,noscript,form,button,textarea,input,select,svg,iframe,object,embed,canvas,[hidden],[aria-hidden='true']";
  const visible = (element, reviewControl = false) => {
    for (let node = element; node && node.nodeType === 1; node = node.parentElement) {
      if (node.matches(ignored) && !(reviewControl && node.matches("button,textarea"))) return false;
      const style = getComputedStyle(node);
      if (style.display === "none" || style.visibility === "hidden") return false;
    }
    return true;
  };
  const clean = value => String(value || "").replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g, "").replace(/\s+/g, " ").trim();
  const text = (element, reviewControl = false) => {
    if (!element || !visible(element, reviewControl)) return "";
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    const parts = [];
    while (walker.nextNode()) {
      if (visible(walker.currentNode.parentElement, reviewControl)) parts.push(walker.currentNode.nodeValue);
    }
    return clean(parts.join(" "));
  };
  const key = value => clean(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[: ]+$/, "");
  const escape = value => String(value).replace(/[&<>"']/g, character => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[character]));
  const main = document.querySelector("main");
  if (!main) throw new Error("Abra a tabela de validação com os produtos visíveis.");
  const headers = [...main.querySelectorAll("header")].filter(header => visible(header) && header.querySelector("h1"));
  const header = headers[0];
  const heading = header?.querySelector("h1") || main.querySelector("h1");
  const clientName = text(heading);
  if (!clientName) throw new Error("O nome do cliente não está visível. Aguarde a página carregar.");
  const metadataLabels = new Set(["logistica", "cidade / estado", "imposto"]);
  const metadata = new Map();
  if (header) {
    for (const node of header.querySelectorAll("*")) {
      if (node.children.length !== 2 || !visible(node)) continue;
      const label = text(node.children[0]);
      const labelKey = key(label);
      if (metadataLabels.has(labelKey) && !metadata.has(labelKey)) {
        metadata.set(labelKey, [label, text(node.children[1])]);
      }
    }
  }
  const fieldLabels = new Set(["custo de compra", "preco de venda", "margem informada", "minimo de compra", "preco medio do produto"]);
  const verdicts = new Set(["validado", "atencao", "invalidado", "nao avaliado"]);
  const reviewScope = (article, kind) => {
    const marker = kind === "robot" ? "leitura da automacao" : "seu parecer";
    const labels = [...article.querySelectorAll(".pm-label,h4,h5")].filter(node => key(text(node)) === marker);
    if (labels.length !== 1) return null;
    for (let parent = labels[0].parentElement; parent && parent !== article; parent = parent.parentElement) {
      if (kind === "robot" && parent.querySelector("dl")) return parent;
      if (kind === "specialist" && parent.querySelector("textarea")) return parent;
      if (kind === "specialist" && parent.querySelector("p") && [...parent.querySelectorAll("span")].some(node => verdicts.has(key(text(node))))) return parent;
    }
    return null;
  };
  const captureReview = (article, kind) => {
    const scope = reviewScope(article, kind);
    if (!scope || !visible(scope)) return "";
    const labels = [...scope.querySelectorAll("span")].map(node => text(node)).filter(value => verdicts.has(key(value)));
    if (kind === "specialist") {
      for (const button of scope.querySelectorAll("button")) {
        if (button.getAttribute("aria-pressed") === "true" && visible(button, true)) {
          const label = text(button, true); if (verdicts.has(key(label))) labels.push(label);
        }
      }
    }
    const uniqueLabels = [...new Set(labels)];
    const badges = uniqueLabels.map(label => `<span>${escape(label)}</span>`).join("");
    const stamp = text(scope).match(/\b\d{2}\/\d{2}\/\d{4},?\s+\d{2}:\d{2}\b/)?.[0] || "";
    const title = kind === "robot" ? "Leitura da automação" : "Seu parecer";
    let body = "";
    if (kind === "robot") {
      const metrics = []; let pending = null;
      for (const node of scope.querySelectorAll("dt,dd")) {
        if (!visible(node)) continue;
        if (node.tagName === "DT") pending = text(node);
        else { if (pending !== null) metrics.push([pending, text(node)]); pending = null; }
      }
      const margin = text(scope).match(/margem estimada\s+([+-]?[\d.,]+\s*%)/i)?.[1];
      body = (margin ? `<span>margem estimada ${escape(margin)}</span>` : "") +
        `<dl>${metrics.map(([name, value]) => `<div><dt>${escape(name)}</dt><dd>${escape(value)}</dd></div>`).join("")}</dl>` +
        [...scope.querySelectorAll("p,li")].filter(node => visible(node)).map(node => `<p>${escape(text(node))}</p>`).join("");
    } else {
      const controls = [...scope.querySelectorAll("textarea")].filter(node => visible(node, true));
      if (controls.length > 1) throw new Error("Há mais de um campo de parecer no produto. Revise a página antes de importar.");
      // Read only the specialist's rendered control; never React state or APIs.
      const note = controls.length === 1 ? String(controls[0].value ?? controls[0].textContent ?? "") :
        [...scope.querySelectorAll("p")].filter(node => visible(node)).map(node => text(node)).join("\n");
      body = `<p data-pronix-review-text="specialist">${escape(note)}</p>`;
    }
    return `<section data-pronix-review="${kind}" data-pronix-assessed-at="${escape(stamp)}"><h4>${title}</h4>${badges}${body}</section>`;
  };
  const cards = [];
  for (const article of main.querySelectorAll("article.pm-panel")) {
    if (!visible(article)) continue;
    const label = [...article.querySelectorAll(".pm-label")].find(node => /^Produto\s+\d+$/i.test(text(node)));
    const productHeading = article.querySelector("h3");
    const dl = article.querySelector("dl");
    if (!label) continue;
    if (!productHeading || !text(productHeading) || !dl || !visible(dl)) {
      throw new Error(`${text(label)}: o card ainda não está completo. Aguarde a página carregar antes de importar.`);
    }
    const fields = [];
    let pending = null;
    for (const node of dl.querySelectorAll("dt,dd")) {
      if (!visible(node)) continue;
      if (node.tagName === "DT") {
        const field = text(node);
        pending = fieldLabels.has(key(field)) ? field : null;
      } else {
        if (pending !== null) fields.push([pending, text(node)]);
        pending = null;
      }
    }
    // Optional package line outside the table: "Embalagem: 192 g · 27 × 15 × 15 cm".
    const packaging = [...article.querySelectorAll("p,div")].filter(node => /^embalagem:/i.test(text(node))).sort((a, b) => text(a).length - text(b).length)[0];
    if (packaging) fields.push(["Embalagem", text(packaging).replace(/^embalagem:\s*/i, "").slice(0, 120)]);
    const presentFields = new Set(fields.map(([name]) => key(name)));
    if (![...fieldLabels].every(name => presentFields.has(name))) {
      throw new Error(`${text(label)}: os campos comerciais ainda não estão completos. Aguarde o carregamento.`);
    }
    const links = [];
    for (const anchor of article.querySelectorAll("a")) {
      if (!visible(anchor) || !(anchor.compareDocumentPosition(dl) & Node.DOCUMENT_POSITION_FOLLOWING) ||
          !key(text(anchor)).includes("abrir anuncio de referencia")) continue;
      const href = anchor.getAttribute("href") || "";
      let url;
      try { url = new URL(href); } catch { throw new Error(`${text(label)}: o link de referência precisa de revisão.`); }
      if (!["https:", "http:"].includes(url.protocol) || url.username || url.password) {
        throw new Error(`${text(label)}: o link de referência precisa de revisão.`);
      }
      // Keep every reference, including distinct links in the same card: the
      // application must flag structural ambiguity rather than pick one.
      links.push(`<a href="${escape(href)}">Abrir anúncio de referência</a>`);
    }
    cards.push(`<article class="pm-panel"><span class="pm-label">${escape(text(label))}</span><h3>${escape(text(productHeading))}</h3>${links.join("")}<dl>${fields.map(([name, value]) => `<div><dt>${escape(name)}</dt><dd>${escape(value)}</dd></div>`).join("")}</dl>${captureReview(article, "robot")}${captureReview(article, "specialist")}</article>`);
    if (cards.length > 500) throw new Error("A página contém mais de 500 produtos. Divida a importação.");
  }
  if (!cards.length) throw new Error("Nenhum card de produto foi encontrado. Abra a tabela completa e aguarde o carregamento.");
  const reviewer = header ? [...header.querySelectorAll("p")].map(node => text(node)).find(value => /\brevisor:\s*\S/i.test(value))?.match(/\brevisor:\s*(.+)$/i)?.[1] : "";
  const capturedAt = new Date().toISOString();
  const html = `<!doctype html><html lang="pt-BR"><body><main data-pronix-captured-at="${escape(capturedAt)}" data-pronix-source-url="${escape(expectedUrl)}"><header><h1>${escape(clientName)}</h1>${reviewer ? `<p>revisor: ${escape(reviewer)}</p>` : ""}${[...metadata.values()].map(([name, value]) => `<div><span>${escape(name)}</span><span>${escape(value)}</span></div>`).join("")}</header>${cards.join("")}</main></body></html>`;
  if (new TextEncoder().encode(html).byteLength > Math.min(maxBytes, 2097152)) {
    throw new Error("A tabela ultrapassa o limite de 2 MB. Divida os produtos antes de importar.");
  }
  if (location.href !== expectedUrl) throw new Error("A aba mudou durante a captura. Nenhum dado foi enviado.");
  return {url: expectedUrl, title: clientName, html, capturedAt};
}
