﻿; Instalador .exe da Central de Análises (Inno Setup 6).
; Gerado por instalador\montar-pacote.ps1 a partir da pasta montada do pacote (python + pronix-beta).
; Uso manual: ISCC.exe /DVersao=0.9.3 /DPacote=<pasta do pacote> /DSaida=<pasta de saída> central.iss

#ifndef Versao
  #define Versao "0.0.0"
#endif
#ifndef Pacote
  #error Informe /DPacote=<pasta do pacote montado>
#endif
#ifndef Saida
  #define Saida "..\..\dist"
#endif

[Setup]
AppId={{36B15936-81CD-4F11-ACFE-F903DF35BF00}
AppName=Central de Análises
AppVersion={#Versao}
AppVerName=Central de Análises {#Versao}
AppPublisher=Vórtex
AppPublisherURL=https://vortexoec.github.io/central/
AppSupportURL=https://vortexoec.github.io/central/
VersionInfoVersion={#Versao}
VersionInfoCompany=Vórtex
VersionInfoDescription=Instalador da Central de Análises
VersionInfoProductName=Central de Análises
; Instala só para o usuário atual: não pede senha de administrador.
PrivilegesRequired=lowest
DefaultDirName={%USERPROFILE}\Pronix
DisableWelcomePage=no
DisableDirPage=yes
DisableProgramGroupPage=yes
DisableReadyPage=yes
UsePreviousAppDir=no
LicenseFile=termos.txt
WizardStyle=modern
WizardImageFile=lateral-100.bmp,lateral-125.bmp,lateral-150.bmp,lateral-200.bmp,lateral-250.bmp
WizardSmallImageFile=pequena-100.bmp,pequena-125.bmp,pequena-150.bmp,pequena-200.bmp,pequena-250.bmp
SetupIconFile=..\..\static\central.ico
UninstallDisplayIcon={app}\pronix-beta\static\central.ico
UninstallDisplayName=Central de Análises
Compression=lzma2/ultra64
SolidCompression=yes
OutputDir={#Saida}
OutputBaseFilename=Instalar-Central-de-Analises-{#Versao}
CloseApplications=no
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0

[Languages]
Name: "pt"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Messages]
pt.WelcomeLabel1=Bem-vindo à Central de Análises
pt.WelcomeLabel2=Este assistente instala a Central de Análises da Vórtex neste computador.%n%nÉ rápido: não precisa instalar mais nada nem ter senha de administrador. No fim, a Central abre sozinha.
pt.FinishedHeadingLabel=Pronto!
pt.FinishedLabel=A Central de Análises foi instalada. Ela fica no atalho "Central de Análises" da Área de Trabalho.%n%nPróximo passo: instale a extensão do Chrome pelo link que a equipe enviou. Com a Central aberta, a extensão se conecta sozinha.

[Files]
; O pacote vai para uma pasta temporária; o instalar.ps1 copia para o destino preservando dados e conexões.
Source: "{#Pacote}\*"; DestDir: "{tmp}\pacote"; Flags: recursesubdirs createallsubdirs ignoreversion deleteafterinstall
Source: "desinstalar.ps1"; DestDir: "{app}"; Flags: ignoreversion

[Run]
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\pronix-beta\iniciar.ps1"" -Janela"; Description: "Abrir a Central de Análises agora"; Flags: postinstall nowait skipifsilent runhidden

[UninstallRun]
Filename: "{sys}\WindowsPowerShell\v1.0\powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""{app}\desinstalar.ps1"" -Destino ""{app}"""; Flags: runhidden waituntilterminated; RunOnceId: "RemoverCentral"

[Code]
const
  ChavePessoa = 'Software\Vortex\CentralAnalises';
var
  PaginaPessoa: TInputQueryWizardPage;

procedure InitializeWizard;
var
  Valor: String;
begin
  PaginaPessoa := CreateInputQueryPage(wpLicense, 'Quem vai usar a Central?',
    'Seu nome aparece nas análises como especialista.',
    'Informe seu nome completo e seu e-mail. A Vórtex usa esses dados só para identificar quem da equipe usa a Central e em qual versão.');
  PaginaPessoa.Add('Nome completo:', False);
  PaginaPessoa.Add('E-mail:', False);
  if RegQueryStringValue(HKEY_CURRENT_USER, ChavePessoa, 'Nome', Valor) then
    PaginaPessoa.Values[0] := Valor;
  if RegQueryStringValue(HKEY_CURRENT_USER, ChavePessoa, 'Email', Valor) then
    PaginaPessoa.Values[1] := Valor;
end;

function NextButtonClick(CurPageID: Integer): Boolean;
var
  Nome, Email: String;
begin
  Result := True;
  { Instalação silenciosa: não há quem preencha; mantém o que já estiver salvo. }
  if (CurPageID = PaginaPessoa.ID) and not WizardSilent then
  begin
    Nome := Trim(PaginaPessoa.Values[0]);
    Email := Trim(PaginaPessoa.Values[1]);
    if (Length(Nome) < 3) or (Pos(' ', Nome) = 0) then
    begin
      MsgBox('Informe seu nome completo (nome e sobrenome).', mbError, MB_OK);
      Result := False;
    end
    else if (Email = '') or (Pos('@', Email) < 2) or (Pos('.', Email) = 0) then
    begin
      MsgBox('Informe um e-mail válido.', mbError, MB_OK);
      Result := False;
    end
    else
    begin
      RegWriteStringValue(HKEY_CURRENT_USER, ChavePessoa, 'Nome', Nome);
      RegWriteStringValue(HKEY_CURRENT_USER, ChavePessoa, 'Email', Email);
    end;
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  ResultCode: Integer;
  Log, Params, Text: String;
  Lines: TArrayOfString;
  I: Integer;
begin
  if CurStep = ssPostInstall then
  begin
    WizardForm.StatusLabel.Caption := 'Copiando o programa e preparando os atalhos…';
    Log := ExpandConstant('{tmp}\instalacao.log');
    Params := '-NoProfile -ExecutionPolicy Bypass -Command "try { & ''' + ExpandConstant('{tmp}\pacote\instalar.ps1') +
      ''' -Silencioso -NaoIniciar -Destino ''' + ExpandConstant('{app}') + ''' *> ''' + Log + ''' ; exit 0 } catch { $_ | Out-File -Append -Encoding utf8 ''' + Log + ''' ; exit 1 }"';
    if not Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'), Params, '', SW_HIDE, ewWaitUntilTerminated, ResultCode) or (ResultCode <> 0) then
    begin
      Text := '';
      if LoadStringsFromFile(Log, Lines) then
        for I := 0 to GetArrayLength(Lines) - 1 do
          Text := Text + Lines[I] + #13#10;
      MsgBox('A instalação não terminou.' + #13#10#13#10 + Text + #13#10 + 'Tire um print desta mensagem e mande para o suporte.', mbError, MB_OK);

    end;
  end;
end;
