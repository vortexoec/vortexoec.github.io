# Melhorias futuras — Pronix

## Carteira de clientes e coleta automática pelo Mercado Livre

**Status:** proposta para uma próxima versão, depois da validação do beta. Registrada em 30/10/2026. Nenhuma aplicação externa, integração OAuth ou coleta automática foi criada nesta etapa.

**Objetivo:** cadastrar clientes, conectar cada conta autorizada, coletar dados de conta e Product Ads, manter histórico por período e preparar a análise no editor existente. A importação de planilhas continuará disponível como alternativa.

### Condição para quem trabalha como colaborador

A documentação oficial informa que operador/colaborador não pode conceder a autorização OAuth: o Mercado Livre retorna `invalid_operator_user_id`. A conexão deverá ser autorizada pela conta principal/administradora de cada cliente, na própria tela do Mercado Livre. Ter acesso ao painel como colaborador não substitui essa autorização. [Autenticação e autorização](https://developers.mercadolivre.com.br/autenticacao-e-autorizacao).

Fluxo proposto: cadastrar o cliente → enviar/abrir a conexão da aplicação → titular autoriza → vincular o vendedor confirmado à ficha → sincronizar somente os recursos concedidos. O cliente não precisa fornecer sua senha à Pronix. O colaborador poderá trabalhar no programa com as contas que lhe forem atribuídas. Cada vínculo deve ter estado da conexão, última atualização e opção de desconectar. Cookies, senhas e sessões de navegador do colaborador não serão reutilizados para autenticar a API.

### Aplicação e permissões

A aplicação deve pertencer ao proprietário da solução, com autorização separada para cada vendedor. Configurar apenas leitura e as permissões funcionais necessárias: **Publicidade** para Advertising; **Métricas do negócio** e, quando os recursos exigirem, **Vendas e envios** para dados da conta. Essas permissões da API precisam ser conferidas no DevCenter e são distintas do convite de colaborador no painel. [Permissões funcionais](https://developers.mercadolivre.com.br/pt_br/produto-consulta-de-usuarios/permissoes-funcionais).

Para acesso recorrente, prever `offline_access`, renovação e substituição do refresh token e reconexão quando a autorização for invalidada. O fluxo oficial exige callback HTTPS cadastrado, validação de `state` e troca do código no backend, protegendo Client Secret e tokens. [Guia oficial de integração](https://developers.mercadolivre.com.br/pt_br/tendencias/desenvolvimento-in-house).

**Decisão de arquitetura pendente:** preservar a análise e os arquivos locais e definir uma forma segura de completar OAuth. Avaliar um pequeno serviço de autorização ou credenciais de aplicação próprias por instalação. Não distribuir um Client Secret compartilhado dentro do instalador. Isso é uma decisão técnica proposta; não significa que toda a plataforma precise migrar para a nuvem.

### Coleta de Ads e da conta

Para Product Ads, consultar os anunciantes acessíveis ao token em `GET /advertising/advertisers?product_id=PADS` e registrar o `advertiser_id` e o `site_id` retornados. Usar os recursos atuais de campanhas e Ad Groups; a documentação marca APIs antigas de anúncios como descontinuadas. O produto Publicidade precisa estar habilitado para o usuário; a documentação associa sua ausência ao erro `404: No permissions found for user_id`. Há métricas diárias, receita direta/indireta, custo, cliques e impressões, com janela retrospectiva de 90 dias e atualização informada às 10h GMT−3. [Product Ads — leitura](https://developers.mercadolivre.com.br/pt_br/product-ads-para-catalogo-e-user-products-leitura).

Na implementação, mapear cada indicador de negócio ao recurso oficial correspondente. Não pressupor que uma única API reproduza integralmente a planilha “Resumo de desempenho do negócio”. Validar valores contra exportações do mesmo vendedor, canal, moeda e intervalo. Manter receita de Ads separada do faturamento da conta e calcular TACOS apenas com períodos compatíveis. Implementar paginação, tratamento de limites/falhas, atualização incremental e histórico local sem duplicar registros.

### Validação antes de prometer disponibilidade

Fazer uma prova de conceito somente após autorização de uma conta principal: confirmar o vendedor, listar anunciantes, consultar um período conhecido e comparar o resultado com as planilhas já usadas no beta. Testar reconexão, revogação, isolamento entre clientes e seleção da conta correta. A documentação oficial exige controle de acesso por vendedor também dentro do sistema integrador. [Controle de acesso e autorização](https://developers.mercadolivre.com.br/controle-de-acesso-e-autorizacao).

A documentação consultada não comprova que toda aplicação de leitura Product Ads precise de uma aprovação manual prévia. Também não garante acesso irrestrito a qualquer conta: verificar permissões, habilitação de Publicidade, situação cadastral, limites e eventuais exigências do DevCenter antes do lançamento. Os termos reservam ao Mercado Livre a possibilidade de exigir certificação para acesso a recursos. [Termos — certificações](https://developers.mercadolivre.com.br/pt_br/termos-e-condicoes).

**Limite desta pesquisa:** consulta à documentação oficial indexada em 30/10/2026; não foi realizado teste OAuth nem teste autenticado das APIs. A abertura direta de algumas páginas retornou HTTP 403 ao leitor automático, mas os trechos acima estavam disponíveis nos resultados oficiais indexados. Revalidar os requisitos durante a implementação.
