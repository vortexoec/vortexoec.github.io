"""Official JoomPulse MCP client, OAuth PKCE and per-Windows-user secrets.

The provider endpoints are discovered from its public OAuth metadata. Tool names
are learned from tools/list, never guessed. Only explicitly read-only tools run.
"""
from __future__ import annotations

import base64
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import secrets
import threading
import time
from typing import Any
from urllib import error, parse, request

MCP_URL = "https://joompulse.com/mcp"
METADATA_URL = "https://joompulse.com/.well-known/oauth-authorization-server"
SETUP_URL = "https://joompulse.com/dashboard/settings/mcp"
PROTOCOL_VERSION = "2025-03-26"
DEFAULT_REDIRECT_URI = "http://localhost:8765/api/joompulse/callback"
MAX_RESPONSE_BYTES = 12 * 1024 * 1024
# The public skills describe capabilities, but do not publish stable tool names.
# Empty by design: do not infer read-only permissions from a tool's name.
OFFICIAL_READ_ONLY_ALLOWLIST: frozenset[str] = frozenset()
RENEWAL_LEAD_SECONDS = 60
OAUTH_ERROR_CODES = frozenset({"invalid_request", "invalid_client", "invalid_grant",
                             "unauthorized_client", "unsupported_grant_type", "invalid_scope",
                             "access_denied", "temporarily_unavailable", "server_error"})
RECONNECT_CODES = frozenset({"invalid_grant", "invalid_client", "unauthorized_client", "access_denied"})
AUTH_MESSAGES = {
    "invalid_grant": "A JoomPulse recusou a renovação desta autorização. Conecte novamente sua conta.",
    "invalid_client": "A JoomPulse recusou as credenciais da aplicação. Confira a configuração e conecte novamente.",
    "unauthorized_client": "Esta aplicação não está autorizada a renovar o acesso JoomPulse. Confira a configuração e conecte novamente.",
    "access_denied": "A JoomPulse recusou a autorização. Conecte novamente sua conta.",
    "rate_limited": "A JoomPulse limitou temporariamente a renovação. Uma nova tentativa ficará disponível em instantes; sua autorização foi preservada.",
    "network_error": "Não foi possível alcançar a JoomPulse para renovar o acesso. Sua autorização foi preservada para uma nova tentativa.",
    "temporarily_unavailable": "A renovação JoomPulse está temporariamente indisponível. Sua autorização foi preservada para uma nova tentativa.",
    "server_error": "A JoomPulse não conseguiu renovar o acesso agora. Sua autorização foi preservada para uma nova tentativa.",
    "token_response_invalid": "A JoomPulse retornou uma renovação incompleta. Sua autorização foi preservada para uma nova tentativa.",
    "token_endpoint_error": "A renovação JoomPulse não foi concluída. Sua autorização foi preservada para uma nova tentativa.",
    "invalid_request": "A JoomPulse não aceitou a solicitação de autorização. Confira a configuração da conexão.",
    "invalid_scope": "A JoomPulse não aceitou as permissões solicitadas. Confira a configuração da conexão.",
    "unsupported_grant_type": "A JoomPulse não aceitou este modo de autorização. Confira a configuração da conexão.",
    "token_expired": "O acesso JoomPulse expirou e não há renovação disponível. Conecte novamente sua conta.",
    "credentials_unreadable": "A conexão salva não pôde ser aberta neste usuário do Windows. Desconecte e configure novamente.",
}


def _iso_timestamp(value: float | None) -> str | None:
    if value is None:
        return None
    try:
        return datetime.fromtimestamp(value, timezone.utc).isoformat().replace("+00:00", "Z")
    except (OverflowError, OSError, ValueError):
        return None


class JoomPulseError(RuntimeError):
    """Safe user-facing error; never contains credentials or remote response text."""

    def __init__(self, message: str, code: str | None = None):
        super().__init__(message)
        self.code = code


class _NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # In particular, never forward OAuth codes or bearer tokens on redirects.
        return None


def _default_storage() -> Path:
    from .secure_dir import secure_dir
    return secure_dir()


def _crypt_blob(data: bytes, decrypt: bool = False) -> bytes:
    if os.name != "nt":
        raise JoomPulseError("A proteção de credenciais deste beta requer Windows (DPAPI).")

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

    buf = ctypes.create_string_buffer(data)
    incoming = DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
    outgoing = DATA_BLOB()
    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    # CRYPTPROTECT_UI_FORBIDDEN; no machine-wide flag, so bound to this OS user.
    if decrypt:
        fn = crypt32.CryptUnprotectData
        fn.argtypes = [ctypes.POINTER(DATA_BLOB), ctypes.c_void_p,
                       ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                       wintypes.DWORD, ctypes.POINTER(DATA_BLOB)]
        ok = fn(ctypes.byref(incoming), None, None, None, None, 1, ctypes.byref(outgoing))
    else:
        fn = crypt32.CryptProtectData
        fn.argtypes = [ctypes.POINTER(DATA_BLOB), wintypes.LPCWSTR,
                       ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                       wintypes.DWORD, ctypes.POINTER(DATA_BLOB)]
        ok = fn(ctypes.byref(incoming), "Pronix Beta - JoomPulse", None, None,
                None, 1, ctypes.byref(outgoing))
    if not ok:
        raise JoomPulseError("Não foi possível proteger ou abrir a conexão neste usuário do Windows.")
    try:
        return ctypes.string_at(outgoing.pbData, outgoing.cbData)
    finally:
        kernel32.LocalFree(outgoing.pbData)


def _official_https(url: str) -> str:
    parsed = parse.urlsplit(url)
    if (parsed.scheme != "https" or parsed.hostname != "joompulse.com"
            or parsed.port not in (None, 443) or parsed.username or parsed.password
            or parsed.fragment):
        raise JoomPulseError("A JoomPulse retornou um endereço de autenticação não reconhecido.")
    return url


def _validate_redirect(uri: str) -> str:
    parsed = parse.urlsplit(uri)
    if (parsed.scheme != "http" or parsed.hostname not in ("localhost", "127.0.0.1")
            or parsed.path != "/api/joompulse/callback" or parsed.query or parsed.fragment
            or parsed.username or parsed.password or parsed.port is None):
        raise JoomPulseError("Use o retorno local http://localhost:8765/api/joompulse/callback.")
    return uri


def _decode_rpc(raw: bytes, content_type: str, expected_id: int | None) -> dict:
    """Decode either JSON or SSE, skipping notifications and keepalive events."""
    decoded = raw.decode("utf-8-sig")
    if not decoded.strip():
        return {}
    if "text/event-stream" not in content_type:
        result = json.loads(decoded)
        if not isinstance(result, dict):
            raise JoomPulseError("Resposta inesperada do conector JoomPulse.")
        return result
    candidates = []
    data_lines: list[str] = []
    for line in decoded.replace("\r\n", "\n").split("\n") + [""]:
        if line.startswith("data:"):
            data_lines.append(line[5:].lstrip(" "))
        elif not line and data_lines:
            payload = "\n".join(data_lines)
            data_lines = []
            if payload == "[DONE]":
                continue
            try:
                item = json.loads(payload)
            except json.JSONDecodeError:
                continue
            if isinstance(item, dict):
                candidates.append(item)
    for item in candidates:
        if item.get("id") == expected_id and ("result" in item or "error" in item):
            return item
    raise JoomPulseError("O conector não retornou uma resposta completa. Tente novamente.")


class JoomPulseClient:
    def __init__(self, storage_dir: Path | str | None = None):
        self.storage_dir = Path(storage_dir) if storage_dir else _default_storage()
        self.secrets_path = self.storage_dir / "joompulse.dpapi"
        self._lock = threading.RLock()
        self._config: dict[str, Any] = {}
        self._tokens: dict[str, Any] = {}
        self._pending: dict[str, Any] = {}
        self._metadata: dict[str, Any] | None = None
        self._session_id: str | None = None
        self._protocol = PROTOCOL_VERSION
        self._initialized = False
        self._tools: dict[str, dict] = {}
        self._id = 0
        self._load_error = None
        self._auth_error_code: str | None = None
        self._refreshing = False
        self._automatic_renewal = False
        self._retry_at = 0.0
        self._refresh_failures = 0
        self._load()

    def _load(self):
        if self.secrets_path.exists():
            try:
                payload = json.loads(_crypt_blob(self.secrets_path.read_bytes(), decrypt=True))
                self._config = payload.get("config", {})
                self._tokens = payload.get("tokens", {})
            except Exception:
                # Do not silently overwrite a store that belongs to another OS user.
                self._load_error = "Conexão salva não pôde ser aberta. Desconecte e configure novamente."

    def _save(self):
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        blob = _crypt_blob(json.dumps({"config": self._config, "tokens": self._tokens}).encode())
        temporary = self.secrets_path.with_suffix(".tmp")
        temporary.write_bytes(blob)
        os.replace(temporary, self.secrets_path)
        self._load_error = None

    def status(self) -> dict:
        # Snapshot only: never perform network/disk access or wait behind a 60s
        # token request. Mutations and token replacement are serialized by _lock.
        tokens, config, tools = dict(self._tokens), dict(self._config), list(self._tools.values())
        now = time.time()
        has_token = bool(tokens.get("access_token"))
        try:
            expiry = float(tokens.get("expires_at", 0)) if has_token else None
            if expiry is not None and (not math.isfinite(expiry) or _iso_timestamp(expiry) is None):
                expiry = 0.0
        except (ValueError, TypeError):
            expiry = 0.0
        expired = has_token and expiry <= now
        code = self._auth_error_code or tokens.get("auth_error_code")
        if code not in AUTH_MESSAGES:
            code = None
        reconnect = bool(tokens.get("requires_reconnect") or self._load_error
                         or (expired and not tokens.get("refresh_token")))
        if self._load_error:
            code = "credentials_unreadable"
        elif expired and not tokens.get("refresh_token"):
            code = code or "token_expired"
        refresh_available = bool(has_token and tokens.get("refresh_token") and not reconnect)
        renewal_at = expiry - RENEWAL_LEAD_SECONDS if refresh_available else None
        connected = bool(has_token and not reconnect and (not expired or refresh_available))
        mode = "automatic" if self._automatic_renewal else "on_use"
        if code:
            message = AUTH_MESSAGES[code]
        elif self._refreshing:
            message = "Renovando o acesso JoomPulse."
        elif connected and refresh_available:
            message = ("Acesso JoomPulse com renovação automática enquanto o programa estiver aberto."
                       if mode == "automatic" else "O acesso JoomPulse será renovado ao fazer a próxima consulta, quando necessário.")
        elif connected:
            message = "Acesso JoomPulse válido. Será necessário conectar novamente após o vencimento."
        else:
            message = "Conecte sua conta JoomPulse para consultar o mercado."
        return {
            "configured": bool(config.get("client_id")), "connected": connected,
            "client_id": config.get("client_id", ""),
            "has_client_secret": bool(config.get("client_secret")),
            "needs_login": reconnect, "requiresReconnect": reconnect,
            "verified": bool(self._initialized and connected), "tool_count": len(tools),
            "read_only_tool_count": sum(self._is_read_only(t) for t in tools),
            "setup_url": SETUP_URL, "redirect_uri": DEFAULT_REDIRECT_URI,
            "storage": "Credenciais protegidas neste usuário do Windows, fora da pasta do projeto.",
            "error": self._load_error,
            "expiresAt": _iso_timestamp(expiry),
            "remainingSeconds": max(0, math.ceil(expiry - now)) if expiry is not None else None,
            "renewalAt": _iso_timestamp(renewal_at),
            "secondsUntilRenewal": max(0, math.ceil(renewal_at - now)) if renewal_at is not None else None,
            "refreshAvailable": refresh_available, "renewalAvailable": refresh_available,
            "refreshDue": bool(renewal_at is not None and renewal_at <= now),
            "refreshing": self._refreshing, "renewalMode": mode,
            "nextRetryAt": _iso_timestamp(self._retry_at) if self._retry_at > now else None,
            "authErrorCode": code, "connectionMessage": message,
        }

    def set_automatic_renewal(self, enabled: bool) -> None:
        """Declare whether the application is running its maintenance loop."""
        self._automatic_renewal = bool(enabled)

    def maintain_connection(self) -> dict:
        """Renew only when due; no MCP/AI calls. Safe for a 30-second app loop."""
        with self._lock:
            state = self.status()
            if state["refreshDue"] and time.time() >= self._retry_at:
                try:
                    self._refresh_tokens()
                except JoomPulseError:
                    # Curated state is observable in status. Do not log bodies.
                    pass
            return self.status()

    def _clear_auth_error(self):
        self._auth_error_code = None
        self._retry_at = 0.0
        self._refresh_failures = 0

    def configure(self, config: dict) -> dict:
        if not isinstance(config, dict):
            raise JoomPulseError("Informe as configurações da aplicação JoomPulse.")
        client_id = str(config.get("client_id", "")).strip()
        if not client_id or len(client_id) > 4096 or any(c in client_id for c in "\r\n"):
            raise JoomPulseError("Informe o ID do cliente criado na JoomPulse.")
        with self._lock:
            same_client = client_id == self._config.get("client_id")
            previous_secret = self._config.get("client_secret", "") if same_client else ""
            client_secret = str(config.get("client_secret", previous_secret) or "").strip()
            if len(client_secret) > 8192:
                raise JoomPulseError("Segredo do cliente inválido.")
            self._config = {"client_id": client_id, "client_secret": client_secret}
            if not same_client:
                self._tokens = {}
                self._clear_auth_error()
            self._pending = {}
            self._reset_session()
            self._save()
            return self.status()

    def _http(self, url: str, body: bytes | None = None, headers: dict | None = None,
              method: str | None = None) -> tuple[bytes, dict]:
        _official_https(url)
        req = request.Request(url, data=body, headers=headers or {}, method=method)
        try:
            with request.build_opener(_NoRedirect()).open(req, timeout=60) as response:
                content_type = response.headers.get("Content-Type", "")
                if "text/event-stream" in content_type and body:
                    expected_id = json.loads(body).get("id")
                    # A server may keep its SSE connection open after the response.
                    # Stop at our event instead of waiting for EOF/timeout.
                    chunks = []
                    current_event = []
                    size = 0
                    deadline = time.monotonic() + 60
                    while size <= MAX_RESPONSE_BYTES:
                        if time.monotonic() > deadline:
                            raise JoomPulseError("A consulta JoomPulse demorou demais. Tente novamente.")
                        line = response.readline(MAX_RESPONSE_BYTES + 1 - size)
                        if not line:
                            break
                        chunks.append(line)
                        current_event.append(line)
                        size += len(line)
                        if not line.strip():
                            try:
                                event_result = _decode_rpc(b"".join(current_event), content_type, expected_id)
                                if "result" in event_result or "error" in event_result:
                                    break
                                current_event = []
                            except (ValueError, UnicodeError, JoomPulseError):
                                current_event = []
                    raw = b"".join(chunks)
                else:
                    raw = response.read(MAX_RESPONSE_BYTES + 1)
                if len(raw) > MAX_RESPONSE_BYTES:
                    raise JoomPulseError("Resposta muito grande. Reduza a consulta de mercado.")
                return raw, {k.lower(): v for k, v in response.headers.items()}
        except error.HTTPError as exc:
            # OAuth errors have meaning only at the discovered token endpoint.
            # Read a small body, allowlist just the error enum, discard all text.
            if self._metadata and url == self._metadata.get("token_endpoint"):
                code = None
                if exc.code not in (429,) and exc.code < 500:
                    try:
                        raw_error = exc.read(16385)
                        data = json.loads(raw_error) if len(raw_error) <= 16384 else None
                        candidate = data.get("error") if isinstance(data, dict) else None
                        if isinstance(candidate, str) and candidate in OAUTH_ERROR_CODES:
                            code = candidate
                    except (ValueError, UnicodeError, OSError):
                        pass
                code = code or ("rate_limited" if exc.code == 429 else
                                "server_error" if exc.code >= 500 else "token_endpoint_error")
                raise JoomPulseError(AUTH_MESSAGES[code], code=code) from None
            if exc.code == 401:
                raise JoomPulseError("A conexão JoomPulse expirou ou não foi autorizada. Conecte novamente.") from None
            if exc.code == 403:
                raise JoomPulseError("Sua conta JoomPulse não autorizou esta consulta. Verifique o acesso MCP do seu plano.") from None
            if exc.code == 429:
                raise JoomPulseError("Limite de consultas JoomPulse atingido. Aguarde ou confira seu plano.") from None
            raise JoomPulseError(f"JoomPulse não concluiu a solicitação (HTTP {exc.code}). Tente novamente.") from None
        except (error.URLError, TimeoutError, OSError):
            raise JoomPulseError("Não foi possível alcançar a JoomPulse. Confira a internet e tente novamente.",
                                 code="network_error") from None

    def _discover(self) -> dict:
        if self._metadata is None:
            raw, _ = self._http(METADATA_URL)
            try:
                meta = json.loads(raw)
                if meta.get("issuer") != "https://joompulse.com":
                    raise ValueError("issuer")
                _official_https(meta["authorization_endpoint"])
                _official_https(meta["token_endpoint"])
                if "S256" not in meta.get("code_challenge_methods_supported", []):
                    raise ValueError("pkce")
                self._metadata = meta
            except (ValueError, TypeError, KeyError):
                raise JoomPulseError("Metadados OAuth da JoomPulse incompletos. Tente novamente mais tarde.") from None
        return self._metadata

    def authorization_url(self, redirect_uri: str = DEFAULT_REDIRECT_URI) -> str:
        with self._lock:
            if not self._config.get("client_id"):
                raise JoomPulseError("Primeiro salve o ID do cliente criado na JoomPulse.")
            redirect_uri = _validate_redirect(redirect_uri)
            meta = self._discover()
            verifier = secrets.token_urlsafe(64)
            challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
            state = secrets.token_urlsafe(32)
            self._pending = {"state": state, "verifier": verifier,
                             "redirect_uri": redirect_uri, "created_at": time.time()}
            params = {"response_type": "code", "client_id": self._config["client_id"],
                      "redirect_uri": redirect_uri, "scope": "mcp", "state": state,
                      "code_challenge": challenge, "code_challenge_method": "S256",
                      "resource": MCP_URL}
            return meta["authorization_endpoint"] + "?" + parse.urlencode(params)

    def _token_request(self, fields: dict) -> dict:
        meta = self._discover()
        fields = dict(fields, client_id=self._config["client_id"])
        if self._config.get("client_secret"):
            fields["client_secret"] = self._config["client_secret"]
        raw, _ = self._http(meta["token_endpoint"], parse.urlencode(fields).encode(),
                            {"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"})
        try:
            token = json.loads(raw)
            if isinstance(token, dict) and isinstance(token.get("error"), str) and token["error"] in OAUTH_ERROR_CODES:
                code = token["error"]
                raise JoomPulseError(AUTH_MESSAGES[code], code=code)
            if not isinstance(token.get("access_token"), str) or not token["access_token"]:
                raise ValueError("access_token")
            if str(token.get("token_type", "Bearer")).lower() != "bearer":
                raise ValueError("token_type")
            expires_in = float(token.get("expires_in", 3600))
            if not 0 < expires_in < 10 * 365 * 86400:
                raise ValueError("expires_in")
            token["expires_at"] = time.time() + expires_in
            return token
        except (ValueError, TypeError, AttributeError):
            raise JoomPulseError("A JoomPulse retornou uma autorização incompleta. Tente novamente.",
                                 code="token_response_invalid") from None

    def complete_oauth(self, code: str, state: str, redirect_uri: str = DEFAULT_REDIRECT_URI) -> dict:
        with self._lock:
            pending = self._pending
            if (not pending or not isinstance(state, str)
                    or not secrets.compare_digest(state, pending.get("state", ""))
                    or time.time() - pending.get("created_at", 0) > 600
                    or redirect_uri != pending.get("redirect_uri")):
                raise JoomPulseError("Esta autorização expirou ou não corresponde à conexão iniciada. Conecte novamente.")
            if not isinstance(code, str) or not code or len(code) > 16384:
                raise JoomPulseError("A JoomPulse não enviou um código de autorização válido.")
            # Single-use state, including on failed code exchange.
            self._pending = {}
            tokens = self._token_request({"grant_type": "authorization_code", "code": code,
                                          "redirect_uri": redirect_uri,
                                          "code_verifier": pending["verifier"], "resource": MCP_URL})
            self._tokens = tokens
            self._clear_auth_error()
            self._reset_session()
            self._save()
            return self.status()

    def _refresh_tokens(self) -> None:
        """Caller holds _lock: serialize rotation, persistence and retry state."""
        refresh = self._tokens.get("refresh_token")
        if not refresh or self._tokens.get("requires_reconnect"):
            raise JoomPulseError(AUTH_MESSAGES.get(self._tokens.get("auth_error_code"),
                                                  AUTH_MESSAGES["token_expired"]))
        self._refreshing = True
        try:
            new_tokens = self._token_request({"grant_type": "refresh_token", "refresh_token": refresh,
                                              "resource": MCP_URL})
            if not new_tokens.get("refresh_token"):
                new_tokens["refresh_token"] = refresh
            self._tokens = new_tokens
            self._save()
            self._clear_auth_error()
        except JoomPulseError as exc:
            code = exc.code if exc.code in AUTH_MESSAGES else "token_endpoint_error"
            self._auth_error_code = code
            if code in RECONNECT_CODES:
                # Preserve the protected credential for diagnosis/reconfiguration,
                # but do not repeatedly send a known-rejected refresh token.
                self._tokens = dict(self._tokens, requires_reconnect=True, auth_error_code=code)
                self._retry_at = 0.0
                self._reset_session()
                self._save()
            else:
                self._refresh_failures += 1
                self._retry_at = time.time() + min(300, 30 * 2 ** min(self._refresh_failures - 1, 4))
            raise JoomPulseError(AUTH_MESSAGES[code], code=code) from None
        finally:
            self._refreshing = False

    def _access_token(self) -> str:
        with self._lock:
            state = self.status()
            if not self._tokens.get("access_token"):
                raise JoomPulseError("Conecte sua conta JoomPulse antes de pesquisar o mercado.")
            if state["requiresReconnect"]:
                raise JoomPulseError(state["connectionMessage"], code=state["authErrorCode"])
            if state["refreshDue"]:
                if time.time() >= self._retry_at:
                    try:
                        self._refresh_tokens()
                    except JoomPulseError:
                        # A temporary early-renewal failure does not invalidate
                        # an access token that has not expired yet.
                        if self.status()["requiresReconnect"] or self.status()["remainingSeconds"] == 0:
                            raise
                elif state["remainingSeconds"] == 0:
                    raise JoomPulseError(state["connectionMessage"], code=state["authErrorCode"])
            return self._tokens["access_token"]

    def _reset_session(self):
        self._initialized = False
        self._session_id = None
        self._tools = {}
        self._protocol = PROTOCOL_VERSION

    def disconnect(self) -> dict:
        with self._lock:
            self._tokens = {}
            self._pending = {}
            self._config = {}
            self._clear_auth_error()
            self._reset_session()
            if self.secrets_path.exists():
                self.secrets_path.unlink()
            self._load_error = None
            return self.status()

    def _rpc(self, method: str, params: dict | None = None, notification: bool = False) -> dict:
        self._id += 1
        rpc_id = self._id
        payload: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if not notification:
            payload["id"] = rpc_id
        if params is not None:
            payload["params"] = params
        headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream",
                   "Authorization": "Bearer " + self._access_token(),
                   "MCP-Protocol-Version": self._protocol}
        if self._session_id:
            headers["Mcp-Session-Id"] = self._session_id
        raw, response_headers = self._http(MCP_URL, json.dumps(payload).encode(), headers)
        if method == "initialize" and response_headers.get("mcp-session-id"):
            self._session_id = response_headers["mcp-session-id"]
        if notification:
            return {}
        try:
            response = _decode_rpc(raw, response_headers.get("content-type", "application/json"), rpc_id)
        except (ValueError, UnicodeError):
            raise JoomPulseError("Resposta inválida do conector JoomPulse. Tente novamente.") from None
        if response.get("id") != rpc_id:
            raise JoomPulseError("O conector retornou uma resposta fora da sequência esperada.")
        if "error" in response:
            raise JoomPulseError("O conector JoomPulse recusou esta consulta. Confira os parâmetros e sua conexão.")
        if "result" not in response or not isinstance(response["result"], dict):
            raise JoomPulseError("O conector JoomPulse retornou um resultado incompleto.")
        return response["result"]

    def _initialize(self):
        if not self._initialized:
            result = self._rpc("initialize", {"protocolVersion": PROTOCOL_VERSION, "capabilities": {},
                                             "clientInfo": {"name": "PronixBeta", "version": "0.1.0"}})
            version = result.get("protocolVersion", PROTOCOL_VERSION)
            if version not in ("2024-11-05", "2025-03-26", "2025-06-18", "2025-11-25"):
                raise JoomPulseError("A versão do conector JoomPulse requer uma atualização do beta.")
            self._protocol = version
            self._rpc("notifications/initialized", notification=True)
            self._initialized = True

    @staticmethod
    def _is_read_only(tool: dict) -> bool:
        annotations = tool.get("annotations")
        return ((isinstance(annotations, dict) and annotations.get("readOnlyHint") is True)
                or tool.get("name") in OFFICIAL_READ_ONLY_ALLOWLIST)

    def list_tools(self) -> list[dict]:
        with self._lock:
            self._initialize()
            cursor = None
            seen = set()
            collected = {}
            for _ in range(20):
                result = self._rpc("tools/list", {"cursor": cursor} if cursor else {})
                for tool in result.get("tools", []):
                    if isinstance(tool, dict) and isinstance(tool.get("name"), str):
                        collected[tool["name"]] = tool
                cursor = result.get("nextCursor")
                if not cursor:
                    self._tools = collected
                    # The caller may display blocked tools but must not run them.
                    return [dict(tool, pronix_read_only=self._is_read_only(tool)) for tool in collected.values()]
                if not isinstance(cursor, str) or cursor in seen:
                    break
                seen.add(cursor)
            raise JoomPulseError("Não foi possível concluir o catálogo de ferramentas JoomPulse.")

    def call_tool(self, name: str, args: dict) -> dict:
        if not isinstance(name, str) or not isinstance(args, dict):
            raise JoomPulseError("Ferramenta ou parâmetros inválidos.")
        with self._lock:
            if not self._tools:
                self.list_tools()
            tool = self._tools.get(name)
            if not tool:
                raise JoomPulseError("Esta ferramenta não consta no conector JoomPulse conectado.")
            if not self._is_read_only(tool):
                raise JoomPulseError("Esta ferramenta não declara consulta somente de leitura e foi bloqueada no beta.")
            result = self._rpc("tools/call", {"name": name, "arguments": args})
            if result.get("isError"):
                raise JoomPulseError("A consulta JoomPulse não foi concluída. Verifique os dados do produto e tente novamente.")
            return result


_client: JoomPulseClient | None = None
_client_lock = threading.Lock()


def _get_client() -> JoomPulseClient:
    global _client
    with _client_lock:
        if _client is None:
            _client = JoomPulseClient()
    return _client


def status() -> dict:
    return _get_client().status()


def set_automatic_renewal(enabled: bool) -> None:
    _get_client().set_automatic_renewal(enabled)


def maintain_connection() -> dict:
    return _get_client().maintain_connection()


def configure(config: dict) -> dict:
    return _get_client().configure(config)


def authorization_url(redirect_uri: str = DEFAULT_REDIRECT_URI) -> str:
    return _get_client().authorization_url(redirect_uri)


def complete_oauth(code: str, state: str, redirect_uri: str = DEFAULT_REDIRECT_URI) -> dict:
    return _get_client().complete_oauth(code, state, redirect_uri)


def disconnect() -> dict:
    return _get_client().disconnect()


def list_tools() -> list[dict]:
    return _get_client().list_tools()


def call_tool(name: str, args: dict) -> dict:
    return _get_client().call_tool(name, args)
