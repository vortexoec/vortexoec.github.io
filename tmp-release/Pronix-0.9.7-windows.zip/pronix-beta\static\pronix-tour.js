// Central de Análises · instruções guiadas dentro do programa.
// Escurece a tela, destaca um elemento por vez e explica o que ele faz.
// Aparece sozinho só no primeiro acesso (e na primeira análise aberta);
// "Rever instruções", em Preferências, começa tudo de novo.
(() => {
  const PAD = 8, STORE = 'pronix-tour';
  const boot = () => (typeof S !== 'undefined' && S.boot) || null;
  const settings = () => (boot() && boot().settings) || {};
  const view = () => (typeof S !== 'undefined' ? S.view : '');
  const go = name => { if (view() !== name) nav(name); };
  const joomOn = () => !!boot()?.joompulse?.connected;
  const meliOn = () => !!boot()?.mercadolivre?.connected;
  const extOn = () => !!((typeof ExtUI !== 'undefined' && ExtUI.status) || boot()?.hub)?.connected;
  const extSeen = () => typeof ExtUI !== 'undefined' && !!ExtUI.present;
  const hubRows = () => document.querySelector('.hub-sheet-row [data-open-report]');
  const marketOpen = () => view() === 'editor' && typeof S !== 'undefined' && S.report && typeof isMarketReport === 'function' && isMarketReport(S.report);

  const MENU = [['Visão geral', 'as planilhas que você importou do Hub.'], ['Análise de mercado', 'todas as análises de produtos.'],
    ['Nova análise', 'começar uma análise sem passar pelo Hub.'], ['Relatórios', 'relatórios salvos, por cliente e data.'],
    ['Reuniões', 'reuniões do cliente pelo Google Agenda (opcional).'], ['Modelos', 'modelos de relatório.']];

  const TOURS = {
    setup: {flag: 'tourSetupDone', steps: [
      {title: 'Bem-vindo à Central de Análises', next: 'Começar',
        text: 'Em uns dois minutos eu te mostro o caminho até a primeira análise: conectar as contas, importar uma planilha do Hub e conferir o parecer. Se pular sem querer, dá para rever em Preferências.'},
      {target: '.sidebar .nav', before: () => go('dashboard'), title: 'O menu',
        html: () => '<ul class="tour-list">' + MENU.map(([name, what]) => `<li><strong>${name}</strong>: ${what}</li>`).join('') + '</ul>'},
      {target: '[data-nav="joompulse"]', click: true, doneWhen: () => view() === 'joompulse', title: 'Comece por Integrações',
        text: 'É aqui que você conecta as suas contas, uma vez só. Clique em Integrações.'},
      {target: '[data-int-card="ext"]', before: () => go('joompulse'), interactive: true, title: 'Extensão do Chrome',
        text: () => extOn() ? 'Conectada. É ela que coloca os botões roxos da Central no Hub e faz os logins sem copiar e colar.'
          : extSeen() ? 'A extensão foi encontrada e está se conectando sozinha. Aguarde alguns segundos.'
          : 'Instale a extensão “Central de Análises - Vórtex” no Chrome. Assim que ela estiver instalada, a conexão acontece sozinha, sem código.',
        next: () => extOn() ? 'Próximo' : 'Fazer depois'},
      {target: '[data-int-card="joompulse"]', before: () => go('joompulse'), interactive: true, title: 'JoomPulse',
        text: () => joomOn() ? 'Conectada. É dela que vêm os anúncios parecidos, os preços e as vendas.'
          : 'Traz os anúncios parecidos, os preços e as vendas. Clique em Conectar e entre com a sua conta da JoomPulse.',
        next: () => joomOn() ? 'Próximo' : 'Fazer depois'},
      {target: '[data-int-card="meli"]', before: () => go('joompulse'), interactive: true, title: 'Mercado Livre',
        text: () => meliOn() ? 'Conectado. É daqui que vêm a comissão e o frete de cada produto.'
          : 'Traz a comissão e o frete de cada produto. Clique em Conectar: a extensão abre o login do Mercado Livre e fecha a aba sozinha.',
        next: () => meliOn() ? 'Próximo' : 'Fazer depois'},
      {target: '.topbar-right', title: 'Está tudo conectado?',
        text: 'Estes avisos ficam sempre no alto da tela. Verde quer dizer conectado. Se algum ficar amarelo, clique nele para voltar a Integrações.'},
      {target: '[data-nav="dashboard"]', click: true, doneWhen: () => view() === 'dashboard', title: 'Voltar ao início',
        text: 'Agora clique em Visão geral.'},
      {target: '.hub-sheets', before: () => go('dashboard'), title: 'Planilhas do Hub',
        text: 'As planilhas que você importar aparecem aqui, com a contagem de produtos em verde, amarelo e vermelho. “Revisar” abre a análise.'},
      {title: 'Agora é no Hub', next: 'Concluir', link: ['Abrir o Hub', 'https://pronixhub.com.br/validacao-planilhas'],
        text: 'Na lista de planilhas do Hub, clique no botão roxo Importar na Central, ao lado do prazo. Um painel no canto da tela mostra o andamento. Quando a planilha chegar aqui, eu te mostro a tela de análise.'},
    ]},
    firstSheet: {flag: 'tourAnalysisDone', keepFlag: true, steps: [
      {target: () => hubRows(), click: true, doneWhen: () => view() === 'editor', title: 'Sua planilha chegou',
        text: 'Clique em Revisar para abrir a análise dos produtos.'},
    ]},
    analysis: {flag: 'tourAnalysisDone', steps: [
      {target: '.page-heading', title: 'A análise da planilha',
        text: 'Cada produto da planilha recebeu um parecer automático: Validado, Atenção ou Invalidado. Vou te mostrar os botões desta tela.'},
      {target: '[data-action="market-collect"]', optional: true, title: 'Consultar mercado',
        text: 'Busca de novo os dados na JoomPulse e refaz os cálculos. Use se a análise ficou incompleta.'},
      {target: '[data-action="market-fees"]', optional: true, title: 'Atualizar comissão e frete',
        text: 'Consulta de novo só a comissão do Mercado Livre e o frete. O peso e o tamanho são estimados pelo anúncio quando a planilha não informa a embalagem.'},
      {target: '[data-action="save-report"]', optional: true, title: 'Salvar análise',
        text: 'Grava as suas alterações neste computador.'},
      {target: () => document.querySelector('.market-filter')?.parentElement, optional: true, title: 'Contadores e filtros',
        text: 'Mostram quantos produtos ficaram em cada parecer. Clique em um deles para ver só aqueles produtos.'},
      {target: ['.market-tile-decision', '.market-decision-badge'], optional: true, title: 'O parecer do produto',
        text: 'Este selo é a sugestão automática. Mais abaixo, em “Parecer do especialista”, você pode trocar o resultado.'},
      {target: '.market-primary-message', optional: true, title: 'Devolutiva para o cliente',
        text: 'É o texto que vai para o Hub. Você pode editar aqui; o que mudar passa a valer no balão da planilha.'},
      {title: 'Para terminar', next: 'Concluir',
        text: 'Abra a planilha no Hub: em cada produto aparece um balão roxo, “Sugestão da Central”, com o botão Inserir. Confira, ajuste se quiser e envie a validação você mesmo. Para rever estas instruções, vá em Preferências.'},
    ]},
  };

  const tour = {name: '', index: 0, ui: null, timer: null, misses: 0, html: '', started: false, coached: false};

  function build() {
    const root = document.createElement('div');
    root.className = 'tour-root';
    root.innerHTML = '<div class="tour-shade"></div><div class="tour-shade"></div><div class="tour-shade"></div><div class="tour-shade"></div>'
      + '<div class="tour-block"></div><div class="tour-ring"></div>'
      + '<div class="tour-balloon" role="dialog" aria-live="polite" aria-label="Instruções"><div class="tour-count"></div><h3></h3><div class="tour-text"></div>'
      + '<div class="tour-actions"><button type="button" class="tour-skip">Pular instruções</button><span></span>'
      + '<a class="btn small ghost tour-link" target="_blank" rel="noopener noreferrer" hidden></a>'
      + '<button type="button" class="btn small ghost tour-back">Voltar</button><button type="button" class="btn small primary tour-next">Próximo</button></div></div>';
    document.body.appendChild(root);
    const ui = {root, shades: [...root.querySelectorAll('.tour-shade')], block: root.querySelector('.tour-block'), ring: root.querySelector('.tour-ring'),
      balloon: root.querySelector('.tour-balloon'), count: root.querySelector('.tour-count'), title: root.querySelector('h3'), text: root.querySelector('.tour-text'),
      skip: root.querySelector('.tour-skip'), back: root.querySelector('.tour-back'), next: root.querySelector('.tour-next'), link: root.querySelector('.tour-link')};
    ui.next.addEventListener('click', () => move(1));
    ui.back.addEventListener('click', () => move(-1));
    ui.skip.addEventListener('click', () => finish(true));
    return ui;
  }

  const steps = () => TOURS[tour.name]?.steps || [];
  const step = () => steps()[tour.index];
  const value = item => (typeof item === 'function' ? item() : item);
  function target(current) {
    for (const selector of [].concat(current.target || [])) {
      const el = typeof selector === 'function' ? selector() : document.querySelector(selector);
      if (el && el.getClientRects().length) return el;
    }
    return null;
  }
  const remember = () => { try { tour.name ? sessionStorage.setItem(STORE, JSON.stringify({name: tour.name, index: tour.index})) : sessionStorage.removeItem(STORE); } catch { /* sem armazenamento */ } };

  function start(name, index = 0) {
    if (!TOURS[name]) return;
    tour.name = name; tour.index = Math.max(0, Math.min(index, TOURS[name].steps.length - 1));
    tour.ui ||= build();
    tour.ui.root.hidden = false;
    enter();
    clearInterval(tour.timer);
    tour.timer = setInterval(update, 200);
  }

  function enter() {
    const current = step();
    tour.misses = 0; tour.html = ''; tour.scrolled = false;
    remember();
    try { current.before?.(); } catch { /* a tela pode não estar pronta */ }
    update();
    if (!current.click) setTimeout(() => tour.ui?.next.focus({preventScroll: true}), 60);
  }

  function move(delta) {
    const next = tour.index + delta;
    if (next < 0) return;
    if (next >= steps().length) return finish(false);
    tour.index = next;
    enter();
  }

  async function mark(flag, done) {
    try { localStorage.setItem('pronix-' + flag, done ? '1' : ''); } catch { /* opcional */ }
    try { const saved = await api('/api/settings', {[flag]: done}); if (boot() && saved && typeof saved === 'object') S.boot.settings = saved; }
    catch { if (boot()) S.boot.settings = {...settings(), [flag]: done}; }
  }
  const isDone = flag => { if (settings()[flag]) return true; try { return localStorage.getItem('pronix-' + flag) === '1' && settings()[flag] !== false; } catch { return false; } };

  function finish(skipped) {
    const definition = TOURS[tour.name];
    clearInterval(tour.timer);
    if (tour.ui) tour.ui.root.hidden = true;
    const name = tour.name;
    tour.name = ''; remember();
    if (definition && (!definition.keepFlag || skipped)) void mark(definition.flag, true);
    if (skipped && typeof notify === 'function') notify('Instruções fechadas. Para rever, abra Preferências e clique em Rever instruções.');
    if (!skipped && name === 'setup' && typeof notify === 'function') notify('Pronto. Quando a primeira planilha chegar, eu mostro a tela de análise.');
  }

  function place(rect) {
    const {balloon} = tour.ui, bw = balloon.offsetWidth, bh = balloon.offsetHeight, vw = window.innerWidth, vh = window.innerHeight, gap = 16;
    const clamp = (number, low, high) => Math.max(low, Math.min(number, Math.max(low, high)));
    let x, y;
    if (!rect) { x = (vw - bw) / 2; y = Math.max(24, (vh - bh) / 2 - 20); }
    else if (rect.left < vw * 0.3 && rect.width < vw * 0.45 && rect.right + gap + bw <= vw) { x = rect.right + gap; y = clamp(rect.top, 12, vh - bh - 12); }
    else if (rect.bottom + gap + bh <= vh) { y = rect.bottom + gap; x = clamp(rect.left, 12, vw - bw - 12); }
    else if (rect.top - gap - bh >= 0) { y = rect.top - gap - bh; x = clamp(rect.left, 12, vw - bw - 12); }
    else if (rect.left - gap - bw >= 0) { x = rect.left - gap - bw; y = clamp(rect.top, 12, vh - bh - 12); }
    else { x = vw - bw - 16; y = vh - bh - 16; }
    balloon.style.left = Math.round(x) + 'px'; balloon.style.top = Math.round(y) + 'px';
  }

  function update() {
    const current = step(), ui = tour.ui;
    if (!current || !ui) return;
    if (current.doneWhen && current.doneWhen()) return move(1);
    const el = current.target ? target(current) : null;
    if (current.target && !el) {
      tour.misses += 1;
      if (current.optional && tour.misses > 8) return move(1);
    } else tour.misses = 0;
    if (el && !tour.scrolled) {
      tour.scrolled = true;
      const r = el.getBoundingClientRect();
      if (r.top < 90 || r.bottom > window.innerHeight - 40) el.scrollIntoView({block: r.height > window.innerHeight * 0.7 ? 'start' : 'center', behavior: 'instant'});
    }
    // Texto e botões (podem mudar enquanto a pessoa conecta uma conta).
    const body = current.html ? value(current.html) : `<p>${String(value(current.text) || '').replace(/[&<>]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;'}[c]))}</p>`;
    const label = current.click ? '' : (value(current.next) || (tour.index === steps().length - 1 ? 'Concluir' : 'Próximo'));
    const signature = [tour.name, tour.index, body, label].join('|');
    if (signature !== tour.html) {
      tour.html = signature;
      ui.count.textContent = steps().length > 1 ? `${tour.index + 1} de ${steps().length}` : 'Novidade';
      ui.title.textContent = current.title || '';
      ui.text.innerHTML = body + (current.click ? '<p class="tour-hint">Clique no item destacado para continuar.</p>' : '');
      ui.next.hidden = !!current.click; ui.next.textContent = label;
      ui.back.hidden = tour.index === 0 || !!steps()[tour.index - 1]?.click;
      ui.link.hidden = !current.link;
      if (current.link) { ui.link.textContent = current.link[0]; ui.link.href = current.link[1]; }
    }
    const vw = window.innerWidth, vh = window.innerHeight;
    let rect = null;
    if (el) {
      const r = el.getBoundingClientRect();
      // Valores inteiros: evita frestas claras entre as quatro faixas escuras.
      rect = {left: Math.max(0, Math.floor(r.left - PAD)), top: Math.max(0, Math.floor(r.top - PAD)), right: Math.min(vw, Math.ceil(r.right + PAD)), bottom: Math.min(vh, Math.ceil(r.bottom + PAD))};
      rect.width = rect.right - rect.left; rect.height = rect.bottom - rect.top;
    }
    const box = (node, left, top, width, height) => { node.style.cssText = `left:${left}px;top:${top}px;width:${Math.max(0, width)}px;height:${Math.max(0, height)}px`; };
    if (rect && rect.height > 0) {
      box(ui.shades[0], 0, 0, vw, rect.top);
      box(ui.shades[1], 0, rect.bottom, vw, vh - rect.bottom);
      box(ui.shades[2], 0, rect.top, rect.left, rect.height);
      box(ui.shades[3], rect.right, rect.top, vw - rect.right, rect.height);
      box(ui.ring, rect.left, rect.top, rect.width, rect.height);
      box(ui.block, rect.left, rect.top, rect.width, rect.height);
      ui.ring.hidden = false;
      ui.block.hidden = !!(current.click || current.interactive);
      ui.ring.classList.toggle('pulse', !!current.click);
    } else {
      box(ui.shades[0], 0, 0, vw, vh);
      for (const shade of ui.shades.slice(1)) box(shade, 0, 0, 0, 0);
      ui.ring.hidden = true; ui.block.hidden = true;
    }
    place(rect && rect.height > 0 ? rect : null);
  }

  // Quando começar sozinho: primeiro acesso, primeira planilha na Visão geral e primeira análise aberta.
  function watch() {
    if (!boot() || tour.name) return;
    if (document.querySelector('dialog[open]')) return;
    if (!tour.started) {
      tour.started = true;
      let saved = null;
      try { saved = JSON.parse(sessionStorage.getItem(STORE) || 'null'); } catch { /* ignora */ }
      if (saved && TOURS[saved.name] && !isDone(TOURS[saved.name].flag)) return start(saved.name, saved.index);
      if (!isDone('tourSetupDone')) return start('setup');
    }
    if (isDone('tourAnalysisDone')) return;
    if (marketOpen() && document.querySelector('.market-product-tile')) return start('analysis');
    if (isDone('tourSetupDone') && !tour.coached && view() === 'dashboard' && hubRows()) { tour.coached = true; return start('firstSheet'); }
  }

  async function restart() {
    await mark('tourSetupDone', false);
    await mark('tourAnalysisDone', false);
    tour.coached = false;
    start('setup');
  }

  window.tourCard = () => `<section class="card form-card"><h2>Instruções guiadas</h2><p class="integration-message">O passo a passo do primeiro acesso: o menu, as integrações, a importação pelo Hub e a tela de análise. Aparece sozinho só na primeira vez.</p><div class="buttons space-top"><button type="button" class="btn" data-action="tour-restart">${typeof icon === 'function' ? icon('info') : ''}Rever instruções</button></div></section>`;
  window.PronixTour = {start, restart, finish, active: () => tour.name};
  document.addEventListener('click', event => { if (event.target.closest?.('[data-action="tour-restart"]')) void restart(); });
  window.addEventListener('resize', () => { if (tour.name) update(); });
  window.addEventListener('scroll', () => { if (tour.name) update(); }, {passive: true});
  setInterval(watch, 700);
})();
