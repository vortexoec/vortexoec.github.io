﻿# Publica uma versão nova no GitHub Releases (usa o GitHub CLI "gh", já autenticado).
# Uso: powershell -ExecutionPolicy Bypass -File instalador\publicar-release.ps1 -Repo dono/nome [-Notas "texto"]
# Antes: atualize o arquivo VERSION, faça commit e rode instalador\montar-pacote.ps1.
param([Parameter(Mandatory=$true)][string]$Repo, [string]$Notas = '')
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$version = (Get-Content -LiteralPath (Join-Path $root 'VERSION') -Raw).Trim()
$zip = Join-Path $root "dist\Pronix-$version-windows.zip"
if (-not (Test-Path $zip) -or -not (Test-Path "$zip.sha256")) { throw "Monte o pacote antes: instalador\montar-pacote.ps1" }
if (-not $Notas) { $Notas = "Pronix $version" }
gh release create "v$version" $zip "$zip.sha256" --repo $Repo --title "Pronix $version" --notes $Notas
if ($LASTEXITCODE -ne 0) { throw 'Falha ao publicar no GitHub.' }
Write-Host "Versão $version publicada. Os Pronix com o repositório $Repo vão oferecer a atualização."
