"""Seed editable DVP evidence from cached facts, without network or estimates.

The caller owns persistence and invalidation after a source/date change. Existing
review values, including explicit null/false values, always take precedence.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date
from decimal import Decimal, InvalidOperation
import re


VERSION = 1
_ID = re.compile(r"MLB\d{5,16}\Z")


def _number(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        number = Decimal(str(value))
        return float(number) if number.is_finite() and 0 <= number <= Decimal("1e15") else None
    except (InvalidOperation, ValueError, TypeError):
        return None


def _identity(value):
    result = re.sub(r"[-\s]", "", str(value or "")).upper()
    return result if _ID.fullmatch(result) else None


def _catalog_identity(value):
    # MLB-<item> is the MCP placeholder outside a catalog, never a catalog ID.
    result = str(value or "").strip().upper()
    return result if _ID.fullmatch(result) else None


def _date(value):
    try:
        return date.fromisoformat(str(value)[:10]).isoformat()
    except (ValueError, TypeError):
        return None


def _lifetime(row, identity, kind):
    value = row.get("lifetimeRevenue")
    if not isinstance(value, dict) or value.get("basis") != "lifetime":
        return None
    scope = value.get("scope")
    expected = identity if scope == kind else (_catalog_identity(row.get("catalogId"))
        if scope == "catalog" and row.get("isCatalogProduct") is True else None)
    amount = _number(value.get("value"))
    if (scope not in {"item", "catalog"} or not expected or
            _identity(value.get("entityId")) != expected or amount is None or
            not str(value.get("source") or "").strip() or not _date(value.get("observedAt"))):
        return None
    return {**deepcopy(value), "value": amount, "scope": scope, "entityId": expected, "basis": "lifetime"}


def _seed_listing(row):
    kind = row.get("kind", "item")
    if kind not in {"item", "catalog"}:
        return None
    identity = _identity(row.get("itemId") if kind == "item" else row.get("catalogId")) or _identity(row.get("id"))
    if not identity:
        return None
    catalog = _catalog_identity(row.get("catalogId")) if row.get("isCatalogProduct") is True or kind == "catalog" else None
    if kind == "catalog":
        catalog = _catalog_identity(row.get("catalogId") or row.get("id"))
        if catalog is None:
            return None
        identity = catalog
    source = str(row.get("source") or "Evidência de mercado em cache")
    observed = row.get("observedAt")
    created = []
    if _date(row.get("createdAt")):
        precision = row.get("createdAtPrecision")
        # A first-of-month source date can be an approximation. Do not upgrade
        # an unknown precision, or derive a precise age from this date.
        precision = precision if precision in {"day", "month"} else "unknown"
        created.append({"date": row["createdAt"], "precision": precision,
                        "scope": kind, "entityId": identity, "source": source})
    own_age = _number(row.get("exposureDays")) if row.get("exposureBasis") == "item_age" and kind == "item" else None
    lifetime = _lifetime(row, identity, kind)
    result = {
        "id": identity, "kind": kind, "itemId": identity if kind == "item" else None,
        "catalogId": catalog, "title": str(row.get("title") or ""),
        "url": str(row.get("url") or ""), "firstPageConfirmed": False,
        "comparison": "unconfirmed", "comparisonConfirmed": False,
        "price": _number(row.get("price")), "observedAt": observed,
        "source": source, "active": row.get("active"), "current": row.get("current"),
        "createdDates": created, "ageDays": own_age, "ageConfirmed": False,
        "ageScope": "item" if kind == "item" else "catalog",
        "ageSource": source if own_age is not None else "", "ageObservedAt": observed if own_age is not None else None,
        "lifetimeRevenue": lifetime, "recentReviews": None,
        "logistics": "Full" if row.get("isFull") is True else "",
        "historicalAverages": deepcopy(row.get("historicalAverages")) if isinstance(row.get("historicalAverages"), dict) else None,
    }
    warnings = []
    if lifetime is None:
        warnings.append("Faturamento acumulado não disponível: médias históricas, indicador de vendidos e séries de 120 dias não foram convertidos em receita vitalícia.")
    if row.get("exposureBasis") == "catalog_first_item_age":
        warnings.append("A idade fornecida é da primeira oferta do catálogo; não foi usada como idade deste anúncio.")
    if created and created[0]["precision"] != "day":
        warnings.append("A precisão da data de criação precisa ser conferida antes de calcular a idade do anúncio.")
    result["sourceMetadata"] = {
        "adapterVersion": VERSION, "source": source, "observedAt": observed,
        "sourceRefreshedAt": row.get("sourceRefreshedAt"), "sourceAvailable": True,
        "priceBasis": "current_listing_price" if kind == "item" else "catalog_price",
        "exposureContext": {"days": _number(row.get("exposureDays")), "basis": row.get("exposureBasis")},
        "provenance": deepcopy(row.get("provenance") or []), "warnings": warnings,
    }
    return result


def _merge_seed(seed, existing):
    """Record preserved edits while leaving every existing control untouched."""
    existing = existing if isinstance(existing, dict) else {}
    original_values = {key: deepcopy(value) for key, value in seed.items() if key != "sourceMetadata"}
    old_meta = existing.get("sourceMetadata") if isinstance(existing.get("sourceMetadata"), dict) else {}
    had_seed = isinstance(old_meta.get("seededValues"), dict)
    old_values = old_meta.get("seededValues") if had_seed else original_values
    preserved = [key for key in original_values if key in existing and existing[key] != old_values.get(key)]
    result = {**deepcopy(seed), **deepcopy(existing)}
    # A later cache snapshot may refresh fields that are provably unchanged
    # since this adapter seeded them. A manual null, zero, name or confirmation
    # differing from that snapshot remains an explicit review value.
    if had_seed:
        for key in original_values:
            if key in existing and key in old_values and existing[key] == old_values[key]:
                result[key] = deepcopy(original_values[key])
    origins = {key: "preserved_review" if key in preserved else "cached_source" for key in original_values}
    result["sourceMetadata"] = {**deepcopy(old_meta), **deepcopy(seed.get("sourceMetadata") or {}),
                                "seededValues": original_values, "fieldOrigins": origins,
                                "preservedFields": preserved}
    return result


def build_dvp_evidence(entry, context):
    """Return a full editable DVP input; never mutate entry or confirm evidence.

    Unknown/explicitly cleared review fields stay unknown. Search ranking is a
    suggestion, not proof of the Mercado Livre first page or of DVP's top five.
    """
    if not isinstance(entry, dict) or not isinstance(context, dict):
        raise ValueError("Produto e contexto DVP precisam ser registros separados.")
    evidence = entry.get("evidence") if isinstance(entry.get("evidence"), dict) else {}
    existing = entry.get("dvpReview") if isinstance(entry.get("dvpReview"), dict) else {}
    search_data = evidence.get("search") if isinstance(evidence.get("search"), dict) else {}
    arguments = search_data.get("arguments") if isinstance(search_data.get("arguments"), dict) else {}
    queries = arguments.get("queries")
    query = arguments.get("query") or (queries[0] if isinstance(queries, list) and queries else "")
    reference = evidence.get("reference") if isinstance(evidence.get("reference"), dict) else {}
    search = {
        "query": str(query or ""), "url": "", "page": 1, "firstPageConfirmed": False,
        "observedAt": reference.get("observedAt") or context.get("analysisDate"),
        "source": "Busca MCP em cache; primeira página do Mercado Livre não confirmada",
        "fullCount": None, "totalListings": None, "countsComplete": False, "recentReviews": None,
    }
    old_search = existing.get("search") if isinstance(existing.get("search"), dict) else {}
    old_selection = existing.get("selection") if isinstance(existing.get("selection"), dict) else {}
    selection = {"demandIds": [], "priceIds": [], "confirmed": False, "reason": ""}
    seeds = {}
    rows = [reference] + list(evidence.get("candidates") or []) + list(evidence.get("competitors") or [])
    for row in rows:
        if not isinstance(row, dict):
            continue
        seed = _seed_listing(row)
        if seed is not None:
            key = (seed["kind"], seed["id"])
            if key not in seeds:
                seeds[key] = seed
            elif not seeds[key]["sourceMetadata"]["provenance"] and seed["sourceMetadata"]["provenance"]:
                seeds[key]["sourceMetadata"]["provenance"] = seed["sourceMetadata"]["provenance"]
    listings, used = [], set()
    for row in existing.get("listings") if isinstance(existing.get("listings"), list) else []:
        if not isinstance(row, dict):
            continue
        key = (row.get("kind", "item"), _identity(row.get("id") or row.get("itemId")))
        # Never discard manually entered rows/duplicates: the DVP engine reports
        # invalid selection and deduplicates financial identities independently.
        listings.append(_merge_seed(seeds[key], row) if key in seeds else deepcopy(row))
        used.add(key)
    for key, seed in seeds.items():
        if key not in used:
            listings.append(_merge_seed(seed, {}))
    old_meta = existing.get("sourceMetadata") if isinstance(existing.get("sourceMetadata"), dict) else {}
    return {**deepcopy(existing), "search": {**search, **deepcopy(old_search)},
            "selection": {**selection, **deepcopy(old_selection)}, "listings": listings,
            "sourceMetadata": {**deepcopy(old_meta), "adapterVersion": VERSION,
                "sourceReference": evidence.get("sourceReference") or (entry.get("source") or {}).get("reference"),
                "analysisDate": context.get("analysisDate"), "suggestedIds": [seed["id"] for seed in seeds.values()],
                "selectionAutomaticallyConfirmed": False, "newCandidatesAutomaticallySelected": False,
                "warnings": ["A busca MCP não comprova primeira página, ranking DVP ou similaridade direta.",
                             "Confirmações DVP permanecem separadas da análise Gabriel."]}}
