"""Pronix Beta: loopback-only local application, no framework or cloud backend."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import mimetypes
import os
import secrets
import socket
import sys
import threading
import traceback
import uuid
import webbrowser
from datetime import datetime,timedelta
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from services import storage
from services.documents import extract_pdf, make_pdf, LABELS
from services.ads import inspect_spreadsheet, analyze_spreadsheet
from services.account import inspect_account, analyze_account
from services.joompulse import JoomPulseClient, JoomPulseError
from services import market
from services import market_workflow
from services import assets,templates
from services.direction import enrich_report,extract_meeting_actions
from services.google_meet import GoogleMeetClient,GoogleMeetError
from services.hub_bridge import HubBridge
from services.mercadolivre import MercadoLivreClient, MercadoLivreError
from services import hub_import, market_fees
from services.report_schema import is_market_report

storage.init()
from services.secure_dir import migrate_legacy
from services.version import VERSION as APP_VERSION
from services import updater
if __name__=='__main__':
    _migrated=migrate_legacy()
    if _migrated: print('Conexões trazidas da versão anterior: '+', '.join(_migrated),flush=True)
TOKEN=secrets.token_urlsafe(32)
JOOM=JoomPulseClient()
GOOGLE=GoogleMeetClient()
HUB=HubBridge()
MELI=MercadoLivreClient()
MELI_AUTO={'error':None}
def _meli_oauth_return(url):
    try:
        MELI.complete(url); MELI_AUTO['error']=None
    except Exception as exc:
        MELI_AUTO['error']=str(exc) if isinstance(exc,(MercadoLivreError,ValueError)) else 'Não foi possível concluir a conexão. Tente novamente.'
HUB.oauth_handler=_meli_oauth_return
HUB.ext_handler=lambda action,payload: handle_extension_request(action,payload)
threading.Thread(target=__import__('services.mercadolivre',fromlist=['x']).find_vortex_vault,name='vortex-lookup',daemon=True).start()
JOBS={}
JOBS_LOCK=threading.RLock()
SETTINGS=storage.RUNTIME/'settings.json'
PORT=8765


class ReportChangedError(ValueError):
    def __init__(self):
        super().__init__('Este relatório foi alterado em outra aba ou etapa. Sua cópia não foi salva. Reabra a versão salva antes de analisar ou retomar; preserve seu rascunho para conferir as diferenças.')


def report_revision(report):
    """Saved-content identity, independent of timestamps changed by recalculation."""
    value={key:item for key,item in report.items() if key!='baseRevision'}
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode('utf-8')).hexdigest()


def save_report_with_revision(report):
    # This transport field describes the saved base, not a user-editable value.
    saved,paths=storage.save_report({key:value for key,value in report.items() if key!='baseRevision'})
    saved['baseRevision']=report_revision(saved)
    return saved,paths


def require_current_report_base(report):
    """Caller holds storage.LOCK through the subsequent write."""
    if not report.get('id'): return None
    try: latest=storage.get_report(report['id'])
    except FileNotFoundError:
        if report.get('baseRevision'): raise ReportChangedError() from None
        return None
    if report.get('baseRevision')!=report_revision(latest): raise ReportChangedError()
    return latest


def market_job_summary(report_id):
    """Cross-tab progress only; never returns a partial result or tool audit."""
    report_id=storage.identifier(report_id)
    with JOBS_LOCK:
        latest=next(((job_id,dict(job)) for job_id,job in reversed(list(JOBS.items()))
                     if job.get('reportId')==report_id),None)
    if latest:
        job_id,job=latest
        if job.get('status')=='complete': return None
        if job.get('status')!='running': return None
    else:
        return None
    return {'id':job_id,'reportId':report_id,'status':job['status'],'useAI':False,
            'message':str(job.get('message') or '')[:2000],
            'completedCount':job.get('completedCount',0),'totalCount':job.get('totalCount',0)}


def retain_collected_market(report):
    """Older open tabs must not discard a market result collected meanwhile."""
    if not isinstance(report,dict) or report.get('marketAnalysis') or not report.get('id'): return report
    try: latest=storage.get_report(report['id'])
    except FileNotFoundError: return report
    if latest.get('pdfId')==report.get('pdfId') and latest.get('marketAnalysis'):
        report={**report,'marketAnalysis':latest['marketAnalysis'],'marketAudit':latest.get('marketAudit',{})}
    return report


def analyze(data):
    report={key:data.get(key,'') for key in ('clientName','date','specialist','objective','pdfId','sheetId','accountId')}
    report['id']=uuid.uuid4().hex
    report['reportType']=data.get('reportType','performance')
    if report['reportType'] not in ('performance','reputation','market'): raise ValueError('Escolha o tipo de análise.')
    report['title']={'reputation':'Direcionamento de Reputação','market':'Análise de mercado','performance':'Performance e crescimento'}[report['reportType']]
    report['showDetails']=data.get('showDetails',False) is True
    if report['reportType']=='market' and (not report.get('pdfId') or report.get('sheetId') or report.get('accountId')):
        raise ValueError('Na análise de mercado, importe somente a planilha de produtos do Pronix Hub. Conta e campanhas ficam em Nova análise.')
    report['meeting']=data.get('meeting') or {}
    report['sections']=[]; report['warnings']=[]; report['sources']=[]; report['metrics']={}
    report['metricLabels']=dict(LABELS)
    report['context']=data.get('context') or {}
    if report.get('pdfId'):
        pdf=market.source_document(report['pdfId'],data.get('productReferences'))
        report['clientName']=report['clientName'] or pdf.get('clientName','')
        report['sources'].append({'name':pdf['name'],'id':pdf['id'],'sha256':pdf['sha256'],'kind':pdf['kind']})
        report['warnings']+=pdf.get('warnings',[])
        if pdf['kind']=='html':
            report['productSource']={'type':'html','name':pdf['name'],'id':pdf['id'],
                                     'products':pdf['products'],'metadata':pdf.get('metadata',{})}
            if pdf.get('hubSource'):
                report['productSource']['hubSource']=pdf['hubSource']
                report['sources'][-1]['url']=pdf['hubSource']['url']
    if report['reportType']=='market':
        report['marketAnalysis']={'sourceId':report['pdfId'],
            'methodology':market_workflow.normalize_methodology(data.get('methodology'),default='combined')}
        if data.get('automatic') is True: report['marketAnalysis']['policy']={'automatic':True}
        report=market_workflow.recalculate(report,pdf)
        return save_report_with_revision(report)[0]
    if report.get('accountId'):
        account=storage.get_upload(report['accountId'])
        result=analyze_account(account['path'],data.get('context'))
        for section in result['sections']:
            section['body']=section['body'].replace(Path(account['path']).name,account['name'])
        result['provenance']['filename']=account['name']
        report['account']=result
        report['metrics'].update(result['metrics'])
        report['metricLabels'].update(result['metricLabels'])
        report['sections']+=result['sections']
        report['warnings']+=result['warnings']
        report['sources'].append({'name':account['name'],'id':account['id'],'sha256':account['sha256'],'kind':'account'})
    if report.get('sheetId'):
        sheet=storage.get_upload(report['sheetId'])
        if sheet['kind']!='spreadsheet': raise ValueError('Selecione um relatório de Ads em XLSX ou CSV.')
        result=analyze_spreadsheet(sheet['path'],sheet=data.get('sheet'),header_row=data.get('headerRow'),mapping=data.get('mapping'),context=data.get('context'))
        if report.get('account') and report['context'].get('totalRevenue') in (None,''):
            ap=report['account']['provenance']; dp=result['provenance']
            same_period=(ap.get('completeCoverage') and dp.get('completeCoverage') and dp.get('periodIsDaily') and
                         (ap.get('periodStart'),ap.get('periodEnd'))==(dp.get('periodStart'),dp.get('periodEnd')))
            revenue=report['account']['metrics'].get('accountRevenue')
            if same_period and revenue is not None:
                context={**report['context'],'totalRevenue':revenue}
                result=analyze_spreadsheet(sheet['path'],sheet=data.get('sheet'),header_row=data.get('headerRow'),mapping=data.get('mapping'),context=context)
                report['context']=context
                result['sections'].append({'id':'tacos-provenance','title':'Cruzamento entre conta e publicidade','body':
                    'O TACOS utiliza as vendas brutas do relatório da conta e o investimento do relatório de Ads. '
                    'Os dois arquivos cobrem o mesmo intervalo completo: '+ap['periodStart']+' a '+ap['periodEnd']+'. '
                    'Na conta, o período é comprovado pelas datas ou pelo cabeçalho da exportação; em Ads, pelas linhas diárias. '
                    'Vendas brutas incluem o efeito das regras do relatório, antes de apurar lucro.'})
            else:
                report['warnings'].append('TACOS não cruzado automaticamente: conta e Ads precisam de períodos completos e coincidentes, com datas comprovadas na fonte. Confira os intervalos dos dois arquivos.')
        for section in result['sections']:
            section['body']=section['body'].replace(Path(sheet['path']).name,sheet['name']).replace('não disponível%','não disponível').replace('não disponívelx','não disponível')
        result['provenance']['filename']=sheet['name']
        report['metrics'].update(result['metrics'])
        report['sections']+=result['sections']
        report['warnings']+=result.get('warnings',[])
        report['ads']=result
        report['sources'].append({'name':sheet['name'],'id':sheet['id'],'sha256':sheet['sha256'],'kind':'spreadsheet'})
        report['importConfig']={k:data.get(k) for k in ('sheet','headerRow','mapping')}
    elif report['reportType']=='performance':
        report['warnings'].append('Relatório de Ads não importado. Não há métricas publicitárias calculadas.')
    if not any(report.get(k) for k in ('pdfId','sheetId','accountId')) and report['reportType']=='performance' and not (report['meeting'].get('transcriptText') or report['meeting'].get('notes')):
        raise ValueError('Importe uma fonte ou informe a transcrição/anotações da reunião para direcionar uma conta em operação.')
    if report.get('pdfId'):report['warnings'].append('Análise de mercado pendente: conecte a JoomPulse e inicie a pesquisa, ou importe um resultado já revisado.')
    if report['reportType']=='performance':report['sections'].append({'id':'action-plan','title':'Plano de acompanhamento','body':
        '7 dias: validar os dados de origem, resolver as lacunas indicadas e revisar as ações propostas.\n\n'
        '30 dias: comparar os indicadores do próximo período equivalente e verificar os efeitos das alterações registradas.\n\n'
        '90 dias: reavaliar mix, estoque, margem e estratégia com o histórico acumulado.\n\n'
        'Defina as metas e os prazos específicos após validar os dados. Não há projeção automática sem premissas fundamentadas.'})
    report['sources'].append({'name':'Metodologia Pronix fornecida - revisar as orientações conforme a conta e as condições vigentes; parâmetros internos não são regras oficiais do Mercado Livre','kind':'methodology'})
    report=enrich_report(report)
    if report.get('pdfId'):
        report=market_workflow.recalculate(report,pdf)
    if report['meeting'].get('transcriptText') or report['meeting'].get('notes'):
        report,_=attach_meeting_actions(report,report['meeting'])
    return save_report_with_revision(report)[0]


def attach_meeting_actions(report,meeting):
    report=enrich_report(report)
    report['meeting']=meeting
    text=str(meeting.get('transcriptText') or meeting.get('notes') or '')
    if len(text)>500000: raise ValueError('A transcrição ultrapassa 500 mil caracteres. Divida em trechos.')
    if not text.strip(): raise ValueError('Importe a transcrição ou escreva as anotações da reunião.')
    extracted=extract_meeting_actions(text)
    fingerprints={c.get('meetingQuoteHash') for c in report['actionCards']}
    for action in extracted['actions']:
        fingerprint=hashlib.sha256(action['quote'].encode()).hexdigest()
        if fingerprint in fingerprints:continue
        fingerprint_id='meeting-'+fingerprint[:14]
        report['actionCards'].append({'id':fingerprint_id,'title':action['text'][:160],
            'problem':'Encaminhamento encontrado na reunião. Confira o trecho e o contexto antes de aprovar.',
            'why':'Organizar a execução do que foi discutido com o cliente.',
            'steps':[{'id':fingerprint_id+'-1','text':action['text'],'done':False}],
            'owner':action.get('owner',''),'due':action.get('due',''),'priority':'media','status':'pending',
            'metric':'Definir com o especialista','target':'Conferir antes de executar','images':[],
            'sourceQuote':action['quote'],'meetingQuoteHash':fingerprint,'reviewRequired':True})
        fingerprints.add(fingerprint)
    report['meetingReview']={'mode':'rules','summary':extracted['summary'],'warnings':extracted['warnings']}
    report['warnings']=list(dict.fromkeys(report.get('warnings',[])+extracted['warnings']))
    if not any(isinstance(s,dict) and s.get('kind')=='meeting' for s in report['sources']):
        report['sources'].append({'kind':'meeting','name':'Reunião: '+str(meeting.get('title') or 'Transcrição/anotações fornecidas'),'url':meeting.get('transcriptUrl') or meeting.get('url','')})
    return report,extracted


class Handler(BaseHTTPRequestHandler):
    server_version='PronixBeta/'+APP_VERSION
    def log_message(self, fmt, *args):
        # OAuth codes, tokens, imported texts and names never enter console logs.
        if '/callback' not in self.path:
            print(f'{self.command} {self.path.split("?")[0]}', flush=True)

    def allowed(self):
        host=self.headers.get('Host','')
        if host not in (f'localhost:{PORT}',f'127.0.0.1:{PORT}'):
            return False
        origin=self.headers.get('Origin')
        return not origin or origin in (f'http://localhost:{PORT}',f'http://127.0.0.1:{PORT}')

    def send(self, status, body, content_type='application/json; charset=utf-8', headers=None):
        if isinstance(body,(dict,list)): body=json.dumps(body,ensure_ascii=False,allow_nan=False).encode('utf-8')
        elif isinstance(body,str): body=body.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(body)))
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Cache-Control','no-store')
        self.send_header('Referrer-Policy','no-referrer')
        for key,value in (headers or {}).items(): self.send_header(key,value)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        try:
            if not self.allowed(): return self.send(403,{'error':'Acesso permitido apenas neste computador.'})
            parsed=urlparse(self.path); path=parsed.path
            if path=='/api/bootstrap':
                return self.send(200,{'reports':storage.list_reports(),'settings':storage.read_json(SETTINGS,{'specialist':''}),'joompulse':JOOM.status(),'mercadolivre':MELI.status(),'hub':HUB.status(),'update':{**updater.status(),'repo':updater.repo_from_settings(storage.read_json(SETTINGS,{}))},'google':GOOGLE.status(),'outputDirectory':str(storage.OUTPUT),'date':storage.today(),'csrfToken':TOKEN,'version':APP_VERSION+'-beta'})
            if path=='/api/health': return self.send(200,{'ok':True,'app':'pronix-beta','version':APP_VERSION,'activeJobs':sum(j.get('status')=='running' for j in JOBS.values())})
            if path=='/api/market/methodology/source':
                return self.send(200,(storage.ROOT/'resources'/'methodologies'/'pronix-dvp.pdf').read_bytes(),'application/pdf',{'Content-Disposition':'inline; filename="Pronix-Metodo-DVP.pdf"'})
            if path=='/api/hub/status': return self.send(200,HUB.status())
            if path=='/api/market/jobs':
                query=parse_qs(parsed.query)
                if set(query)!={'reportId'} or len(query['reportId'])!=1: raise ValueError('Informe um único relatório para consultar o andamento.')
                return self.send(200,{'job':market_job_summary(query['reportId'][0])})
            if path=='/api/mercadolivre/status': return self.send(200,{**MELI.status(),'autoError':MELI_AUTO['error']})
            if path=='/api/hub/help':
                return self.send(200,(storage.ROOT/'docs'/'extensao-pronix.html').read_bytes(),'text/html; charset=utf-8')
            if path=='/api/hub/extension.zip':
                return self.send(200,hub_import.extension_zip(),'application/zip',{'Content-Disposition':'attachment; filename="pronix-hub-beta.zip"'})
            if path.startswith('/api/reports/'):
                saved=storage.get_report(path.rsplit('/',1)[-1])
                base_revision=report_revision(saved)
                report=enrich_report(saved)
                if is_market_report(report) and report.get('pdfId'):
                    report=market_workflow.recalculate(report)
                report['baseRevision']=base_revision
                return self.send(200,report)
            if path.startswith('/api/assets/'):
                file=assets.get_path(path.rsplit('/',1)[-1]);return self.send(200,file.read_bytes(),'image/png')
            if path=='/api/templates':return self.send(200,templates.list_templates())
            if path.startswith('/api/templates/'):return self.send(200,templates.get_template(path.rsplit('/',1)[-1]))
            if path=='/api/google/status':return self.send(200,GOOGLE.status())
            if path=='/api/google/calendars':return self.send(200,GOOGLE.list_calendars())
            if path=='/api/google/events':
                query=parse_qs(parsed.query)
                start=datetime.strptime(query.get('from',[storage.today()])[0],'%Y-%m-%d')
                end=datetime.strptime(query.get('to',[storage.today()])[0],'%Y-%m-%d')+timedelta(days=1)
                if end<=start or (end-start).days>93:raise ValueError('Selecione um intervalo de até 93 dias.')
                return self.send(200,GOOGLE.list_events(query.get('calendarId',['primary'])[0],start.isoformat()+'-03:00',end.isoformat()+'-03:00'))
            if path=='/api/google/callback':
                query=parse_qs(parsed.query)
                if query.get('error'):raise ValueError('A conexão Google foi cancelada ou recusada.')
                GOOGLE.complete_oauth(query.get('code',[''])[0],query.get('state',[''])[0],f'http://localhost:{PORT}/api/google/callback')
                return self.send(200,'<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Google conectado</title><body style="font:18px Segoe UI;padding:60px;background:#faf9f6"><h1>Conta Google conectada.</h1><p>Volte à Central e escolha a agenda do especialista.</p><a href="/">Voltar à Central</a></body></html>','text/html; charset=utf-8')
            if path=='/api/joompulse/status': return self.send(200,JOOM.status())
            if path=='/api/joompulse/tools': return self.send(200,{'tools':JOOM.list_tools()})
            if path=='/api/joompulse/callback':
                q=parse_qs(parsed.query)
                if q.get('error'): raise ValueError('A autorização JoomPulse foi cancelada ou recusada.')
                JOOM.complete_oauth(q.get('code',[''])[0],q.get('state',[''])[0],f'http://localhost:{PORT}/api/joompulse/callback')
                JOOM.list_tools()
                return self.send(200,'<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>JoomPulse conectada</title><body style="font:18px Segoe UI;padding:60px;background:#faf9f6"><h1>JoomPulse conectada.</h1><p>As ferramentas de consulta foram verificadas. Você pode voltar à Central.</p><a href="/">Voltar à Central</a></body></html>','text/html; charset=utf-8')
            if path.startswith('/api/jobs/'):
                job_id=path.rsplit('/',1)[-1]
                job=JOBS.get(job_id)
                if not job: raise FileNotFoundError('Consulta não encontrada. Inicie novamente.')
                return self.send(200,job)
            if path.startswith('/api/files/'):
                parts=path.strip('/').split('/')
                if len(parts)!=4 or parts[-1] not in ('pdf','txt','html','json'): raise FileNotFoundError('Arquivo não encontrado.')
                report=storage.get_report(parts[-2]); file=storage.paths_for(report)[parts[-1]]
                if not file.exists(): raise FileNotFoundError('Exporte o relatório para gerar este arquivo.')
                return self.send(200,file.read_bytes(),mimetypes.guess_type(str(file))[0] or 'application/octet-stream',{'Content-Disposition':f'attachment; filename="Pronix_{report["date"]}.{parts[-1]}"'})
            if path=='/api/example':
                return self.send(200,(storage.ROOT/'examples'/'ads-demonstracao-FICTICIA.csv').read_bytes(),'text/csv; charset=utf-8',{'Content-Disposition':'attachment; filename="ads-demonstracao-FICTICIA.csv"'})
            name='index.html' if path=='/' else path.removeprefix('/static/').lstrip('/')
            if name=='app.js':name='pronix-ui-v02.js'
            if name in ('central-logo.png','favicon.png'):
                return self.send(200,(storage.ROOT/'static'/name).read_bytes(),'image/png',{'Cache-Control':'max-age=86400'})
            if name not in ('index.html','pronix-ui-v02.js','pronix-tour.js','styles.css'): raise FileNotFoundError('Página não encontrada.')
            file=storage.ROOT/'static'/name
            return self.send(200,file.read_bytes(),mimetypes.guess_type(name)[0]+'; charset=utf-8')
        except Exception as exc: self.handle_error(exc)

    def do_POST(self):
        try:
            if not self.allowed() or self.headers.get('X-Pronix-Token')!=TOKEN:
                return self.send(403,{'error':'Sessão local expirada. Recarregue a página.'})
            if not self.headers.get('Content-Type','').startswith('application/json'):
                return self.send(415,{'error':'Envie dados JSON.'})
            size=int(self.headers.get('Content-Length','0'))
            if size<=0 or size>42*1024*1024: return self.send(413,{'error':'Arquivo muito grande. Limite: 30 MB por arquivo.'})
            data=json.loads(self.rfile.read(size))
            if not isinstance(data,dict): raise ValueError('Solicitação inválida.')
            path=urlparse(self.path).path
            if path=='/api/hub/pairing': return self.send(200,HUB.begin_pairing())
            if path=='/api/hub/disconnect': return self.send(200,HUB.disconnect())
            if path=='/api/hub/tabs': return self.send(200,HUB.list_tabs())
            if path=='/api/mercadolivre/config':
                return self.send(200,MELI.configure(data.get('clientId'),data.get('clientSecret'),data.get('redirectUri')))
            if path=='/api/mercadolivre/import-vortex': return self.send(200,MELI.import_from_vortex())
            if path=='/api/mercadolivre/connect': return self.send(200,{'url':MELI.authorization_url()})
            if path=='/api/mercadolivre/connect-auto':
                url=MELI.authorization_url(); MELI_AUTO['error']=None
                state=parse_qs(urlparse(url).query).get('state',[''])[0]
                HUB.open_oauth(url,MELI.status()['redirectUri'],state)
                return self.send(200,{'opened':True})
            if path=='/api/mercadolivre/complete': return self.send(200,MELI.complete(data.get('returnUrl')))
            if path=='/api/mercadolivre/disconnect': return self.send(200,MELI.disconnect())
            if path=='/api/hub/import':
                captured=HUB.capture(data.get('tabId'),data.get('expectedUrl'))
                meta=hub_import.save_capture(captured,data.get('expectedUrl'),HUB.status().get('extensionVersion',''))
                return self.send(200,meta)
            if path=='/api/assets':return self.send(200,assets.save_image(data))
            if path=='/api/templates':return self.send(200,templates.save_template(data))
            if path=='/api/templates/use':
                report=templates.apply_template(data['report'],data['templateId']);return self.send(200,{'report':storage.validate_report(report)})
            if path=='/api/templates/archive':return self.send(200,templates.archive_template(data['id']))
            if path=='/api/reports/visualize':return self.send(200,enrich_report(data['report'],force=data.get('force') is True))
            if path=='/api/google/config':return self.send(200,GOOGLE.configure(data))
            if path=='/api/google/connect':return self.send(200,{'url':GOOGLE.authorization_url(f'http://localhost:{PORT}/api/google/callback')})
            if path=='/api/google/disconnect':return self.send(200,GOOGLE.disconnect())
            if path=='/api/meetings/resolve':return self.send(200,GOOGLE.resolve_link(data['url']))
            if path=='/api/meetings/transcript':return self.send(200,GOOGLE.fetch_transcript(data['candidate']))
            if path=='/api/meetings/actions':
                report,extracted=attach_meeting_actions(data['report'],data.get('meeting') or data['report'].get('meeting') or {})
                return self.send(200,{'report':storage.validate_report(report),'extracted':extracted})
            if path=='/api/upload':
                name=Path(str(data.get('name','')).replace('\\','/')).name
                extension=Path(name).suffix.lower()
                if extension not in ('.pdf','.html','.htm','.xlsx','.csv','.tsv'): raise ValueError('Use PDF, HTML do Pronix Hub, XLSX, CSV ou TSV. Salve arquivos XLS antigos como XLSX.')
                raw=base64.b64decode(str(data.get('data','')).split(',')[-1],validate=True)
                if not raw or len(raw)>30*1024*1024: raise ValueError('O arquivo deve ter até 30 MB.')
                upload_id=uuid.uuid4().hex; file=storage.UPLOADS/(upload_id+extension)
                file.write_bytes(raw)
                meta={'id':upload_id,'name':name,'extension':extension,'sha256':hashlib.sha256(raw).hexdigest(),'createdAt':storage.now()}
                try:
                    if extension=='.pdf': meta.update({'kind':'pdf',**extract_pdf(file)})
                    elif extension in ('.html','.htm'):
                        from services.product_source import extract_product_html
                        meta.update(extract_product_html(file))
                    else:
                        meta.update({'kind':'spreadsheet','inspection':inspect_spreadsheet(file)})
                        if data.get('kind')=='account': meta['accountInspection']=inspect_account(file)
                except Exception:
                    file.unlink(missing_ok=True); raise
                storage.write_json(storage.UPLOADS/(upload_id+'.json'),meta)
                return self.send(200,meta)
            if path=='/api/analyze': return self.send(200,analyze(data))
            if path=='/api/reports':
                report=retain_collected_market(data.get('report',data))
                if report.get('marketAnalysis'): report=market_workflow.recalculate(report)
                with storage.LOCK:
                    require_current_report_base(report)
                    report,paths=save_report_with_revision(report)
                return self.send(200,{'report':report,'paths':paths})
            if path=='/api/export':
                report=retain_collected_market(data['report'])
                if report.get('marketAnalysis'): report=market_workflow.recalculate(report)
                with storage.LOCK:
                    require_current_report_base(report)
                    report,paths=save_report_with_revision(report)
                temporary=Path(paths['pdf']).with_suffix('.pdf.tmp')
                try:
                    make_pdf(report,temporary)
                    os.replace(temporary,paths['pdf'])
                finally:
                    temporary.unlink(missing_ok=True)
                return self.send(200,{'report':report,'paths':paths,'download':'/api/files/'+report['id']+'/pdf'})
            if path=='/api/history/clear':
                if data.get('confirm')!='LIMPAR': raise ValueError('Digite LIMPAR para confirmar.')
                with JOBS_LOCK:
                    if any(job.get('status')=='running' for job in JOBS.values()): raise ValueError('Há uma análise em andamento. Espere terminar para limpar o histórico.')
                    removed=storage.clear_history(include_exports=data.get('exports') is True)
                    JOBS.clear()
                return self.send(200,{'ok':True,**removed})
            if path=='/api/settings':
                settings=storage.read_json(SETTINGS,{'specialist':''})
                if 'specialist' in data: settings['specialist']=str(data.get('specialist',''))[:150]
                if 'updateRepo' in data:
                    repo=str(data.get('updateRepo') or '').strip()
                    if repo and not updater.REPO.fullmatch(repo): raise ValueError('Informe o repositório no formato dono/nome.')
                    settings['updateRepo']=repo
                if 'updateToken' in data:
                    updater.save_access(data.get('updateToken'))   # vai para o cofre DPAPI, nunca para settings.json
                for key in ('autoMinMarginPercent','autoMaxPremiumPercent','autoMinMonthlyUnits','autoMinNicheRevenue'):
                    if key in data:
                        value=data.get(key)
                        if value in (None,''): settings.pop(key,None); continue
                        number=float(str(value).replace(',','.'))
                        if not 0<=number<=(10000000 if key=='autoMinNicheRevenue' else 100000): raise ValueError('Valor fora do limite.')
                        settings[key]=number
                for key in ('tourSetupDone','tourAnalysisDone'):
                    if key in data: settings[key]=data.get(key) is True
                storage.write_json(SETTINGS,settings); return self.send(200,settings)
            if path=='/api/update/check': return self.send(200,updater.check(updater.repo_from_settings(storage.read_json(SETTINGS,{}))))
            if path=='/api/update/apply': return self.send(200,updater.apply(updater.repo_from_settings(storage.read_json(SETTINGS,{}))))
            if path=='/api/joompulse/config':
                JOOM.configure({'client_id':data.get('clientId',data.get('client_id','')),'client_secret':data.get('clientSecret',data.get('client_secret',''))}); return self.send(200,JOOM.status())
            if path=='/api/joompulse/connect':
                return self.send(200,{'url':JOOM.authorization_url(f'http://localhost:{PORT}/api/joompulse/callback')})
            if path=='/api/joompulse/disconnect': JOOM.disconnect(); return self.send(200,JOOM.status())
            if path=='/api/joompulse/call': return self.send(200,{'result':JOOM.call_tool(data['name'],data.get('arguments',{}))})
            if path=='/api/market/import':
                report=market_workflow.attach_narrative(data['report'],data['text'])
                with storage.LOCK:
                    require_current_report_base(report)
                    report,_=save_report_with_revision(report)
                return self.send(200,report)
            if path=='/api/market/recalculate':
                return self.send(200,market_workflow.recalculate(storage.validate_report(data['report'])))
            if path=='/api/market/merge':
                report=storage.validate_report(retain_collected_market(data['report']))
                job=JOBS.get(data.get('jobId')) or {}
                if job.get('status')!='complete':
                    raise ValueError('A coleta ainda não está disponível para aplicar.')
                if job.get('reportId')!=report['id'] or job.get('sourceId')!=report.get('pdfId'):
                    raise ValueError('Esta coleta pertence a outro relatório ou documento de produtos.')
                with storage.LOCK:
                    latest=storage.get_report(report['id'])
                    current_revision=report_revision(latest)
                    base=report.get('baseRevision')
                    allowed={current_revision}
                    if job.get('savedRevision')==current_revision:
                        allowed.add(job.get('resultBaseRevision'))
                        if job.get('resultBaseRevision')==job.get('startedRevision'):
                            allowed.add(job.get('requestBaseRevision'))
                    if not base or base not in allowed: raise ReportChangedError()
                    if job.get('evidence'):
                        updated=market_workflow.apply_evidence(report,job['evidence'],job.get('collectedAt'))
                    else:
                        raise ValueError('Esta consulta não tem dados para aplicar. Inicie uma nova consulta.')
                    updated['marketAudit']=job.get('report',{}).get('marketAudit',{})
                    updated['baseRevision']=current_revision
                return self.send(200,updated)
            if path=='/api/market/fees':
                report=market_workflow.recalculate(storage.validate_report(data['report']))
                market_fees.refresh(report,MELI if MELI.status().get('connected') else None)
                return self.send(200,market_workflow.recalculate(report))
            if path in ('/api/market/analyze','/api/market/collect'):
                report=storage.validate_report(retain_collected_market(data['report']))
                if data.get('pdfId'): report['pdfId']=data['pdfId']
                if not report.get('pdfId'): raise ValueError('Importe um PDF ou HTML de produtos neste relatório.')
                return self.send(202,start_collect_job(report))
            raise FileNotFoundError('Operação não encontrada.')
        except Exception as exc: self.handle_error(exc)

    def handle_error(self, exc):
        if isinstance(exc,ReportChangedError): return self.send(409,{'error':str(exc),'code':'report_changed'})
        if isinstance(exc,FileNotFoundError): status=404
        elif isinstance(exc,(ValueError,KeyError,JoomPulseError,GoogleMeetError,MercadoLivreError)): status=400
        else: status=500
        message=str(exc) if status!=500 else 'Não foi possível concluir a operação. Confira o formato do arquivo e tente novamente.'
        if status==500: print('Falha local: '+type(exc).__name__,flush=True)
        self.send(status,{'error':message})


class LocalServer(ThreadingHTTPServer):
    # On Windows SO_REUSEADDR can let two processes serve the same port.
    # Keep a single instance so requests cannot reach an older running version.
    allow_reuse_address = False

    def server_bind(self):
        if os.name == 'nt':
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


QUOTA_NOTE='cota ou o orçamento de consultas'
QUOTA_RESUMES={}


def evidence_done(entry):
    """Produto já coletado para o mesmo link: não precisa gastar consultas de novo."""
    evidence=entry.get('evidence') or {}
    return (evidence.get('status')=='collected' and bool(evidence.get('reference'))
            and str(evidence.get('sourceReference') or '')==str((entry.get('source') or {}).get('reference') or ''))


def quota_pending(report):
    """Quantos produtos ficaram sem pesquisa porque a cota ou o orçamento de consultas acabou."""
    return sum(1 for entry in ((report.get('marketAnalysis') or {}).get('products') or [])
               if QUOTA_NOTE in ' '.join(str(note) for note in ((entry.get('evidence') or {}).get('limitations') or [])) and not evidence_done(entry))


def merge_resumed_evidence(previous, positions, evidence):
    """Junta as evidências já coletadas com as da retomada, devolvendo cada produto à sua posição original."""
    fresh=[]
    for item in evidence.get('products') or []:
        if isinstance(item,dict):
            try: number=int(item.get('index'))
            except (TypeError,ValueError): number=0
            if 1<=number<=len(positions): item={**item,'index':positions[number-1]}
            fresh.append(item)
    merged=[*previous,*fresh]
    return {**evidence,'products':sorted(merged,key=lambda item:int(item.get('index') or 0))}


def schedule_quota_resume(report_id, soon=False):
    """Continua a coleta sozinha: já, se só o orçamento da rodada acabou; na próxima hora cheia, se foi a cota da JoomPulse."""
    attempts=QUOTA_RESUMES.get(report_id,0)
    if attempts>=8: return None
    QUOTA_RESUMES[report_id]=attempts+1
    now=datetime.now()
    wait=20 if soon else (60-now.minute)*60-now.second+90
    def resume():
        try:
            latest=storage.get_report(report_id)
            if not quota_pending(latest) or any(job.get('status')=='running' and job.get('reportId')==report_id for job in JOBS.values()): return
            latest['baseRevision']=report_revision(latest)
            start_collect_job(latest)
        except Exception as exc: print('Retomada automática não iniciada: '+type(exc).__name__,flush=True)
    timer=threading.Timer(wait,resume); timer.daemon=True; timer.start()
    return wait


def start_collect_job(report):
    """Start the JoomPulse + Mercado Livre collection for a saved market report."""
    connection_message=market.connection_message(JOOM.status().get('connected'))
    if connection_message: raise ValueError(connection_message)
    with JOBS_LOCK:
        for existing_id,job in list(JOBS.items()):
            if job.get('status')=='running' and job.get('reportId')==report['id']:
                return {'jobId':existing_id,'baseRevision':report.get('baseRevision')}
        report=market_workflow.recalculate(report)
        request_base_revision=report.get('baseRevision')
        with storage.LOCK:
            require_current_report_base(report)
            report,_=save_report_with_revision(report)
        started_revision=report['baseRevision']
        job_id=uuid.uuid4().hex
        total_count=len((report.get('marketAnalysis') or {}).get('products') or [])
        JOBS[job_id]={'status':'running','message':'Iniciando consulta…','reportId':report['id'],'sourceId':report.get('pdfId'),
                      'completedCount':0,'totalCount':total_count,'resumable':False,'resumeJobId':None,'useAI':False}
    def run():
        try:
            def progress(message): JOBS[job_id]['message']=message
            from services.market_data import collect_market
            pdf=market.report_document(report)
            # Retomada: os produtos já coletados para o mesmo link ficam como estão; só os pendentes consomem consultas.
            all_products=pdf.get('products')
            entries=(report.get('marketAnalysis') or {}).get('products') or []
            kept=[entry['evidence'] for entry in entries if evidence_done(entry)]
            kept_indexes={str(item.get('index')) for item in kept}
            positions=[number for number in range(1,len(all_products)+1) if str(number) not in kept_indexes] if isinstance(all_products,list) else []
            if kept and positions and len(kept)+len(positions)==len(all_products):
                result=collect_market(pdf.get('text',''),report['date'],JOOM,progress,products=[all_products[number-1] for number in positions])
                evidence=merge_resumed_evidence(kept,positions,result.get('evidence') or {})
            else:
                result=collect_market(pdf.get('text',''),report['date'],JOOM,progress,products=all_products)
                evidence=result.get('evidence') or {}
            market_fees.attach(report,evidence,MELI if MELI.status().get('connected') else None,progress)
            progress('Organizando imagens, cálculos e pareceres por produto…')
            from services.market_images import cache_evidence_images
            cache_evidence_images(evidence)
            collected_at=storage.now()
            audit={'mode':'deterministic','calls':result.get('audit',[]),'completedAt':collected_at}
            # Preserve any edits saved while the external research ran.
            with storage.LOCK:
                latest=storage.get_report(report['id'])
                result_base_revision=report_revision(latest)
                if latest.get('pdfId')!=report.get('pdfId'):
                    raise ValueError('O documento de produtos foi alterado durante a coleta. Inicie uma nova consulta.')
                merged=market_workflow.apply_evidence(latest,evidence,collected_at)
                merged['marketAudit']=audit
                merged['warnings']=list(dict.fromkeys(merged['warnings']+[w for w in result.get('warnings',[]) if w not in report.get('warnings',[])]))
                updated,_=save_report_with_revision(merged)
            JOBS[job_id]={'status':'complete','message':'Análise pronta para revisão.','report':updated,
                'reportId':report['id'],'sourceId':report.get('pdfId'),'useAI':False,
                'requestBaseRevision':request_base_revision,'startedRevision':started_revision,
                'resultBaseRevision':result_base_revision,'savedRevision':updated['baseRevision'],
                'completedCount':total_count,'totalCount':total_count,'resumable':False,'resumeJobId':None,
                'evidence':evidence,'collectedAt':collected_at}
            # Sobrou produto sem pesquisa? Continua sozinho (já, ou na próxima hora cheia se a cota da JoomPulse acabou).
            left=quota_pending(updated)
            if left:
                # Nenhum produto avançou nesta rodada: a cota por hora acabou; espera a próxima hora cheia.
                stalled=left>=len(positions or all_products or [])
                wait=schedule_quota_resume(report['id'],soon=not stalled)
                if wait: JOBS[job_id]['message']=f'{left} produto(s) aguardando o limite de consultas da JoomPulse. A análise continua sozinha em cerca de {max(1,round(wait/60))} min.'
            else: QUOTA_RESUMES.pop(report['id'],None)
        except Exception as exc:
            JOBS[job_id]={'status':'error','error':str(exc),'message':'A consulta não foi concluída.',
                'reportId':report['id'],'sourceId':report.get('pdfId'),'completedCount':0,
                'totalCount':total_count,'resumable':False,'resumeJobId':None,'useAI':False}
    threading.Thread(target=run,daemon=True).start()
    return {'jobId':job_id,'baseRevision':started_revision}


def _hub_reports(url):
    found=[]
    for item in storage.list_reports():
        try: report=storage.get_report(item['id'])
        except (FileNotFoundError,ValueError): continue
        if ((report.get('productSource') or {}).get('hubSource') or {}).get('url')==url: found.append(report)
    return sorted(found,key=lambda r:str(r.get('updatedAt') or r.get('createdAt') or ''),reverse=True)


def _hub_sheet_states(urls):
    """Latest local analysis of each Hub sheet shown in the list (read-only)."""
    wanted=set(urls); latest={}
    for item in storage.list_reports():
        if 'hubUrl' in item and item.get('hubUrl') not in wanted: continue
        try: report=storage.get_report(item['id'])
        except (FileNotFoundError,ValueError): continue
        url=((report.get('productSource') or {}).get('hubSource') or {}).get('url')
        if url not in wanted: continue
        stamp=str(report.get('updatedAt') or report.get('createdAt') or '')
        if url not in latest or stamp>latest[url][0]: latest[url]=(stamp,report)
    running={j.get('reportId') for j in JOBS.values() if j.get('status')=='running'}
    states={}
    for url,(_,report) in latest.items():
        products=(report.get('marketAnalysis') or {}).get('products') or []
        counts={}
        for entry in products:
            decision=(entry.get('analysis') or {}).get('decision') or {}
            status='pendente' if decision.get('incomplete') else decision.get('status')
            if status: counts[status]=counts.get(status,0)+1
        states[url]={'reportId':report['id'],'running':report['id'] in running,'products':len(products),'counts':counts,
                     'collected':bool((report.get('marketAnalysis') or {}).get('collectedAt')),'date':report.get('date')}
    return states


def handle_extension_request(action, payload):
    """Actions the paired extension may start from the Pronix Hub page. Never writes to the Hub."""
    if action=='sheets':
        urls=[u for u in (payload.get('urls') or [])[:60] if isinstance(u,str) and hub_import.HUB_URL.fullmatch(u)]
        return {'sheets':_hub_sheet_states(urls)}
    url=str(payload.get('url') or '')
    if not hub_import.HUB_URL.fullmatch(url): raise ValueError('Abra uma planilha de validação do Pronix Hub.')
    if action=='import_capture':
        meta=hub_import.save_capture(payload.get('capture'),url,HUB.status().get('extensionVersion',''))
        if not meta.get('products'): raise ValueError('A planilha não trouxe produtos. Aguarde a página carregar e tente de novo.')
        settings=storage.read_json(SETTINGS,{'specialist':''})
        report=analyze({'reportType':'market','methodology':'gabriel','automatic':True,'clientName':meta.get('clientName') or '',
                        'date':storage.today(),'specialist':meta.get('reviewerName') or settings.get('specialist') or 'Especialista Pronix','pdfId':meta['id']})
        job=start_collect_job(report)
        return {'reportId':report['id'],'clientName':report.get('clientName'),'products':len(meta['products']),'jobId':job['jobId']}
    if action=='suggestions':
        reports=_hub_reports(url)
        if not reports: return {'found':False}
        report=reports[0]
        running=any(j.get('status')=='running' and j.get('reportId')==report['id'] for j in JOBS.values())
        products=[]
        for entry in (report.get('marketAnalysis') or {}).get('products') or []:
            decision=(entry.get('analysis') or {}).get('decision') or {}
            note=str((entry.get('review') or {}).get('notes') or '').strip()
            message=note or str(decision.get('message') or '')
            waiting=decision.get('incomplete')=='quota' and not note
            products.append({'index':entry.get('index'),'name':(entry.get('source') or {}).get('name'),'pending':'quota' if waiting else None,
                             'reference':' '.join(re.findall(r'MLB-?\d{6,15}',str((entry.get('source') or {}).get('reference') or ''),re.I))[:120],
                             'status':None if waiting else decision.get('status'),'label':decision.get('label'),'message':'' if waiting else message[:1000]})
        job=next((j for j in JOBS.values() if j.get('status')=='running' and j.get('reportId')==report['id']),None)
        progress={'message':str(job.get('message') or '')[:200],'completed':job.get('completedCount') or 0,'total':job.get('totalCount') or len(products)} if job else None
        failed=next((str(j.get('error') or j.get('message') or '')[:300] for j in reversed(list(JOBS.values())) if j.get('reportId')==report['id'] and j.get('status')=='error'),'')
        return {'found':True,'reportId':report['id'],'clientName':report.get('clientName'),'running':running,'collected':bool((report.get('marketAnalysis') or {}).get('collectedAt')),
                'progress':progress,'failed':'' if running else failed,'products':products}
    raise ValueError('Ação não permitida.')


def start_joom_maintenance(client, *, interval=30):
    """Maintain this installation's OAuth session; never research market data."""
    stop_event=threading.Event()

    def maintain():
        client.set_automatic_renewal(True)
        try:
            while not stop_event.is_set():
                try:
                    # The client owns expiry checks, refresh locking and backoff.
                    # In particular, status reads and other providers stay offline.
                    client.maintain_connection()
                except Exception:
                    # Never expose OAuth response bodies or credentials in logs.
                    # Still wait after a failure; the loop must not retry rapidly.
                    pass
                if stop_event.wait(interval):
                    break
        finally:
            client.set_automatic_renewal(False)

    worker=threading.Thread(target=maintain,name='joompulse-oauth-maintenance',daemon=True)
    worker.start()
    return stop_event,worker


def main():
    global PORT
    parser=argparse.ArgumentParser(); parser.add_argument('--port',type=int,default=8765); parser.add_argument('--open',action='store_true')
    args=parser.parse_args(); PORT=args.port
    server=LocalServer(('127.0.0.1',PORT),Handler)
    maintenance_stop=maintenance_worker=None
    try:
        # The extension's CSP and connection endpoint use one fixed loopback port,
        # even when a developer changes the HTTP UI port.
        HUB.start(port=8766)
        # Pacote da equipe: aplicativos do Mercado Livre e da JoomPulse já vêm prontos (só falta Conectar).
        from services import bundled
        embedded=bundled.apply(MELI,JOOM)
        if embedded: print('Aplicativos configurados pelo pacote: '+', '.join(embedded),flush=True)
        maintenance_stop,maintenance_worker=start_joom_maintenance(JOOM)
        updater.start_background(lambda: storage.read_json(SETTINGS,{}))
        print(f'Central de Análises pronta: http://localhost:{PORT}',flush=True)
        if args.open: webbrowser.open(f'http://localhost:{PORT}')
        server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        if maintenance_stop is not None:
            maintenance_stop.set()
            # An in-flight HTTP refresh has its own timeout. Do not hold local
            # shutdown open for it; this daemon cannot schedule another refresh.
            maintenance_worker.join(timeout=2)
        HUB.stop()
        server.server_close()


if __name__=='__main__': main()
