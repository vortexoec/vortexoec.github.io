"""Dados dos aplicativos embutidos no pacote de instalação.

Permite que Mercado Livre e JoomPulse tenham só o botão "Conectar": o pacote
leva o Client ID/Secret do aplicativo do Mercado Livre e o Client ID da
aplicação JoomPulse em ``resources/conexoes.bin``. O arquivo é gerado na hora
de montar o pacote (instalador/embutir_conexoes.py), nunca entra no Git e é
apenas embaralhado: quem tiver o instalador consegue extrair os valores com
esforço. Distribua o instalador só para a equipe. Os tokens de cada pessoa
continuam individuais e protegidos pelo DPAPI.
"""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path

FILE = Path(__file__).resolve().parents[1] / "resources" / "conexoes.bin"
_MAGIC = b"PRONIX-CONEXOES1"
_SEED = b"PronixBeta:conexoes:v1"


def _stream(length: int) -> bytes:
    out, counter = b"", 0
    while len(out) < length:
        out += hashlib.sha256(_SEED + counter.to_bytes(4, "big")).digest()
        counter += 1
    return out[:length]


def encode(data: dict) -> bytes:
    raw = json.dumps(data, separators=(",", ":")).encode("utf-8")
    mixed = bytes(a ^ b for a, b in zip(raw, _stream(len(raw))))
    return _MAGIC + base64.b64encode(mixed)


def decode(blob: bytes) -> dict:
    if not blob.startswith(_MAGIC):
        raise ValueError("Arquivo de conexões inválido.")
    mixed = base64.b64decode(blob[len(_MAGIC):], validate=True)
    data = json.loads(bytes(a ^ b for a, b in zip(mixed, _stream(len(mixed)))).decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Arquivo de conexões inválido.")
    return data


def load(path: Path | None = None) -> dict:
    path = path or FILE
    try:
        return decode(path.read_bytes()) if path.is_file() else {}
    except (OSError, ValueError):
        return {}


def apply(meli, joom, path: Path | None = None) -> list[str]:
    """Configura só o que ainda não estiver configurado. Nunca troca uma conexão existente."""
    data, applied = load(path), []
    app = data.get("mercadolivre") or {}
    if app.get("client_id") and app.get("client_secret") and app.get("redirect_uri") and not meli.status().get("configured"):
        try:
            meli.configure(app["client_id"], app["client_secret"], app["redirect_uri"], source="embutido")
            applied.append("mercadolivre")
        except Exception:
            pass
    client_id = (data.get("joompulse") or {}).get("client_id")
    if client_id and not joom.status().get("configured"):
        try:
            joom.configure({"client_id": client_id})
            applied.append("joompulse")
        except Exception:
            pass
    return applied
