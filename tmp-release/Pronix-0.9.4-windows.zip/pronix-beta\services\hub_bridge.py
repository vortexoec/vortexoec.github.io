"""Authenticated, loopback-only bridge to the user's own Pronix Chrome extension.

No browser cookies, remote requests, or scripts are read or executed here.
Credentials are loaded lazily and protected with per-Windows-user DPAPI.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
import hmac
import json
import logging
import os
from pathlib import Path
import re
import secrets
import socket
import threading
import time
from urllib.parse import urlsplit
import uuid

from .joompulse import _crypt_blob


MAX_HTML_BYTES = 2 * 1024 * 1024
MAX_MESSAGE_BYTES = 2 * MAX_HTML_BYTES + 65536
PAIR_SECONDS = 300
MAX_PAIR_ATTEMPTS = 5
REQUEST_TIMEOUT = 20
AUTH_TIMEOUT = 5
EXTENSION_VERSION = "0.8.0"
OAUTH_EXTENSION_VERSIONS = {"0.5.0", "0.6.0", "0.6.1", "0.7.0", "0.7.1", "0.7.2", "0.7.3", "0.8.0"}
EXT_ACTIONS = {"import_capture", "suggestions", "sheets"}
OAUTH_AUTH_PREFIX = "https://auth.mercadolivre.com.br/authorization?"
REVIEW_EXTENSION_VERSION = "0.2.0"
LEGACY_EXTENSION_VERSIONS = {"0.3.0", "0.3.1", "0.3.2", "0.3.3", "0.3.4", "0.3.5", "0.3.6", "0.3.7", "0.4.0", "0.5.0", "0.6.0", "0.6.1", "0.7.0", "0.7.1", "0.7.2", "0.7.3"}
SUPPORTED_EXTENSION_VERSIONS = {"0.1.0", "0.2.0", *LEGACY_EXTENSION_VERSIONS, EXTENSION_VERSION}
_ORIGIN = re.compile(r"chrome-extension://([a-p]{32})\Z")
_TOKEN = re.compile(r"[A-Za-z0-9_-]{43}\Z")
_ID = re.compile(r"[a-f0-9]{32}\Z")
class HubBridgeError(ValueError):
    """A safe, local UI error; never includes tokens or remote payloads."""


@dataclass
class _Pending:
    connection: object
    action: str
    expected_url: str | None = None
    arguments: dict = field(default_factory=dict)
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    event: threading.Event = field(default_factory=threading.Event)
    data: dict | None = None
    error: str | None = None


def _url(value):
    if not isinstance(value, str) or len(value) > 2048 or any(c.isspace() for c in value):
        raise HubBridgeError("Selecione uma tabela de produtos válida do Pronix Hub.")
    try:
        parsed = urlsplit(value)
        if (parsed.scheme != "https" or parsed.netloc != "pronixhub.com.br"
                or parsed.username or parsed.password or parsed.query or parsed.fragment
                or not re.fullmatch(r"/validacao-planilhas/[A-Za-z0-9_-]{1,128}/?", parsed.path)):
            raise ValueError()
    except ValueError:
        raise HubBridgeError("Selecione uma tabela de produtos válida do Pronix Hub.") from None
    return value


def _tab_id(value):
    if type(value) is not int or not 0 <= value <= 2**31 - 1:
        raise HubBridgeError("A aba selecionada é inválida. Atualize a lista de abas.")
    return value


def _json(raw, limit=MAX_MESSAGE_BYTES):
    if not isinstance(raw, str) or len(raw.encode("utf-8")) > limit:
        raise ValueError("Invalid frame")
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate field")
            result[key] = value
        return result
    result = json.loads(raw, object_pairs_hook=pairs,
                        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Non-finite number")))
    if not isinstance(result, dict):
        raise ValueError("Invalid message")
    return result


class HubBridge:
    def __init__(self, storage_dir=None):
        from .secure_dir import secure_dir
        self.storage_dir = Path(storage_dir) if storage_dir is not None else secure_dir()
        self.secrets_path = self.storage_dir / "hub-bridge.dpapi" if self.storage_dir else None
        self._lock = threading.RLock()
        self._loaded = False
        self._credential = None
        self._error = None
        self.oauth_handler = None
        self.ext_handler = None
        self._server = None
        self._thread = None
        self._run_id = None
        self._connections = set()
        self._connection = None
        self._version = None
        self._pending = {}
        self._pair_code = None
        self._pair_deadline = 0
        self._pair_attempts = 0
        self.port = None
        # An unregistered logger cannot inherit DEBUG payload logging from the app.
        self._logger = logging.Logger("pronix.hub_bridge.private")
        self._logger.disabled = True
        self._logger.propagate = False

    def _load(self):
        if self._loaded:
            return
        self._loaded = True
        if self.secrets_path is None:
            self._error = "A conexão da extensão requer o armazenamento protegido do Windows."
            return
        try:
            if self.secrets_path.exists():
                if self.secrets_path.stat().st_size > 16384:
                    raise ValueError()
                saved = json.loads(_crypt_blob(self.secrets_path.read_bytes(), decrypt=True))
                if (not isinstance(saved, dict) or set(saved) != {"token", "extensionId"}
                        or not _TOKEN.fullmatch(str(saved.get("token", "")))
                        or not re.fullmatch(r"[a-p]{32}", str(saved.get("extensionId", "")))):
                    raise ValueError()
                self._credential = saved
        except Exception:
            self._error = "A conexão salva da extensão não pôde ser aberta. Faça o pareamento novamente."

    def _save(self, credential):
        temporary = None
        try:
            if self.secrets_path is None:
                raise ValueError()
            blob = _crypt_blob(json.dumps(credential).encode("utf-8"))
            self.storage_dir.mkdir(parents=True, exist_ok=True)
            temporary = self.storage_dir / (".hub-bridge-" + uuid.uuid4().hex + ".tmp")
            temporary.write_bytes(blob)
            os.replace(temporary, self.secrets_path)
        except Exception:
            raise HubBridgeError("Não foi possível guardar o pareamento protegido neste usuário do Windows.") from None
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    def status(self):
        with self._lock:
            self._load()
            result = {"paired": bool(self._credential), "connected": self._connection is not None,
                      "extensionId": self._credential["extensionId"] if self._credential else None,
                      "extensionVersion": self._version,
                      "captureReviewsSupported": self._version in {REVIEW_EXTENSION_VERSION, *LEGACY_EXTENSION_VERSIONS, EXTENSION_VERSION},
                      "requiredVersion": REVIEW_EXTENSION_VERSION,
                      "oauthSupported": self._version in OAUTH_EXTENSION_VERSIONS,
                      "latestExtensionVersion": EXTENSION_VERSION}
            if self._version == "0.1.0":
                result["warning"] = "A extensão 0.1.0 importa os dados comerciais. Para incluir os pareceres, atualize e recarregue a extensão 0.2.0 e importe novamente."
            if self._error:
                result["error"] = self._error
            return result

    def start(self, port=8766):
        with self._lock:
            self._load()
            if self._server is not None:
                return self.status()
            listener = None
            try:
                if type(port) is not int or not 0 <= port <= 65535:
                    raise ValueError()
                from websockets.sync.server import serve
                listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                if os.name == "nt":
                    listener.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                listener.bind(("127.0.0.1", port))
                listener.listen(16)
                self.port = listener.getsockname()[1]
                run_id = uuid.uuid4().hex
                self._run_id = run_id
                self._server = serve(lambda ws: self._handle(ws, run_id), sock=listener,
                    origins=[_ORIGIN], process_request=self._handshake, compression=None,
                    server_header=None, open_timeout=5, ping_interval=20, ping_timeout=20,
                    close_timeout=1, max_size=MAX_MESSAGE_BYTES, max_queue=4, logger=self._logger)
                self._thread = threading.Thread(target=self._serve, args=(self._server, run_id), daemon=True,
                                                name="PronixHubBridge")
                self._thread.start()
                if self._credential or self.secrets_path and not self.secrets_path.exists():
                    self._error = None
            except ImportError:
                self._error = "A conexão da extensão requer websockets 15.0.1. Atualize as dependências do programa."
            except Exception:
                self._error = "Não foi possível iniciar a conexão local da extensão. Confira se a porta está disponível."
            if self._server is None and listener is not None:
                listener.close()
            return self.status()

    def _serve(self, server, run_id):
        try:
            server.serve_forever()
        except Exception:
            with self._lock:
                if self._run_id == run_id:
                    self._error = "A conexão local da extensão foi interrompida. Reinicie o programa."
        finally:
            with self._lock:
                if self._run_id == run_id:
                    self._server = None
                    self._cancel(None, "A conexão local da extensão foi encerrada.")

    def _handshake(self, connection, request):
        try:
            origin = request.headers.get("Origin", "")
            host = request.headers.get("Host", "")
            if (request.path != "/" or not _ORIGIN.fullmatch(origin)
                    or host not in {f"127.0.0.1:{self.port}", f"localhost:{self.port}"}
                    or request.headers.get("Authorization") is not None
                    or request.headers.get("Proxy-Authorization") is not None):
                raise ValueError()
        except Exception:
            return connection.respond(403, "Conexão não autorizada.\n")
        return None

    def _cancel(self, connection, message):
        for request_id, pending in list(self._pending.items()):
            if connection is None or pending.connection is connection:
                pending.error = message
                pending.event.set()
                self._pending.pop(request_id, None)

    @staticmethod
    def _close(connection, code=1000):
        if connection is not None:
            try:
                connection.close(code=code)
            except Exception:
                pass

    def stop(self):
        with self._lock:
            server, thread = self._server, self._thread
            self._server = self._thread = self._run_id = None
            connections = list(self._connections)
            self._connection = None
            self._version = None
            self._pair_code = None
            self._cancel(None, "A conexão local da extensão foi encerrada.")
        if server is not None:
            server.shutdown()
        for connection in connections:
            self._close(connection, 1001)
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=2)
        return self.status()

    def begin_pairing(self):
        with self._lock:
            self._load()
            if self._server is None:
                raise HubBridgeError(self._error or "Inicie a conexão local antes de parear a extensão.")
            self._pair_code = f"{secrets.randbelow(1_000_000):06d}"
            self._pair_deadline = time.monotonic() + PAIR_SECONDS
            self._pair_attempts = 0
            return {"code": self._pair_code,
                    "expiresAt": (datetime.now(timezone.utc) + timedelta(seconds=PAIR_SECONDS)).isoformat()}

    def disconnect(self):
        with self._lock:
            self._loaded = True
            self._credential = self._pair_code = self._connection = self._version = None
            self._cancel(None, "O pareamento da extensão foi removido.")
            connections = list(self._connections)
            try:
                if self.secrets_path is not None:
                    self.secrets_path.unlink(missing_ok=True)
                self._error = None
            except OSError:
                self._error = "Não foi possível remover a conexão salva da extensão. Confira as permissões da pasta local."
        for connection in connections:
            self._close(connection, 1008)
        if self._error:
            raise HubBridgeError(self._error)
        return self.status()

    def _authenticate(self, ws, message):
        origin = ws.request.headers["Origin"]
        extension_id = _ORIGIN.fullmatch(origin)[1]
        previous = None
        with self._lock:
            self._load()
            if message.get("type") == "pair":
                if set(message) != {"type", "code"} or not isinstance(message.get("code"), str):
                    raise HubBridgeError("Mensagem de pareamento inválida.")
                self._pair_attempts += 1
                if (not self._pair_code or time.monotonic() >= self._pair_deadline
                        or self._pair_attempts > MAX_PAIR_ATTEMPTS
                        or not hmac.compare_digest(message["code"], self._pair_code)):
                    if self._pair_attempts >= MAX_PAIR_ATTEMPTS or time.monotonic() >= self._pair_deadline:
                        self._pair_code = None
                    raise HubBridgeError("Código de pareamento inválido ou expirado. Gere um novo código no programa.")
                credential = {"token": secrets.token_urlsafe(32), "extensionId": extension_id}
                self._save(credential)
                self._credential = credential
                self._pair_code = None
                self._error = None
                previous, self._connection = self._connection, None
                self._version = None
                self._cancel(None, "O pareamento da extensão foi substituído.")
                reply = {"type": "paired", "token": credential["token"]}
                authenticated = False
            elif (set(message) == {"type", "token", "version"} and message.get("type") == "hello"
                  and isinstance(message.get("token"), str) and _TOKEN.fullmatch(message["token"])
                  and isinstance(message.get("version"), str) and message.get("version") in SUPPORTED_EXTENSION_VERSIONS and self._credential
                  and extension_id == self._credential["extensionId"]
                  and hmac.compare_digest(message["token"], self._credential["token"])):
                previous, self._connection = self._connection, ws
                self._version = message["version"]
                self._error = None
                if previous is not None:
                    self._cancel(previous, "A extensão reconectou. Repita a operação.")
                reply, authenticated = {"type": "hello", "ok": True}, True
            else:
                raise HubBridgeError("Extensão não autorizada. Confira o pareamento e a versão instalada.")
        if previous is not ws:
            self._close(previous, 1001)
        ws.send(json.dumps(reply))
        return authenticated

    def _handle(self, ws, run_id):
        with self._lock:
            if run_id != self._run_id or self._server is None:
                return
            self._connections.add(ws)
        try:
            if not self._authenticate(ws, _json(ws.recv(timeout=AUTH_TIMEOUT), 4096)):
                return  # Paired sockets close; authentication requires a fresh socket.
            for raw in ws:
                message = _json(raw)
                if (message.get("type") == "ping" and set(message) <= {"type", "at"}
                        and ("at" not in message or isinstance(message["at"], str) and len(message["at"]) <= 64)):
                    ws.send('{"type":"pong"}')
                elif message.get("type") == "response":
                    self._response(ws, message)
                elif (message.get("type") == "ext_request" and isinstance(message.get("id"), str)
                        and _ID.fullmatch(message["id"]) and message.get("action") in EXT_ACTIONS
                        and isinstance(message.get("payload"), dict) and set(message) == {"type", "id", "action", "payload"}):
                    with self._lock:
                        handler = self.ext_handler if ws is self._connection else None
                    threading.Thread(target=self._ext_request, args=(ws, handler, message), daemon=True).start()
                elif (message.get("type") == "oauth_return" and set(message) == {"type", "url"}
                        and isinstance(message["url"], str) and 0 < len(message["url"]) <= 8192):
                    with self._lock:
                        handler = self.oauth_handler if ws is self._connection else None
                    if callable(handler):
                        # The handler validates state/redirect itself; never block the socket loop.
                        threading.Thread(target=handler, args=(message["url"],), daemon=True).start()
                # Unsolicited data and unsupported actions never initiate local work.
        except HubBridgeError as exc:
            try:
                ws.send(json.dumps({"type": "error", "error": str(exc)}, ensure_ascii=False))
            except Exception:
                pass
            self._close(ws, 1008)
        except Exception:
            self._close(ws, 1008)
        finally:
            with self._lock:
                self._connections.discard(ws)
                self._cancel(ws, "A extensão desconectou. Abra o Chrome e tente novamente.")
                if self._connection is ws:
                    self._connection = None
                    self._version = None

    def _response(self, ws, message):
        request_id = message.get("id")
        if not isinstance(request_id, str) or not _ID.fullmatch(request_id):
            return
        with self._lock:
            pending = self._pending.get(request_id)
            if pending is None or pending.connection is not ws or self._connection is not ws:
                return
            if type(message.get("ok")) is not bool:
                return
            expected_keys = {"type", "id", "ok", "data" if message["ok"] else "error"}
            if set(message) != expected_keys:
                return
            try:
                if not message["ok"]:
                    raise HubBridgeError("A extensão não conseguiu concluir a operação. Confira a aba selecionada e tente novamente.")
                pending.data = self._validate_data(pending, message["data"])
            except (HubBridgeError, ValueError, TypeError, UnicodeError):
                pending.error = "A extensão retornou dados inválidos ou de outra página. Atualize as abas e tente novamente."
                if not message["ok"]:
                    pending.error = "A extensão não conseguiu concluir a operação. Confira a aba selecionada e tente novamente."
            self._pending.pop(request_id, None)
            pending.event.set()

    def _validate_data(self, pending, data):
        if not isinstance(data, dict):
            raise ValueError()
        if pending.action == "oauth_open":
            if data != {"opened": True}:
                raise ValueError()
            return {"opened": True}
        if pending.action == "list_tabs":
            if set(data) != {"tabs"} or not isinstance(data["tabs"], list) or len(data["tabs"]) > 200:
                raise ValueError()
            tabs, seen = [], set()
            for tab in data["tabs"]:
                if (not isinstance(tab, dict) or set(tab) != {"id", "title", "url", "active"}
                        or not isinstance(tab["title"], str) or len(tab["title"]) > 500
                        or type(tab["active"]) is not bool):
                    raise ValueError()
                tab_id = _tab_id(tab["id"])
                if tab_id in seen:
                    raise ValueError()
                seen.add(tab_id)
                tabs.append({"id": tab_id, "title": tab["title"], "url": _url(tab["url"]), "active": tab["active"]})
            return {"tabs": tabs}
        if (set(data) != {"url", "title", "html", "capturedAt"}
                or _url(data["url"]) != pending.expected_url
                or not isinstance(data["title"], str) or len(data["title"]) > 500
                or not isinstance(data["html"], str) or not data["html"].strip()
                or len(data["html"].encode("utf-8")) > MAX_HTML_BYTES
                or not isinstance(data["capturedAt"], str) or len(data["capturedAt"]) > 64
                or datetime.fromisoformat(data["capturedAt"].replace("Z", "+00:00")).tzinfo is None):
            raise ValueError()
        return {key: data[key] for key in ("url", "title", "html", "capturedAt")}

    def _request(self, action, *, timeout=None, **arguments):
        timeout = REQUEST_TIMEOUT if timeout is None else timeout
        with self._lock:
            ws = self._connection
            if ws is None:
                raise HubBridgeError("A extensão não está conectada. Abra o Chrome e confira o pareamento.")
            if len(self._pending) >= 8:
                raise HubBridgeError("Aguarde a operação atual da extensão terminar.")
            request_id = uuid.uuid4().hex
            pending = _Pending(ws, action, arguments.get("expectedUrl"), dict(arguments))
            self._pending[request_id] = pending
        try:
            ws.send(json.dumps({"type": "request", "id": request_id, "action": action, **arguments}))
        except Exception:
            with self._lock:
                self._pending.pop(request_id, None)
            raise HubBridgeError("A extensão desconectou. Abra o Chrome e tente novamente.") from None
        if not pending.event.wait(timeout):
            with self._lock:
                self._pending.pop(request_id, None)
            raise HubBridgeError("A extensão não respondeu em 20 segundos. Confira a aba e tente novamente.")
        if pending.error:
            raise HubBridgeError(pending.error)
        return pending.data

    def list_tabs(self):
        return self._request("list_tabs")

    def capture(self, tab_id, expected_url):
        return self._request("capture", tabId=_tab_id(tab_id), expectedUrl=_url(expected_url))

    def open_oauth(self, auth_url, return_prefix, state):
        """Ask the paired extension to open the login tab and report the return URL."""
        if not isinstance(auth_url, str) or not auth_url.startswith(OAUTH_AUTH_PREFIX) or len(auth_url) > 4096:
            raise HubBridgeError("Endereço de autorização inválido.")
        if (not isinstance(return_prefix, str) or not return_prefix.startswith("https://") or len(return_prefix) > 2048
                or not isinstance(state, str) or not re.fullmatch(r"[A-Za-z0-9_-]{16,128}", state)):
            raise HubBridgeError("Configuração de retorno inválida.")
        # The Chrome service worker may be briefly asleep; its alarm reconnects within ~30s.
        deadline = time.monotonic() + 35
        while True:
            with self._lock:
                connected, supported = self._connection is not None, self._version in OAUTH_EXTENSION_VERSIONS
            if connected or time.monotonic() >= deadline:
                break
            time.sleep(0.5)
        if not connected:
            raise HubBridgeError("A extensão da Central não está conectada. Abra o Chrome e clique no ícone da extensão.")
        if not supported:
            raise HubBridgeError(f"Recarregue a extensão da Central (versão {EXTENSION_VERSION}) para conectar sem copiar e colar.")
        return self._request("oauth_open", authUrl=auth_url, returnPrefix=return_prefix, state=state)

    def _ext_request(self, ws, handler, message):
        """Run one request started by the extension and answer on the same socket."""
        reply = {"type": "ext_response", "id": message["id"]}
        try:
            if not callable(handler):
                raise HubBridgeError("A Central não está pronta para esta ação.")
            reply.update(ok=True, data=handler(message["action"], message["payload"]))
        except (HubBridgeError, ValueError) as exc:
            reply.update(ok=False, error=str(exc)[:400])
        except Exception:
            reply.update(ok=False, error="Não foi possível concluir. Confira a Central e tente de novo.")
        try:
            ws.send(json.dumps(reply, ensure_ascii=False))
        except Exception:
            pass
