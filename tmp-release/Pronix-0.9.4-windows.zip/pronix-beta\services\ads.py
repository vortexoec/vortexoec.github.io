"""Local, deterministic analysis of Mercado Livre CSV/XLSX reports.

Percentages use percentage points (20 means 20%). Missing values are None.
No external service is contacted; original data and formulas are never modified.
"""
from __future__ import annotations

import csv
import hashlib
import io
import math
import re
import unicodedata
import zipfile
from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path


FIELDS = [
    ("campaign", "Campanha / anúncio"),
    ("date", "Data (somente relatório diário)"),
    ("dateFrom", "Desde (início da linha no relatório ML)"),
    ("dateTo", "Até (fim da linha no relatório ML)"),
    ("spend", "Investimento em Ads (R$)"),
    ("revenue", "Receita total atribuída a Ads (R$)"),
    ("directRevenue", "Receita direta de Ads (R$)"),
    ("indirectRevenue", "Receita indireta de Ads (R$)"),
    ("orders", "Vendas / conversões atribuídas (quantidade)"),
    ("directOrders", "Vendas diretas (quantidade)"),
    ("indirectOrders", "Vendas indiretas (quantidade)"),
    ("clicks", "Cliques"),
    ("impressions", "Impressões"),
    ("dailyBudget", "Orçamento diário (R$)"),
    ("targetRoas", "ROAS objetivo (x)"),
    ("lostBudget", "Impressões perdidas por orçamento (%)"),
    ("lostRank", "Impressões perdidas por classificação (%)"),
]
LABELS = dict(FIELDS)
ALIASES = {
    "campaign": ["nome", "campanha", "nome da campanha", "campanha publicitaria", "campaign", "campaign name", "nome do anuncio", "anuncio", "titulo do anuncio", "produto", "sku"],
    "date": ["data", "dia", "date", "day"],
    "dateFrom": ["desde", "data inicial", "inicio do periodo"],
    "dateTo": ["ate", "data final", "fim do periodo"],
    "spend": ["investimento", "investimento em ads", "investimento em publicidade", "custo", "gasto", "gastos", "spend", "cost", "investment", "custo total", "valor investido"],
    "revenue": ["receita", "receita atribuida", "receita por publicidade", "receita total atribuida", "receita total atribuida a ads", "receita de publicidade", "faturamento atribuido", "receita total", "receita por ads", "revenue", "total amount", "total revenue", "total_amount"],
    "directRevenue": ["receita direta", "receita por ventas diretas", "receita por vendas diretas", "receita de vendas diretas", "receita direta por publicidade", "faturamento direto", "direct revenue", "direct amount", "direct_amount"],
    "indirectRevenue": ["receita indireta", "receita por vendas indiretas", "receita de vendas indiretas", "receita indireta por publicidade", "faturamento indireto", "indirect revenue", "indirect amount", "indirect_amount"],
    "orders": ["vendas", "vendas por publicidade", "vendas atribuidas", "vendas totais atribuidas", "conversoes", "numero de vendas", "quantidade de vendas", "orders", "conversions", "total sales", "total_sales"],
    "directOrders": ["vendas diretas", "quantidade de vendas diretas", "direct sales", "direct_sales"],
    "indirectOrders": ["vendas indiretas", "quantidade de vendas indiretas", "indirect sales", "indirect_sales"],
    "clicks": ["cliques", "clicks", "quantidade de cliques"],
    "impressions": ["impressoes", "impressions", "quantidade de impressoes"],
    "dailyBudget": ["orcamento", "orcamento diario", "budget", "daily budget"],
    "targetRoas": ["roas objetivo", "roas alvo", "roas desejado", "target roas", "roas target"],
    "lostBudget": ["de impressoes perdidas por orcamento", "impressoes perdidas por orcamento", "perdidas por orcamento", "impression share lost budget", "lost impression share budget"],
    "lostRank": ["de impressoes perdidas por classificacao", "impressoes perdidas por classificacao", "perdidas por classificacao", "impression share lost rank", "lost impression share rank"],
}
BASE = ("spend", "revenue", "orders", "clicks", "impressions")
COMPONENTS = ("directRevenue", "indirectRevenue", "directOrders", "indirectOrders")
MISSING = {"", "-", "--", "—", "n/a", "na", "n.d.", "nd", "null", "none", "indisponivel", "nao disponivel"}
MAX_ROWS = 100000


def normalize(value):
    value = unicodedata.normalize("NFKD", str(value or ""))
    value = "".join(char for char in value if not unicodedata.combining(char)).lower()
    value = re.sub(r"\([^)]*\)|\[[^]]*\]", " ", value)
    value = value.replace("r$", " ").replace("%", " ").replace("_", " ")
    return re.sub(r"\s+", " ", value).strip()


def parse_number(value):
    """Read Brazilian or unambiguous international numeric cells; never coerce blanks."""
    if value is None or isinstance(value, (bool, date, datetime)):
        return None
    if isinstance(value, (int, float)):
        return float(value) if math.isfinite(float(value)) else None
    raw = str(value).strip()
    missing_key = "".join(char for char in unicodedata.normalize("NFKD", raw.lower()) if not unicodedata.combining(char))
    if missing_key in MISSING:
        return None
    negative = raw.startswith("(") and raw.endswith(")")
    raw = re.sub(r"(?i)R\$|BRL|USD|\$|%|\s|\u00a0", "", raw).strip("()")
    if raw.lower().endswith("x"):
        raw = raw[:-1]
    if not re.fullmatch(r"[-+]?\d[\d.,]*", raw):
        return None
    if "," in raw and "." in raw:
        # The final punctuation denotes the decimal portion.
        raw = raw.replace(".", "").replace(",", ".") if raw.rfind(",") > raw.rfind(".") else raw.replace(",", "")
    elif "," in raw:
        # Native BR report text uses decimal commas; repeated groups are thousands.
        raw = raw.replace(",", "") if raw.count(",") > 1 and re.fullmatch(r"[-+]?\d{1,3}(,\d{3})+", raw) else raw.replace(",", ".")
    elif "." in raw and re.fullmatch(r"[-+]?\d{1,3}(\.\d{3})+", raw):
        raw = raw.replace(".", "")
    try:
        number = float(raw)
        if not math.isfinite(number):
            return None
        return -number if negative else number
    except ValueError:
        return None


def _date(value):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    raw = str(value or "").strip()
    # Mercado Livre exports abbreviated Portuguese months independently of the
    # operating-system locale (for example 01-out-2026). Reject invalid dates.
    abbreviated = re.fullmatch(r"(\d{1,2})-(jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez)-(\d{4})", raw.lower())
    if abbreviated:
        month = ("jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez").index(abbreviated[2]) + 1
        try:
            return date(int(abbreviated[3]), month, int(abbreviated[1]))
        except ValueError:
            return None
    for pattern in ("%Y-%m-%d", "%d/%m/%Y", "%d/%m/%y", "%d-%m-%Y", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M:%S"):
        try:
            return datetime.strptime(raw, pattern).date()
        except ValueError:
            continue
    return None


def _read_sheets(path):
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in (".csv", ".tsv"):
        data = path.read_bytes()
        try:
            text = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = data.decode("cp1252")
        try:
            dialect = csv.Sniffer().sniff(text[:20000], delimiters=";,\t")
            rows = list(csv.reader(io.StringIO(text), dialect))
        except csv.Error:
            rows = list(csv.reader(io.StringIO(text), delimiter="\t" if suffix == ".tsv" else ";"))
        if rows and len(rows[0]) == 1 and str(rows[0][0]).lower().startswith("sep="):
            rows = list(csv.reader(io.StringIO("\n".join(text.splitlines()[1:])), delimiter=text.splitlines()[0][-1]))
        if len(rows) > MAX_ROWS:
            raise ValueError(f"O beta aceita até {MAX_ROWS:,} linhas por aba. Exporte um período menor.")
        return [("Dados", rows)]
    if suffix != ".xlsx":
        raise ValueError("Formato não suportado. Use XLSX ou CSV; no Excel, salve arquivos XLS como XLSX.")
    with zipfile.ZipFile(path) as archive:
        if sum(item.file_size for item in archive.infolist()) > 120_000_000:
            raise ValueError("A planilha expandida é muito grande para o beta. Exporte um período menor.")
    from openpyxl import load_workbook
    workbook = load_workbook(path, read_only=True, data_only=True, keep_links=False)
    result = []
    try:
        for worksheet in workbook.worksheets:
            if worksheet.max_row and worksheet.max_row > MAX_ROWS:
                raise ValueError(f"A aba {worksheet.title} ultrapassa {MAX_ROWS:,} linhas. Exporte um período menor.")
            if worksheet.max_column and worksheet.max_column > 300:
                raise ValueError(f"A aba {worksheet.title} tem mais de 300 colunas. Exporte apenas os dados necessários.")
            rows = []
            for row in worksheet.iter_rows(values_only=True):
                if len(rows) >= MAX_ROWS or len(row) > 300:
                    raise ValueError(f"A aba {worksheet.title} ultrapassa o limite de linhas/colunas do beta. Exporte um período menor.")
                rows.append(row)
            result.append((worksheet.title, rows))
    finally:
        workbook.close()
    return result


def _suggest(headers):
    output = {}
    for index, header in enumerate(headers):
        normal = normalize(header)
        for key, aliases in ALIASES.items():
            if key not in output and normal in aliases:
                output[key] = index
                break
    return output


def _header(rows):
    best = (0, 0)
    for index, row in enumerate(rows[:60]):
        suggested = _suggest(row)
        score = len(suggested) + sum(2 for key in BASE if key in suggested)
        if score > best[1]:
            best = (index, score)
    return best[0]


def _json_cell(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def inspect_spreadsheet(path):
    sheets = []
    for name, rows in _read_sheets(path):
        header_row = _header(rows)
        headers = [str(value or f"Coluna {index + 1}") for index, value in enumerate(rows[header_row])] if rows else []
        sheets.append({"name": name, "headers": headers, "headerRow": header_row,
                       "preview": [[_json_cell(value) for value in row] for row in rows[header_row + 1:header_row + 7]],
                       "suggestedMapping": _suggest(headers), "rowCount": max(0, len(rows) - header_row - 1)})
    return {"sheets": sheets, "fields": [{"key": key, "label": label} for key, label in FIELDS]}


def _ratio(numerator, denominator, percent=False):
    if numerator is None or denominator is None or denominator <= 0:
        return None
    return round(numerator / denominator * (100 if percent else 1), 6)


def _totals(rows, total_revenue=None):
    metrics = {}
    for key in BASE + COMPONENTS:
        values = [row.get(key) for row in rows]
        metrics[key] = round(sum(values), 6) if values and all(value is not None for value in values) else None
    metrics.update({
        "roas": _ratio(metrics["revenue"], metrics["spend"]),
        "acos": _ratio(metrics["spend"], metrics["revenue"], True),
        "ctr": _ratio(metrics["clicks"], metrics["impressions"], True),
        "cpc": _ratio(metrics["spend"], metrics["clicks"]),
        "cvr": _ratio(metrics["orders"], metrics["clicks"], True),
        "tacos": _ratio(metrics["spend"], total_revenue, True),
    })
    return metrics


def _fmt(number, decimals=2):
    if number is None:
        return "não disponível"
    return f"{number:,.{decimals}f}".replace(",", "~").replace(".", ",").replace("~", ".")


def _money(number):
    return "não disponível" if number is None else "R$ " + _fmt(number)


def _unit(number, unit):
    return "não disponível" if number is None else _fmt(number) + unit


def _consistent(rows, key):
    values = {row.get(key) for row in rows if row.get(key) is not None}
    return next(iter(values)) if len(values) == 1 else None


def _classify(metrics, rows, context, days):
    margin = parse_number(context.get("marginPercent"))
    target = parse_number(context.get("targetRoas")) or _consistent(rows, "targetRoas")
    observations, actions = [], []
    status = "Poucos dados para conclusão"
    if metrics["spend"] is not None and metrics["revenue"] is not None:
        observations.append(f"Investimento de {_money(metrics['spend'])} e receita atribuída de {_money(metrics['revenue'])} no período informado.")
    if metrics["roas"] is not None:
        observations.append(f"ROAS de {_fmt(metrics['roas'])}x: cada R$ 1 investido gerou R$ {_fmt(metrics['roas'])} em receita atribuída. Isso não representa lucro.")
    if margin is not None and metrics["acos"] is not None:
        observations.append(f"ACOS de {_fmt(metrics['acos'])}% frente à margem antes de Ads informada de {_fmt(margin)}%. Margem aplicada como referência agregada; diferenças entre SKUs exigem custos individuais.")
        if metrics["acos"] >= margin:
            status = "Risco de prejuízo" if metrics["acos"] > margin else "No ponto de equilíbrio"
            actions.append("Revisar custos, preço e frete por SKU antes de ampliar a verba. Prioridade: validar ACOS abaixo da margem disponível.")
    if margin is not None and metrics["spend"] and metrics["revenue"] == 0:
        status = "Investimento sem receita atribuída"
    if target and metrics["roas"] is not None:
        observations.append(f"ROAS objetivo informado: {_fmt(target)}x; o realizado está {'acima ou igual' if metrics['roas'] >= target else 'abaixo'} ao objetivo.")
        if days is not None and days >= 7 and metrics["orders"] is not None and metrics["orders"] > 0 and not status.startswith(("Risco", "No ponto")):
            status = "Objetivo de ROAS atingido" if metrics["roas"] >= target else "Abaixo do ROAS objetivo"
    if metrics["clicks"] is not None and metrics["clicks"] > 0 and metrics["orders"] == 0:
        observations.append(f"Foram registrados {_fmt(metrics['clicks'], 0)} cliques e nenhuma venda atribuída. Preço, frete, prazo e qualidade do anúncio são hipóteses a verificar, não causas confirmadas.")
        actions.append("Conferir oferta completa (preço + frete), prazo, imagens, título e avaliações. Acompanhar vendas atribuídas e CVR; revisar em 7 dias, respeitando o período e a atualização da atribuição.")
    if any((row.get("lostRank") or 0) > 0 for row in rows):
        observations.append("Há perda de impressões por classificação em linhas da fonte. Isso indica necessidade de investigar competitividade; não identifica isoladamente a causa.")
        actions.append("Verificar qualidade do anúncio, preço e logística antes de mudar orçamento ou ROAS.")
    budget_limited = any((row.get("lostBudget") or 0) > 0 for row in rows)
    if budget_limited:
        observations.append("A fonte registra perda de impressões por orçamento. A presença desse indicador, isoladamente, não autoriza aumentar a verba.")
    enough_context = days is not None and days >= 7 and (metrics["orders"] or 0) > 0
    profitable = margin is not None and metrics["acos"] is not None and metrics["acos"] < margin
    target_met = target is not None and metrics["roas"] is not None and metrics["roas"] >= target
    if enough_context and profitable and target_met and budget_limited and context.get("stockConfirmed") is True and context.get("priceCompetitive") is True:
        status = "Possível oportunidade de escala"
        actions.append("Avaliar teste gradual de orçamento após confirmar os custos por SKU e capacidade operacional. Definir o incremento com o especialista e acompanhar ACOS, ROAS e estoque. O diagnóstico não garante ganho de vendas.")
    if not days or days < 7:
        observations.append("Período ausente ou inferior a 7 dias: a referência interna Pronix recomenda mais observação antes de uma conclusão estratégica. Riscos de custo ou falta de estoque podem exigir correção imediata.")
    if not actions:
        actions.append("Revisar os indicadores por campanha e completar margem, estoque, competitividade e período. Definir metas com o cliente antes de alterar o investimento; primeira revisão sugerida em 7 dias.")
    return status, observations, actions


def analyze_spreadsheet(path, sheet=None, header_row=None, mapping=None, context=None):
    context = dict(context or {})
    sheet_data = _read_sheets(path)
    if not sheet_data:
        raise ValueError("Nenhuma aba encontrada na planilha.")
    if sheet is not None:
        chosen = next((pair for pair in sheet_data if pair[0] == sheet), None)
        if chosen is None:
            raise ValueError("A aba selecionada não existe no arquivo.")
    else:
        chosen = max(sheet_data, key=lambda pair: len(_suggest(pair[1][_header(pair[1])])) if pair[1] else 0)
    sheet_name, raw_rows = chosen
    if not raw_rows:
        raise ValueError("A aba selecionada está vazia.")
    header_row = _header(raw_rows) if header_row is None else int(header_row)
    if header_row < 0 or header_row >= len(raw_rows):
        raise ValueError("Linha de cabeçalho inválida.")
    headers = list(raw_rows[header_row])
    mapping = _suggest(headers) if mapping is None else {key: int(value) for key, value in mapping.items() if value not in (None, "", -1, "-1")}
    if any(key not in LABELS for key in mapping):
        raise ValueError("O mapeamento contém uma métrica desconhecida.")
    if any(index < 0 or index >= len(headers) for index in mapping.values()):
        raise ValueError("O mapeamento aponta para uma coluna inexistente.")
    if len(set(mapping.values())) != len(mapping):
        raise ValueError("Uma mesma coluna não pode representar duas métricas. Revise o mapeamento.")
    if not any(key in mapping for key in BASE + COMPONENTS):
        raise ValueError("Nenhuma métrica reconhecida. Associe as colunas de investimento, receita, cliques, impressões ou vendas.")

    warnings, rows, totals = [], [], []
    counters = Counter()
    invalid_cells = []
    start, end = _date(context.get("periodStart")), _date(context.get("periodEnd"))
    if bool(start) != bool(end):
        warnings.append("Informe início e fim do período para avaliar sua duração.")
    if start and end and start > end:
        raise ValueError("A data inicial não pode ser posterior à data final.")
    for index, raw in enumerate(raw_rows[header_row + 1:], start=header_row + 2):
        if not any(value not in (None, "") for value in raw):
            counters["blank"] += 1
            continue
        if list(raw)[:len(headers)] == headers:
            counters["repeatedHeaders"] += 1
            continue
        cell = lambda key: raw[mapping[key]] if key in mapping and mapping[key] < len(raw) else None
        name = str(cell("campaign") or "Consolidado da aba").strip()
        row = {"sourceRow": index, "campaign": name, "date": _date(cell("date")),
               "dateFrom": _date(cell("dateFrom")), "dateTo": _date(cell("dateTo"))}
        if row["dateFrom"] and row["dateTo"] and row["dateFrom"] == row["dateTo"] and row["date"] is None:
            row["date"] = row["dateFrom"]
        for key in LABELS:
            if key in ("date", "dateFrom", "dateTo", "campaign"):
                continue
            source_value = cell(key)
            row[key] = parse_number(source_value)
            if row[key] is not None and row[key] < 0:
                row[key] = None
                invalid_cells.append(f"linha {index}, {LABELS[key]}: valor negativo")
            elif key in mapping and row[key] is None and normalize(source_value) not in MISSING:
                invalid_cells.append(f"linha {index}, {LABELS[key]}: valor não numérico")
        for key, direct, indirect in (("revenue", "directRevenue", "indirectRevenue"), ("orders", "directOrders", "indirectOrders")):
            if row[key] is None and key not in mapping and row[direct] is not None and row[indirect] is not None:
                row[key] = row[direct] + row[indirect]
            elif row[key] is not None and row[direct] is not None and row[indirect] is not None:
                if abs(row[key] - row[direct] - row[indirect]) > max(.02, row[key] * .001):
                    counters["componentMismatch"] += 1
        if not any(row[key] is not None for key in BASE + COMPONENTS):
            counters["unrecognizedRows"] += 1
            continue
        # Summary labels in descriptive cells, never in metric numeric columns.
        labels = [normalize(value) for idx, value in enumerate(raw[:5]) if idx not in [mapping[k] for k in mapping if k not in ("campaign", "date")]]
        summary = any(re.match(r"^(?:total(?: geral| de campanhas| das campanhas| da conta)?|totais|subtotal|resumo)(?:\s*[:\-].*|\s*\(.*\))?$", label) for label in labels)
        if summary:
            totals.append(row)
            continue
        if "date" in mapping or ("dateFrom" in mapping and "dateTo" in mapping):
            if row["dateFrom"] and row["dateTo"] and row["dateFrom"] != row["dateTo"]:
                if row["dateFrom"] > row["dateTo"]:
                    raise ValueError(f"Período invertido na linha {index}.")
                if start and end and (row["dateTo"] < start or row["dateFrom"] > end):
                    counters["excludedDates"] += 1
                    continue
                if start and end and not (start <= row["dateFrom"] <= row["dateTo"] <= end):
                    raise ValueError("O período selecionado corta linhas agrupadas da planilha. Exporte dados diários ou selecione o período integral; não é possível dividir os valores com segurança.")
                rows.append(row)
                continue
            if row["date"] is None:
                counters["invalidDates"] += 1
                if start and end:
                    counters["excludedDates"] += 1
                    continue
            elif start and end and not start <= row["date"] <= end:
                counters["excludedDates"] += 1
                continue
        rows.append(row)
    if not rows and len(totals) == 1 and not counters["excludedDates"]:
        rows = totals
        warnings.append("A aba contém apenas uma linha de total. Foi usada como consolidado; não há detalhamento por campanha.")
    elif not rows:
        raise ValueError("Nenhuma linha de dados utilizável após o mapeamento e filtro de período. Revise a aba e as colunas.")
    elif totals:
        warnings.append(f"{len(totals)} linha(s) de total/subtotal ignorada(s) para evitar contar os mesmos valores duas vezes.")
    if counters["componentMismatch"]:
        warnings.append("O total atribuído difere da soma direta + indireta em algumas linhas. Foram preservados os totais da fonte; confira a definição de atribuição.")
    if invalid_cells:
        warnings.append(f"{len(invalid_cells)} célula(s) inválida(s), tratada(s) como indisponível: " + "; ".join(invalid_cells[:8]) + ("; outras ocorrências na fonte." if len(invalid_cells) > 8 else "."))
    if counters["unrecognizedRows"]:
        warnings.append(f"{counters['unrecognizedRows']} linha(s) sem métricas numéricas reconhecidas foram ignoradas.")
    if counters["invalidDates"]:
        warnings.append(f"{counters['invalidDates']} linha(s) sem data diária válida." + (" Foram excluídas do período filtrado." if start and end else " O período deve ser confirmado manualmente."))
    if counters["excludedDates"]:
        warnings.append(f"{counters['excludedDates']} linha(s) excluída(s) por data ausente ou fora do período selecionado.")
    if len(sheet_data) > 1:
        warnings.append(f"Somente a aba '{sheet_name}' foi analisada. Outras abas não foram somadas, evitando duplicidade entre resumos e detalhes.")
    for key in BASE:
        missing = sum(row.get(key) is None for row in rows)
        if missing:
            warnings.append(f"{LABELS[key]}: indisponível em {missing} de {len(rows)} linha(s). O consolidado e os indicadores dependentes ficam indisponíveis, sem substituir lacunas por zero.")
    if "orders" in mapping and normalize(headers[mapping["orders"]]) == "vendas":
        warnings.append("Confirme que a coluna 'Vendas' representa quantidade de conversões atribuídas, e não receita, unidades ou vendas totais da conta.")
    if "dailyBudget" in mapping and normalize(headers[mapping["dailyBudget"]]) == "orcamento":
        warnings.append("Confirme que 'Orçamento' é diário. Esse valor não foi confundido com o investimento realizado nem somado entre dias.")
    if "revenue" in mapping and normalize(headers[mapping["revenue"]]) in ("receita", "receita total"):
        warnings.append("Confirme que a coluna de receita selecionada é atribuída ao Product Ads. Faturamento total da conta deve ser informado separadamente para TACOS.")
    missing_formula = "No XLSX, fórmulas sem resultado armazenado são indisponíveis; abra e salve a planilha no Excel se necessário."
    if Path(path).suffix.lower() == ".xlsx":
        warnings.append(missing_formula)
    dates = [row["date"] for row in rows if row["date"]]
    row_starts = [row["dateFrom"] or row["date"] for row in rows if row["dateFrom"] or row["date"]]
    row_ends = [row["dateTo"] or row["date"] for row in rows if row["dateTo"] or row["date"]]
    inferred_start, inferred_end = (min(row_starts), max(row_ends)) if row_starts and row_ends else (None, None)
    effective_start = start if start and end else inferred_start
    effective_end = end if start and end else inferred_end
    days = (effective_end - effective_start).days + 1 if effective_start and effective_end else None
    if days is None:
        warnings.append("Período não identificado. Não é possível afirmar duração, tendência ou maturidade da análise.")
    elif "date" not in mapping and not ("dateFrom" in mapping and "dateTo" in mapping):
        warnings.append("Período informado manualmente: confirme que o arquivo exportado corresponde exatamente a essas datas. O beta não consegue filtrar um relatório sem data diária.")
    if dates and days and len(set(dates)) < days:
        warnings.append("Há datas sem registro dentro do intervalo. Dias ausentes não foram tratados como zero; confirme a cobertura do relatório.")
    total_revenue = parse_number(context.get("totalRevenue"))
    margin = parse_number(context.get("marginPercent"))
    if total_revenue is not None and total_revenue < 0:
        raise ValueError("O faturamento total não pode ser negativo.")
    if margin is not None and not 0 <= margin <= 100:
        raise ValueError("A margem antes de Ads deve estar entre 0 e 100%.")
    metrics = _totals(rows, total_revenue)
    metrics["breakEvenAcos"] = margin
    metrics["breakEvenRoas"] = _ratio(100, margin)
    if total_revenue is None:
        warnings.append("TACOS não calculado: falta faturamento total da conta no mesmo período.")
    elif metrics["revenue"] is not None and total_revenue < metrics["revenue"]:
        warnings.append("Faturamento total informado é menor que a receita atribuída. Confira período e atribuição antes de interpretar TACOS.")
    if margin is None:
        warnings.append("Rentabilidade não confirmada: informe a margem antes de Ads após CMV, comissão, impostos, logística e demais custos.")
    if context.get("stockConfirmed") is not True:
        warnings.append("Estoque disponível não confirmado; não há recomendação automática de escala.")
    if "campaign" not in mapping:
        warnings.append("Sem coluna de campanha/anúncio: todos os dados foram agrupados em um único consolidado.")
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["campaign"]].append(row)
    campaigns = []
    for name, entries in grouped.items():
        campaign_metrics = _totals(entries)
        campaign_dates = [row["date"] for row in entries if row["date"]]
        campaign_days = len(set(campaign_dates)) if campaign_dates else days
        status, findings, actions = _classify(campaign_metrics, entries, context, campaign_days)
        campaigns.append({"name": name, "metrics": campaign_metrics, "status": status,
                          "findings": findings, "actions": actions,
                          "sourceRows": [row["sourceRow"] for row in entries],
                          "dailyBudget": _consistent(entries, "dailyBudget"),
                          "targetRoas": parse_number(context.get("targetRoas")) or _consistent(entries, "targetRoas")})
    campaigns.sort(key=lambda item: item["metrics"]["spend"] if item["metrics"]["spend"] is not None else -1, reverse=True)
    status, findings, actions = _classify(metrics, rows, context, days)
    period = f"{effective_start.strftime('%d/%m/%Y')} a {effective_end.strftime('%d/%m/%Y')} ({days} dias)" if days else "não informado"
    metric_text = [
        f"Investimento: {_money(metrics['spend'])}; receita atribuída: {_money(metrics['revenue'])}; vendas/conversões atribuídas: {_fmt(metrics['orders'], 0)}.",
        f"ROAS: {_unit(metrics['roas'], 'x')} (receita atribuída / investimento). ACOS: {_unit(metrics['acos'], '%')} (investimento / receita atribuída × 100).",
        f"CTR: {_unit(metrics['ctr'], '%')} (cliques / impressões × 100). CPC: {_money(metrics['cpc'])} (investimento / cliques). CVR: {_unit(metrics['cvr'], '%')} (conversões atribuídas / cliques × 100).",
        f"TACOS: {_unit(metrics['tacos'], '%')} (investimento / faturamento total da conta × 100). Faturamento total informado: {_money(total_revenue)}.",
        "Os percentuais são calculados a partir dos valores consolidados, sem tirar média simples dos percentuais das linhas. Denominador zero ou dado ausente torna o indicador indisponível.",
    ]
    positives = [finding for finding in findings if "acima ou igual" in finding]
    if metrics["orders"] and metrics["orders"] > 0:
        positives.insert(0, f"O relatório registra {_fmt(metrics['orders'], 0)} vendas/conversões atribuídas. A existência de conversões permite investigar quais campanhas contribuem para o resultado.")
    campaign_text = []
    for campaign in campaigns:
        cm = campaign["metrics"]
        campaign_text.append(f"{campaign['name']} — {campaign['status']}\nInvestimento: {_money(cm['spend'])} | Receita atribuída: {_money(cm['revenue'])} | ROAS: {_unit(cm['roas'], 'x')} | ACOS: {_unit(cm['acos'], '%')}\n" + "\n".join(campaign["findings"] + campaign["actions"]))
    sections = [
        {"id": "ads-overview", "title": "Panorama da conta e Ads", "body": f"Período: {period}. Fonte: {Path(path).name}, aba {sheet_name}. {len(rows)} linhas válidas e {len(campaigns)} grupo(s) analisado(s).\nClassificação: {status}.\n" + "\n".join(findings)},
        {"id": "ads-metrics", "title": "Indicadores e memória de cálculo", "body": "\n\n".join(metric_text)},
        {"id": "ads-positive", "title": "Pontos positivos", "body": "\n".join(positives) or "Não há evidência suficiente para destacar eficiência, lucro ou evolução positiva. Complete as métricas e a referência de comparação."},
        {"id": "ads-campaigns", "title": "Leitura por campanha / anúncio", "body": "\n\n".join(campaign_text)},
        {"id": "ads-actions", "title": "Direcionamento estratégico", "body": "\n\n".join(actions) + "\n\n7 dias: validar dados e corrigir problemas da oferta; acompanhar ACOS, ROAS e CVR.\n30 dias: revisar desempenho com custos por SKU e cobertura de estoque, antes de reestruturar campanhas.\n90 dias: avaliar expansão somente com evidência de margem, demanda e capacidade. Metas numéricas dependem da validação do especialista; não foram inventadas."},
        {"id": "ads-objective", "title": "Objetivo esperado", "body": "Melhorar a qualidade das decisões sobre investimento, conversão e rentabilidade. O acompanhamento deve comparar períodos equivalentes e considerar atualização da atribuição. Nenhum cenário de vendas ou ganho foi projetado sem premissas verificáveis."},
        {"id": "ads-limits", "title": "Lacunas e critérios da análise", "body": "\n".join("• " + warning for warning in warnings) + "\n\nMétodo: regras determinísticas derivadas da BASE DE CONHECIMENTO COMPLETA DE ADS DO GPT.txt (seções 6–11, 13–15, 21–25) e do prompt de direcionamento Pronix. A referência de 7 dias é interna, não regra oficial.\nUm relatório de Ads não confirma sozinho reputação, estoque, promoções, visitas orgânicas, custos por SKU ou tendências de 7/15/30/60/90 dias. Esses pilares permanecem pendentes quando suas fontes não foram importadas."},
    ]
    serial_rows = [{key: (value.isoformat() if isinstance(value, date) else value) for key, value in row.items()} for row in rows]
    return {"metrics": metrics, "campaigns": campaigns, "sections": sections, "warnings": warnings,
            "provenance": {"filename": Path(path).name, "sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest(),
                           "sheet": sheet_name, "headerRow": header_row, "mapping": mapping,
                           "campaignCount": len(campaigns), "allCampaignsAnalyzed": True,
                           "headers": [str(value or "") for value in headers], "rowsAnalyzed": len(rows),
                           "ignoredTotals": len(totals) if totals != rows else 0, "counters": dict(counters),
                           "periodStart": effective_start.isoformat() if effective_start else None,
                           "periodEnd": effective_end.isoformat() if effective_end else None,
                           "dataStart": inferred_start.isoformat() if inferred_start else None,
                           "dataEnd": inferred_end.isoformat() if inferred_end else None,
                           "completeCoverage": bool(days and len(set(dates)) == days and len(row_starts) == len(rows)),
                           "periodIsDaily": bool(dates and len(dates) == len(rows)),
                           "periodSource": "datas das linhas" if row_starts and row_ends else "informado pelo usuário" if start and end else "indisponível",
                           "context": context, "engineVersion": "1.0.0", "rulesSource": "BASE DE CONHECIMENTO COMPLETA DE ADS DO GPT.txt"},
            "rows": serial_rows}
