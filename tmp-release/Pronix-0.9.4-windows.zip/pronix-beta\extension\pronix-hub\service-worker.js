import {createBridge, ALARM} from "./bridge.js";
import {capturePage, readClientName} from "./capture.js";

const bridge = createBridge({chrome, capturePage, readClientName});
const initialize = () => bridge.init().catch(() => {});

// Ao instalar ou atualizar, apresenta a extensão às abas do programa já abertas: a conexão começa sem recarregar a página.
const announce = async () => {
  try {
    const tabs = await chrome.tabs.query({url: ["http://localhost:8765/*", "http://127.0.0.1:8765/*"]});
    for (const tab of tabs) { try { await chrome.scripting.executeScript({target: {tabId: tab.id}, files: ["pronix-app.js"]}); } catch { /* aba indisponível */ } }
  } catch { /* sem abas do programa */ }
};
chrome.runtime.onInstalled.addListener(() => { void initialize(); void announce(); });
chrome.runtime.onStartup.addListener(initialize);
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === ALARM) void bridge.init().then(() => bridge.connect()).catch(() => {});
});
// Listeners at top level so the login return wakes the service worker.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url) void bridge.init().then(() => bridge.oauthTabUpdated(tabId, changeInfo.url)).catch(() => {});
});
chrome.tabs.onRemoved.addListener(tabId => { void bridge.oauthTabRemoved(tabId).catch(() => {}); });
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  // Only our popup can pair, inspect status or disconnect. No page/external
  // extension messages and no arbitrary script/URL requests are accepted.
  // Pronix app page (localhost:8765): one-click pairing.
  if (sender.id === chrome.runtime.id && sender.tab && typeof sender.url === "string" && /^http:\/\/(localhost|127\.0\.0\.1):8765\//.test(sender.url)) {
    if (message?.type === "app_status") {
      bridge.init().then(() => { const status = bridge.status(); respond({ok: true, data: {paired: !!status.paired, connected: !!status.connected}}); }, () => respond({ok: false}));
      return true;
    }
    if (message?.type !== "app_pair") return false;
    (async () => {
      await bridge.init();
      if (bridge.status().paired) await bridge.disconnect();
      return bridge.pair(String(message.code || ""));
    })().then(data => respond({ok: true, data}), error => respond({ok: false, error: String(error?.message || "Não foi possível parear.")}));
    return true;
  }
  // Buttons injected in the Pronix Hub page: only import and suggestions, only for Hub sheets.
  if (sender.id === chrome.runtime.id && sender.tab && typeof sender.url === "string" && sender.url.startsWith("https://pronixhub.com.br/validacao-planilhas")) {
    const url = typeof message?.url === "string" ? message.url.split(/[?#]/)[0] : "";
    const runHub = async () => {
      await bridge.init();
      if (message?.type === "hub_import") return bridge.importSheet(url, url === sender.tab.url.split(/[?#]/)[0] ? sender.tab.id : null,
        stage => { chrome.tabs.sendMessage(sender.tab.id, {type: "pronix_import_stage", url, stage}).catch(() => {}); });
      if (message?.type === "hub_suggestions") return bridge.extRequest("suggestions", {url}, 20000);
      // Lista de planilhas: quais já têm análise na Central (somente consulta).
      if (message?.type === "hub_sheets") {
        const urls = (Array.isArray(message.urls) ? message.urls : []).filter(item => typeof item === "string").map(item => item.split(/[?#]/)[0]).slice(0, 60);
        return bridge.extRequest("sheets", {urls}, 20000);
      }
      if (message?.type === "hub_status") return bridge.status();
      throw new Error("Ação não permitida.");
    };
    runHub().then(data => respond({ok: true, data}), error => respond({ok: false, error: String(error?.message || "Não foi possível concluir.")}));
    return true;
  }
  if (sender.id !== chrome.runtime.id || sender.tab || sender.url !== chrome.runtime.getURL("popup.html")) return false;
  const run = async () => {
    await bridge.init();
    if (message?.type === "status") return bridge.status();
    if (message?.type === "pair") return bridge.pair(message.code);
    if (message?.type === "disconnect") return bridge.disconnect();
    if (message?.type === "reconnect") { await bridge.connect(); return bridge.status(); }
    throw new Error("Ação não permitida.");
  };
  run().then(data => respond({ok: true, data}), error => respond({ok: false, error: String(error?.message || "Não foi possível concluir.")}));
  return true;
});
void initialize();
