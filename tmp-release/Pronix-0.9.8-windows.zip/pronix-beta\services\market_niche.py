"""Amostra do nicho: os anúncios do mesmo tipo de produto, para medir procura e preço.

A auditoria de 14/11/2026 (planilhas já validadas) mostrou que comparar só com anúncios quase
idênticos (título inteiro, marca e categoria iguais) deixava quase metade dos produtos sem nenhuma
comparação. O nicho é mais largo: os produtos do mesmo tipo, de qualquer marca, ordenados pelo
faturamento estimado do último mês fechado. As medidas são as que os especialistas usam no
parecer: quanto faturam os maiores anúncios, a média dos três menores preços e o preço médio.

Tudo aqui é cálculo local sobre as linhas que a busca da JoomPulse devolve; nenhuma consulta é feita.
"""
from __future__ import annotations

import re
import statistics
import unicodedata
from urllib.parse import unquote, urlsplit

ROWS = 50            # linhas pedidas por busca
MIN_ROWS = 8         # com menos que isso a busca é alargada
TOP = 10             # anúncios de maior faturamento que formam a procura do nicho
KEEP = 15            # linhas guardadas no relatório
MIN_SHARE = 0.5      # parte das palavras do produto que o anúncio precisa ter no título
PRICE_BAND = (0.4, 2.5)   # faixa de preço em volta do anúncio de referência (mesmo porte de produto)

_IGNORED = {"de", "da", "do", "das", "dos", "para", "pra", "com", "sem", "em", "e", "a", "o", "as", "os", "um", "uma",
            "no", "na", "nos", "nas", "por", "ao", "c", "p", "ou", "que"}
_UNITS = {"v", "volts", "w", "watts", "ah", "mah", "kg", "g", "cm", "mm", "m", "ml", "l", "litro", "litros", "hz",
          "pas", "pa", "un", "und", "unid", "unidade", "unidades", "peca", "pecas", "pcs", "pc", "pol", "polegadas"}
_MARKETING = {"viral", "tiktok", "premium", "original", "originais", "novo", "nova", "promocao", "oferta", "envio",
              "imediato", "pronta", "entrega", "nf", "nota", "fiscal", "top", "melhor", "barato", "lancamento",
              "exclusivo", "exclusiva", "raro", "rara", "luxo", "full", "frete", "gratis", "brinde", "garantia",
              "qualidade", "alta", "super", "mega", "ultra", "profissional", "moderno", "moderna", "detalhe",
              "modelo", "model", "sku", "codigo", "cod", "ref", "cores", "cor", "tamanho", "varias", "varios"}
_COLOURS = {"preto", "preta", "branco", "branca", "vermelho", "vermelha", "azul", "verde", "amarelo", "amarela",
            "rosa", "cinza", "bege", "dourado", "dourada", "prata", "prateado", "marrom", "roxo", "roxa", "lilas",
            "laranja", "transparente", "colorido", "colorida", "grafite", "cromado", "cromada"}
_KIT = {"kit", "kits", "conjunto", "jogo", "combo"}
_MEASURE = re.compile(r"\b(\d+(?:[.,]\d+)?)\s*(cm|mm|ml|kg|mah|ah|hz|volts|v|w|litros?|l|pas|pa|unidades?|un|pecas?|pcs)\b")
_MEASURE_ALIASES = {"litro": "l", "litros": "l", "volts": "v", "pa": "pas", "unidade": "un", "unidades": "un",
                    "peca": "un", "pecas": "un", "pcs": "un"}
# Quantidade de peças escrita junto do kit: "Kit 12", "Kit c/ 5", "Kit com 3", "19 pçs", "10pc".
_KIT_COUNT = re.compile(r"\b(?:kit|conjunto|jogo)\s*(?:c/|c|com|de)?\s*(\d{1,3})\b|\b(\d{1,3})\s*(?:pcs|pc|pecas|peca|itens)\b")


def key(value):
    """Minúsculas, sem acento."""
    return "".join(ch for ch in unicodedata.normalize("NFKD", str(value or "").casefold()) if not unicodedata.combining(ch))


def _stem(word):
    word = key(word)
    return word[:-1] if len(word) > 3 and word.endswith("s") else word


def _tokens(text):
    return re.findall(r"[^\W_]+", key(text), flags=re.UNICODE)


def core_words(title, brand=None, limit=6):
    """Palavras que dizem que tipo de produto é, na ordem do título.

    Saem marca, medidas, cores, palavras de propaganda e de ligação: elas estreitam a busca até
    sobrar só o próprio anúncio. Medidas voltam depois como filtro (ver conflicts).
    """
    brand_words = {_stem(word) for word in _tokens(brand)}
    words, seen = [], set()
    raw = re.findall(r"[^\W_]+", str(title or ""), flags=re.UNICODE)
    for index, word in enumerate(raw):
        low = key(word)
        stem = _stem(word)
        after_number = index > 0 and any(ch.isdigit() for ch in raw[index - 1])
        if (len(low) < 2 or any(ch.isdigit() for ch in low) or low in _IGNORED or low in _MARKETING or low in _COLOURS
                or stem in brand_words or (low in _UNITS and after_number) or stem in seen):
            continue
        seen.add(stem)
        words.append(word)
        if len(words) >= limit:
            break
    return words


def queries(title, brand=None):
    """Da busca mais estreita à mais larga: três palavras do tipo de produto, depois duas."""
    words = core_words(title, brand)
    result = []
    for size in (3, 2):
        text = " ".join(words[:size])
        if text and text not in result:
            result.append(text)
    return result


def title_from_link(reference):
    """Nome do produto escrito no próprio link (página de busca ou de anúncio), sem consultar nada."""
    try:
        parsed = urlsplit(str(reference or "").strip())
    except ValueError:
        return ""
    host = (parsed.hostname or "").lower()
    if "mercadoli" not in host:
        return ""
    for segment in unquote(parsed.path).split("/"):
        text = re.sub(r"_[A-Za-z].*$", "", segment)                 # filtros da busca e sufixo _JM
        text = re.sub(r"^MLBU?-?\d+-?", "", text, flags=re.I)      # produto.mercadolivre.com.br/MLB-123-titulo-_JM
        if text.lower() in ("", "p", "up", "jm") or re.fullmatch(r"MLBU?-?\d+", text, re.I):
            continue
        words = [word for word in text.split("-") if word]
        if len(words) >= 2:
            return " ".join(words)
    return ""


def _measures(title):
    result = {}
    text = key(title)
    for number, unit in _MEASURE.findall(text):
        result.setdefault(_MEASURE_ALIASES.get(unit, unit), set()).add(float(number.replace(",", ".")))
    for first, second in _KIT_COUNT.findall(text):
        result.setdefault("un", set()).add(float(first or second))
    return result


def conflicts(reference_title, candidate_title):
    """Medida declarada diferente (35 l × 45 l, 110 v × 220 v) ou kit × unidade. Medida ausente não é conflito."""
    reference, candidate = _measures(reference_title), _measures(candidate_title)
    found = [unit for unit, expected in reference.items() if unit in candidate and expected.isdisjoint(candidate[unit])]
    ref_kit = bool(_KIT & set(_tokens(reference_title)))
    cand_kit = bool(_KIT & set(_tokens(candidate_title)))
    if ref_kit != cand_kit:
        found.append("kit")
    return found


def share(reference_words, candidate_title):
    """Parte das palavras do produto que aparece no título do anúncio (0 a 1)."""
    wanted = [_stem(word) for word in reference_words]
    if not wanted:
        return 0.0
    have = {_stem(word) for word in _tokens(candidate_title)}
    return sum(1 for word in wanted if word in have) / len(wanted)


def _num(value):
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) and value == value and abs(value) != float("inf") else None


def _row(row):
    """Linha da busca (produto de catálogo ou anúncio) reduzida ao que o nicho usa."""
    item = row.get("itemId") or row.get("buyBoxItemId")
    price = _num(row.get("price")) if row.get("itemId") else None
    if price is None:
        price = _num(row.get("buyBoxPrice")) or _num(row.get("price")) or _num(row.get("priceMin"))
    revenue = _num(row.get("revenueLastMonth"))
    units = _num(row.get("salesLastMonth"))
    basis = "last_month"
    if revenue is None and units is None:
        revenue, units, basis = _num(row.get("revenue1m")), _num(row.get("sales1m")), "historical_average"
    return {"itemId": str(item) if item else None, "productId": row.get("productId"), "title": row.get("title"),
            "price": price, "revenue": revenue, "units": units, "basis": basis, "isFull": row.get("isFull"),
            "brand": row.get("brand"), "categoryId": row.get("categoryLeafId") or row.get("categoryId"),
            "sellerName": row.get("sellerName") or row.get("buyBoxSellerName")}


def select(reference_titles, rows, brand=None, anchor_price=None):
    """Linhas do nicho: mesmo tipo de produto, sem medida ou kit conflitante.

    reference_titles: título do anúncio de referência e, se houver, o nome na planilha.
    anchor_price: preço do anúncio de referência; anúncios muito mais baratos ou caros são outro
    porte de produto (bateria de R$ 170 × bateria de R$ 3.000) e saem junto com os de medida diferente.
    Sem anúncio de referência, a âncora é o preço mediano das próprias linhas (nunca o preço do cliente,
    para não esconder um preço fora do mercado).
    Devolve (linhas aceitas com 'share', quantas saíram por pouca semelhança, quantas por medida/kit/porte).
    """
    titles = [title for title in reference_titles if title]
    words = core_words(titles[0], brand) if titles else []
    kept, weak, variant, seen = [], 0, 0, set()
    if not (anchor_price and anchor_price > 0):
        prices = [price for price in (_row(row)["price"] for row in rows) if price and price > 0]
        anchor_price = statistics.median(prices) if len(prices) >= 5 else None
    for position, original in enumerate(rows):
        row = _row(original)
        row["position"] = position                 # lugar na lista recebida, para achar a linha original
        identity = row["productId"] or row["itemId"]
        if not identity or identity in seen or not row["price"] or row["price"] <= 0:
            continue
        seen.add(identity)
        off_band = bool(anchor_price and anchor_price > 0 and not PRICE_BAND[0] <= row["price"] / anchor_price <= PRICE_BAND[1])
        if off_band or any(conflicts(title, row["title"]) for title in titles):
            variant += 1
            continue
        row["share"] = round(share(words, row["title"]), 3)
        if words and row["share"] < MIN_SHARE:
            weak += 1
            continue
        kept.append(row)
    return kept, weak, variant


def enough(kept, returned, limit):
    """A amostra basta? Sim com MIN_ROWS linhas; ou com 3 quando a busca já voltou cheia.

    Busca cheia com poucas linhas aceitas quer dizer que o filtro (medida, kit, porte) é que apertou:
    alargar as palavras traria produtos menos parecidos, não mais anúncios do mesmo produto.
    """
    return len(kept) >= MIN_ROWS or (returned >= limit and len(kept) >= 3)


def summarize(rows, period=None):
    """Medidas do nicho a partir das linhas aceitas. None quando não há linhas."""
    if not rows:
        return None
    earning = sorted((row for row in rows if (row.get("revenue") or 0) > 0), key=lambda row: -row["revenue"])
    top = earning[:TOP]
    priced = earning or rows                      # preço: de quem vende; sem vendas, de todos
    prices = sorted(row["price"] for row in priced)
    low = prices[:3]
    known_revenue = any(row.get("revenue") is not None for row in rows)
    return {"sampleSize": len(rows), "withRevenue": len(earning), "topCount": len(top),
            "revenueTop": round(sum(row["revenue"] for row in top), 2) if known_revenue else None,
            "unitsTop": round(sum(row.get("units") or 0 for row in top), 1) if known_revenue else None,
            # Vendas por mês do anúncio típico do nicho (mediana de quem vende): base da quantidade inicial.
            "unitsTypical": round(statistics.median(units), 1) if (units := [row["units"] for row in rows if (row.get("units") or 0) > 0]) else None,
            "priceLow3": round(statistics.fmean(low), 2), "priceAverage": round(statistics.fmean(prices), 2),
            "priceMin": prices[0], "priceMax": prices[-1], "pricedCount": len(prices),
            "fullCount": sum(1 for row in rows if row.get("isFull") is True),
            "basis": next((row["basis"] for row in top), rows[0].get("basis")), "period": period,
            "rows": [{key_: row.get(key_) for key_ in ("itemId", "title", "price", "revenue", "units", "isFull", "sellerName", "share")}
                     for row in (top + [row for row in rows if row not in top])[:KEEP]]}


def period_label(notes):
    """'LastMonth is Oct 2026 …' → 'Oct 2026' (texto da própria fonte)."""
    for note in notes or []:
        match = re.search(r"LastMonth is ([A-Za-zçÇ]{3,9} \d{4})", str(note))
        if match:
            return match.group(1)
    return None


def main_category(rows):
    """Categoria mais comum entre as linhas (para comissão quando o anúncio de referência não foi localizado)."""
    counts = {}
    for row in rows:
        category = row.get("categoryId")
        if category:
            counts[category] = counts.get(category, 0) + 1
    return max(counts, key=counts.get) if counts else None
