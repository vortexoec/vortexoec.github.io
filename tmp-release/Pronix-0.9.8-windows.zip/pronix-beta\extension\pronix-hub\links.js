// Conferência dos links de anúncio de referência antes de enviar a planilha à Central.
// Mesmas regras do programa (services/market_data.py, reference_spec): o link precisa ser do
// Mercado Livre e apontar um único anúncio ou catálogo. Nada aqui consulta a internet.
export const ML_HOSTS = ["mercadolivre.com.br", "mercadolivre.com", "mercadolibre.com.br", "mercadolibre.com"];
const ID = /\bMLBU?[- ]?\d{5,16}\b/gi;
const ITEM = /^MLB[- ]?\d{5,16}$/i;
const normal = value => value.replace(/[- ]/g, "").toUpperCase();
const CONFLICT = "O link tem códigos de anúncios diferentes. Abra o anúncio certo e copie o link de novo.";

/** Texto do problema do link, ou "" quando o link serve para a análise. */
export function referenceProblem(href) {
  const value = String(href || "").trim();
  if (!value) return "O produto está sem o link do anúncio de referência.";
  let url;
  try { url = new URL(/^www\./i.test(value) ? "https://" + value : value); } catch { return "O link não é um endereço válido."; }
  const host = url.hostname.toLowerCase();
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password ||
      !ML_HOSTS.some(name => host === name || host.endsWith("." + name))) {
    return "O link não é de um anúncio do Mercado Livre.";
  }
  const selected = new Set();
  for (const part of [url.search.replace(/^\?/, ""), url.hash.replace(/^#\??/, "")]) {
    for (const [key, raw] of new URLSearchParams(part)) {
      const name = key.toLowerCase();
      let values = [];
      if (name === "pdp_filters") {
        values = raw.split("|").map(entry => entry.split(":")).filter(([field]) => ["item_id", "itemid"].includes(field.trim().toLowerCase())).map(([, code = ""]) => code.trim());
      } else if (["wid", "item_id", "itemid"].includes(name)) values = [raw.trim()];
      for (const code of values) {
        if (!ITEM.test(code)) return "O link tem um código de anúncio inválido.";
        selected.add(normal(code));
      }
    }
  }
  if (selected.size > 1) return CONFLICT;
  let path = url.pathname;
  try { path = decodeURIComponent(path); } catch { /* mantém o caminho como veio */ }
  const pathIds = new Set([...path.matchAll(ID)].map(match => normal(match[0])));
  const grouping = path.match(/\/up\/(MLBU[- ]?\d{5,16})(?=\/|$)/i);
  const catalog = path.match(/\/p\/(MLBU?[- ]?\d{5,16})(?=\/|$)/i);
  if (grouping || catalog) {
    if (pathIds.size !== 1) return CONFLICT;
    if (grouping && !selected.size) return "O link abre um grupo de anúncios (/up/), sem escolher um. Abra o anúncio e copie o link de novo.";
    return "";
  }
  if (pathIds.size > 1 || (selected.size && pathIds.size && [...selected][0] !== [...pathIds][0])) return CONFLICT;
  if (selected.size || pathIds.size) return "";
  if (host.startsWith("lista.")) return "O link é uma página de busca, não um anúncio. Abra o anúncio e copie o link.";
  return "O link não tem o código do anúncio (MLB…). Abra o anúncio e copie o link completo.";
}

const unescape = value => String(value).replace(/&(amp|lt|gt|quot|#39);/g, (_, name) => ({amp: "&", lt: "<", gt: ">", quot: '"', "#39": "'"}[name]));
const escape = value => String(value).replace(/[&<>"']/g, character => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[character]));
const ANCHOR = /<a href="([^"]*)"(?: data-pronix-hub-href="[^"]*")?>Abrir anúncio de referência<\/a>/g;
const strip = value => unescape(String(value).replace(/<[^>]*>/g, "")).replace(/\s+/g, " ").trim();

// A captura (capture.js) monta cada produto como <article class="pm-panel"> com rótulo, nome, links e campos.
function cards(html) {
  const parts = html.split('<article class="pm-panel">');
  return parts.slice(1).map((body, index) => {
    const head = body.split("<dl>")[0];
    return {position: index + 1, label: strip(head.match(/<span class="pm-label">([\s\S]*?)<\/span>/)?.[1] || `Produto ${index + 1}`),
            name: strip(head.match(/<h3>([\s\S]*?)<\/h3>/)?.[1] || ""),
            links: [...new Set([...head.matchAll(ANCHOR)].map(match => unescape(match[1])))]};
  });
}

/** Produtos cujo link de referência parece errado: [{position, label, name, link, problem}]. */
export function reviewLinks(html) {
  const found = [];
  for (const card of cards(String(html || ""))) {
    const problem = card.links.length > 1 ? "O produto tem mais de um link de referência. Deixe só o do anúncio certo." : referenceProblem(card.links[0]);
    if (problem) found.push({position: card.position, label: card.label, name: card.name.slice(0, 160), link: (card.links[0] || "").slice(0, 2048), problem});
  }
  return found.slice(0, 100);
}

/** Troca o link dos produtos corrigidos (por posição na planilha) e guarda o link original do Hub. */
export function applyCorrections(html, corrections) {
  const fixes = new Map(Object.entries(corrections || {}).map(([position, link]) => [Number(position), String(link || "").trim()])
    .filter(([position, link]) => Number.isInteger(position) && position > 0 && link && link.length <= 2048));
  if (!fixes.size) return html;
  const parts = String(html).split('<article class="pm-panel">');
  for (let position = 1; position < parts.length; position++) {
    const link = fixes.get(position);
    if (!link) continue;
    const cut = parts[position].indexOf("<dl>");
    const head = cut >= 0 ? parts[position].slice(0, cut) : parts[position];
    const original = unescape([...head.matchAll(ANCHOR)][0]?.[1] || "");
    const anchor = `<a href="${escape(link)}" data-pronix-hub-href="${escape(original)}">Abrir anúncio de referência</a>`;
    let next = head.replace(ANCHOR, "");
    next = next.includes("</h3>") ? next.replace("</h3>", "</h3>" + anchor) : next + anchor;
    parts[position] = next + (cut >= 0 ? parts[position].slice(cut) : "");
  }
  return parts.join('<article class="pm-panel">');
}
