"""Read saved Pronix Hub product cards as local data, without loading the page.

Commercial fields and previous Hub assessments remain separate. Imported
assessments are comparison material, never newly verified market evidence.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from html.parser import HTMLParser
import json
import math
from pathlib import Path
import re
import unicodedata
from urllib.parse import urlsplit

from .market_data import reference_spec


MAX_HTML_BYTES = 20 * 1024 * 1024
MAX_NODES = 150_000
MAX_DEPTH = 150
MAX_PRODUCTS = 500
PRODUCT_FIELDS = ("Custo de compra", "Preço de venda", "Margem informada",
                  "Mínimo de compra", "Preço médio do produto", "Embalagem")
META_FIELDS = ("Logística", "Cidade / Estado", "Imposto")
REVIEW_VERDICTS = {"validado": "validado", "atencao": "atencao", "invalidado": "invalidado", "nao avaliado": "nao_avaliado"}
_IGNORED = {"head", "script", "style", "template", "noscript", "form", "button",
            "textarea", "input", "select", "svg", "iframe", "object", "embed", "canvas"}
_VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link",
         "meta", "param", "source", "track", "wbr"}


def _clean(value) -> str:
    value = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", str("" if value is None else value))
    return " ".join(value.split())


def _key(value) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", _clean(value).lower())
                   if not unicodedata.combining(c)).rstrip(": ")


def _value(value):
    value = _clean(value)
    return None if value in ("", "—", "–", "-") else value


def _review_text(value):
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", str(value or ""))
    return "\n".join(" ".join(line.split()) for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n")).strip()


def _number(value, *, percent=False):
    """Parse the page's Brazilian numeric display; never infer missing as zero."""
    if value is None:
        return None
    value = _clean(value).replace(" ", "")
    if percent:
        value = value.removesuffix("%")
    else:
        value = re.sub(r"^R\$", "", value, flags=re.I)
    if len(value) > 128:
        return None
    if re.fullmatch(r"[+-]?(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d+)?", value):
        value = value.replace(".", "").replace(",", ".")
    elif not re.fullmatch(r"[+-]?\d+\.\d{1,2}", value):
        return None
    try:
        number = float(Decimal(value))
    except (InvalidOperation, OverflowError, ValueError):
        return None
    return number if math.isfinite(number) else None


@dataclass
class _Node:
    tag: str
    attrs: dict = field(default_factory=dict)
    children: list = field(default_factory=list)
    ignored: bool = False
    control: bool = False

    def walk(self, include_controls=False):
        stack = list(reversed(self.children))
        while stack:
            child = stack.pop()
            if isinstance(child, _Node):
                if child.control and not include_controls:
                    continue
                yield child
                stack.extend(reversed(child.children))

    def text(self):
        pieces, stack = [], list(reversed(self.children))
        while stack:
            child = stack.pop()
            if isinstance(child, str):
                pieces.append(child)
            else:
                if child.control:
                    continue
                stack.extend(reversed(child.children))
        return _clean(" ".join(pieces))

    def raw_text(self):
        pieces, stack = [], list(reversed(self.children))
        while stack:
            child = stack.pop()
            if isinstance(child, str):
                pieces.append(child)
            elif not child.control:
                stack.extend(reversed(child.children))
        return "".join(pieces)


class _Parser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = _Node("document")
        self.stack = [self.root]
        self.count = 0

    def handle_starttag(self, tag, attrs):
        self.count += 1
        if self.count > MAX_NODES or len(self.stack) > MAX_DEPTH:
            raise ValueError("HTML muito complexo. Salve apenas a página da tabela de produtos.")
        attrs = dict(attrs)
        style = re.sub(r"\s+", "", (attrs.get("style") or "").lower())
        ignored = (self.stack[-1].ignored or (tag in _IGNORED and tag not in ("button", "textarea")) or "hidden" in attrs
                   or (attrs.get("aria-hidden") or "").lower() == "true"
                   or re.search(r"(?:^|;)display:none(?:!important)?(?:;|$)", style)
                   or re.search(r"(?:^|;)visibility:hidden(?:!important)?(?:;|$)", style))
        node = _Node(tag, attrs, ignored=bool(ignored), control=tag in ("button", "textarea") or self.stack[-1].control)
        if not node.ignored:
            self.stack[-1].children.append(node)
        if tag not in _VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in _VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == tag:
                del self.stack[index:]
                return

    def handle_data(self, data):
        if not self.stack[-1].ignored:
            self.stack[-1].children.append(data)


def _read_html(path):
    path = Path(path)
    with path.open("rb") as source:
        raw = source.read(MAX_HTML_BYTES + 1)
    if len(raw) > MAX_HTML_BYTES:
        raise ValueError("O HTML excede o limite de 20 MB. Salve apenas a página da tabela de produtos.")
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16"), []
    try:
        return raw.decode("utf-8-sig"), []
    except UnicodeDecodeError:
        # Chrome's saved pages may retain their declared Windows encoding.
        if re.search(br"charset\s*=\s*[\"']?(?:windows-1252|iso-8859-1)", raw[:4096], re.I):
            return raw.decode("cp1252"), []
        raise ValueError("Não foi possível ler a codificação do HTML. Salve a página em UTF-8.")


def _fields(dl):
    allowed = {_key(label): label for label in PRODUCT_FIELDS}
    values, duplicates, pending = {}, [], None
    for node in dl.walk():
        if node.tag == "dt":
            pending = allowed.get(_key(node.text()))
        elif node.tag == "dd":
            if pending:
                if pending in values:
                    duplicates.append(pending)
                else:
                    values[pending] = _value(node.text())
            pending = None
    return values, duplicates


def _metadata(root):
    allowed = {_key(label): label for label in META_FIELDS}
    candidates = []
    for header in (node for node in root.walk() if node.tag == "header"):
        headings = [node for node in header.walk() if node.tag == "h1"]
        if not headings:
            continue
        values = {}
        for node in header.walk():
            children = [child for child in node.children if isinstance(child, _Node)]
            if len(children) != 2:
                continue
            label = allowed.get(_key(children[0].text()))
            if label:
                values.setdefault(label, _value(children[1].text()))
        candidates.append((headings[0].text(), values))
    if candidates:
        client, fields = max(candidates, key=lambda value: len(value[1]))
    else:
        heading = next((node for node in root.walk() if node.tag == "h1"), None)
        client, fields = (heading.text() if heading else ""), {}
    return client, {"logistics": fields.get("Logística"), "cityState": fields.get("Cidade / Estado"),
                    "taxPercent": _number(fields.get("Imposto"), percent=True), "fields": fields}


def _safe_url(value):
    value = _clean(value)
    try:
        parsed = urlsplit(value)
        if (parsed.scheme.lower() in ("http", "https") and parsed.hostname
                and not parsed.username and not parsed.password):
            return value
    except ValueError:
        pass
    return ""


def normalize_hub_review(value):
    """Bound imported opinions while keeping them outside current calculations."""
    if not isinstance(value, dict):
        return None
    def bounded(text, maximum):
        return _clean(text)[:maximum] if isinstance(text, str) else None
    result = {"version": 1, "comparisonOnly": True, "robot": None, "specialist": None}
    for kind in ("robot", "specialist"):
        supplied = value.get(kind)
        if not isinstance(supplied, dict):
            continue
        verdict = supplied.get("verdict")
        result[kind] = {"verdict": verdict if isinstance(verdict, str) and verdict in set(REVIEW_VERDICTS.values()) else None,
                        "verdictLabel": bounded(supplied.get("verdictLabel"), 80),
                        "text": _review_text(supplied.get("text"))[:16000],
                        "assessedAtText": bounded(supplied.get("assessedAtText"), 100)}
        if kind == "robot":
            metrics = []
            for metric in supplied.get("metrics", [])[:20] if isinstance(supplied.get("metrics"), list) else []:
                if not isinstance(metric, dict):
                    continue
                number = metric.get("value")
                try:
                    number = number if isinstance(number, (int, float)) and not isinstance(number, bool) and math.isfinite(number) else None
                except OverflowError:
                    number = None
                metrics.append({"label": bounded(metric.get("label"), 120), "text": bounded(metric.get("text"), 8000),
                                "value": number, "unit": metric.get("unit") if metric.get("unit") in ("percent", "BRL", "units", "days") else None})
            result[kind]["metrics"] = metrics
            result[kind]["costBreakdown"] = _robot_cost_breakdown(metrics, result[kind]["assessedAtText"])
        else:
            result[kind]["reviewerName"] = bounded(supplied.get("reviewerName"), 180)
    if not result["robot"] and not result["specialist"]:
        return None
    supplied = value.get("provenance") if isinstance(value.get("provenance"), dict) else {}
    result["provenance"] = {"source": "Pronix Hub", "method": supplied.get("method") if supplied.get("method") in ("rendered_dom", "saved_html") else "saved_html",
                            "url": _safe_url(supplied.get("url")) or None,
                            "capturedAt": bounded(supplied.get("capturedAt"), 80)}
    result["warnings"] = [bounded(warning, 500) for warning in value.get("warnings", [])[:10] if isinstance(warning, str)] if isinstance(value.get("warnings"), list) else []
    return result


def _robot_cost_breakdown(metrics, assessed_at):
    """Read only explicitly named values in the robot's margin line.

    The source quote is historical and incomplete until reviewed. These fields
    are never installed in fee inputs or treated as confirmed charges.
    """
    lines = [metric.get("text") for metric in metrics if _key(metric.get("label")) == "margem" and metric.get("text")]
    if len(lines) != 1:
        return None
    text = lines[0]
    amount = r"([+-]?[\d.]+(?:,\d+)?)"
    patterns = {"quotedPrice": rf"\ba\s+R\$\s*{amount}", "cost": rf"\bcusto\s+R\$\s*{amount}",
                "profitPerUnit": rf"^R\$\s*{amount}\s+por unidade", "marginPercent": rf"por unidade\s*\({amount}\s*%\)",
                "commissionAmount": rf"\bcomiss[aã]o\s+R\$\s*{amount}",
                "commissionPercent": rf"\bcomiss[aã]o\s+R\$\s*[\d.,]+\s*\((?:Cl[aá]ssico|Premium)\s+{amount}\s*%\)",
                "taxAmount": rf"\bimposto\s+R\$\s*{amount}", "taxPercent": rf"\bimposto\s+R\$\s*[\d.,]+\s*\({amount}\s*%\)",
                "shipping": rf"\bfrete\s+R\$\s*{amount}"}
    values = {}
    for field, pattern in patterns.items():
        found = re.findall(pattern, text, flags=re.I)
        values[field] = _number(found[0]) if len(found) == 1 else None
    values.update(fixedFee=None, otherCosts=None, source="Pronix Hub — robô", sourceText=text,
                  assessedAtText=assessed_at, requiresConfirmation=True, confirmed=False,
                  allApplicableCostsConfirmed=False)
    values["missing"] = [field for field in ("quotedPrice", "cost", "commissionPercent", "fixedFee", "taxPercent", "shipping", "otherCosts") if values[field] is None]
    return values


def _review_scope(article, kind):
    nodes = list(article.walk(include_controls=True))
    canonical = [node for node in nodes if node.attrs.get("data-pronix-review") == kind]
    if len(canonical) == 1:
        return canonical[0]
    if len(canonical) > 1:
        return None
    marker = "leitura da automacao" if kind == "robot" else "seu parecer"
    labels = [node for node in nodes if node.tag in ("span", "h4", "h5") and _key(node.text()) == marker]
    if len(labels) != 1:
        return None
    parents = {id(child): parent for parent in [article, *nodes] for child in parent.children if isinstance(child, _Node)}
    parent = parents.get(id(labels[0]))
    while parent and parent is not article:
        children = list(parent.walk(include_controls=True))
        if kind == "robot" and any(node.tag == "dl" for node in children):
            return parent
        if kind == "specialist" and any(node.tag == "textarea" for node in children):
            return parent
        if kind == "specialist" and any(node.tag == "p" for node in children) and any(_key(node.text()) in REVIEW_VERDICTS for node in children if node.tag == "span"):
            return parent
        parent = parents.get(id(parent))
    return None


def _hub_review(article, reviewer_name=None):
    result = {"robot": None, "specialist": None, "warnings": []}
    for kind in ("robot", "specialist"):
        scope = _review_scope(article, kind)
        if scope is None:
            continue
        nodes = list(scope.walk(include_controls=True))
        verdict_labels = list(dict.fromkeys(node.text() for node in nodes if not node.control and
                             node.tag == "span" and _key(node.text()) in REVIEW_VERDICTS))
        pressed = [node for node in nodes if node.tag == "button" and node.attrs.get("aria-pressed") == "true"]
        if kind == "specialist" and pressed:
            selected = [node.text() for node in pressed if _key(node.text()) in REVIEW_VERDICTS]
            verdict_labels = list(dict.fromkeys([*verdict_labels, *selected]))
        verdict = REVIEW_VERDICTS.get(_key(verdict_labels[0])) if len(verdict_labels) == 1 else None
        if len(verdict_labels) > 1:
            result["warnings"].append("Parecer do Hub com estados divergentes; confirmar na página de origem.")
        assessed = scope.attrs.get("data-pronix-assessed-at")
        if not assessed:
            match = re.search(r"\b\d{2}/\d{2}/\d{4},?\s+\d{2}:\d{2}\b", scope.text())
            assessed = match.group() if match else None
        paragraphs = [node.text() for node in nodes if node.tag in ("p", "li") and not node.control]
        review = {"verdict": verdict, "verdictLabel": verdict_labels[0] if len(verdict_labels) == 1 else None,
                  "assessedAtText": assessed, "text": "\n".join(paragraphs)}
        if kind == "robot":
            metrics, pending = [], None
            for node in nodes:
                if node.tag == "dt":
                    pending = node.text().rstrip(": ")
                elif node.tag == "dd" and pending:
                    metrics.append({"label": pending, "text": node.text(), "value": None, "unit": None})
                    pending = None
            margin = re.search(r"margem estimada\s+([+-]?[\d.,]+\s*%)", scope.text(), re.I)
            if margin:
                metrics.insert(0, {"label": "Margem estimada", "text": margin.group(1),
                                   "value": _number(margin.group(1), percent=True), "unit": "percent"})
            review["metrics"] = metrics
        else:
            textareas = [node for node in nodes if node.tag == "textarea"]
            captured = [node for node in nodes if node.attrs.get("data-pronix-review-text") == "specialist"]
            if len(textareas) == 1:
                review["text"] = textareas[0].raw_text()
            elif len(captured) == 1:
                review["text"] = captured[0].raw_text()
            elif len(textareas) > 1:
                review["text"] = ""
                result["warnings"].append("Mais de um campo de parecer no mesmo produto; texto não selecionado automaticamente.")
            review["reviewerName"] = reviewer_name
        result[kind] = review
    return normalize_hub_review(result)


def render_source_text(clientName, products, metadata=None) -> str:
    """Render current references and original commercial fields as inert data.

    Call again after the user corrects a reference. Original links are retained
    in the structured source, but excluded here to avoid stale mandatory IDs.
    """
    metadata = metadata or {}
    meta_fields = {label: _value(metadata.get("fields", {}).get(label)) for label in META_FIELDS
                   if label in metadata.get("fields", {})}
    parts = ["DADOS COMERCIAIS INFORMADOS NO PRONIX HUB (SEM PRÉ-ANÁLISES)",
             json.dumps({"cliente": _clean(clientName), "metadadosInformados": meta_fields},
                        ensure_ascii=False, indent=2)]
    for index, product in enumerate(products, 1):
        fields = {label: _value(product.get("fields", {}).get(label)) for label in PRODUCT_FIELDS
                  if label in product.get("fields", {})}
        reference = _clean(product.get("reference"))
        # A reviewed reference can be a bare MLB code; never turn it into a URL
        # or discard it merely because the original source was an HTML anchor.
        if not re.fullmatch(r"MLBU?[- ]?\d{5,16}", reference, re.I):
            reference = _safe_url(reference)
        data = {"produto": index, "nome": _clean(product.get("name")),
                "referencia": reference, "camposInformados": fields}
        parts.append(json.dumps(data, ensure_ascii=False, indent=2))
    return "\n\n".join(parts)


def extract_product_html(path) -> dict:
    """Extract the original product table from a locally saved Pronix Hub HTML."""
    html, warnings = _read_html(path)
    parser = _Parser()
    parser.feed(html)
    parser.close()
    client, metadata = _metadata(parser.root)
    captured_main = next((node for node in parser.root.walk() if node.tag == "main" and node.attrs.get("data-pronix-captured-at")), None)
    review_provenance = {"source": "Pronix Hub", "method": "rendered_dom" if captured_main else "saved_html",
                         "url": captured_main.attrs.get("data-pronix-source-url") if captured_main else None,
                         "capturedAt": captured_main.attrs.get("data-pronix-captured-at") if captured_main else None}
    reviewer_name = None
    for node in parser.root.walk():
        if node.tag == "header":
            for paragraph in node.walk():
                if paragraph.tag == "p" and (match := re.search(r"\brevisor:\s*(.+)$", paragraph.text(), re.I)):
                    reviewer_name = match.group(1)[:180]
    products, links, ignored_articles, previous_analysis = [], [], 0, False
    for article in (node for node in parser.root.walk() if node.tag == "article"):
        nodes = list(article.walk())
        heading = next((node for node in nodes if node.tag == "h3"), None)
        dl = next((node for node in nodes if node.tag == "dl"), None)
        fields, duplicates = _fields(dl) if dl else ({}, [])
        if heading is None or not fields:
            ignored_articles += 1
            continue
        if len(products) >= MAX_PRODUCTS:
            raise ValueError("O HTML contém mais de 500 produtos. Divida a tabela antes de importar.")
        index = len(products) + 1
        if duplicates:
            raise ValueError(f"Produto {index}: campo comercial repetido no primeiro bloco. Revise o HTML.")
        # Only the reference in the product heading, before its first data list.
        before_fields = nodes[:nodes.index(dl)]
        anchors = [node for node in before_fields if node.tag == "a" and node.attrs.get("href")]
        labelled = [node for node in anchors if "referencia" in _key(node.text())]
        chosen = labelled or anchors
        raw_links = list(dict.fromkeys(_clean(node.attrs["href"]) for node in chosen))
        reference = _safe_url(raw_links[0]) if raw_links else ""
        spec = reference_spec(reference)
        error = spec.get("error")
        if len(raw_links) > 1:
            error = "Há mais de um link de referência no cabeçalho. Confirme o anúncio deste produto."
        elif not reference:
            error = "O produto não contém um link HTTP(S) de referência. Informe o anúncio do Mercado Livre."
        status = "ready" if spec.get("valid") and not error else "needs_review"
        # Link corrigido na extensão antes do envio: o original do Hub fica guardado para conferência.
        hub_href = next((_clean(node.attrs.get("data-pronix-hub-href") or "") for node in chosen if node.attrs.get("data-pronix-hub-href")), "")
        product = {"index": index, "name": heading.text(), "reference": reference,
                   "originalReference": _safe_url(hub_href) or hub_href[:2048] if hub_href and len(raw_links) == 1 else reference, "fields": fields,
                   "cost": _number(fields.get("Custo de compra")),
                   "salePrice": _number(fields.get("Preço de venda")),
                   "referenceStatus": status, "referenceId": spec.get("id"), "referenceError": error}
        review = _hub_review(article, reviewer_name)
        if review:
            review["provenance"] = review_provenance.copy()
            product["hubReview"] = normalize_hub_review(review)
        products.append(product)
        if reference:
            links.append(reference)
        if error:
            warnings.append(f"Produto {index}: {error}")
        if not product["name"]:
            warnings.append(f"Produto {index}: nome não informado no HTML.")
        for label, key in (("Custo de compra", "cost"), ("Preço de venda", "salePrice")):
            if fields.get(label) is not None and product[key] is None:
                warnings.append(f"Produto {index}: {label.lower()} não pôde ser convertido; valor original preservado.")
        previous_analysis = previous_analysis or sum(node.tag == "dl" for node in nodes) > 1
    if not products:
        raise ValueError("Nenhum produto da tabela Pronix Hub foi encontrado. O arquivo pode ser uma tela de login "
                         "ou a estrutura vazia do site. Abra a tabela completa e salve a página com os produtos visíveis.")
    if not client:
        warnings.append("Nome do cliente não encontrado no cabeçalho. Informe-o antes de criar o relatório.")
    if metadata["fields"].get("Imposto") is not None and metadata["taxPercent"] is None:
        warnings.append("Imposto informado não pôde ser convertido; texto original preservado, sem assumir zero.")
    if ignored_articles:
        warnings.append(f"{ignored_articles} bloco(s) sem a estrutura comercial de produto foram ignorados.")
    if previous_analysis:
        warnings.append("Pré-análises automáticas e pareceres anteriores foram preservados separadamente para comparação, quando identificados; não são dados de mercado atualizados.")
    warnings.append("Os valores importados são informações fornecidas na página. Os links ainda exigem consulta atual "
                    "para validar o anúncio, suas variações e os dados de mercado.")
    return {"kind": "html", "text": render_source_text(client, products, metadata), "clientName": client, "reviewerName": reviewer_name,
            "products": products, "metadata": metadata, "links": links, "warnings": warnings,
            "sourceType": "pronix-hub-html"}
