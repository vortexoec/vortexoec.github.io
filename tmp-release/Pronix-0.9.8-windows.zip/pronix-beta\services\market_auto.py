"""Parecer automático e mensagem ao cliente (sem IA, sem confirmação manual).

Usado quando a análise está no modo automático (importação pelo Hub). Usa só o
que a coleta trouxe: anúncio de referência, anúncios parecidos da JoomPulse
(preço e média mensal de vendas), comissão e frete do Mercado Livre e os
custos informados. Os limites são configuráveis em Preferências; não existe
margem universal — os valores padrão são só ponto de partida.

Quando a coleta traz a amostra do nicho (market_niche), procura e preço são medidos nela, do jeito
que os especialistas escrevem o parecer: faturamento dos maiores anúncios, média dos três menores
preços e preço médio. Os limites padrão saíram da auditoria de 14–15/11/2026 com planilhas já
validadas (32 produtos): margem mínima de 15%, preço até 40% acima do preço médio e nicho faturando
ao menos R$ 5.000 por mês foram a combinação que mais se aproximou dos especialistas.
"""
from __future__ import annotations

import math
import statistics

DEFAULTS = {"autoMinMarginPercent": 15.0, "autoMaxPremiumPercent": 40.0, "autoMinMonthlyUnits": 30.0,
            "autoMinNicheRevenue": 5000.0, "autoMinLotUnits": 10.0}
# Quantidade inicial: o primeiro pedido cobre a metade do que um anúncio típico do nicho vende em um
# mês (um anúncio novo começa sem reputação e vende menos), nunca abaixo do pedido mínimo da equipe.
ENTRY_SHARE = 0.5
LABELS = {"validado": "Validado", "atencao": "Atenção", "invalidado": "Invalidado"}
LIMIT = 1000


def _num(value):
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) else None


def _money(value):
    return "R$ " + f"{value:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")


def _pct(value):
    text = f"{value:.1f}".replace(".", ",")
    return (text[:-2] if text.endswith(",0") else text) + "%"


def _units(value):
    return f"{round(value):,}".replace(",", ".")


def monthly_units(row):
    month = (((row or {}).get("historicalAverages") or {}).get("item") or {}).get("month") or {}
    return _num(month.get("units"))


def similar_listings(entry):
    """Anúncios parecidos ativos, sem o próprio anúncio de referência e sem os excluídos pelo especialista."""
    evidence = entry.get("evidence") or {}
    reference = evidence.get("reference") or {}
    ref_id = reference.get("itemId") or reference.get("id")
    decisions = ((entry.get("review") or {}).get("competitors") or {})
    rows = []
    for row in (evidence.get("candidates") or []) + (evidence.get("competitors") or []):
        rid = str(row.get("itemId") or row.get("id") or "")
        decision = decisions.get(rid) or {}
        if (not rid or rid == ref_id or row.get("isReference") or row.get("active") is False
                or decision.get("exclude") is True or decision.get("exactMatchConfirmed") is False):
            continue
        price = _num(row.get("price"))
        if price and price > 0 and rid not in {r["id"] for r in rows}:
            rows.append({"id": rid, "title": row.get("title"), "price": price, "units": monthly_units(row),
                         "sameCatalog": bool(row.get("catalogId") and row.get("catalogId") == reference.get("catalogId"))})
    return rows[:10]


def _costs(entry, context):
    inputs, fees = entry.get("inputs") or {}, entry.get("fees") or {}
    auto = (entry.get("evidence") or {}).get("autoFees") or {}
    price, cost = _num(inputs.get("salePrice")), _num(inputs.get("cost"))
    tax = _num(context.get("taxPercent"))
    same_price = price is not None and _num(auto.get("quotedPrice")) == price
    pick = lambda key: _num(fees.get(key)) if _num(fees.get(key)) is not None else (_num(auto.get(key)) if same_price else None)
    return {"price": price, "cost": cost, "tax": tax, "commission": pick("commissionPercent"), "fixed": pick("fixedFee"),
            "shipping": pick("shipping"), "others": _num(fees.get("otherCosts")), "listing": auto.get("listingType"),
            # Frete calculado com pacote estimado pelo anúncio (e não informado pelo especialista ou pelo Hub).
            "shippingEstimated": _num(fees.get("shipping")) is None and same_price and auto.get("packageEstimated") is True}


def typical_monthly_units(niche, similar):
    """Vendas por mês do anúncio típico (mediana de quem vende) no nicho ou, sem nicho, nos parecidos."""
    typical = _num((niche or {}).get("unitsTypical"))
    if typical:
        return typical
    sold = [u for u in (_num(row.get("units")) for row in (niche or {}).get("rows") or []) if u and u > 0]
    if not sold:
        sold = [row["units"] for row in similar or [] if row.get("units") and row["units"] > 0]
    return float(statistics.median(sold)) if sold else None


def initial_lot(typical, cost, minimum):
    """Quantidade inicial que limita o risco: metade de um mês de vendas do anúncio típico, no mínimo `minimum`."""
    minimum = max(1, math.ceil(minimum or 1))
    computed = math.ceil(typical * ENTRY_SHARE) if typical else None
    units = max(minimum, computed or 0)
    return {"units": units, "computed": computed, "typicalMonthlyUnits": typical, "minimum": minimum,
            "capital": round(units * cost, 2) if cost else None,
            "basis": "demand" if computed and computed >= minimum else "minimum_over_demand" if computed else "minimum_without_data"}


def lot_text(lot):
    capital = f" (cerca de {_money(lot['capital'])} em mercadoria)" if lot.get("capital") else ""
    head = f"Quantidade inicial sugerida: {lot['units']} unidades{capital}"
    typical = lot.get("typicalMonthlyUnits")
    if lot["basis"] == "demand":
        return (head + f". Um anúncio típico desse nicho vende cerca de {_units(typical)} por mês; começar com a metade disso"
                " limita o risco enquanto o anúncio novo ganha reputação, e o estoque é reposto conforme as vendas.")
    if lot["basis"] == "minimum_over_demand":
        return (head + f", o pedido mínimo. Um anúncio típico desse nicho vende cerca de {_units(typical)} por mês,"
                " então um lote maior ficaria parado mais tempo.")
    return head + ", o pedido mínimo: sem o dado de vendas por anúncio do nicho não dá para calcular um lote maior com segurança."


def reference_issue(entry):
    """Problema com o link do anúncio de referência, para avisar e pedir o link certo (fora do texto do cliente)."""
    evidence = entry.get("evidence") or {}
    if "referenceIssue" in evidence:            # coletas a partir da 0.9.8 dizem o motivo (None = link certo)
        issue = evidence["referenceIssue"]
        return issue if isinstance(issue, dict) and issue.get("kind") else None
    if not evidence or evidence.get("status") == "collected":
        return None
    notes = " ".join(str(note) for note in evidence.get("limitations") or [])
    if "cota ou o orçamento de consultas" in notes:
        return None
    # Análises anteriores à 0.9.8 não guardam o motivo: deduz pelas notas da coleta.
    if "Produto não localizado" in notes:
        return {"kind": "not_found", "message": NOT_FOUND}
    source = entry.get("source") or {}
    if source.get("referenceStatus") == "needs_review" or source.get("referenceError"):
        return {"kind": "invalid", "message": str(source.get("referenceError") or "O link do anúncio precisa de revisão.")}
    return None


NOT_FOUND = ("A JoomPulse não tem um anúncio ativo com o código deste link: o anúncio pode estar pausado, ser muito novo "
             "ou o link pode ser de outro anúncio. Confira o link; se estiver certo, a análise usa anúncios do mesmo tipo de produto.")


def required_price(c, margin):
    rate = ((c["commission"] or 0) + (c["tax"] or 0) + margin) / 100
    fixed = (c["cost"] or 0) + (c["fixed"] or 0) + (c["shipping"] or 0) + (c["others"] or 0)
    return fixed / (1 - rate) if rate < 1 else None


def verdict(entry, context, policy=None):
    policy = {**DEFAULTS, **{k: v for k, v in (policy or {}).items() if k in DEFAULTS and _num(v) is not None}}
    c = _costs(entry, context)
    reference = (entry.get("evidence") or {}).get("reference") or {}
    similar = similar_listings(entry)
    prices = [r["price"] for r in similar]
    niche = (entry.get("evidence") or {}).get("niche") or {}
    niche = niche if _num(niche.get("priceAverage")) else {}          # sem preço médio não há amostra utilizável
    niche_revenue, niche_low = _num(niche.get("revenueTop")), _num(niche.get("priceLow3"))
    average = _num(niche.get("priceAverage")) if niche else (statistics.median(prices) if prices else None)
    units = [r["units"] for r in similar if r["units"] is not None]
    market_units = sum(units) if units else None
    ref_units = monthly_units(reference)
    # Procura do nicho: os parecidos mais o próprio anúncio de referência. Zero em todos = a fonte não tem o dado.
    niche_units = (market_units or 0) + (ref_units or 0) if (market_units is not None or ref_units is not None) else None
    demand_unknown = bool(similar) and not niche_units
    reasons, gaps = [], []
    limitations = " ".join(str(note) for note in ((entry.get("evidence") or {}).get("limitations") or []))
    if "cota ou o orçamento de consultas" in limitations and not similar and not niche:
        # A pesquisa deste produto não aconteceu: não existe parecer para sugerir ainda.
        return {"status": "atencao", "label": LABELS["atencao"], "basis": "automatic", "incomplete": "quota",
                "reasons": ["Análise incompleta: o limite de consultas da JoomPulse acabou antes deste produto."],
                "message": "Análise incompleta: o limite de consultas por hora da JoomPulse acabou antes deste produto. "
                           "O programa continua a pesquisa sozinho na próxima hora; para adiantar, clique em Consultar mercado."}
    if c["price"] is None or c["cost"] is None:
        return {"status": "atencao", "label": LABELS["atencao"], "reasons": ["Faltam custo ou preço de venda."], "message":
                "Atenção: para avaliar este produto precisamos do custo de compra e do preço de venda pretendido.", "basis": "automatic",
                "referenceIssue": reference_issue(entry)}
    commission_amount = c["price"] * c["commission"] / 100 if c["commission"] is not None else None
    tax_amount = c["price"] * c["tax"] / 100 if c["tax"] is not None else 0.0
    known = c["cost"] + (commission_amount or 0) + (c["fixed"] or 0) + (c["shipping"] or 0) + tax_amount + (c["others"] or 0)
    balance = c["price"] - known
    margin = balance / c["price"] * 100 if c["price"] else None
    if c["commission"] is None: gaps.append("comissão do Mercado Livre")
    if c["shipping"] is None: gaps.append("frete")
    premium = (c["price"] / average - 1) * 100 if average else None
    premium_low = (c["price"] / niche_low - 1) * 100 if niche_low else None

    if balance <= 0:
        status = "invalidado"; reasons.append("O preço não cobre custo, taxas e frete.")
    else:
        status = "validado"
        if gaps:
            status = "atencao"; reasons.append(("Falta o " if gaps == ["frete"] else "Faltam ") + " e ".join(gaps) + " para fechar a conta.")
        if margin is not None and margin < policy["autoMinMarginPercent"]:
            status = "atencao"; reasons.append(f"Margem de {_pct(margin)} abaixo do mínimo de {_pct(policy['autoMinMarginPercent'])}.")
        if premium is not None and premium > policy["autoMaxPremiumPercent"]:
            status = "atencao"; reasons.append(f"Preço {_pct(premium)} acima " + ("do preço médio do nicho." if niche else "da média dos anúncios parecidos."))
        if niche:
            if niche_revenue is None:
                status = "atencao"; reasons.append("Sem estimativa de vendas do nicho para medir a procura.")
            elif niche_revenue == 0:
                status = "atencao"; reasons.append("Nenhum anúncio do nicho com venda estimada no último mês.")
            elif niche_revenue < policy["autoMinNicheRevenue"]:
                status = "atencao"; reasons.append(f"Procura baixa: os maiores anúncios do nicho faturam juntos cerca de {_money(niche_revenue)} por mês.")
        elif not similar:
            status = "atencao"; reasons.append("Sem anúncios parecidos para comparar preço e procura.")
        elif demand_unknown:
            status = "atencao"; reasons.append("Sem dado de vendas dos anúncios parecidos para medir a procura.")
        elif niche_units is not None and niche_units < policy["autoMinMonthlyUnits"]:
            status = "atencao"; reasons.append("Procura baixa nos anúncios parecidos.")

    parts = []
    opening = {"validado": "Validado: os números fecham para este produto.",
               "atencao": "Atenção: o produto pode funcionar, mas pede alguns cuidados.",
               "invalidado": "Invalidado: neste preço o produto não se paga."}[status]
    parts.append(opening)
    # O aviso de link não localizado fica fora deste texto (vai ao cliente): aparece no programa e na extensão.
    if niche:
        count = int(niche.get("topCount") or 0)
        if niche_revenue:
            parts.append(f"Os {count} maiores anúncios desse nicho faturam juntos cerca de {_money(niche_revenue)} por mês"
                         + (", um volume baixo para dividir com um vendedor novo." if niche_revenue < policy["autoMinNicheRevenue"] else ", um volume que comporta a sua entrada."))
        elif niche_revenue == 0:
            parts.append(f"Encontramos {int(niche.get('sampleSize') or 0)} anúncios desse nicho, mas nenhum com venda estimada no último mês.")
        else:
            parts.append("Não há estimativa de vendas desse nicho, então a procura não pôde ser medida.")
        position = lambda value: "no mesmo nível" if abs(value) < 1 else f"{_pct(abs(value))} {'acima' if value > 0 else 'abaixo'}"
        line = f"Seu preço de {_money(c['price'])} está "
        if premium_low is not None:
            line += f"{position(premium_low)} da média dos três mais baratos ({_money(niche_low)}) e "
        parts.append(line + f"{position(premium)} do preço médio do nicho ({_money(average)}).")
    elif similar:
        line = f"Encontramos {len(similar)} anúncio{'s' if len(similar) > 1 else ''} parecido{'s' if len(similar) > 1 else ''} no Mercado Livre, com preço típico (mediana) de {_money(average)}"
        if premium is not None:
            line += f" (o seu: {_money(c['price'])}, {_pct(abs(premium))} {'acima' if premium > 0 else 'abaixo'})" if abs(premium) >= 1 else f" (o seu: {_money(c['price'])}, na média)"
        if niche_units:
            line += f", e o nicho (esses anúncios mais o de referência) vende cerca de {_units(niche_units)} unidades por mês"
        parts.append(line + ".")
        if demand_unknown:
            parts.append("Não há dado de vendas desses anúncios, então a procura não pôde ser medida.")
    else:
        parts.append("Não encontramos anúncios parecidos suficientes para comparar preço e procura.")
    fee_bits = []
    if c["commission"] is not None:
        kind = {"premium": "Premium", "classic": "Clássico"}.get(c["listing"], "")
        fee_bits.append(f"a comissão {kind + ' ' if kind else ''}é de {_pct(c['commission'])} ({_money(commission_amount)})".replace("  ", " "))
    if c["fixed"]:
        fee_bits.append(f"a tarifa fixa é de {_money(c['fixed'])}")
    if c["shipping"] is not None:
        fee_bits.append(f"o frete{' estimado' if c.get('shippingEstimated') else ''} fica em torno de {_money(c['shipping'])} por unidade")
    if fee_bits:
        parts.append("No Mercado Livre, " + ", ".join(fee_bits) + ".")
    # O que ainda não entrou na conta: a sobra é maior do que a real enquanto faltar comissão ou frete.
    # Só fala do que foi analisado: embalagem e demais gastos o cliente controla por conta própria.
    missing = [label for label, gap in (("a comissão", c["commission"] is None), ("o frete", c["shipping"] is None)) if gap]
    tail = ", sem contar " + " e ".join(missing) if missing else ", já com os custos informados" if c["others"] is not None else ""
    if balance > 0:
        parts.append(f"Com custo de {_money(c['cost'])}{' e imposto de ' + _pct(c['tax']) if c['tax'] else ''}, sobram cerca de {_money(balance)} por unidade ({_pct(margin)} do preço){tail}.")
    else:
        parts.append(f"Com custo de {_money(c['cost'])}{' e imposto de ' + _pct(c['tax']) if c['tax'] else ''}, faltam cerca de {_money(-balance)} por unidade para cobrir os gastos.")
    if missing:
        names = " e ".join(missing).replace("a comissão", "a comissão do Mercado Livre", 1)
        parts.append(names[0].upper() + names[1:] + (" ainda não entraram" if len(missing) > 1 else " ainda não entrou")
                     + " na conta; com " + ("eles" if len(missing) > 1 else "ela" if missing == ["a comissão"] else "ele") + ", a sobra por unidade fica menor.")
    target = required_price(c, policy["autoMinMarginPercent"])
    lot = initial_lot(typical_monthly_units(niche, similar), c["cost"], policy["autoMinLotUnits"]) if status != "invalidado" else None
    if status == "invalidado":
        parts.append("Sugestão: negocie o custo com o fornecedor ou avalie outro produto; subir o preço tende a afastar o comprador." if average and target and target > average * 1.1
                     else f"Sugestão: para fechar a conta, o preço precisaria ficar perto de {_money(target)}, ou o custo precisaria cair." if target else "Sugestão: reveja custo e preço antes de comprar.")
    elif status == "atencao":
        if margin is not None and margin < policy["autoMinMarginPercent"] and target:
            parts.append(f"Sugestão: para uma margem de {_pct(policy['autoMinMarginPercent'])}, o preço ficaria perto de {_money(target)}{', acima da média dos concorrentes' if average and target > average else ''}; negociar o custo também ajuda.")
        elif premium is not None and premium > policy["autoMaxPremiumPercent"]:
            parts.append(f"Sugestão: para competir, considere um preço mais perto de {_money(average)}.")
        elif premium is not None and premium < -15:
            parts.append(f"Sugestão: seu preço está bem abaixo dos parecidos; há espaço para testar algo mais perto de {_money(average)}.")
    elif premium is not None and premium < -15:
        parts.append(f"Sugestão: há espaço para testar um preço mais perto de {_money(average)}.")
    # A quantidade inicial sempre entra: o espaço dela é reservado antes das outras frases.
    closing = lot_text(lot) if lot else ""
    message = ""
    for part in parts:
        candidate = (message + " " + part).strip()
        if len(candidate) <= LIMIT - (len(closing) + 1 if closing else 0):
            message = candidate
    message = (message + " " + closing).strip()
    return {"status": status, "label": LABELS[status], "reasons": reasons, "message": message, "basis": "automatic",
            "initialLot": lot, "referenceIssue": reference_issue(entry),
            "data": {"balance": round(balance, 2), "marginPercent": round(margin, 2) if margin is not None else None,
                     "similarCount": len(similar), "similarAveragePrice": round(average, 2) if average else None,
                     "similarMonthlyUnits": market_units, "referenceMonthlyUnits": ref_units, "nicheMonthlyUnits": niche_units,
                     "commissionPercent": c["commission"], "shipping": c["shipping"], "requiredPrice": round(target, 2) if target else None,
                     "nicheRevenueTop": niche_revenue, "nicheSampleSize": niche.get("sampleSize"), "nichePriceAverage": average if niche else None,
                     "nichePriceLow3": niche_low, "premiumOverAveragePercent": round(premium, 1) if premium is not None else None,
                     "premiumOverLow3Percent": round(premium_low, 1) if premium_low is not None else None},
            "similar": similar}
