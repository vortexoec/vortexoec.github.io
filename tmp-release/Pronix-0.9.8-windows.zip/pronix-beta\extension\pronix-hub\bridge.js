import {applyCorrections, reviewLinks} from "./links.js";

export const BRIDGE_URL = "ws://127.0.0.1:8766/";
export const VERSION = "0.8.2";
// Programas anteriores à 0.9.7 só aceitam versões que já conhecem. Recusada, a extensão se apresenta
// como a 0.8.0 (mesmo protocolo) para continuar funcionando até o programa ser atualizado.
export const COMPAT_VERSION = "0.8.0";
export const APP_TABS = ["http://localhost:8765/*", "http://127.0.0.1:8765/*"];
export const LAUNCH_URL = "central-analises://abrir";
export const OAUTH_KEY = "pronixOAuthWatch";
const OAUTH_PREFIX = "https://auth.mercadolivre.com.br/authorization?";
export const ALARM = "pronix-local-reconnect";
export const TOKEN_KEY = "pronixLocalToken";
export const MAX_HTML_BYTES = 2 * 1024 * 1024;

export function isHubUrl(value) {
  return typeof value === "string" && /^https:\/\/pronixhub\.com\.br\/validacao-planilhas\/[A-Za-z0-9_-]{1,128}\/?$/.test(value);
}

export function createBridge({chrome, WebSocketClass = WebSocket, capturePage, readClientName,
                              setTimeoutFn = setTimeout, clearTimeoutFn = clearTimeout,
                              setIntervalFn = setInterval, clearIntervalFn = clearInterval}) {
  let socket = null, pairingSocket = null, heartbeat = null, helloTimer = null;
  let token = null, generation = 0, initializing = null, requestBusy = false, helloVersion = VERSION;
  let state = {paired: false, connected: false, connecting: false, error: "", lastCaptureAt: null};
  const seen = new Set();
  const extPending = new Map();
  const publicState = () => ({...state, version: VERSION});
  const stopTimers = () => {
    if (heartbeat !== null) clearIntervalFn(heartbeat);
    if (helloTimer !== null) clearTimeoutFn(helloTimer);
    heartbeat = helloTimer = null;
  };
  const close = () => {
    stopTimers();
    const previous = socket;
    socket = null;
    state.connected = state.connecting = false;
    if (previous) previous.close();
  };
  const arm = async () => chrome.alarms.create(ALARM, {periodInMinutes: 0.5});
  const sameTab = (tab, expected) => tab && isHubUrl(tab.url) && tab.url === expected && (!tab.pendingUrl || tab.pendingUrl === expected);

  async function listTabs() {
    const candidates = await chrome.tabs.query({url: "https://pronixhub.com.br/validacao-planilhas/*"});
    const tabs = [];
    for (const tab of candidates.slice(0, 100)) {
      if (!Number.isInteger(tab.id) || !sameTab(tab, tab.url)) continue;
      let name = "";
      try {
        const read = await chrome.scripting.executeScript({target: {tabId: tab.id, frameIds: [0]}, world: "ISOLATED", func: readClientName, args: [tab.url]});
        if (read[0]?.result?.url === tab.url) name = read[0].result.name;
      } catch { /* A restricted or loading tab may still have a safe tab title. */ }
      try {
        if (!sameTab(await chrome.tabs.get(tab.id), tab.url)) continue;
      } catch { continue; }
      tabs.push({id: tab.id, title: String(name || tab.title || "Cliente do Hub").slice(0, 240), url: tab.url, active: tab.active === true});
    }
    return {tabs};
  }

  async function capture(message) {
    if (!Number.isInteger(message.tabId) || message.tabId < 0 || !isHubUrl(message.expectedUrl)) {
      throw new Error("Selecione uma aba válida no aplicativo antes de importar.");
    }
    const before = await chrome.tabs.get(message.tabId);
    if (!sameTab(before, message.expectedUrl)) throw new Error("A aba mudou. Atualize a lista no aplicativo.");
    const results = await chrome.scripting.executeScript({target: {tabId: message.tabId, frameIds: [0]}, world: "ISOLATED", func: capturePage, args: [message.expectedUrl, MAX_HTML_BYTES]});
    const data = results[0]?.result;
    const after = await chrome.tabs.get(message.tabId);
    if (!sameTab(after, message.expectedUrl) || data?.url !== message.expectedUrl) throw new Error("A aba mudou durante a captura. Atualize a lista no aplicativo.");
    if (typeof data.html !== "string" || !data.html || new TextEncoder().encode(data.html).byteLength > MAX_HTML_BYTES) {
      throw new Error("A captura está vazia ou ultrapassa o limite de 2 MB.");
    }
    if (typeof data.title !== "string" || !data.title.trim() || typeof data.capturedAt !== "string" || !Number.isFinite(Date.parse(data.capturedAt))) {
      throw new Error("A página não retornou uma captura válida. Aguarde o carregamento e tente novamente.");
    }
    state.lastCaptureAt = data.capturedAt;
    return {url: data.url, title: data.title, html: data.html, capturedAt: data.capturedAt};
  }

  async function oauthOpen(message) {
    const {authUrl, returnPrefix, state: oauthState} = message;
    if (typeof authUrl !== "string" || !authUrl.startsWith(OAUTH_PREFIX) || authUrl.length > 4096
        || typeof returnPrefix !== "string" || !returnPrefix.startsWith("https://") || returnPrefix.length > 2048
        || typeof oauthState !== "string" || !/^[A-Za-z0-9_-]{16,128}$/.test(oauthState)) {
      throw new Error("Pedido de conexão inválido.");
    }
    const tab = await chrome.tabs.create({url: authUrl, active: true});
    await chrome.storage.session.set({[OAUTH_KEY]: {tabId: tab.id, returnPrefix, state: oauthState, expires: Date.now() + 10 * 60 * 1000}});
    return {opened: true};
  }

  // Called for every URL change; acts only on the login tab this extension opened.
  async function oauthTabUpdated(tabId, url) {
    if (typeof url !== "string") return;
    const watch = (await chrome.storage.session.get(OAUTH_KEY))[OAUTH_KEY];
    if (!watch || watch.tabId !== tabId) return;
    if (Date.now() > watch.expires) { await chrome.storage.session.remove(OAUTH_KEY); return; }
    if (!url.startsWith(watch.returnPrefix)) return;
    let params;
    try { params = new URL(url).searchParams; } catch { return; }
    if (params.get("state") !== watch.state || !(params.get("code") || params.get("error"))) return;
    await chrome.storage.session.remove(OAUTH_KEY);
    if (!state.connected) await connect();
    for (let i = 0; i < 40 && !state.connected; i++) await new Promise(resolve => setTimeoutFn(resolve, 200));
    if (socket && state.connected && socket.readyState === 1) socket.send(JSON.stringify({type: "oauth_return", url}));
    try { await chrome.tabs.remove(tabId); } catch { /* already closed */ }
    try {
      const [app] = await chrome.tabs.query({url: ["http://localhost:8765/*", "http://127.0.0.1:8765/*"]});
      if (app?.id) { await chrome.tabs.update(app.id, {active: true}); if (app.windowId) await chrome.windows.update(app.windowId, {focused: true}); }
    } catch { /* focusing the app is optional */ }
  }

  async function waitConnected() {
    if (!token) throw new Error("Abra a Central de Análises neste computador: a extensão se conecta sozinha.");
    if (!state.connected) await connect();
    for (let i = 0; i < 50 && !state.connected; i++) await new Promise(resolve => setTimeoutFn(resolve, 200));
    if (!state.connected || !socket || socket.readyState !== 1) throw new Error("A Central de Análises não está aberta neste computador. Abra o programa e tente de novo.");
  }

  // Requests started by the user on the Pronix Hub page (import button, suggestions).
  async function extRequest(action, payload, timeoutMs = 120000) {
    await waitConnected();
    const id = crypto.randomUUID().replace(/-/g, "");
    return new Promise((resolve, reject) => {
      const timer = setTimeoutFn(() => { extPending.delete(id); reject(new Error("A Central demorou para responder.")); }, timeoutMs);
      extPending.set(id, {resolve, reject, timer});
      socket.send(JSON.stringify({type: "ext_request", id, action, payload}));
    });
  }

  // "Abrir a Central" (janela da extensão e painel do Hub). Nunca abre a Central como aba comum:
  // 1) se ela já está aberta, traz a janela para a frente; 2) com o programa no ar, pede a ele a
  // janela própria; 3) com o programa fechado, pede ao Windows para abri-lo (link central-analises://)
  // na aba em que a pessoa está, sem criar outra.
  async function openApp(fromTabId = null) {
    const tabs = await chrome.tabs.query({url: APP_TABS});
    if (tabs.length) {
      await chrome.tabs.update(tabs[0].id, {active: true});
      if (tabs[0].windowId !== undefined) await chrome.windows.update(tabs[0].windowId, {focused: true});
      return {how: "focused"};
    }
    if (state.connected && !state.compat && socket?.readyState === 1) {
      try { await extRequest("open_app", {}, 6000); return {how: "window"}; } catch { /* segue pelo link do Windows */ }
    }
    let tabId = fromTabId;
    if (!Number.isInteger(tabId)) tabId = (await chrome.tabs.query({active: true, lastFocusedWindow: true}))[0]?.id;
    try {
      if (!Number.isInteger(tabId)) throw new Error("sem aba");
      await chrome.tabs.update(tabId, {url: LAUNCH_URL});
    } catch { await chrome.tabs.create({url: LAUNCH_URL}); }
    return {how: "launch"};
  }

  async function captureTab(tabId, url, onLoaded = () => {}) {
    let loaded = false;
    for (let attempt = 0; attempt < 25; attempt++) {
      try {
        const results = await chrome.scripting.executeScript({target: {tabId, frameIds: [0]}, world: "ISOLATED", func: capturePage, args: [url, MAX_HTML_BYTES]});
        const data = results[0]?.result;
        if (data?.url === url && !loaded) { loaded = true; onLoaded(); }
        if (data?.url === url && typeof data.html === "string" && data.html.includes("<article")) return data;
      } catch { /* page still loading */ }
      await new Promise(resolve => setTimeoutFn(resolve, 1000));
    }
    throw new Error("A planilha não terminou de carregar. Tente de novo.");
  }

  // Import a sheet: the open tab when the user is on it, otherwise a hidden background tab closed afterwards.
  // Antes de enviar, confere os links de referência: com link suspeito, devolve {review} para a pessoa
  // corrigir na página (corrections: {posição: link}) ou mandar assim mesmo (confirmed).
  async function importSheet(url, openTabId = null, onStage = () => {}, {corrections = {}, confirmed = false} = {}) {
    if (!isHubUrl(url)) throw new Error("Planilha do Hub inválida.");
    await waitConnected();
    const stage = name => { try { onStage(name); } catch { /* o aviso na página é opcional */ } };
    let tabId = openTabId, created = false;
    stage("open");
    if (!Number.isInteger(tabId)) { tabId = (await chrome.tabs.create({url, active: false})).id; created = true; }
    try {
      const capture = await captureTab(tabId, url, () => stage("read"));
      state.lastCaptureAt = capture.capturedAt;
      stage("review");
      const html = applyCorrections(capture.html, corrections);
      if (new TextEncoder().encode(html).byteLength > MAX_HTML_BYTES) throw new Error("A tabela ultrapassa o limite de 2 MB. Divida os produtos antes de importar.");
      const problems = confirmed ? [] : reviewLinks(html);
      if (problems.length) return {review: {products: problems}};
      stage("send");
      return await extRequest("import_capture", {url, capture: {url: capture.url, title: capture.title, html, capturedAt: capture.capturedAt}});
    } finally {
      if (created) { try { await chrome.tabs.remove(tabId); } catch { /* closed */ } }
    }
  }

  async function oauthTabRemoved(tabId) {
    const watch = (await chrome.storage.session.get(OAUTH_KEY))[OAUTH_KEY];
    if (watch?.tabId === tabId) await chrome.storage.session.remove(OAUTH_KEY);
  }

  async function request(ws, message) {
    if (typeof message.id !== "string" || !message.id || message.id.length > 128) return;
    const reply = value => { if (ws === socket && state.connected && ws.readyState === 1) ws.send(JSON.stringify({type: "response", id: message.id, ...value})); };
    if (seen.has(message.id)) { reply({ok: false, error: "Solicitação repetida. Atualize a operação no aplicativo."}); return; }
    if (requestBusy) { reply({ok: false, error: "Outra consulta ou importação está em andamento. Aguarde e tente novamente."}); return; }
    seen.add(message.id);
    if (seen.size > 200) seen.delete(seen.values().next().value);
    requestBusy = true;
    try {
      let data;
      if (message.action === "list_tabs") data = await listTabs();
      else if (message.action === "capture") data = await capture(message);
      else if (message.action === "oauth_open") data = await oauthOpen(message);
      else throw new Error("Ação não permitida pela extensão.");
      reply({ok: true, data});
    } catch (error) {
      // Only controlled validation errors or short Chrome API errors. Never log
      // page data, pairing codes, tokens or the complete request.
      reply({ok: false, error: String(error?.message || "Não foi possível importar esta aba.").slice(0, 350)});
    } finally { requestBusy = false; }
  }

  async function connect() {
    if (!token || pairingSocket || socket) return publicState();
    const ws = new WebSocketClass(BRIDGE_URL);
    socket = ws;
    const started = generation;
    state.connecting = true;
    state.error = "";
    const fail = message => {
      if (ws !== socket) return;
      state.error = message;
      close();
    };
    helloTimer = setTimeoutFn(() => fail("O programa local não respondeu. Abra a Central de Análises."), 10000);
    ws.onopen = () => {
      if (ws !== socket || started !== generation || !token) return ws.close();
      ws.send(JSON.stringify({type: "hello", token, version: helloVersion}));
    };
    ws.onmessage = event => {
      if (ws !== socket || typeof event.data !== "string" || event.data.length > 262144) return;
      let message;
      try { message = JSON.parse(event.data); } catch { return; }
      if (!message || typeof message !== "object" || Array.isArray(message)) return;
      if (message.type === "hello" && message.ok === true && !state.connected) {
        clearTimeoutFn(helloTimer); helloTimer = null;
        state.connected = true; state.connecting = false; state.error = "";
        state.compat = helloVersion !== VERSION;
        heartbeat = setIntervalFn(() => {
          if (ws === socket && ws.readyState === 1) ws.send(JSON.stringify({type: "ping", at: new Date().toISOString()}));
        }, 20000);
      } else if (message.type === "ext_response" && typeof message.id === "string" && extPending.has(message.id)) {
        const {resolve, reject, timer} = extPending.get(message.id);
        extPending.delete(message.id); clearTimeoutFn(timer);
        if (message.ok === true) resolve(message.data); else reject(new Error(String(message.error || "A Central não concluiu o pedido.").slice(0, 400)));
      } else if (message.type === "request" && state.connected) {
        void request(ws, message);
      } else if (message.type === "error") {
        if (!state.connected && helloVersion === VERSION && COMPAT_VERSION !== VERSION) {
          helloVersion = COMPAT_VERSION; close(); void connect();   // programa antigo: tenta como 0.8.0
        } else {
          helloVersion = VERSION;
          fail("A conexão foi recusada. Confira o pareamento no programa.");
        }
      }
    };
    ws.onerror = () => fail("Programa local indisponível. Abra a Central de Análises neste computador.");
    ws.onclose = event => {
      if (ws !== socket) return;
      stopTimers(); socket = null;
      state.connected = state.connecting = false;
      helloVersion = VERSION;   // na próxima conexão o programa pode já estar atualizado
      state.error = event.code === 1008 ? "Pareamento recusado ou revogado. Gere um novo código no aplicativo." : "Programa local desconectado. A reconexão é automática.";
    };
    return publicState();
  }

  async function init() {
    if (!initializing) initializing = (async () => {
      await chrome.storage.local.setAccessLevel({accessLevel: "TRUSTED_CONTEXTS"});
      const stored = await chrome.storage.local.get(TOKEN_KEY);
      token = typeof stored[TOKEN_KEY] === "string" && stored[TOKEN_KEY].length <= 512 ? stored[TOKEN_KEY] : null;
      state.paired = Boolean(token);
      if (token) { await arm(); await connect(); }
      return publicState();
    })();
    return initializing;
  }

  async function pair(code) {
    await init();
    if (typeof code !== "string" || !/^[A-Za-z0-9 -]{6,128}$/.test(code.trim())) throw new Error("Cole o código de pareamento exibido no programa.");
    if (pairingSocket) throw new Error("O pareamento já está em andamento.");
    if (token) throw new Error("Desconecte esta instalação antes de parear outra.");
    generation++; close();
    const pairingGeneration = generation;
    state.connecting = true; state.error = "";
    const ws = new WebSocketClass(BRIDGE_URL);
    pairingSocket = ws;
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (error, pairedToken) => {
        if (settled) return;
        settled = true; clearTimeoutFn(timer);
        if (pairingSocket === ws) pairingSocket = null;
        ws.close(); state.connecting = false;
        if (error) { state.error = error; reject(new Error(error)); return; }
        void (async () => {
          await chrome.storage.local.set({[TOKEN_KEY]: pairedToken});
          if (generation !== pairingGeneration) {
            await chrome.storage.local.remove(TOKEN_KEY);
            throw new Error("Pareamento cancelado.");
          }
          token = pairedToken; state.paired = true; state.error = "";
          await arm(); await connect(); resolve(publicState());
        })().catch(() => { state.error = "Não foi possível salvar o pareamento. Tente novamente."; reject(new Error(state.error)); });
      };
      const timer = setTimeoutFn(() => finish("O programa local não respondeu. Abra o programa e gere outro código."), 10000);
      ws.onopen = () => ws.send(JSON.stringify({type: "pair", code: code.trim()}));
      ws.onmessage = event => {
        if (typeof event.data !== "string" || event.data.length > 2048) return;
        let message;
        try { message = JSON.parse(event.data); } catch { return; }
        if (message?.type === "paired" && typeof message.token === "string" && /^[A-Za-z0-9_-]{20,512}$/.test(message.token)) finish(null, message.token);
        else if (message?.type === "error") finish("Código inválido ou expirado. Gere outro código no programa.");
      };
      ws.onerror = () => finish("Programa local indisponível. Abra a Central de Análises neste computador.");
      ws.onclose = () => finish("Pareamento não concluído. Gere um novo código no programa.");
    });
  }

  async function disconnect() {
    await init();
    generation++; token = null;
    if (pairingSocket) { const ws = pairingSocket; pairingSocket = null; ws.close(); }
    close(); seen.clear();
    await chrome.storage.local.remove(TOKEN_KEY);
    await chrome.alarms.clear(ALARM);
    state = {paired: false, connected: false, connecting: false, error: "", lastCaptureAt: null};
    return publicState();
  }

  return {init, pair, disconnect, connect, oauthTabUpdated, oauthTabRemoved, importSheet, extRequest, openApp, status: publicState};
}
